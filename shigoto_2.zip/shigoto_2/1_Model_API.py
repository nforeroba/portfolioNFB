# pages/1_Model_API.py
import streamlit as st
import pandas as pd
import numpy as np
import mlflow
from mlflow.tracking import MlflowClient
import json
import logging
from datetime import datetime
import requests

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

MLFLOW_TRACKING_URI = "http://127.0.0.1:8080"

def initialize_mlflow():
    """Inicializar conexión con MLflow"""
    try:
        # Verificar si el servidor está activo
        try:
            response = requests.get(MLFLOW_TRACKING_URI, timeout=2)
            if response.status_code == 200:
                mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
                return True
        except:
            st.error("No se pudo conectar con el servidor MLflow. Por favor, asegúrese de que la aplicación principal está en ejecución.")
            return False
            
        mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
        return True
    except Exception as e:
        logger.error(f"Error iniciando MLflow: {e}")
        st.error(f"Error conectando con MLflow: {str(e)}")
        return False

def get_registered_models(client):
    """Obtener lista de modelos registrados organizados por tipo y modo"""
    try:
        models = client.search_registered_models()
        model_groups = {}
        
        for model in models:
            # Extraer información del nombre
            name_parts = model.name.replace('dialer_ratio_predictor_', '').split('_')
            
            if len(name_parts) >= 2:
                # Identificar el tipo de modelo (global/portfolio/campaign)
                if name_parts[0] == 'global':
                    model_type = 'global'
                    model_id = 'global'
                elif name_parts[0] == 'portfolio':
                    model_type = 'portfolio'
                    model_id = '_'.join(name_parts[:2])
                else:
                    model_type = 'campaign'
                    model_id = '_'.join(name_parts[:2])
                
                # Identificar modo y configuración
                mode = name_parts[-2] if len(name_parts) > 2 else 'optimal'
                config = name_parts[-1] if mode == 'optimal' and len(name_parts) > 3 else None
                
                # Organizar en la estructura
                if model_type not in model_groups:
                    model_groups[model_type] = {}
                if model_id not in model_groups[model_type]:
                    model_groups[model_type][model_id] = {'historical': [], 'optimal_auto': [], 'optimal_manual': []}
                
                # Agregar al grupo correspondiente
                if mode == 'historical':
                    model_groups[model_type][model_id]['historical'].append((model.name, model.latest_versions[-1]))
                elif mode == 'optimal':
                    group_key = f'optimal_{config}' if config else 'optimal_auto'
                    model_groups[model_type][model_id][group_key].append((model.name, model.latest_versions[-1]))
                
        return model_groups
    except Exception as e:
        logger.error(f"Error obteniendo modelos registrados: {e}")
        return {}

def get_model_metrics(run_id):
    """Obtener métricas del modelo"""
    try:
        run = mlflow.get_run(run_id)
        metrics = run.data.metrics
        params = run.data.params
        return metrics, params
    except Exception as e:
        logger.error(f"Error obteniendo métricas: {e}")
        return {}, {}

def get_available_hours(day_of_week):
    """Obtener horas disponibles según el día"""
    if day_of_week <= 4:  # Lunes a viernes
        return list(range(7, 20))  # 7:00 - 19:00
    else:  # Sábado
        return list(range(8, 16))  # 8:00 - 15:00

def make_prediction(model, input_data, mae):
    """Realizar predicción con el modelo"""
    try:
        # Crear DataFrame con timestamp
        current_time = pd.Timestamp.now()
        df = pd.DataFrame({
            'timestamp': [current_time],
            'agents_connected': [input_data['agents_connected']],
            'agents_available': [input_data['agents_available']],
            'call_duration': [input_data['avg_call_duration']],
            # Otros campos necesarios inicializados a 0
            'dials': [0],
            'contacts': [0],
            'abandonments': [0]
        })
        
        # Preparar features usando el mismo flujo que en app.py
        features = model.prepare_features(df)
        prediction = model.predict(features)[0]
        
        # Calcular límites de confianza
        lower_bound = max(1, prediction - mae)
        upper_bound = prediction + mae
        
        return prediction, lower_bound, upper_bound
    except Exception as e:
        logger.error(f"Error en predicción: {e}")
        raise

def main():
    st.set_page_config(page_title="Model API", layout="wide")
    st.title("API de Predicción de Ratio de Marcación")
    
    # Inicializar MLflow
    if not initialize_mlflow():
        st.warning("No se pudo inicializar MLflow. Las funcionalidades estarán limitadas.")
        return
    
    client = MlflowClient()
    
    # Obtener modelos registrados
    model_groups = get_registered_models(client)
    if not model_groups:
        st.error("No hay modelos registrados disponibles")
        return
    
    # Selector de tipo de modelo
    st.write("### Selección de Modelo")
    model_type = st.selectbox(
        "Tipo de Modelo",
        options=list(model_groups.keys()),
        format_func=lambda x: x.capitalize()
    )
    
    # Selector de ID de modelo
    if model_type:
        model_ids = list(model_groups[model_type].keys())
        selected_id = st.selectbox(
            "ID del Modelo",
            options=model_ids,
            format_func=lambda x: x.replace(f"{model_type}_", "") if model_type != "global" else x
        )
        
        if selected_id:
            # Selector de modo y configuración
            available_modes = []
            if model_groups[model_type][selected_id]['historical']:
                available_modes.append(("historical", "Histórico"))
            if model_groups[model_type][selected_id]['optimal_auto']:
                available_modes.append(("optimal_auto", "Optimización (Auto)"))
            if model_groups[model_type][selected_id]['optimal_manual']:
                available_modes.append(("optimal_manual", "Optimización (Manual)"))
            
            selected_mode = st.selectbox(
                "Modo de Predicción",
                options=[m[0] for m in available_modes],
                format_func=lambda x: dict(available_modes)[x]
            )
            
            if selected_mode:
                # Obtener el modelo seleccionado
                model_list = model_groups[model_type][selected_id][selected_mode]
                if model_list:
                    selected_model = model_list[0]  # Usar la última versión
                    version = selected_model[1]
                    
                    # Mostrar información del modelo
                    st.write("### Métricas de Desempeño del Modelo")
                    metrics, params = get_model_metrics(version.run_id)
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric(
                            "Error Absoluto Medio (MAE)", 
                            f"{metrics.get('mae', 0):.3f}",
                            help="Error promedio en la predicción del ratio"
                        )
                    with col2:
                        st.metric(
                            "Coeficiente de Determinación (R²)", 
                            f"{metrics.get('r2', 0):.3f}",
                            help="Calidad del ajuste del modelo"
                        )
                    with col3:
                        st.metric(
                            "Error Cuadrático Medio (RMSE)", 
                            f"{metrics.get('mse', 0)**0.5:.3f}",
                            help="Error cuadrático medio de las predicciones"
                        )
                    
                    # Formulario para predicción
                    st.write("### Variables de Entrada")
                    st.markdown("Ingrese los valores para obtener una predicción:")
                    
                    with st.form("prediction_form"):
                        # Sección Agentes
                        st.subheader("Datos de Agentes")
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            agents_connected = st.number_input(
                                "Agentes Conectados",
                                min_value=0,
                                value=1000,
                                help="Número total de agentes conectados"
                            )
                        
                        with col2:
                            agents_available = st.number_input(
                                "Agentes Disponibles",
                                min_value=0,
                                max_value=agents_connected,
                                value=min(500, agents_connected),
                                help="Número de agentes disponibles"
                            )
                        
                        with col3:
                            avg_call_duration = st.number_input(
                                "Duración Promedio de Llamada (seg)",
                                min_value=0,
                                value=180,
                                help="Duración promedio de las llamadas"
                            )
                        
                        # Sección Horario
                        st.markdown("---")
                        st.subheader("Horario")
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            day_of_week = st.selectbox(
                                "Día de la Semana",
                                options=[(0, "Lunes"), (1, "Martes"), (2, "Miércoles"),
                                        (3, "Jueves"), (4, "Viernes"), (5, "Sábado")],
                                format_func=lambda x: x[1]
                            )[0]
                        
                        with col2:
                            available_hours = get_available_hours(day_of_week)
                            default_hour = 9 if day_of_week <= 4 else 10
                            
                            hour = st.selectbox(
                                "Hora del Día",
                                options=available_hours,
                                index=available_hours.index(default_hour) if default_hour in available_hours else 0,
                                format_func=lambda x: f"{x:02d}:00"
                            )
                        
                        submit = st.form_submit_button("Calcular Predicción", use_container_width=True)
                    
                    if submit:
                        try:
                            # Determinar parte del día
                            part_of_day = -1
                            if day_of_week <= 4:  # Lunes a viernes
                                if 7 <= hour < 11:
                                    part_of_day = 0
                                elif 11 <= hour < 14:
                                    part_of_day = 1
                                elif 14 <= hour < 19:
                                    part_of_day = 2
                            elif day_of_week == 5:  # Sábado
                                if 8 <= hour < 11:
                                    part_of_day = 0
                                elif 11 <= hour < 15:
                                    part_of_day = 1
                            
                            # Preparar datos de entrada
                            input_data = {
                                'agents_connected': agents_connected,
                                'agents_available': agents_available,
                                'avg_call_duration': avg_call_duration,
                                'hour': hour,
                                'day_of_week': day_of_week,
                                'part_of_day': part_of_day
                            }
                            
                            # Cargar modelo
                            model = mlflow.xgboost.load_model(f"runs:/{version.run_id}/model")
                            
                            # Realizar predicción
                            prediction, lower_bound, upper_bound = make_prediction(
                                model,
                                input_data,
                                metrics.get('mae', 0)
                            )
                            
                            # Mostrar resultados
                            st.write("### Resultados de la Predicción")
                            col1, col2, col3 = st.columns(3)
                            
                            ratio_type = "Predicho" if "historical" in selected_mode else "Óptimo"
                            with col1:
                                st.metric(
                                    f"Ratio {ratio_type}",
                                    f"{prediction:.2f}",
                                    help=f"Ratio {ratio_type.lower()} de marcación"
                                )
                            
                            with col2:
                                st.metric(
                                    "Límite Inferior",
                                    f"{lower_bound:.2f}",
                                    help="Límite inferior del intervalo de confianza"
                                )
                            
                            with col3:
                                st.metric(
                                    "Límite Superior",
                                    f"{upper_bound:.2f}",
                                    help="Límite superior del intervalo de confianza"
                                )
                            
                            st.info(
                                f"Con un Error Absoluto Medio de {metrics.get('mae', 0):.3f}, " 
                                f"el ratio {ratio_type.lower()} debería estar entre {lower_bound:.2f} "
                                f"y {upper_bound:.2f} llamadas por agente disponible."
                            )
                            
                        except Exception as e:
                            st.error(f"Error al realizar la predicción: {str(e)}")

if __name__ == "__main__":
    main()