# Procesador de PDF e Imágenes a Markdown

Este proyecto implementa un servicio que monitorea una carpeta para procesar archivos PDF e imágenes y convertirlos a formato Markdown. El sistema está diseñado para funcionar tanto en entornos Windows (desarrollo) como Ubuntu (producción).

## Características

- Monitoreo continuo de una carpeta de entrada y sus subdirectorios
- Procesamiento de múltiples tipos de archivos:
  - PDFs editables mediante pymupdf4llm
  - PDFs no editables mediante Modelos de Visión y Lenguaje (VLM)
  - Imágenes en diversos formatos (TIFF, JPG, PNG, etc.)
- Filtrado de archivos por palabras clave en el nombre
- Sistema de fallback inteligente para PDFs problemáticos:
  - Intentar primero extracción directa con límite de tiempo configurable
  - Si falla o toma demasiado tiempo, usar VLM como respaldo
- Soporte para imágenes multipágina (TIFF)
- Registro detallado de operaciones y errores
- Configuración flexible mediante variables de entorno

## Requisitos

- Python 3.6+
- Dependencias listadas en `requirements.txt`
- Acceso a un endpoint de Ollama con un modelo de visión configurado (para PDFs no editables e imágenes)

## Estructura del proyecto

```
pdf-image-processor/
│
├── pdf_image_processor.py    # Clase principal para procesamiento 
├── service.py                # Implementación del servicio de monitoreo
├── config.py                 # Configuración centralizada
├── security_module.py        # Módulo para seguridad y encriptación
├── db_manager.py             # Módulo para integración con PostgreSQL
├── encrypt_password.py       # Script para encriptar contraseñas
│
├── .env.example              # Plantilla para variables de entorno
├── .gitignore                # Archivos a ignorar en control de versiones
├── requirements.txt          # Dependencias del proyecto
├── README.md                 # Documentación
│
├── pdf-processor.service     # Configuración para systemd (Ubuntu)
│
└── logs/                     # Directorio para archivos de log
    ├── processor_*.log       # Logs de procesamiento (uno por día)
    ├── service.log           # Logs del servicio
    └── processed_files.json  # Registro de archivos procesados
```

## Instalación

### Desarrollo (Windows)

1. Clonar el repositorio
2. Crear un entorno virtual:
   ```
   python -m venv venv
   venv\Scripts\activate
   ```
3. Instalar dependencias:
   ```
   pip install -r requirements.txt
   ```
4. Crear archivo de variables de entorno:
   ```
   copy .env.example .env
   # Editar el archivo .env con la configuración deseada
   ```
5. Ejecutar el servicio:
   ```
   python service.py
   ```

### Para usar con Anaconda

1. Activar el ambiente existente:
   ```
   conda activate cidat_ai
   ```
2. Instalar dependencias:
   ```
   pip install -r requirements.txt
   ```
3. Crear archivo de variables de entorno
4. Ejecutar el servicio:
   ```
   python service.py
   ```

### Producción (Ubuntu)

1. Clonar el repositorio en el servidor
2. Crear un entorno virtual:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```
3. Instalar dependencias:
   ```
   pip install -r requirements.txt
   ```
4. Crear archivo de variables de entorno:
   ```
   cp .env.example .env
   nano .env  # Editar con valores reales
   ```
5. Configurar el servicio systemd:
   ```
   sudo cp pdf-processor.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable pdf-processor
   sudo systemctl start pdf-processor
   ```

## Configuración

### Variables de entorno

El sistema utiliza variables de entorno para configuración. Puedes configurar:

- Rutas de directorios (`INPUT_DIR`, `OUTPUT_DIR`, `LOG_DIR`)
- Tiempos límite (`PDF_PROCESSING_TIMEOUT`, `PDF_EXTRACTION_TIMEOUT`)
- Configuración de Ollama (`OLLAMA_ENABLED`, `OLLAMA_ENDPOINT`, `OLLAMA_MODEL`)
- Configuración de base de datos (opcional)

### Configuración de tiempos límite

El sistema utiliza dos tiempos límite diferentes:

- `PDF_EXTRACTION_TIMEOUT`: Tiempo máximo para la extracción directa con pymupdf4llm antes de intentar el fallback a VLM (por defecto: 10 segundos)
- `PDF_PROCESSING_TIMEOUT`: Tiempo máximo total para procesar un archivo (por defecto: 300 segundos)

Puedes ajustar estos valores en el archivo `.env` según tus necesidades.

### Configuración de Ollama

Para procesar PDFs no editables e imágenes, necesitas configurar el acceso a un endpoint de Ollama:

```
OLLAMA_ENABLED=true
OLLAMA_ENDPOINT=http://localhost:11434/api/chat
OLLAMA_MODEL=llama3.2-vision:11b
```

Si no tienes Ollama configurado, puedes desactivarlo con `OLLAMA_ENABLED=false`, pero en ese caso solo se procesarán los PDFs editables.

## Formatos soportados

- PDFs: Archivos PDF editables y no editables
- Imágenes:
  - TIFF (incluidos TIFF multipágina)
  - JPG/JPEG
  - PNG
  - BMP
  - GIF

## Resolución de problemas

Si encuentra problemas:

1. Verificar los archivos de log en `logs/`
2. Asegurarse de que las carpetas de entrada y salida existen y tienen permisos correctos
3. Verificar que Ollama está configurado correctamente si se procesan PDFs no editables o imágenes
4. Comprobar que el archivo contiene alguna de las palabras clave configuradas en su nombre

## Licencia

Este proyecto está licenciado bajo los términos de la licencia MIT.
