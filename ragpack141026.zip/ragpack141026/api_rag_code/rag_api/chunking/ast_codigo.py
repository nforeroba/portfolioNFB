"""
Estrategia de chunking consciente de codigo (patron cAST), via Tree-sitter.

Nunca corta un nodo de nivel superior del arbol sintactico por la
mitad (una funcion, una clase, un statement SQL, un elemento HTML de
primer nivel...). Agrupa nodos de nivel superior consecutivos y
pequenos en un mismo chunk hasta acercarse al tamano objetivo; si un
solo nodo de nivel superior sigue siendo mas grande que el tamano
objetivo, recursiona hacia sus hijos antes de recurrir a un corte
ciego como ultimo recurso.

Ademas, antepone a cada chunk un preambulo de contexto (guardado en
ChunkGenerado.texto_padre, no en el texto del chunk mismo) con la
ruta del archivo, el alcance/scope (clase o funcion contenedora, si
aplica) y una descripcion de lo que el fragmento define. Esto resuelve
un problema conocido de RAG sobre codigo: un fragmento aislado como
"def getUser(id):" no le dice al modelo de embeddings que esa funcion
pertenece a una clase UserService en un archivo especifico -- esa
relacion se pierde si el chunk viaja solo. El preambulo se guarda
separado del codigo (no mezclado en el mismo texto) para no ensuciar
el contenido que despues se le muestra al LLM como codigo puro.

No aplica overlap entre chunks: cada chunk ya es una o mas unidades
sintacticas completas y autocontenidas.

Cobertura de lenguajes: python, javascript, html, cpp usan gramaticas
oficiales de Tree-sitter, bien mantenidas. sql usa una gramatica
comunitaria, mas propensa a necesitar ajuste una vez probada contra
casos reales.

Para python, javascript y cpp se extrae una firma real (nombre +
parametros) cuando el nodo es una funcion o clase. Para html y sql, el
concepto de "firma" no tiene un equivalente claro, asi que el
preambulo usa la primera linea del propio chunk como descripcion,
sin intentar extraer una firma formal.
"""

import tiktoken
from tree_sitter import Language, Node, Parser

from rag_api.chunking.base import ChunkGenerado, EstrategiaChunkingBase

_ENCODING = tiktoken.get_encoding("cl100k_base")

_LENGUAJES_SOPORTADOS = ("python", "javascript", "html", "sql", "cpp")

_TIPOS_CON_FIRMA = {
    "python": {"function_definition", "class_definition"},
    "javascript": {"function_declaration", "class_declaration", "method_definition"},
    "cpp": {"function_definition", "class_specifier", "struct_specifier"},
    "html": set(),
    "sql": set(),
}


class LenguajeNoSoportadoError(ValueError):
    """Se lanza cuando se pide chunking AST para un lenguaje no soportado o no especificado."""


def _cargar_parser(lenguaje: str) -> Parser:
    if lenguaje == "python":
        import tree_sitter_python as gramatica
    elif lenguaje == "javascript":
        import tree_sitter_javascript as gramatica
    elif lenguaje == "html":
        import tree_sitter_html as gramatica
    elif lenguaje == "cpp":
        import tree_sitter_cpp as gramatica
    elif lenguaje == "sql":
        import tree_sitter_sql as gramatica
    else:
        raise LenguajeNoSoportadoError(
            f"Lenguaje '{lenguaje}' no soportado. Lenguajes soportados: {_LENGUAJES_SOPORTADOS}"
        )

    return Parser(Language(gramatica.language()))


def _contar_tokens(texto: str) -> int:
    return len(_ENCODING.encode(texto))


class ChunkingAstCodigo(EstrategiaChunkingBase):
    def chunkear(
        self,
        texto: str,
        tamano_tokens: int,
        overlap_tokens: int,
        lenguaje_codigo: str | None = None,
        fuente: str | None = None,
    ) -> list[ChunkGenerado]:
        if lenguaje_codigo is None:
            raise LenguajeNoSoportadoError(
                "CHUNKING_AST_CODIGO requiere especificar lenguaje_codigo explicitamente "
                f"(uno de: {_LENGUAJES_SOPORTADOS})"
            )
        if lenguaje_codigo not in _LENGUAJES_SOPORTADOS:
            raise LenguajeNoSoportadoError(
                f"Lenguaje '{lenguaje_codigo}' no soportado. Lenguajes soportados: {_LENGUAJES_SOPORTADOS}"
            )

        # overlap_tokens se ignora deliberadamente: ver docstring del modulo.

        parser = _cargar_parser(lenguaje_codigo)
        texto_bytes = texto.encode("utf-8")
        arbol = parser.parse(texto_bytes)

        nodos_de_nivel_superior = list(arbol.root_node.children)
        resultados = self._agrupar_nodos(
            nodos_de_nivel_superior, texto_bytes, tamano_tokens, lenguaje_codigo, scope_actual=None
        )

        chunks = []
        for texto_chunk, scope in resultados:
            if not texto_chunk.strip():
                continue
            preambulo = self._construir_preambulo(fuente, scope, texto_chunk)
            chunks.append(ChunkGenerado(texto=texto_chunk, texto_padre=preambulo))

        return chunks

    def _agrupar_nodos(
        self,
        nodos: list[Node],
        texto_bytes: bytes,
        tamano_tokens: int,
        lenguaje: str,
        scope_actual: str | None,
    ) -> list[tuple[str, str | None]]:
        resultados: list[tuple[str, str | None]] = []
        grupo_actual: list[Node] = []
        tokens_grupo_actual = 0

        for nodo in nodos:
            texto_nodo = texto_bytes[nodo.start_byte : nodo.end_byte].decode("utf-8", errors="replace")
            tokens_nodo = _contar_tokens(texto_nodo)

            if tokens_nodo > tamano_tokens:
                if grupo_actual:
                    resultados.append((self._unir_nodos(grupo_actual, texto_bytes), scope_actual))
                    grupo_actual = []
                    tokens_grupo_actual = 0

                if nodo.children:
                    nuevo_scope = self._extraer_firma(nodo, texto_bytes, lenguaje) or scope_actual
                    resultados.extend(
                        self._agrupar_nodos(
                            list(nodo.children), texto_bytes, tamano_tokens, lenguaje, nuevo_scope
                        )
                    )
                else:
                    for fragmento in self._corte_ciego(texto_nodo, tamano_tokens):
                        resultados.append((fragmento, scope_actual))
                continue

            if tokens_grupo_actual + tokens_nodo > tamano_tokens and grupo_actual:
                resultados.append((self._unir_nodos(grupo_actual, texto_bytes), scope_actual))
                grupo_actual = []
                tokens_grupo_actual = 0

            grupo_actual.append(nodo)
            tokens_grupo_actual += tokens_nodo

        if grupo_actual:
            resultados.append((self._unir_nodos(grupo_actual, texto_bytes), scope_actual))

        return resultados

    @staticmethod
    def _extraer_firma(nodo: Node, texto_bytes: bytes, lenguaje: str) -> str | None:
        if nodo.type not in _TIPOS_CON_FIRMA.get(lenguaje, set()):
            return None

        texto_nodo = texto_bytes[nodo.start_byte : nodo.end_byte].decode("utf-8", errors="replace")
        primera_linea = texto_nodo.split("\n", 1)[0].strip()
        return primera_linea

    def _construir_preambulo(
        self,
        fuente: str | None,
        scope: str | None,
        texto_chunk: str,
    ) -> str:
        lineas = []
        if fuente:
            lineas.append(f"# {fuente}")
        if scope:
            lineas.append(f"# Scope: {scope}")

        primera_linea_chunk = texto_chunk.split("\n", 1)[0].strip()
        lineas.append(f"# Defines: {primera_linea_chunk}")

        return "\n".join(lineas)

    @staticmethod
    def _unir_nodos(nodos: list[Node], texto_bytes: bytes) -> str:
        inicio = nodos[0].start_byte
        fin = nodos[-1].end_byte
        return texto_bytes[inicio:fin].decode("utf-8", errors="replace")

    @staticmethod
    def _corte_ciego(texto: str, tamano_tokens: int) -> list[str]:
        tokens = _ENCODING.encode(texto)
        fragmentos = []
        for i in range(0, len(tokens), tamano_tokens):
            fragmento_tokens = tokens[i : i + tamano_tokens]
            fragmentos.append(_ENCODING.decode(fragmento_tokens))
        return fragmentos
