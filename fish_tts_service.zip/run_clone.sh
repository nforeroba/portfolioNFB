#!/bin/bash
source venv/bin/activate
python clone_voice.py --audio sample.wav --text "Hola, esta es una muestra de mi voz." --output voz_clonada.pth
