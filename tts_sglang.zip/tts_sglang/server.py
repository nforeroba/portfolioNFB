"""
Servicio gRPC TTS — Fish Audio S2-Pro + motor SGLang-Omni
Arquitectura: gRPC (grpc.aio) -> HTTP interno (sgl-omni serve, /v1/audio/speech)
Protocolo externo: tts_service.proto (TTS unary + TTSStream streaming)
Motor interno: sgl-omni serve, arrancado por entrypoint.sh como proceso
              separado dentro del mismo contenedor, escuchando en
              localhost:{SGLANG_OMNI_PORT} (default 8000).

Diferencias respecto a tts_s2_pro/server.py (TTSInferenceEngine clásico):
  - NO carga el modelo directamente. Es un traductor de protocolo delgado
    que reenvía requests al proceso sgl-omni serve vía HTTP.
  - Sin TTSInferenceEngine, sin warmup propio (el warmup real ocurre en
    sgl-omni serve durante su propio arranque, vía CUDA graph capture).
  - Nuevo RPC: TTSStream() — streaming real hacia el cliente, chunk por
    chunk, aprovechando streaming_vocoder=true confirmado en los
    "Model capabilities" de sgl-omni.

⚠️ PENDIENTE DE VALIDACIÓN EMPÍRICA (no confirmado en sesión de pruebas en
RTX 5070 Ti, porque el vocoder nunca llegó a completar una síntesis real
por falta de VRAM — solo se confirmó que el servidor arranca y rechaza
requests por capacidad de KV cache, no por payload inválido):
  - El campo exacto para pasar audio de referencia (voice cloning) —
    aquí se usa "references": [{"audio_path": ..., "text": ...}] según
    la documentación de la API OpenAI-compatible de sgl-omni, pero no
    se probó de punta a punta con una síntesis exitosa.
  - El formato exacto de los eventos SSE en streaming (aquí se asume
    "audio.speech.chunk" con "audio" en base64, PCM 16-bit).
  - Si sgl-omni espera el audio de referencia como ruta de archivo
    accesible desde su propio proceso, o como bytes embebidos en el
    request — aquí se asume ruta de archivo, ya que server.py y
    sgl-omni corren en el mismo contenedor y comparten filesystem
    (/voices montado en ambos).
PRIMERA ACCIÓN AL DESPLEGAR EN H200: correr client_test.py con un texto
corto y revisar el log de sgl-omni serve si algo de esto no coincide con
la realidad del payload esperado — ajustar resolve_voice_payload() y/o
parse_sse_chunk() según lo que el error reporte.
"""

import argparse
import asyncio
import base64
import io
import json
import logging
import os
import time
from pathlib import Path

import grpc
import grpc.aio
import httpx
from pydub import AudioSegment

import tts_service_pb2
import tts_service_pb2_grpc

# =============================================================================
# Logging
# =============================================================================

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s|%(name)s|%(levelname)s|%(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("tts_service")

# httpcore/httpx en DEBUG imprimen una línea por cada intento de conexión
# TCP — durante la espera de wait_for_sglang_omni() (que reintenta hasta
# que el motor cargue, normalmente 1-3 min) esto genera decenas de líneas
# que ahogan el log real de sgl-omni serve en la salida del contenedor.
# Se sube su nivel a WARNING específicamente; el resto del wrapper sigue
# en DEBUG.
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)

# =============================================================================
# Configuración
# =============================================================================

def load_config(path: str) -> dict:
    defaults = {
        "listen": "0.0.0.0:50051",
        "temperature": 0.8,
        "top_p": 0.8,
        "top_k": 50,
        "default_reference_id": "vanessa",
        "sglang_omni_base_url": "http://127.0.0.1:8000",
        "sglang_omni_model": "fishaudio/s2-pro",
        "request_timeout_s": 120.0,
        "initial_codec_chunk_frames": None,  # None = default de sgl-omni (1 frame)
        "max_audio_duration_sanity_s": 60.0,  # ver sanity check en _run_inference_stream
    }
    try:
        with open(path) as f:
            cfg = json.load(f)
        defaults.update(cfg)
        logger.info("Configuración cargada desde %s", path)
    except FileNotFoundError:
        logger.warning("Config no encontrada en %s — usando defaults", path)
    logger.debug("Config: %s", json.dumps(defaults))
    return defaults


# =============================================================================
# Resolución de voces de referencia
# =============================================================================

VOICES_DIR = Path(os.environ.get("VOICES_DIR", "/voices"))
SAMPLES_DIR = Path("/app/samples")


def resolve_voice_paths(reference_id: str) -> tuple[str, str]:
    """
    Devuelve (audio_path, transcript) para un reference_id dado.
    A diferencia de tts_s2_pro/server.py (TTSInferenceEngine, que leía los
    bytes del wav directamente), aquí devolvemos la RUTA del archivo, ya
    que sgl-omni serve corre como proceso separado en el mismo contenedor
    y accede al archivo directamente desde el filesystem compartido
    (/voices montado igual en ambos procesos).
    """
    for base in [VOICES_DIR, SAMPLES_DIR]:
        wav = base / f"{reference_id}.wav"
        txt = base / f"{reference_id}.txt"
        if wav.exists() and txt.exists():
            transcript = txt.read_text(encoding="utf-8").strip()
            logger.debug("Voz '%s' resuelta desde %s", reference_id, base)
            return str(wav), transcript
    raise FileNotFoundError(
        f"Voz '{reference_id}' no encontrada en {VOICES_DIR} ni en {SAMPLES_DIR}"
    )


# =============================================================================
# Conversión PCM/WAV → Opus
# =============================================================================

def wav_bytes_to_opus(wav_bytes: bytes) -> tuple[bytes, float]:
    """Convierte bytes WAV completos a bytes Opus. Usado en TTS() unary."""
    t0 = time.perf_counter()
    audio = AudioSegment.from_wav(io.BytesIO(wav_bytes))
    duration = len(audio) / 1000.0

    buf = io.BytesIO()
    audio.export(buf, format="opus", codec="libopus")
    opus_bytes = buf.getvalue()

    elapsed = time.perf_counter() - t0
    logger.debug(
        "WAV->Opus | dur=%.3fs | opus_size=%d bytes | conv_time=%.3fs",
        duration, len(opus_bytes), elapsed,
    )
    return opus_bytes, duration


def pcm_chunk_to_opus(pcm_bytes: bytes, sample_rate: int = 44100,
                       channels: int = 1, sample_width: int = 2) -> tuple[bytes, float]:
    """
    Convierte un chunk de PCM crudo (sin header WAV) a un Opus INDEPENDIENTE
    y válido (con su propio header), para que cada mensaje del stream gRPC
    sea reproducible por sí solo. Usado en TTSStream().

    ⚠️ sample_rate/channels/sample_width son valores por defecto razonables
    para S2-Pro (44.1kHz mono 16-bit, como confirmamos en tts_s2_pro con
    TTSInferenceEngine) — PENDIENTE DE CONFIRMAR que sgl-omni usa la misma
    tasa de muestreo; ajustar si el primer chunk real suena distorsionado
    o a velocidad incorrecta.
    """
    audio = AudioSegment(
        data=pcm_bytes,
        sample_width=sample_width,
        frame_rate=sample_rate,
        channels=channels,
    )
    duration = len(audio) / 1000.0

    buf = io.BytesIO()
    audio.export(buf, format="opus", codec="libopus")
    opus_bytes = buf.getvalue()

    return opus_bytes, duration


# =============================================================================
# Cliente HTTP hacia sgl-omni serve
# =============================================================================

class SGLangOmniClient:
    """
    Cliente delgado hacia la API HTTP OpenAI-compatible que expone
    `sgl-omni serve` en localhost. Encapsula la traducción de nuestro
    contrato gRPC hacia el payload que espera esa API.
    """

    def __init__(self, base_url: str, model: str, timeout_s: float):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout_s = timeout_s
        self._client: httpx.AsyncClient | None = None

    async def start(self):
        self._client = httpx.AsyncClient(timeout=self.timeout_s)

    async def stop(self):
        if self._client:
            await self._client.aclose()

    def _build_payload(
        self,
        text: str,
        audio_path: str,
        transcript: str,
        temperature: float,
        top_p: float,
        top_k: int,
        stream: bool,
        initial_codec_chunk_frames: int | None,
    ) -> dict:
        payload = {
            "model": self.model,
            "input": text,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
            "stream": stream,
            # ⚠️ PENDIENTE DE VALIDAR: nombre y forma exacta de este campo.
            # Ver docstring del módulo — asumido según la doc de la API
            # OpenAI-compatible de sgl-omni para voice cloning.
            "references": [
                {"audio_path": audio_path, "text": transcript}
            ],
        }
        if stream:
            payload["response_format"] = "pcm"
            if initial_codec_chunk_frames is not None:
                payload["initial_codec_chunk_frames"] = initial_codec_chunk_frames
        return payload

    async def synthesize_unary(
        self, text: str, audio_path: str, transcript: str,
        temperature: float, top_p: float, top_k: int,
    ) -> bytes:
        """Devuelve bytes WAV completos (no streaming)."""
        payload = self._build_payload(
            text, audio_path, transcript, temperature, top_p, top_k,
            stream=False, initial_codec_chunk_frames=None,
        )
        logger.debug("HTTP -> sgl-omni | POST /v1/audio/speech | payload=%s", payload)

        resp = await self._client.post(
            f"{self.base_url}/v1/audio/speech", json=payload,
        )
        if resp.status_code != 200:
            raise RuntimeError(
                f"sgl-omni serve devolvió {resp.status_code}: {resp.text}"
            )
        return resp.content

    async def synthesize_stream(
        self, text: str, audio_path: str, transcript: str,
        temperature: float, top_p: float, top_k: int,
        initial_codec_chunk_frames: int | None,
    ):
        """
        Generador async que produce bytes PCM crudos por cada chunk SSE
        recibido. El llamador se encarga de convertir cada chunk a Opus.

        ⚠️ PENDIENTE DE VALIDAR el nombre exacto del campo de evento SSE
        ("audio.speech.chunk") y si el payload base64 viene en un campo
        "audio" o algún otro nombre — ajustar el parseo según la
        respuesta real del primer intento en H200.
        """
        payload = self._build_payload(
            text, audio_path, transcript, temperature, top_p, top_k,
            stream=True, initial_codec_chunk_frames=initial_codec_chunk_frames,
        )
        logger.debug("HTTP -> sgl-omni (stream) | POST /v1/audio/speech | payload=%s", payload)

        async with self._client.stream(
            "POST", f"{self.base_url}/v1/audio/speech", json=payload,
        ) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                raise RuntimeError(
                    f"sgl-omni serve devolvió {resp.status_code}: {body!r}"
                )

            async for line in resp.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data_str = line[len("data:"):].strip()
                if data_str == "[DONE]":
                    break
                try:
                    event = json.loads(data_str)
                except json.JSONDecodeError:
                    logger.warning("SSE | línea no-JSON ignorada: %r", data_str)
                    continue

                # ⚠️ PENDIENTE DE VALIDAR la forma exacta de "event".
                audio_b64 = (
                    event.get("audio")
                    or event.get("chunk", {}).get("audio")
                    or event.get("data")
                )
                if audio_b64 is None:
                    logger.warning("SSE | evento sin campo de audio reconocible: %s", event)
                    continue

                pcm_bytes = base64.b64decode(audio_b64)
                yield pcm_bytes


# =============================================================================
# Servicer gRPC
# =============================================================================

class TTSServicer(tts_service_pb2_grpc.TTSServiceServicer):

    def __init__(self, omni_client: SGLangOmniClient, config: dict):
        self.omni = omni_client
        self.config = config

    def _resolve_params(self, request: tts_service_pb2.ServeTTSRequest):
        reference_id = request.reference_id or self.config["default_reference_id"]
        temperature = request.temperature or self.config["temperature"]
        top_p = request.top_p or self.config["top_p"]
        top_k = request.top_k or self.config["top_k"]
        return reference_id, temperature, top_p, top_k

    # ── TTS unary ────────────────────────────────────────────────────────────

    async def TTS(
        self,
        request: tts_service_pb2.ServeTTSRequest,
        context: grpc.aio.ServicerContext,
    ) -> tts_service_pb2.ServeAudioResponse:

        t_total = time.perf_counter()
        text = request.text
        reference_id, temperature, top_p, top_k = self._resolve_params(request)

        logger.info(
            "REQUEST (unary) | text_len=%d | voz=%s | temp=%.2f | top_p=%.2f | top_k=%d",
            len(text), reference_id, temperature, top_p, top_k,
        )

        try:
            audio_path, transcript = resolve_voice_paths(reference_id)
        except FileNotFoundError as e:
            logger.error("Voz no encontrada: %s", e)
            await context.abort(grpc.StatusCode.NOT_FOUND, str(e))
            return

        t0 = time.perf_counter()
        try:
            wav_bytes = await self.omni.synthesize_unary(
                text, audio_path, transcript, temperature, top_p, top_k,
            )
        except Exception as e:
            logger.exception("INFERENCIA | falló: %s", e)
            await context.abort(grpc.StatusCode.INTERNAL, f"Error en síntesis: {e}")
            return
        logger.info("INFERENCIA | fin | elapsed=%.3fs", time.perf_counter() - t0)

        t0 = time.perf_counter()
        opus_bytes, audio_duration = wav_bytes_to_opus(wav_bytes)
        logger.debug("CONVERSIÓN | WAV->Opus | elapsed=%.3fs", time.perf_counter() - t0)

        total_elapsed = time.perf_counter() - t_total
        rtf = total_elapsed / audio_duration if audio_duration > 0 else 0.0
        logger.info(
            "RESPONSE (unary) | voz=%s | audio_dur=%.3fs | total_time=%.3fs | RTF=%.4f",
            reference_id, audio_duration, total_elapsed, rtf,
        )

        return tts_service_pb2.ServeAudioResponse(
            audio_bytes=opus_bytes,
            audio_duration=audio_duration,
        )

    # ── TTSStream — nuevo RPC, aditivo ──────────────────────────────────────

    async def TTSStream(
        self,
        request: tts_service_pb2.ServeTTSRequest,
        context: grpc.aio.ServicerContext,
    ):
        t_total = time.perf_counter()
        text = request.text
        reference_id, temperature, top_p, top_k = self._resolve_params(request)
        chunk_frames = self.config.get("initial_codec_chunk_frames")

        logger.info(
            "REQUEST (stream) | text_len=%d | voz=%s | temp=%.2f | top_p=%.2f | top_k=%d",
            len(text), reference_id, temperature, top_p, top_k,
        )

        try:
            audio_path, transcript = resolve_voice_paths(reference_id)
        except FileNotFoundError as e:
            logger.error("Voz no encontrada: %s", e)
            await context.abort(grpc.StatusCode.NOT_FOUND, str(e))
            return

        # Verificación de sanidad: acumula duración total del stream y corta
        # si excede un umbral razonable — red de seguridad contra el patrón
        # de bug de duplicación de audio documentado en proyectos hermanos
        # (vLLM-omni) durante la investigación de esta fase.
        max_sane_duration = self.config.get("max_audio_duration_sanity_s", 60.0)
        accumulated_duration = 0.0
        chunk_count = 0

        try:
            async for pcm_bytes in self.omni.synthesize_stream(
                text, audio_path, transcript, temperature, top_p, top_k,
                initial_codec_chunk_frames=chunk_frames,
            ):
                opus_bytes, chunk_duration = pcm_chunk_to_opus(pcm_bytes)
                accumulated_duration += chunk_duration
                chunk_count += 1

                if accumulated_duration > max_sane_duration:
                    logger.error(
                        "SANITY CHECK | duración acumulada %.1fs excede el umbral "
                        "%.1fs para un texto de %d caracteres — cortando stream "
                        "(posible bug de duplicación, ver docstring del módulo)",
                        accumulated_duration, max_sane_duration, len(text),
                    )
                    await context.abort(
                        grpc.StatusCode.INTERNAL,
                        "Duración de audio generada excede el límite de sanidad",
                    )
                    return

                logger.debug(
                    "STREAM | chunk #%d | dur=%.3fs | acumulado=%.3fs",
                    chunk_count, chunk_duration, accumulated_duration,
                )

                yield tts_service_pb2.ServeAudioResponse(
                    audio_bytes=opus_bytes,
                    audio_duration=chunk_duration,
                )
        except Exception as e:
            logger.exception("INFERENCIA (stream) | falló: %s", e)
            await context.abort(grpc.StatusCode.INTERNAL, f"Error en síntesis: {e}")
            return

        total_elapsed = time.perf_counter() - t_total
        rtf = total_elapsed / accumulated_duration if accumulated_duration > 0 else 0.0
        logger.info(
            "RESPONSE (stream) | voz=%s | chunks=%d | audio_dur=%.3fs | "
            "total_time=%.3fs | RTF=%.4f",
            reference_id, chunk_count, accumulated_duration, total_elapsed, rtf,
        )


# =============================================================================
# Servidor gRPC
# =============================================================================

async def serve(omni_client: SGLangOmniClient, config: dict, port: int):
    listen_addr = f"0.0.0.0:{port}"
    server = grpc.aio.server()
    tts_service_pb2_grpc.add_TTSServiceServicer_to_server(
        TTSServicer(omni_client, config), server
    )
    server.add_insecure_port(listen_addr)

    await server.start()
    logger.info("════════════════════════════════════════════════")
    logger.info("  gRPC escuchando en %s", listen_addr)
    logger.info("  Motor interno (sgl-omni serve): %s", config["sglang_omni_base_url"])
    logger.info("  Servicio listo para recibir requests")
    logger.info("════════════════════════════════════════════════")

    await server.wait_for_termination()


async def wait_for_sglang_omni(base_url: str, timeout_s: float = 900.0):
    """
    Espera a que sgl-omni serve (proceso separado, arrancado por
    entrypoint.sh) esté listo antes de que este wrapper acepte tráfico.
    Necesario porque sgl-omni serve puede tardar varios minutos en cargar
    el modelo (LLaMA + KV cache + CUDA graphs + vocoder) — ver logs de la
    sesión de pruebas en 5070 Ti, donde el arranque tomó ~1-2 minutos
    incluso con VRAM restringida; en H200 sin restricción probablemente
    similar o algo más rápido en la etapa de CUDA graph capture.
    """
    logger.info("Esperando a que sgl-omni serve esté listo en %s ...", base_url)
    t0 = time.perf_counter()
    poll_interval_s = 5.0
    progress_every_s = 30.0  # imprime "sigo esperando" cada 30s, no cada intento
    last_progress = t0

    async with httpx.AsyncClient(timeout=5.0) as client:
        while time.perf_counter() - t0 < timeout_s:
            try:
                resp = await client.get(f"{base_url}/health")
                if resp.status_code == 200:
                    logger.info(
                        "sgl-omni serve listo | elapsed=%.1fs",
                        time.perf_counter() - t0,
                    )
                    return
            except Exception:
                pass

            now = time.perf_counter()
            if now - last_progress >= progress_every_s:
                logger.info(
                    "Sigue esperando a sgl-omni serve... (%.0fs transcurridos, "
                    "ver log [sglang-omni] arriba para el progreso real de carga)",
                    now - t0,
                )
                last_progress = now

            await asyncio.sleep(poll_interval_s)
    raise TimeoutError(
        f"sgl-omni serve no respondió en {timeout_s}s — revisar su log por separado"
    )


# =============================================================================
# Main
# =============================================================================

def parse_args():
    parser = argparse.ArgumentParser(description="Fish Audio S2-Pro TTS gRPC Service (SGLang-Omni)")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 50051)))
    parser.add_argument("--config", default="/app/config_tts.json")
    return parser.parse_args()


async def main_async():
    t_start = time.perf_counter()
    args = parse_args()
    config = load_config(args.config)

    await wait_for_sglang_omni(config["sglang_omni_base_url"])

    omni_client = SGLangOmniClient(
        base_url=config["sglang_omni_base_url"],
        model=config["sglang_omni_model"],
        timeout_s=config["request_timeout_s"],
    )
    await omni_client.start()

    logger.info(
        "ARRANQUE | wrapper gRPC listo | elapsed_total=%.2fs",
        time.perf_counter() - t_start,
    )

    try:
        await serve(omni_client, config, args.port)
    finally:
        await omni_client.stop()


def main():
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
