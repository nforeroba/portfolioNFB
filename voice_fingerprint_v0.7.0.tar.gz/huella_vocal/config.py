"""Parámetros compartidos del núcleo de huella vocal."""

import os
from pathlib import Path

SR = 16000                      # frecuencia de trabajo de toda la cadena (Hz)

MODELO_HUELLA = "speechbrain/spkrec-ecapa-voxceleb"
DIM_HUELLA = 192

MODELO_STT = "base"             # faster-whisper, int8 en CPU (elegido en la Fase 0)

# Decisión de identidad (provisional, Fase 1): identificado si el mejor score
# supera UMBRAL_ALTO y le saca MARGEN_MINIMO al segundo; zona gris entre
# UMBRAL_BAJO y UMBRAL_ALTO ("no concluyente, repita").
UMBRAL_ALTO = 0.65
UMBRAL_BAJO = 0.50
MARGEN_MINIMO = 0.10

SEGUNDOS_MIN_VALIDACION = 3.0   # por debajo: "muestra insuficiente"

# Prueba de vida (Fase 2): la persona dice su nombre y repite una secuencia de
# dígitos al azar. Se aprueba si los dígitos oídos coinciden con los pedidos,
# admitiendo como mucho ERRORES_DIGITOS_PERMITIDOS (un dígito omitido, cambiado o de más).
DIGITOS_DESAFIO = 6
ERRORES_DIGITOS_PERMITIDOS = 1

SEGUNDOS_TRAMO = 10.0          # longitud de cada tramo de voz neta en las referencias
SEGUNDOS_MIN_TRAMO = 5.0        # un sobrante menor que esto se une al tramo anterior
SEGUNDOS_MIN_REFERENCIA = 3.0   # un archivo de referencia con menos voz neta que esto se rechaza

# Sufijos de país reconocidos en los nombres de archivo existentes (nombre_pais.wav).
PAISES = {
    "arg": "Argentina",
    "bol": "Bolivia",
    "chi": "Chile",
    "col": "Colombia",
    "cri": "Costa Rica",
    "cub": "Cuba",
    "dom": "República Dominicana",
    "ecu": "Ecuador",
    "esp": "España",
    "gua": "Guatemala",
    "mex": "México",
    "pan": "Panamá",
    "par": "Paraguay",
    "pe": "Perú",
    "peru": "Perú",
    "pr": "Puerto Rico",
    "uru": "Uruguay",
    "ven": "Venezuela",
}


def config_qdrant():
    """
    Conexión a Qdrant desde variables de ambiente, para usar otro host o puerto
    sin tocar el código. QDRANT_URL=":memory:" usa una base temporal en memoria.
    """
    return {
        "url": os.environ.get("QDRANT_URL", "http://localhost:6333"),
        "api_key": os.environ.get("QDRANT_API_KEY") or None,
        "prefijo": os.environ.get("QDRANT_PREFIJO", "huella_vocal"),
    }


def configurar_cache_modelos(dir_modelos):
    """Fija la caché de Hugging Face. Debe llamarse antes de importar speechbrain."""
    dir_modelos = Path(dir_modelos).resolve()
    dir_modelos.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HOME", str(dir_modelos / "huggingface"))
    return dir_modelos
