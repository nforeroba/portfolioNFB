#!/usr/bin/env python
# extractor_20.py

import pymupdf4llm
import pathlib
import re
import pandas as pd
import datetime
from typing import Dict, Any, Tuple, Optional
import unicodedata
import signal
import sys
import atexit

# Variables globales para manejar interrupciones
results = []
start_time = None
unprocessed_files = []
total_processed = 0
CHECKPOINT_INTERVAL = 5  # Guardar cada 5 archivos procesados

def create_checkpoint_folder():
    """Crea la carpeta de checkpoints si no existe."""
    checkpoint_dir = pathlib.Path('0779665_extraccion_datos_peritajes/checkpoints')
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    return checkpoint_dir

def save_checkpoint():
    """Guarda el progreso actual en archivos de checkpoint."""
    if not results:
        return

    checkpoint_dir = create_checkpoint_folder()
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

    # Guardar resultados parciales
    checkpoint_results = f'checkpoint_results_{timestamp}.csv'
    df_results = pd.DataFrame(results)
    df_results.to_csv(checkpoint_dir / checkpoint_results, index=False)

    # Guardar estado del proceso
    checkpoint_state = {
        'fecha_inicio': start_time.strftime('%Y-%m-%d %H:%M:%S'),
        'ultimo_checkpoint': timestamp,
        'archivos_procesados': total_processed,
        'archivos_no_procesados': unprocessed_files
    }

    checkpoint_state_file = f'checkpoint_state_{timestamp}.csv'
    pd.DataFrame([checkpoint_state]).to_csv(checkpoint_dir / checkpoint_state_file, index=False)

    # Mantener solo los últimos 3 checkpoints
    cleanup_old_checkpoints()

def cleanup_old_checkpoints():
    """Mantiene solo los 3 checkpoints más recientes."""
    checkpoint_dir = pathlib.Path('0779665_extraccion_datos_peritajes/checkpoints')

    # Listar archivos de checkpoint por tipo
    results_files = sorted(checkpoint_dir.glob('checkpoint_results_*.csv'))
    state_files = sorted(checkpoint_dir.glob('checkpoint_state_*.csv'))

    # Eliminar checkpoints antiguos, manteniendo los 3 más recientes
    for files in [results_files, state_files]:
        while len(files) > 3:
            oldest_file = files.pop(0)
            oldest_file.unlink()

def load_latest_checkpoint() -> Tuple[list, list, int, datetime.datetime]:
    """Carga el checkpoint más reciente si existe."""
    checkpoint_dir = pathlib.Path('0779665_extraccion_datos_peritajes/checkpoints')

    if not checkpoint_dir.exists():
        return [], [], 0, datetime.datetime.now()

    # Buscar el checkpoint más reciente
    results_files = sorted(checkpoint_dir.glob('checkpoint_results_*.csv'), reverse=True)
    state_files = sorted(checkpoint_dir.glob('checkpoint_state_*.csv'), reverse=True)

    if not results_files or not state_files:
        return [], [], 0, datetime.datetime.now()

    # Cargar datos del checkpoint
    df_results = pd.read_csv(results_files[0])
    df_state = pd.read_csv(state_files[0])

    results = df_results.to_dict('records')
    state = df_state.iloc[0]

    start_time = datetime.datetime.strptime(state['fecha_inicio'], '%Y-%m-%d %H:%M:%S')
    unprocessed = state['archivos_no_procesados'] if isinstance(state['archivos_no_procesados'], list) else eval(state['archivos_no_procesados'])

    return results, unprocessed, state['archivos_procesados'], start_time

def normalize_text(text: str) -> str:
    """Normaliza el texto removiendo tildes y convirtiendo a minúsculas."""
    text = unicodedata.normalize('NFD', text).encode('ascii', 'ignore').decode('ascii')
    return text.lower()

def normalize_date(date_str: Optional[str]) -> Optional[str]:
    """
    Normaliza fechas en varios formatos a YYYY-MM-DD

    Args:
        date_str: String de fecha en formato '07 septiembre 2023' o '09 de octubre de 2024'

    Returns:
        String de fecha en formato 'YYYY-MM-DD' o None si no se puede parsear
    """
    if not date_str:
        return None

    # Diccionario de meses en español
    meses = {
        'enero': '01', 'febrero': '02', 'marzo': '03', 'abril': '04',
        'mayo': '05', 'junio': '06', 'julio': '07', 'agosto': '08',
        'septiembre': '09', 'octubre': '10', 'noviembre': '11', 'diciembre': '12'
    }

    try:
        date_str = date_str.lower().strip()
        date_str = date_str.replace('de ', '')
        parts = date_str.split()
        if len(parts) != 3:
            return None

        day, month, year = parts
        month_num = meses.get(month)
        if not month_num:
            return None

        date_obj = datetime.datetime(int(year), int(month_num), int(day))
        return date_obj.strftime('%Y-%m-%d')

    except (ValueError, KeyError, IndexError):
        return None

def normalize_monetary_value(value: Optional[str]) -> Optional[float]:
    """
    Normaliza valores monetarios a formato float estándar.

    Args:
        value: String con valor monetario en diferentes formatos:
            - '$46,830,000'
            - '46,830,000.00'
            - '46,830,000'
            - '36.580.000,00'

    Returns:
        Float con el valor normalizado o None si no se puede parsear
    """
    if not value:
        return None

    try:
        value = value.strip().replace('$', '').replace(' ', '')
        if not value:
            return None

        dots_count = value.count('.')
        commas_count = value.count(',')

        # Caso 1: formato con comas como separador de miles y punto decimal opcional
        if (commas_count >= 1 and dots_count <= 1) and ((dots_count == 0) or (dots_count == 1 and '.' in value[-3:])):
            value = value.replace(',', '')
        # Caso 2: formato con puntos como separador de miles y coma decimal
        elif dots_count >= 1 and commas_count == 1 and ',' in value[-3:]:
            value = value.replace('.', '').replace(',', '.')
        # Caso 3: formato con puntos como separador de miles
        elif dots_count >= 1 and commas_count == 0:
            value = value.replace('.', '')

        result = float(value)
        return round(result, 2)

    except (ValueError, AttributeError) as e:
        print(f"Error normalizando valor monetario '{value}': {str(e)}")
        return None

def validate_filename(filename: str) -> Tuple[bool, str]:
    """
    Valida si el nombre del archivo contiene el patrón ABC123.
    Retorna una tupla (es_válido, placa).
    """
    pattern = r'[A-Z]{3}\d{3}'
    match = re.search(pattern, filename)
    if match:
        return True, match.group(0)
    return False, None

def extract_placa(text: str) -> str:
    """
    Extrae la placa (formato ABC123) del texto markdown.
    """
    pattern = r'#\s*([A-Z]{3}\d{3})'
    match = re.search(pattern, text)
    return match.group(1) if match else None

def identify_company(md_text: str) -> Optional[str]:
    """
    Identifica la empresa que realizó el peritaje.
    Retorna None si no se encuentra ninguna empresa válida.
    """
    if re.search(r'Automás\s+Comercial\s+LTDA', md_text, re.IGNORECASE):
        return 'Automás Comercial LTDA'
    elif re.search(r'Colserauto\s+S\.A\.', md_text, re.IGNORECASE):
        return 'Colserauto S.A.'
    return None

def clean_value(value: str) -> str:
    """Limpia el valor extraído removiendo caracteres especiales de markdown."""
    if not value:
        return None
    value = value.strip('| \t').replace('*', '')
    return value.strip()

def clean_localizacion(value: str) -> str:
    """Limpia específicamente el campo de localización vehículo."""
    if not value:
        return None
    value = value.replace('**Localización Vehículo**', '')
    value = value.replace('N°', '')
    value = value.replace('*', '')
    value = re.sub(r'\b(el|en)\s+', '', value, flags=re.IGNORECASE)
    value = ' '.join(line.strip() for line in value.split('\n') if line.strip())
    return value.strip()

def signal_handler(signum, frame):
    """Maneja la interrupción del proceso guardando los resultados parciales."""
    print("\n\nProceso interrumpido. Guardando resultados parciales...")
    save_checkpoint()
    save_final_results()
    sys.exit(0)

def save_final_results():
    """Guarda los resultados finales y genera el log."""
    end_time = datetime.datetime.now()

    if results:
        output_file = '0779665_extraccion_datos_peritajes/resultados_procesamiento_19.csv'
        df_results = pd.DataFrame(results)
        df_results.to_csv(output_file, index=False)
        print(f'Resultados guardados en {output_file}')

    timestamp = start_time.strftime('%Y%m%d_%H%M%S')
    log_file = f'0779665_extraccion_datos_peritajes/log_extractor_avaluos_{timestamp}.csv'

    log_data = {
        'fecha_inicio': [start_time.strftime('%Y-%m-%d %H:%M:%S')],
        'fecha_fin': [end_time.strftime('%Y-%m-%d %H:%M:%S')],
        'archivos_procesados': [total_processed],
        'archivos_no_procesados': [len(unprocessed_files)],
        'nombres_archivos_no_procesados': [', '.join(f['nombre_archivo'] for f in unprocessed_files)]
    }

    pd.DataFrame(log_data).to_csv(log_file, index=False)
    print(f'Log guardado en {log_file}')

# ============================================================
# Definición de patrones por empresa

# Para AutoMás (se actualizan los patrones para cumplir con los 8 ejemplos)
automas_patterns = {
    'fecha_inspeccion': r'\*\*Fecha Inspecci[óòô]n\*\*\s*([^\n]+)',
    'localizacion_vehiculo': r'\*\*Servicio Domicilio\*\*\s*(?:SI|NO)\s*\n+(?:(?!\*\*)(.+?)\n+)?\*\*Localización Vehículo\*\*\s*(.+?)(?:\n+(?!\*\*)(.+?))?\s*\n+\*\*N° Inspección\*\*',
    'marca': r'(?:(?<=\n)(?!\*\*)(.+?)\s*\n)?\*\*Marca\*\*(?:\s*\*\*Regrabado\*\*)?\s*(\S.*?)\s*(?=\n|\*\*)',
    'linea': r'(?:(?<=\n)(?!\*\*)(.+?)\s*\n)?\*\*L[íìî]nea\*\*\s*(\[[^\]]+\])',
    'modelo': r'\*\*Modelo\*\*\s*(.*?)\s*\*\*(?:\[)?Propietario(?:\s*\])?\*\*',
    'resultado_final': r'\|Resultado Final\|(.*?)\|',
    'valor_mercado': r'\|Valor de Mercado de Acuerdo al Modelo\|\s*\$?\s*([\d.,]+)\s*\|',
    'avaluo': r'(?:\#{1,3})\s*Aval[úu]o[^$]*\$?\s*([\d.,]+)'
}

colserauto_patterns = {
    'fecha_inspeccion': r'\*\*FECHA DE INSPECCION\*\*\n(.*?)\n',
    'localizacion_vehiculo': r'\*\*LOCALIZACION\*\*\n[^\n]*placas[^\n]*inspeccionado\s*(.*?\n.*?)\n',
    'marca': r'\*\*Marca\*\*[_ ](.*?)\n',
    'linea': r'\*\*Línea\*\*[_ ](.*?)\n',
    'modelo': r'\*\*Modelo\*\*[_ ](.*?)\n',
    'resultado_final': r'\*\*Estado del vehículo: (.*?)(?:\.?\*\*)',
    'valor_mercado': r'\*\*Valor Razonable Automotor\*\*[_ ]\$?\s*([\d.,]+)',
    'avaluo': r'###[_ ]El[_ ]aval[úu]o[^$]*\$?\s*([\d.,]+)'
}

def extract_fields_from_markdown(md_text: str, filename: str, placa_filename: str) -> Dict[str, Any]:
    """Extrae los campos específicos del texto markdown."""
    fields = {
        'nombre_archivo_pdf': pathlib.Path(filename).stem,
        'placa': None,
        'placa_filename': placa_filename,
        'chequeo_placa': None,
        'fecha_inspeccion': None,
        'localizacion_vehiculo': None,
        'marca': None,
        'linea': None,
        'modelo': None,
        'resultado_final': None,
        'valor_mercado': None,
        'avaluo': None,
        'empresa_peritaje': None
    }

    # Extraer placa del texto markdown
    fields['placa'] = extract_placa(md_text)

    # Identificar empresa de peritaje
    fields['empresa_peritaje'] = identify_company(md_text)

    # Seleccionar patrones según la empresa
    patterns = colserauto_patterns if fields['empresa_peritaje'] == 'Colserauto S.A.' else automas_patterns

    # Comparar placas y establecer chequeo
    if fields['placa'] and fields['placa_filename']:
        fields['chequeo_placa'] = 'Si' if fields['placa'] == fields['placa_filename'] else 'No'
    else:
        fields['chequeo_placa'] = 'No'

    # Extraer cada campo según los patrones de la empresa correspondiente
    for field, pattern in patterns.items():
        match = re.search(pattern, md_text, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        if match:
            if field == 'localizacion_vehiculo' and fields['empresa_peritaje'] == 'Automás Comercial LTDA':
                # Se pueden capturar hasta 3 grupos: línea previa, línea principal y línea extra
                location_parts = []
                for i in range(1, (match.lastindex or 0) + 1):
                    part = match.group(i)
                    if part:
                        location_parts.append(clean_value(part))
                fields[field] = " ".join(location_parts)
            elif field == 'marca' and fields['empresa_peritaje'] == 'Automás Comercial LTDA':
                group1 = match.group(1) if (match.lastindex and match.lastindex >= 1 and match.group(1)) else ''
                group2 = match.group(2) if (match.lastindex and match.lastindex >= 2 and match.group(2)) else ''
                fields[field] = clean_value(group1 + group2) if group1 else clean_value(group2)
            elif field == 'linea' and fields['empresa_peritaje'] == 'Automás Comercial LTDA':
                group1 = match.group(1) if (match.lastindex and match.lastindex >= 1 and match.group(1)) else ''
                group2 = match.group(2) if (match.lastindex and match.lastindex >= 2 and match.group(2)) else ''
                if group1:
                    fields[field] = clean_value(group1) + " " + clean_value(group2)
                else:
                    fields[field] = clean_value(group2)
            elif field in ['valor_mercado', 'avaluo']:
                value = match.group(1)
                fields[field] = normalize_monetary_value(value)
            else:
                fields[field] = clean_value(match.group(1))

    # Normalizar la fecha después de la extracción
    fields['fecha_inspeccion'] = normalize_date(fields['fecha_inspeccion'])

    return fields

def process_pdf_file(pdf_path: pathlib.Path, placa_filename: str) -> Tuple[Dict[str, Any], Optional[Dict[str, str]]]:
    """
    Procesa un archivo PDF y retorna una tupla con:
    1. Diccionario con los campos extraídos o None si hay error
    2. Diccionario con información de error si ocurre uno
    """
    try:
        md_text = pymupdf4llm.to_markdown(str(pdf_path))

        # Identificar empresa primero
        empresa = identify_company(md_text)
        if not empresa:
            return None, {
                'nombre_archivo': pdf_path.name,
                'razon': 'Empresa de peritaje no identificada'
            }

        # Si la empresa es válida, continuar con el procesamiento
        fields = extract_fields_from_markdown(md_text, pdf_path.name, placa_filename)
        return fields, None

    except Exception as e:
        return None, {
            'nombre_archivo': pdf_path.name,
            'razon': f'Error procesando archivo: {str(e)}'
        }

def process_all_pdfs(folder_path: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Procesa todos los PDFs en una carpeta y retorna dos DataFrames:
    1. Resultados del procesamiento
    2. Archivos no procesados
    """
    global results, unprocessed_files, total_processed

    pdf_folder = pathlib.Path(folder_path)
    pdf_files = list(pdf_folder.glob('*.pdf'))

    # Verificar si hay un checkpoint previo
    loaded_results, loaded_unprocessed, loaded_total, loaded_start_time = load_latest_checkpoint()
    if loaded_results:
        print(f"\nCargando checkpoint previo con {len(loaded_results)} archivos procesados...")
        results = loaded_results
        unprocessed_files = loaded_unprocessed
        total_processed = loaded_total

        # Filtrar archivos ya procesados
        processed_files = {result['nombre_archivo_pdf'] for result in results}
        pdf_files = [f for f in pdf_files if f.stem not in processed_files]

    total_files = len(pdf_files)
    bar_width = 50

    print(f"\nIniciando procesamiento de {total_files} archivos PDF restantes...")
    print(f"Hora de inicio: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    try:
        for i, pdf_file in enumerate(pdf_files, 1):
            is_valid, placa_filename = validate_filename(pdf_file.name)

            if not is_valid:
                unprocessed_files.append({
                    'nombre_archivo': pdf_file.name,
                    'razon': 'Nombre de archivo no contiene placa válida'
                })
                continue

            progress = i / total_files
            filled_length = int(bar_width * progress)
            bar = '=' * filled_length + '-' * (bar_width - filled_length)
            percentage = progress * 100

            print(f'\rArchivo {i}/{total_files} [{bar}] {percentage:.1f}%__', end='', flush=True)

            result, error = process_pdf_file(pdf_file, placa_filename)

            if error:
                unprocessed_files.append(error)
            elif result:
                results.append(result)
                total_processed += 1

            if total_processed % CHECKPOINT_INTERVAL == 0:
                save_checkpoint()

    except Exception as e:
        print(f"\nError durante el procesamiento: {str(e)}")
        save_checkpoint()
        raise

    end_time = datetime.datetime.now()
    print(f'\nProcesamiento completado.')
    print(f"Hora de finalización: {end_time.strftime('%Y-%m-%d %H:%M:%S')}")

    return pd.DataFrame(results), pd.DataFrame(unprocessed_files)

# Ejemplo de uso
if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal_handler)
    atexit.register(save_checkpoint)
    start_time = datetime.datetime.now()

    folder_path = '0779665_extraccion_datos_peritajes/avaluos_prueba'
    df_results, _ = process_all_pdfs(folder_path)
    save_final_results()