"""
Estrategia de chunking recursivo.

Corta el texto intentando respetar separadores naturales, en orden de
preferencia: parrafos, luego lineas, luego oraciones. Solo si un
fragmento sigue siendo mas grande que el tamano objetivo despues de
agotar esos separadores, se recurre a un corte ciego por tokens como
ultimo recurso.

Es el default general: un buen punto de partida cuando el corpus no
tiene una estructura fuerte evidente (a diferencia de codigo o texto
legal, que si la tienen).

El conteo de tokens usa tiktoken (codificacion cl100k_base, la misma
familia que usan los modelos de OpenAI). No es el tokenizador nativo
de Qwen3 -- ningun tokenizador de tiktoken lo es -- pero da un conteo
consistente y mucho mas preciso que aproximar por caracteres, sin
anadir la dependencia mas pesada del tokenizador real de Qwen3.
"""

import tiktoken

from rag_api.chunking.base import ChunkGenerado, EstrategiaChunkingBase

_ENCODING = tiktoken.get_encoding("cl100k_base")

SEPARADORES_EN_ORDEN = [
    "\n\n",  # parrafos
    "\n",    # lineas
    ". ",    # oraciones
]


def _contar_tokens(texto: str) -> int:
    return len(_ENCODING.encode(texto))


class ChunkingRecursivo(EstrategiaChunkingBase):
    def chunkear(
        self,
        texto: str,
        tamano_tokens: int,
        overlap_tokens: int,
        lenguaje_codigo: str | None = None,
        fuente: str | None = None,
    ) -> list[ChunkGenerado]:
        fragmentos = self._dividir_recursivo(texto, tamano_tokens, nivel_separador=0)
        fragmentos_con_overlap = self._aplicar_overlap(fragmentos, overlap_tokens)

        return [ChunkGenerado(texto=fragmento) for fragmento in fragmentos_con_overlap if fragmento.strip()]

    def _dividir_recursivo(
        self,
        texto: str,
        tamano_tokens: int,
        nivel_separador: int,
    ) -> list[str]:
        if _contar_tokens(texto) <= tamano_tokens:
            return [texto]

        if nivel_separador >= len(SEPARADORES_EN_ORDEN):
            # Se agotaron los separadores naturales: corte ciego por tokens
            return self._corte_ciego(texto, tamano_tokens)

        separador = SEPARADORES_EN_ORDEN[nivel_separador]
        partes = texto.split(separador)

        if len(partes) == 1:
            # Este separador no aparece en el texto, se intenta con el siguiente
            return self._dividir_recursivo(texto, tamano_tokens, nivel_separador + 1)

        fragmentos: list[str] = []
        acumulado = ""

        for parte in partes:
            candidato = acumulado + separador + parte if acumulado else parte

            if _contar_tokens(candidato) <= tamano_tokens:
                acumulado = candidato
            else:
                if acumulado:
                    fragmentos.append(acumulado)
                if _contar_tokens(parte) > tamano_tokens:
                    # La parte individual sigue siendo muy grande: se sigue
                    # recursando con el siguiente separador
                    fragmentos.extend(
                        self._dividir_recursivo(parte, tamano_tokens, nivel_separador + 1)
                    )
                    acumulado = ""
                else:
                    acumulado = parte

        if acumulado:
            fragmentos.append(acumulado)

        return fragmentos

    @staticmethod
    def _corte_ciego(texto: str, tamano_tokens: int) -> list[str]:
        tokens = _ENCODING.encode(texto)
        fragmentos = []
        for i in range(0, len(tokens), tamano_tokens):
            fragmento_tokens = tokens[i : i + tamano_tokens]
            fragmentos.append(_ENCODING.decode(fragmento_tokens))
        return fragmentos

    @staticmethod
    def _aplicar_overlap(fragmentos: list[str], overlap_tokens: int) -> list[str]:
        if overlap_tokens <= 0 or len(fragmentos) <= 1:
            return fragmentos

        con_overlap = [fragmentos[0]]
        for i in range(1, len(fragmentos)):
            tokens_anterior = _ENCODING.encode(fragmentos[i - 1])
            cola_tokens = tokens_anterior[-overlap_tokens:]
            cola_texto = _ENCODING.decode(cola_tokens)
            con_overlap.append(cola_texto + fragmentos[i])

        return con_overlap
