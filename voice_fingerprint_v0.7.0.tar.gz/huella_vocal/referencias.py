"""Lectura de la carpeta de referencias y de la convención de nombres.

Dos formatos conviven en la carpeta:

- Archivos existentes: `nombre.wav`, `nombre_pais.wav` o `nombre_pais_2.wav`.
  Si la última parte es un código de país conocido, es el origen; un número
  final después de nombre y país indica otra grabación de la misma persona.

- Hablantes de los corpus de OpenSLR con su código original: `cof_01523.wav`
  (co = Colombia, f = mujer, 01523 = hablante). Cada código es una persona.

- Registros desde la web: `persona__web__AAAAMMDD-HHMMSS__n.wav`, con un JSON
  acompañante `persona__web__AAAAMMDD-HHMMSS.json` que guarda el nombre para
  mostrar, el origen y el consentimiento.
"""

import hashlib
import json
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .config import PAISES

SEPARADOR_WEB = "__"

# Códigos de hablante de los corpus de español de OpenSLR (país + sexo + número).
CORPUS_PAISES = {"co": "Colombia", "ar": "Argentina", "cl": "Chile", "pe": "Perú", "pr": "Puerto Rico", "ve": "Venezuela"}
_CODIGO_CORPUS = re.compile(r"(co|ar|cl|pe|pr|ve)([fm])_(\d+)")


@dataclass
class Referencia:
    archivo: Path
    persona_id: str
    nombre_mostrar: str
    origen: str | None = None
    fuente: str = "archivo"           # "archivo" | "web"
    sesion: str | None = None         # fecha-hora de la sesión web
    consentimiento: dict | None = field(default=None, repr=False)

    def como_dict(self):
        datos = asdict(self)
        datos["archivo"] = self.archivo.name
        return datos


def slug(texto):
    """Minúsculas, sin tildes, solo letras/números separados por guion bajo."""
    sin_tildes = unicodedata.normalize("NFKD", texto.lower())
    sin_tildes = "".join(c for c in sin_tildes if not unicodedata.combining(c))
    partes = "".join(c if c.isalnum() else " " for c in sin_tildes).split()
    return "_".join(partes)


def interpretar_nombre(ruta):
    ruta = Path(ruta)
    base = ruta.stem
    partes_web = base.split(SEPARADOR_WEB)

    if len(partes_web) == 4 and partes_web[1] == "web":
        persona_id, _, sesion, _ = partes_web
        acompanante = ruta.with_name(SEPARADOR_WEB.join(partes_web[:3]) + ".json")
        meta = {}
        if acompanante.is_file():
            meta = json.loads(acompanante.read_text(encoding="utf-8"))
        return Referencia(
            archivo=ruta,
            persona_id=persona_id,
            nombre_mostrar=meta.get("nombre_mostrar") or persona_id.replace("_", " ").title(),
            origen=meta.get("origen"),
            fuente="web",
            sesion=sesion,
            consentimiento=meta.get("consentimiento"),
        )

    corpus = _CODIGO_CORPUS.fullmatch(base.lower())
    if corpus:
        pais, sexo, numero = corpus.groups()
        return Referencia(
            archivo=ruta,
            persona_id=base.lower(),
            nombre_mostrar=f"{'Mujer' if sexo == 'f' else 'Hombre'} {numero}",
            origen=CORPUS_PAISES[pais],
        )

    # Se trabaja con las partes originales (conservan tildes para mostrar)
    # y con su versión normalizada (para el identificador).
    originales = [p for p in base.replace("-", "_").replace(" ", "_").split("_") if p]
    if len(originales) > 2 and originales[-1].isdigit():
        originales = originales[:-1]              # nombre_pais_2 → otra grabación
    origen = None
    nombre = originales
    if len(originales) > 1 and slug(originales[-1]) in PAISES:
        origen = PAISES[slug(originales[-1])]
        nombre = originales[:-1]
    return Referencia(
        archivo=ruta,
        persona_id=slug("_".join(originales)),
        nombre_mostrar=" ".join(p.capitalize() for p in nombre),
        origen=origen,
    )


def listar_referencias(directorio):
    return [interpretar_nombre(r) for r in sorted(Path(directorio).glob("*.wav"))]


def hash_archivo(ruta, bloque=1 << 20):
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        while datos := f.read(bloque):
            h.update(datos)
    return h.hexdigest()
