# build_exe.py - Versión simplificada y robusta
import os
import sys
import subprocess

def build_exe():
    """
    Construye el ejecutable para el Convertidor de Audio MP3/WAV.
    """
    print("Iniciando construcción del ejecutable...")
    
    # Verificar que existe la carpeta ffmpeg
    ffmpeg_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ffmpeg')
    if not os.path.exists(ffmpeg_dir):
        print("ADVERTENCIA: La carpeta 'ffmpeg' no existe. Se recomienda crear esta carpeta")
        print("y colocar ffmpeg.exe, ffprobe.exe y ffplay.exe dentro de ella.")
        input("Presione Enter para continuar de todos modos...")
    
    # Construir comando PyInstaller directamente
    cmd = [
        'pyinstaller',
        '--name=AudioConverter',
        '--onefile',
        '--windowed',
        '--clean',
        '--noconfirm'
    ]
    
    # Agregar la carpeta ffmpeg si existe
    if os.path.exists(ffmpeg_dir):
        cmd.append(f'--add-data={ffmpeg_dir};ffmpeg')
    
    # Agregar el script principal
    cmd.append('main.py')
    
    # Ejecutar PyInstaller como proceso
    print("\nEjecutando PyInstaller con el siguiente comando:")
    print(" ".join(cmd))
    print("\nEsto puede tomar varios minutos...\n")
    
    try:
        process = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print("Construcción completada exitosamente!")
        print(f"El ejecutable se encuentra en: {os.path.join(os.getcwd(), 'dist', 'AudioConverter.exe')}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error durante la construcción: {e}")
        print("\nSalida de error:")
        print(e.stderr)
        return False

if __name__ == "__main__":
    build_exe()
