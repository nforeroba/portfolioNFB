"""
API de tipificación de llamadas.
Endpoints:
  POST /inference  → recibe prompt, devuelve respuesta del modelo
  GET  /health     → estado del servicio y modelo cargado
"""

import asyncio
import logging
from contextlib import asynccontextmanager

import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from app.model_loader import load_model, get_model_info

# ── Logging ───────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ── Estado global ─────────────────────────────────────────────────────────────

model     = None
tokenizer = None
semaphore = asyncio.Semaphore(3)  # máximo 3 requests simultáneos

# ── Parámetros de generación ──────────────────────────────────────────────────

MAX_NEW_TOKENS  = 1024
TEMPERATURE     = 0.1   # baja temperatura para respuestas consistentes/deterministas
DO_SAMPLE       = True

# ── Lifespan: carga el modelo al iniciar ─────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    global model, tokenizer
    logger.info("Iniciando servicio — cargando modelo...")
    model, tokenizer = load_model()
    logger.info("Modelo listo. Servicio disponible.")
    yield
    logger.info("Apagando servicio.")
    del model
    del tokenizer
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Tipificador de Llamadas",
    description="Inferencia LLM para tipificación de llamadas en español.",
    version="1.0.0",
    lifespan=lifespan,
)

# ── Schemas ───────────────────────────────────────────────────────────────────

class InferenceRequest(BaseModel):
    prompt: str

class InferenceResponse(BaseModel):
    respuesta: str

# ── Inferencia (sincrónica, ejecutada en threadpool) ──────────────────────────

def _run_inference(prompt: str) -> str:
    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=False,
    ).to(model.device)

    input_len = inputs["input_ids"].shape[-1]
    logger.info(f"Tokens de entrada: {input_len}")

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            temperature=TEMPERATURE,
            do_sample=DO_SAMPLE,
            pad_token_id=tokenizer.eos_token_id,
        )

    # Decodifica solo los tokens nuevos, no el prompt
    new_tokens = outputs[0][input_len:]
    respuesta  = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    logger.info(f"Tokens generados: {len(new_tokens)}")
    return respuesta

# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.post("/inference", response_model=InferenceResponse)
async def inference(request: InferenceRequest):
    if not request.prompt.strip():
        raise HTTPException(status_code=400, detail="El campo 'prompt' no puede estar vacío.")

    async with semaphore:
        logger.info("Request de inferencia recibido — procesando...")
        try:
            respuesta = await asyncio.get_event_loop().run_in_executor(
                None, _run_inference, request.prompt
            )
        except Exception as e:
            logger.error(f"Error durante inferencia: {e}")
            raise HTTPException(status_code=500, detail=f"Error de inferencia: {str(e)}")

    return InferenceResponse(respuesta=respuesta)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "modelo": get_model_info(),
        "slots_disponibles": semaphore._value,
    }
