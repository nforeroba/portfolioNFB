"""Núcleo de huella vocal: audio, VAD (Silero o TEN), huella ECAPA, perfil acústico,
prueba de vida y referencias. No depende de la web; lo usa el servicio (carpeta servicio/).
"""
