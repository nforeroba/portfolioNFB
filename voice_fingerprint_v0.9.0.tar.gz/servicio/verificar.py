"""Verificación sin red del entorno del servicio: python -m servicio.verificar

La ejecuta construir_imagen.sh con el contenedor SIN red (--network none), y se puede
correr en cualquier momento. Comprueba que:
  1. los modelos locales estén completos y sean exactamente los esperados (hash);
  2. los dos VAD (Silero y TEN), ECAPA-TDNN y faster-whisper carguen sin internet;
  3. cada modelo procese una señal de prueba;
  4. con VF_DISPOSITIVO=gpu, qué modelos quedan en GPU (si la GPU no sirve, siguen en CPU
     con una advertencia: eso no es un error).
No usa Qdrant. Termina con código 0 si todo está bien.
"""

import importlib.util
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np


def _cargar_verificador(dir_modelos):
    """La copia de descargar_modelos.py que viaja con los modelos (o la de codigo/construccion)."""
    candidatos = [dir_modelos / "descargar_modelos.py",
                  Path(__file__).resolve().parents[1] / "construccion" / "descargar_modelos.py"]
    for ruta in candidatos:
        if ruta.is_file():
            spec = importlib.util.spec_from_file_location("descargar_modelos", ruta)
            modulo = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(modulo)
            return modulo
    return None


def _senal_prueba(segundos=3.0, sr=16000):
    """Una vocal sintética (armónicos con vibrato y modulación de amplitud) más un poco de ruido."""
    t = np.arange(int(segundos * sr)) / sr
    f0 = 140 + 10 * np.sin(2 * np.pi * 4 * t)
    fase = 2 * np.pi * np.cumsum(f0) / sr
    voz = sum(np.sin(k * fase) / k for k in range(1, 12))
    voz *= 0.5 * (1 + np.sin(2 * np.pi * 3 * t))
    rng = np.random.default_rng(0)
    return (0.1 * voz / np.max(np.abs(voz)) + 0.003 * rng.standard_normal(len(t))).astype(np.float32)


def _nombre(dispositivo):
    return "GPU" if dispositivo == "cuda" else "CPU"


def main():
    from huella_vocal.config import VERSION, comprobar_modelos, dispositivo_configurado

    dir_modelos = Path(os.environ.get("VF_MODELOS") or Path(__file__).resolve().parents[2] / "modelos").resolve()
    print(f"voice_fingerprint {VERSION} — verificación sin red")
    print(f"  arquitectura: {platform.machine()}, Python {platform.python_version()}")
    print(f"  modelos: {dir_modelos}")
    print(f"  HF_HUB_OFFLINE={os.environ.get('HF_HUB_OFFLINE')}")
    dispositivo = dispositivo_configurado()
    import torch
    gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "ninguna visible"
    print(f"  VF_DISPOSITIVO={dispositivo} · PyTorch {torch.__version__} (CUDA {torch.version.cuda}) · GPU: {gpu}")

    paso = 0

    def titulo(texto):
        nonlocal paso
        paso += 1
        print(f"[{paso}] {texto}", flush=True)

    titulo("Archivos de los modelos y sus hashes")
    rutas = comprobar_modelos(dir_modelos)
    verificador = _cargar_verificador(dir_modelos)
    if verificador is None:
        print("    (no se encontró la tabla de hashes; solo se comprobó que los archivos existen)")
    else:
        verificador.verificar_carpeta(dir_modelos)
        print("    todos coinciden")

    senal = _senal_prueba()

    from huella_vocal.vad import DetectorSilero, DetectorTen

    for nombre, fabrica in (("Silero VAD", DetectorSilero), ("TEN VAD", lambda: DetectorTen(rutas["ten_vad"]))):
        titulo(f"{nombre}: carga y detección")
        t = time.perf_counter()
        detector = fabrica()
        segmentos = detector.segmentos(senal)
        print(f"    OK en {time.perf_counter() - t:.2f} s ({len(segmentos)} segmento(s) en la señal de prueba)")

    titulo("ECAPA-TDNN: carga y huella")
    from huella_vocal.huella import ExtractorHuella

    t = time.perf_counter()
    extractor = ExtractorHuella(rutas["ecapa"], dispositivo=dispositivo)
    huella = extractor.extraer(senal)
    if huella.shape != (192,) or not np.all(np.isfinite(huella)):
        raise SystemExit(f"ERROR: la huella tiene forma {huella.shape} o valores no finitos.")
    print(f"    OK en {time.perf_counter() - t:.2f} s (192 valores, norma {np.linalg.norm(huella):.3f}) "
          f"· dispositivo: {_nombre(extractor.dispositivo)}")
    if extractor.aviso:
        print(f"    ADVERTENCIA: {extractor.aviso}")

    titulo("faster-whisper base: carga y transcripción")
    from huella_vocal.prueba_vida import Transcriptor

    t = time.perf_counter()
    transcriptor = Transcriptor(rutas["whisper"], dispositivo=dispositivo)
    texto, _ = transcriptor.transcribir_detallado(senal)
    print(f"    OK en {time.perf_counter() - t:.2f} s (transcripción de prueba: «{texto[:40]}») "
          f"· dispositivo: {_nombre(transcriptor.dispositivo)}")
    if transcriptor.aviso:
        print(f"    ADVERTENCIA: {transcriptor.aviso}")

    print("VERIFICACIÓN COMPLETA: todo carga y funciona sin internet.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
