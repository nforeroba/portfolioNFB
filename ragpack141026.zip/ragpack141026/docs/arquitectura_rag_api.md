# Arquitectura de la API de RAG

**Estado:** Diseño / prototipado
**Última actualización:** 20 de agosto de 2026
**Contexto:** Mover el contexto que hoy vive como prompts largos hacia una base de conocimiento vectorial externa, consultable en tiempo de inferencia, para servicios que integran LLMs (voicebot de cobranza, copiloto jurídico, copiloto de código).

---

## 1. Objetivo

Actualmente, varios servicios de inferencia (motores Ollama y vLLM) manejan contextos largos a nivel de *prompt* para cumplir instrucciones y tareas de negocio. El objetivo es extraer ese contexto hacia una **Vector Database (VDB)** de acceso rápido, para que:

- El conocimiento de negocio se actualice sin tocar despliegues ni prompts.
- El contexto sea dinámico, categorizado y consultable bajo demanda.
- Cada servicio externo reciba solo la información relevante a su consulta, no el conocimiento completo.

Los servicios externos consumidores tienen perfiles de carga muy distintos:

| Servicio | Perfil de tráfico | Prioridad |
|---|---|---|
| Voicebot (bancos A, B, C) | Tiempo real, múltiples llamadas concurrentes | Latencia mínima |
| Copiloto jurídico (jurisprudencia) | No tiempo real, corpus grande | Calidad de retrieval |
| Copiloto de código | No tiempo real, contenido estructurado (código) | Calidad de retrieval, preservar unidades de código |

Esta diferencia de perfiles es la que determina casi todas las decisiones de arquitectura que siguen.

---

## 2. Glosario de conceptos clave

| Término | Definición |
|---|---|
| **Embedding** | Vector numérico que representa el significado de un texto |
| **Cosine similarity** | Métrica que mide el ángulo entre dos vectores para estimar qué tan parecidos son |
| **Vector Database (VDB)** | Base de datos especializada en almacenar vectores y buscar los más cercanos a gran velocidad |
| **Chunk / Chunking** | Fragmento de un documento con sentido propio / el proceso de cortar el documento en esos fragmentos |
| **HNSW** (Hierarchical Navigable Small World) | Algoritmo/estructura que Qdrant usa para buscar vecinos cercanos sin comparar contra todos los vectores |
| **Bi-encoder** | Modelo que vectoriza la consulta y los documentos por separado (ej. el modelo de embeddings) |
| **Cross-encoder / Reranker** | Modelo que compara consulta y candidato juntos, en una sola pasada, para un puntaje más preciso |
| **BM25 / sparse search** | Búsqueda por coincidencia de palabras clave, con pesos según frecuencia/rareza |
| **Hybrid search** | Combinar búsqueda densa (embeddings) y dispersa (BM25) en la misma consulta |
| **RRF** (Reciprocal Rank Fusion) | Método para fusionar dos rankings con escalas incompatibles, usando la posición (rank), no el puntaje crudo |
| **MTEB** | Benchmark estándar que compara modelos de embeddings en distintos idiomas y tareas |
| **Multitenancy** | Que varios "inquilinos" (categorías/clientes) convivan en la misma infraestructura de forma aislada |
| **Payload filtering** | Filtrar resultados de búsqueda vectorial por metadata (ej. categoría) |
| **AST-aware chunking (cAST)** | Chunking de código que respeta límites de función/clase usando el árbol sintáctico (Tree-sitter) |
| **Chunking jerárquico (padre-hijo)** | Buscar con un chunk pequeño y preciso, pero devolver al LLM el chunk "padre" con más contexto |

### Parámetros de HNSW

HNSW organiza los vectores en un grafo de niveles: pocos nodos muy conectados en el nivel superior (saltos largos), cada vez más nodos y conexiones más locales en niveles inferiores, hasta llegar a un nivel base que contiene todos los puntos. Tres parámetros controlan el comportamiento de ese grafo:

| Parámetro | Cuándo actúa | Qué controla | Efecto de subirlo |
|---|---|---|---|
| **`m`** | Al insertar un punto (ingesta) | Cuántos vecinos se conectan a cada punto nuevo en el grafo | Más memoria por punto, mayor precisión de búsqueda, construcción del índice más lenta |
| **`ef_construct`** | Al insertar un punto (ingesta) | Cuántos candidatos se evalúan antes de elegir los `m` vecinos definitivos de ese punto | Ingesta más lenta, pero mejores conexiones a largo plazo — beneficia a todas las búsquedas futuras que pasen por ese punto |
| **`ef` (o `ef_search`)** | En cada consulta (retrieval) | Cuántos candidatos explora el grafo antes de devolver el top-K final | Búsquedas más lentas, pero con mayor probabilidad de encontrar el verdadero vecino más cercano |

**Relación entre ellos:** `m` y `ef_construct` fijan la *calidad estructural* del grafo en el momento en que se construye (no se pueden cambiar después sin reconstruir el índice); `ef` es el único que se puede ajustar libremente en cada consulta, sin tocar el grafo ya construido — es la palanca más flexible para balancear velocidad/precisión en tiempo real.

**Aplicado a las dos colecciones de este diseño:**

| Parámetro | `rag_voicebot_0_6b` (rápido) | `rag_copilotos_8b` (preciso) |
|---|---|---|
| `m` | Bajo (≈12–16) | Alto (≈32–48) |
| `ef_construct` | Bajo-medio (≈100) | Alto (≈200–400) |
| `ef` (por consulta) | Bajo (≈32–64) | Alto (≈128–256) |

Para el voicebot esto casi no sacrifica precisión real: al ser un universo de búsqueda chico por categoría (cientos/pocos miles de chunks), hay poco margen de error del cual un grafo más denso podría "salvar" — el ahorro en velocidad no cuesta calidad proporcional.

---

## 3. Decisiones de arquitectura y su justificación

### 3.1 Vector Database: Qdrant

| Criterio | Qdrant | ChromaDB | Milvus |
|---|---|---|---|
| Soporte ARM64 (GX10) | Nativo, oficial | Sí, pero pensado para prototipado | Sí en standalone, pero con dependencias pesadas (etcd, MinIO) |
| Hybrid search nativo | Sí | No | Sí |
| Multitenancy | Payload filtering + custom sharding + tiered | Colecciones, sin aislamiento de recursos | Soportado, más fricción operativa |
| Techo de escala práctico | Alto | ~1M vectores por nodo | Muy alto (pensado para clústeres masivos) |
| Complejidad operativa (nodo único) | Baja | Muy baja (embebido) | Alta |
| Licencia | Apache 2.0, on-premises gratis | Apache 2.0 | Apache 2.0 |

**Decisión:** Qdrant, autohospedado, sobre la GX10. ChromaDB queda como herramienta válida solo para prototipado rápido/local. Milvus es sobredimensionado para el volumen esperado.

### 3.2 Multitenancy: una colección por modelo de embedding, con payload filtering por categoría

La guía oficial de Qdrant desaconseja crear una colección por cada categoría/cliente (el límite práctico en Qdrant Cloud es 1000 colecciones por clúster, y el overhead de recursos escala mal). El patrón recomendado es:

- **Una sola colección por modelo de embeddings** (los vectores de dos modelos distintos no son comparables entre sí).
- **Payload filtering** con un campo `categoria` indexado como `is_tenant=true`, que Qdrant optimiza para que el filtro corra *dentro* del recorrido del grafo HNSW, no después.
- **Custom sharding** disponible para categorías de mayor volumen o que requieran aislamiento físico más fuerte.
- **Colecciones separadas de verdad** quedan reservadas solo para requisitos regulatorios explícitos de aislamiento/encriptación por tenant — no es el caso por defecto.

**Por qué se necesitan dos colecciones en este diseño:** no es por categoría de negocio, sino porque **el modelo de embedding usado en cada path es distinto** (0.6B vs. 8B), y sus espacios vectoriales no son compatibles entre sí — comparar un vector de un modelo contra otro no tiene sentido matemático, como usar las coordenadas de un mapa para navegar en otro.

```
Colección: rag_voicebot_0_6b     → vectores de qwen3-embedding:0.6b (categorías banco_a, banco_b, banco_c, marco_legal_cobranza)
Colección: rag_copilotos_8b       → vectores de qwen3-embedding:8b (categorías juridico, codigo)
```

### 3.3 Categorías transversales

Existe información que aplica a todas las categorías de un mismo tipo de servicio (ej. el marco legal de cobranza de la Superintendencia Financiera, aplicable a todos los bancos). Esto se resuelve con un filtro de tipo "pertenece a este conjunto", no de igualdad estricta:

```
filtro: categoria IN ["banco_a", "marco_legal_cobranza"]
```

El contenido transversal se indexa una sola vez, sin duplicarlo por categoría, con un campo de metadata opcional (`alcance: "transversal"`) para facilitar su inclusión automática en el filtrado.

### 3.4 Dos motores de inferencia, según perfil de latencia

| | Path Voicebot | Path Copilotos (jurídico/código) |
|---|---|---|
| Prioridad | Velocidad, baja latencia, alta concurrencia | Calidad de retrieval |
| Volumen del corpus por categoría | Chico (cientos/pocos miles de chunks) | Grande |
| Modelo de embedding | `qwen3-embedding:0.6b` | `qwen3-embedding:8b` |
| Modelo de reranking | — | `qwen3-reranker:8b` |
| Motor de inferencia | **vLLM** (continuous batching, necesario para concurrencia) | **Ollama** (suficiente sin presión de concurrencia) |
| Hybrid search (denso + BM25) | No | Sí |
| Reranking (cross-encoder) | No | Sí — `qwen3-reranker:8b` (Ollama) |
| Colección Qdrant | `rag_voicebot_0_6b` | `rag_copilotos_8b` |
| Parámetros HNSW | `m` y `ef` bajos (prioriza velocidad) | `m` y `ef` altos (prioriza precisión) |

**Por qué vLLM solo en el path del voicebot:** benchmarks muestran que Ollama pierde throughput drásticamente bajo carga concurrente (p99 de latencia sube a ~25s con 50 requests simultáneos, contra <3s de vLLM), aunque Ollama es ligeramente más rápido en peticiones aisladas. El voicebot es el único servicio con concurrencia real esperada (varias llamadas simultáneas), por lo que es el único que justifica el costo de operar vLLM.

**Nota de infraestructura (GX10):** vLLM no tiene soporte oficial de NVIDIA/proyecto vLLM para la arquitectura del DGX Spark (sm_121). Existen imágenes Docker comunitarias parcheadas (ej. `hellohal2064/vllm-dgx-spark-gb10`) con el modo de embeddings (pooling) verificado para Qwen3-Embedding-8B. Plan de contingencia acordado:
1. Probar la imagen comunitaria con el modelo 0.6B.
2. Si falla, desarrollar con Ollama también para el voicebot mientras se resuelve.
3. Para producción, si la latencia de Ollama es un problema real, migrar ese servicio específico a hardware x86 con GPU discreta (RTX 4000/5000) donde vLLM sí tiene soporte oficial.

### 3.5 Por qué se necesita un reranker además del embedding

El modelo de embeddings es un **bi-encoder**: vectoriza la consulta y cada chunk por separado, sin que se "vean" entre sí — esto es lo que permite precalcular millones de vectores y buscar rápido, pero es una comparación indirecta y aproximada.

El **reranker** es un **cross-encoder**: procesa la consulta y un chunk candidato *juntos*, en una sola pasada, dando un puntaje mucho más preciso — pero no puede precalcularse, por lo que no escala a millones de comparaciones.

Por eso se usan en cadena: el bi-encoder hace una primera pasada rápida sobre todo el corpus (trae 50-100 candidatos), y el cross-encoder reordena solo esos pocos candidatos con mayor precisión. En el path del voicebot se omite el reranker porque el universo de búsqueda por categoría ya es chico — hay poco margen de error del que el reranker pueda "salvar".

### 3.6 Chunking heterogéneo, aplicado por categoría — con matiz empírico importante

La estrategia de chunking varía según el tipo de contenido, pero **la evidencia de benchmarks 2026 muestra que la estrategia "más sofisticada" no siempre gana**: en corpus generales, el chunking recursivo de tamaño fijo con overlap superó al chunking semántico (69% vs. 54% de precisión end-to-end) porque el semántico, aunque más "puro" temáticamente, a veces deja fragmentos sin suficiente contexto para que el LLM responda bien. En dominios con estructura fuerte e inherente (legal, código), sí se confirma que una estrategia consciente de esa estructura gana claramente.

**Conclusión de diseño:** la estrategia óptima debe medirse contra el corpus y las preguntas reales de cada categoría, no asumirse. Por eso el contrato de la API expone todas las estrategias como opciones explícitas e igualmente disponibles, sin una "recomendación automática" oculta.

| Estrategia | Cuándo tiene sentido |
|---|---|
| `CHUNKING_RECURSIVO` | Default general — corpus sin estructura fuerte evidente, o como punto de partida antes de medir |
| `CHUNKING_FIJO` | Punto de comparación/control frente al recursivo |
| `CHUNKING_SEMANTIC` | Corpus largo de prosa, cuando el recall temático importa más que el contexto amplio |
| `CHUNKING_AST_CODIGO` | Copiloto de código — nunca fragmenta funciones/clases (Tree-sitter, patrón cAST) |
| `CHUNKING_CLAUSULA_LEGAL_JERARQUICA` | Copiloto jurídico — respeta artículos/cláusulas y conserva el capítulo/sección como contexto padre |

Para contenido donde el cliente ya conoce sus propias unidades de sentido (ej. los prompts de saludo, gestión de cobranza y despedida del voicebot), la API acepta chunks ya cortados por el cliente, sin aplicar ninguna heurística automática.

---

## 4. Flujo completo — Ingesta

```mermaid
flowchart TD
    A[Fuente de datos:<br/>manuales, transcripciones,<br/>OCR, prompts] --> B{Modo de ingesta}
    B -->|Documento completo| C[Chunking según<br/>estrategia elegida]
    B -->|Chunks pre-cortados| D[Chunks tal cual<br/>los entrega el cliente]
    C --> E[rag-api: Ingest]
    D --> E
    E --> F{Categoría del chunk}
    F -->|banco_a/b/c,<br/>marco_legal_cobranza| G[Embedding<br/>qwen3-embedding:0.6b<br/>vLLM]
    F -->|juridico, codigo| H[Embedding<br/>qwen3-embedding:8b<br/>Ollama]
    G --> I[(Qdrant<br/>rag_voicebot_0_6b)]
    H --> J[(Qdrant<br/>rag_copilotos_8b)]

    classDef mono fill:#ffffff,stroke:#000000,stroke-width:1.5px,color:#000000;
    class A,B,C,D,E,F,G,H,I,J mono;
```

---

## 5. Flujo completo — Retrieval (dos caminos)

### 5.1 Camino rápido — Voicebot

```mermaid
flowchart TD
    V1[Voicebot<br/>bancos A/B/C] -->|"perfil = RAPIDO"| V2[rag-api]
    V2 --> V3[Embedding<br/>qwen3-embedding:0.6b<br/>vLLM]
    V3 --> V4[(Qdrant<br/>rag_voicebot_0_6b<br/>filtro: categoria IN banco_x, marco_legal)]
    V4 --> V5[Top-K directo]
    V5 --> V6[Respuesta al voicebot]

    classDef mono fill:#ffffff,stroke:#000000,stroke-width:1.5px,color:#000000;
    class V1,V2,V3,V4,V5,V6 mono;
```

### 5.2 Camino preciso — Copilotos

```mermaid
flowchart TD
    C1[Copiloto jurídico<br/>o de código] -->|"perfil = PRECISO"| C2[rag-api]
    C2 --> C3[Embedding<br/>qwen3-embedding:8b<br/>Ollama]
    C3 --> C4[(Qdrant<br/>rag_copilotos_8b<br/>hybrid: denso + sparse)]
    C4 --> C5[RRF<br/>fusión de rankings]
    C5 --> C6[Reranker<br/>qwen3-reranker:8b<br/>Ollama]
    C6 --> C7[Top-K final]
    C7 --> C8[Respuesta al copiloto]

    classDef mono fill:#ffffff,stroke:#000000,stroke-width:1.5px,color:#000000;
    class C1,C2,C3,C4,C5,C6,C7,C8 mono;
```

---

## 6. Arquitectura de contenedores (GX10)

```mermaid
flowchart TD
    EXT["Servicios externos<br/>(voicebot, copiloto jurídico, copiloto de código)"]
    EXT -->|gRPC / contrato .proto| API

    subgraph API["Contenedor: rag-api"]
        direction TB
        G[Capa gRPC]
        L[Orquestación:<br/>enrutamiento por categoría,<br/>chunking, RRF]
        G --> L
    end

    L -->|gRPC 6334| QD
    L -.->|HTTP 6333<br/>debug/administración| QD

    QD[("Contenedor: qdrant<br/>Puerto 6334 — gRPC<br/>Puerto 6333 — HTTP<br/>Persistencia en disco<br/>API key habilitada")]

    L -->|HTTP| EMB8["Ollama<br/>qwen3-embedding:8b<br/>+ qwen3-reranker:8b"]
    L -->|HTTP| EMB06["vLLM<br/>qwen3-embedding:0.6b<br/>(imagen parcheada GB10)"]

    classDef mono fill:#ffffff,stroke:#000000,stroke-width:1.5px,color:#000000;
    class EXT,G,L,QD,EMB8,EMB06 mono;
```

**Notas de despliegue:**
- Qdrant nunca expone su puerto fuera de la Docker network interna — solo `rag-api` tiene ruta de red hacia él.
- API key de Qdrant habilitada como capa adicional de defensa en profundidad, incluso con el aislamiento de red.
- Los modelos de Ollama corren sin contenerizar por ahora (ya desplegados en el host).
- El servicio de vLLM para el 0.6B queda pendiente de validación con imagen comunitaria (ver §3.4).

---

## 7. Contrato gRPC (resumen funcional)

El contrato (`rag.proto`) expone tres operaciones:

| RPC | Propósito | Puntos clave del contrato |
|---|---|---|
| `Retrieve` | Consulta de contexto en tiempo de inferencia | Perfil (`RAPIDO`/`PRECISO`) obligatorio y explícito — sin default implícito por categoría. Soporta categorías adicionales para contenido transversal. Devuelve `perfil_usado` como eco de trazabilidad. |
| `Ingest` | Alimentar/actualizar la VDB | Modo dual: documento completo (la API aplica la estrategia de chunking elegida) o chunks pre-cortados (el cliente ya definió sus unidades de sentido). Estrategia de chunking obligatoria, sin inferencia automática oculta. |
| `Delete` | Depurar información | Por `id` puntual o por filtro compuesto (`categoria`, `fuente`, `fecha_antes_de`). Modo `dry_run` para contar coincidencias antes de borrar. Nunca acepta un filtro completamente vacío (evita borrar la colección entera por accidente). |

---

## 8. Contrato `.proto` completo

```protobuf
syntax = "proto3";

package rag.v1;

// =====================================================================
// SERVICIO
// =====================================================================

service RagService {
  rpc Retrieve (RetrieveRequest) returns (RetrieveResponse);
  rpc Ingest   (IngestRequest)   returns (IngestResponse);
  rpc Delete   (DeleteRequest)   returns (DeleteResponse);
}

// =====================================================================
// RETRIEVE — camino online, consumido por servicios externos con LLM
// =====================================================================

enum PerfilRetrieval {
  PERFIL_RAPIDO = 0;    // embedding 0.6B (vLLM), sin reranking — usado por el voicebot, mayor volumen de tráfico
  PERFIL_PRECISO = 1;   // embedding 8B (Ollama), hybrid search + reranking — copilotos no-realtime
}

message RetrieveRequest {
  string query = 1;
  string categoria_principal = 2;              // ej. "banco_a", "juridico", "codigo"
  repeated string categorias_adicionales = 3;   // ej. ["marco_legal_cobranza"] (contenido transversal)
  int32 top_k = 4;
  PerfilRetrieval perfil = 5;                   // obligatorio: cada cliente declara explícitamente rápido o preciso
}

message RetrieveResponse {
  repeated Chunk resultados = 1;
  string categoria_usada = 2;
  PerfilRetrieval perfil_usado = 3;             // eco del perfil aplicado, para trazabilidad/logs del cliente
}

message Chunk {
  string id = 1;
  string texto = 2;           // texto del chunk "hijo" (ej. el artículo puntual)
  string fuente = 3;          // ej. "manual_operativo_v3", "prompts_voicebot_v1"
  string categoria = 4;
  float score = 5;            // puntaje final (post-rerank si aplica)
  optional string texto_padre = 6;  // presente solo si la estrategia de ingesta fue CHUNKING_CLAUSULA_LEGAL_JERARQUICA
}

// =====================================================================
// INGEST — camino offline, alimentación/actualización de la VDB
// =====================================================================

enum EstrategiaChunking {
  CHUNKING_RECURSIVO = 0;                 // default si el campo no se especifica — respeta separadores naturales (párrafo/línea/oración), corte ciego solo como último recurso
  CHUNKING_FIJO = 1;                      // corte ciego cada N tokens, sin mirar el contenido. Útil como punto de comparación/control.
  CHUNKING_SEMANTIC = 2;                  // corte por cambio de tema, usando el propio modelo de embeddings
  CHUNKING_AST_CODIGO = 3;                // tree-sitter, respeta límites de función/clase (patrón cAST)
  CHUNKING_CLAUSULA_LEGAL_JERARQUICA = 4; // respeta artículos/cláusulas como unidad mínima + conserva relación padre-hijo (capítulo/sección)
}

message IngestRequest {
  string categoria = 1;
  string fuente = 2;                            // ej. "manual_operativo_v3"

  oneof contenido {
    DocumentoCompleto documento = 3;             // modo A: la API chunkea
    ChunksPreCortados chunks = 4;                // modo B: cliente ya chunkeó (ej. los 3 prompts del voicebot: saludo/gestión/despedida)
  }
}

message DocumentoCompleto {
  string texto = 1;
  optional EstrategiaChunking estrategia = 2;    // optional permite distinguir "no enviado" (rechazar request) de "enviado explícitamente"
  optional ParametrosChunkingConTamano parametros = 3;  // aplica solo a CHUNKING_FIJO y CHUNKING_RECURSIVO
}

message ParametrosChunkingConTamano {
  int32 tamano_tokens = 1;      // default sugerido: 500
  int32 overlap_tokens = 2;     // default sugerido: 100
}

message ChunksPreCortados {
  repeated ChunkEntrante chunks = 1;
}

message ChunkEntrante {
  string id = 1;                                 // idealmente determinístico (hash contenido+fuente)
  string texto = 2;
  map<string, string> metadata_adicional = 3;    // ej. "alcance": "transversal"
  string fecha_ingesta = 4;                      // ISO 8601 — si se omite, la API la asigna al momento de insertar
}

message IngestResponse {
  int32 chunks_insertados = 1;
  int32 chunks_actualizados = 2;
  repeated string ids_generados = 3;
}

// =====================================================================
// DELETE — depuración de información
// =====================================================================

message DeleteRequest {
  oneof criterio {
    string id = 1;                    // borrar un chunk puntual
    FiltroDelete filtro = 2;          // borrar por combinación de criterios
  }
  bool dry_run = 3;                   // si true: solo cuenta y devuelve el número de matches, no borra nada
}

message FiltroDelete {
  optional string categoria = 1;
  optional string fuente = 2;
  optional string fecha_antes_de = 3;   // ISO 8601 — borra todo lo ingresado antes de esta fecha
}

message DeleteResponse {
  int32 chunks_afectados = 1;         // cuántos matchearon (borrados si dry_run=false, contados si dry_run=true)
  bool fue_dry_run = 3;               // eco: confirma si esta ejecución fue solo de conteo
}
```

---

## 9. Ejemplos de solicitudes y respuestas

### 9.1 Retrieve — Voicebot (perfil rápido)

Un cliente del voicebot de cobranza del banco A pregunta por un procedimiento de pago.

**Solicitud:**
```json
{
  "query": "¿Qué medios de pago acepta el banco para regularizar la mora?",
  "categoria_principal": "banco_a",
  "categorias_adicionales": ["marco_legal_cobranza"],
  "top_k": 3,
  "perfil": "PERFIL_RAPIDO"
}
```

**Respuesta:**
```json
{
  "resultados": [
    {
      "id": "banco_a_medios_pago_01",
      "texto": "El cliente puede regularizar su mora mediante transferencia PSE, pago en corresponsal bancario o app móvil. No se aceptan pagos en efectivo a asesores.",
      "fuente": "prompts_voicebot_v1",
      "categoria": "banco_a",
      "score": 0.87
    },
    {
      "id": "marco_legal_cobranza_art_12",
      "texto": "Artículo 12. Las entidades de cobranza deberán informar al deudor todos los canales de pago disponibles, sin poder condicionar la gestión a un único medio.",
      "fuente": "circular_externa_superfinanciera",
      "categoria": "marco_legal_cobranza",
      "score": 0.79
    }
  ],
  "categoria_usada": "banco_a",
  "perfil_usado": "PERFIL_RAPIDO"
}
```

Nota: sin reranking, sin `texto_padre` (no aplica chunking jerárquico en este path), tiempo de respuesta objetivo bajo.

### 9.2 Retrieve — Copiloto jurídico (perfil preciso)

Un abogado interno consulta al copiloto sobre precedentes de un tipo específico de incumplimiento.

**Solicitud:**
```json
{
  "query": "¿Qué antecedentes existen sobre incumplimiento de pagaré con codeudor solidario?",
  "categoria_principal": "juridico",
  "categorias_adicionales": [],
  "top_k": 5,
  "perfil": "PERFIL_PRECISO"
}
```

**Respuesta:**
```json
{
  "resultados": [
    {
      "id": "jurisprudencia_2024_caso_0113_art_3",
      "texto": "El codeudor solidario responde por la totalidad de la obligación en los mismos términos que el deudor principal, sin beneficio de excusión, según lo pactado en el pagaré.",
      "fuente": "jurisprudencia_2024",
      "categoria": "juridico",
      "score": 0.94,
      "texto_padre": "Caso 0113 — Sentencia sobre pagaré con codeudor solidario. [Capítulo completo con antecedentes, argumentos de las partes y fallo]"
    },
    {
      "id": "jurisprudencia_2023_caso_0087_art_1",
      "texto": "En ausencia de cláusula expresa de solidaridad, el codeudor podrá invocar el beneficio de división de la deuda.",
      "fuente": "jurisprudencia_2023",
      "categoria": "juridico",
      "score": 0.88,
      "texto_padre": "Caso 0087 — Sentencia sobre codeuda sin cláusula de solidaridad expresa. [Capítulo completo]"
    }
  ],
  "categoria_usada": "juridico",
  "perfil_usado": "PERFIL_PRECISO"
}
```

Nota: pasó por hybrid search + RRF + reranking; cada resultado trae `texto_padre` porque la categoría `juridico` usa `CHUNKING_CLAUSULA_LEGAL_JERARQUICA`.

### 9.3 Ingest — Documento completo con chunking automático

Se indexa una versión nueva del manual operativo del banco B.

**Solicitud:**
```json
{
  "categoria": "banco_b",
  "fuente": "manual_operativo_v4",
  "documento": {
    "texto": "Capítulo 1. Atención al cliente...\n\nCapítulo 2. Procedimientos de cobranza...\n\n[...]",
    "estrategia": "CHUNKING_RECURSIVO",
    "parametros": {
      "tamano_tokens": 500,
      "overlap_tokens": 100
    }
  }
}
```

**Respuesta:**
```json
{
  "chunks_insertados": 42,
  "chunks_actualizados": 0,
  "ids_generados": [
    "banco_b_manual_v4_0001",
    "banco_b_manual_v4_0002",
    "..."
  ]
}
```

### 9.4 Ingest — Chunks pre-cortados por el cliente

Se indexan los tres prompts del voicebot del banco A, ya definidos manualmente.

**Solicitud:**
```json
{
  "categoria": "banco_a",
  "fuente": "prompts_voicebot_v1",
  "chunks": {
    "chunks": [
      {
        "id": "banco_a_saludo",
        "texto": "Buenos días, le habla [asesor] del banco A...",
        "metadata_adicional": { "tipo_prompt": "saludo" },
        "fecha_ingesta": "2026-08-14T09:00:00Z"
      },
      {
        "id": "banco_a_gestion_cobranza",
        "texto": "Le contactamos respecto a su obligación pendiente...",
        "metadata_adicional": { "tipo_prompt": "gestion" },
        "fecha_ingesta": "2026-08-14T09:00:00Z"
      },
      {
        "id": "banco_a_despedida_encuesta",
        "texto": "Para finalizar, le pedimos calificar la atención...",
        "metadata_adicional": { "tipo_prompt": "despedida" },
        "fecha_ingesta": "2026-08-14T09:00:00Z"
      }
    ]
  }
}
```

**Respuesta:**
```json
{
  "chunks_insertados": 3,
  "chunks_actualizados": 0,
  "ids_generados": [
    "banco_a_saludo",
    "banco_a_gestion_cobranza",
    "banco_a_despedida_encuesta"
  ]
}
```

### 9.5 Delete — Depuración con dry-run

Antes de borrar toda la información del banco C (fin de contrato), se hace una comprobación previa.

**Solicitud (dry-run):**
```json
{
  "filtro": {
    "categoria": "banco_c"
  },
  "dry_run": true
}
```

**Respuesta:**
```json
{
  "chunks_afectados": 187,
  "fue_dry_run": true
}
```

Tras confirmar el número, se repite la misma solicitud con `"dry_run": false` para ejecutar el borrado real.

---

## 10. Validación técnica en el GX10 (prototipo)

Esta sección documenta lo que ya se probó de forma práctica en la ASUS Ascent GX10 de desarrollo, como base para retomar la implementación.

### 10.1 Qdrant — desplegado y funcional

**Nota de nomenclatura:** en este documento, `qwen3-reranker:8b` es un alias de lectura para el modelo real ya descargado en Ollama: `dengcao/Qwen3-Reranker-8B:q8_0`. Usar el nombre completo al invocar la API de Ollama.


```bash
docker pull qdrant/qdrant

mkdir -p /home/user_ia/api_rag_prototipo/qdrant_storage

docker run -d \
  --name qdrant \
  -p 6333:6333 \
  -p 6334:6334 \
  -v /home/user_ia/api_rag_prototipo/qdrant_storage:/qdrant/storage \
  qdrant/qdrant
```

- Versión desplegada: **1.19.0**.
- Sin API key por ahora (aceptable mientras el puerto no se exponga fuera de la red de confianza del GX10; queda como pendiente de hardening — ver sección 11).
- HTTP (6333) y gRPC (6334) confirmados activos simultáneamente en los logs de arranque.
- Persistencia en disco confirmada en `/home/user_ia/api_rag_prototipo/qdrant_storage`.
- Se exploró la Web UI (`/dashboard`), incluyendo un dataset de prueba cargado manualmente (`qdrant_web_docs`) para practicar `scroll` y `filter` antes de tocar datos reales.

### 10.2 vLLM para `qwen3-embedding:0.6b` — validado end-to-end

**Decisión de seguridad previa:** antes de correr la imagen comunitaria (de un único mantenedor, no un proveedor establecido), se revisó su `Dockerfile` y `entrypoint.sh` públicos en Hugging Face. Conclusión: no hay llamadas a servidores externos, credenciales ocultas ni comportamiento sospechoso — pero los binarios precompilados de vLLM/PyTorch (`COPY vllm-env`, `COPY vllm`) no son auditables línea por línea, ya que no se compilan durante el build. Este riesgo residual es aceptable en la GX10 de desarrollo (aislada de la intranet), pero **la decisión para producción es migrar a hardware x86 con GPU discreta (RTX 4000/5000) usando imágenes oficiales de vLLM/NGC**, donde no hace falta ningún parche comunitario para la arquitectura.

**Descarga del modelo, independiente del contenedor:**
```bash
pip install -U huggingface_hub --break-system-packages

hf download Qwen/Qwen3-Embedding-0.6B \
  --local-dir /home/user_ia/api_rag_prototipo/qwen3_0_6_b \
  --token $(cat /home/user_ia/.hft)
```

**Descarga y arranque del contenedor:**
```bash
docker pull hellohal2064/vllm-dgx-spark-gb10

docker run -d \
  --name vllm-embedding-06b \
  --gpus all \
  -p 8001:8000 \
  -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model \
  -e MODEL_PATH=/models/model \
  -e MAX_MODEL_LEN=32768 \
  -e GPU_MEMORY_UTIL=0.3 \
  hellohal2064/vllm-dgx-spark-gb10:latest \
  --hf_overrides '{"matryoshka_dimensions": [32, 64, 128, 256, 512, 1024]}'
```

Notas del comando:
- Sin `--privileged` (deliberado, por seguridad — ver más abajo).
- `GPU_MEMORY_UTIL=0.3` conservador; queda margen amplio para subirlo si se necesita más concurrencia o correr otros servicios en paralelo.
- `--hf_overrides` con `matryoshka_dimensions` explícito fue necesario porque vLLM no detecta automáticamente el soporte de MRL del modelo (el `config.json` de Qwen3-Embedding no trae el campo `is_matryoshka`; es un problema conocido y reportado en el propio repositorio de vLLM). Sin este override, cualquier request con el parámetro `dimensions` devuelve `400 Bad Request`.

**Resultados confirmados:**

| Validación | Resultado |
|---|---|
| Arranque en hardware sm_121 (GB10) | Exitoso — `Detected GPU with compute capability 12.1 (arch=121)` |
| Modo pooling/embeddings detectado automáticamente | Sí — `Resolved --convert auto to --convert embed` |
| Dimensión del vector | 1024 (coincide con `hidden_size` del `config.json`) |
| VRAM usada al cargar el modelo | 1.12 GiB — muy liviano |
| Concurrencia máxima estimada (KV cache) | 9.7x con `max_model_len=32768` y `GPU_MEMORY_UTIL=0.3` |
| Latencia individual (request aislado, ya compilado) | ~19ms |
| Latencia con 10 requests concurrentes | ~20–25ms cada uno, sin degradación |
| Latencia con 100 requests concurrentes | ~90–105ms en el peor caso; lote completo en ~122ms (confirma paralelismo real, no cola) |
| Truncamiento MRL (Matryoshka) | Funcional tras `--hf_overrides`; probado con éxito en 32 dimensiones |
| `/health`, `/v1/models`, `/tokenize`, `/metrics`, `/v1/embeddings` | Todos probados y funcionando correctamente |

**Nota sobre latencia de arranque:** la primera petición tras iniciar el contenedor es lenta (varios segundos) por la compilación en caliente de `torch.compile` (~11s de compilación de grafo, visible en los logs de arranque). Es un costo único por reinicio del contenedor, no una latencia recurrente por request.

**Nota sobre `--trust-remote-code`:** el `entrypoint.sh` lo usa por defecto (comportamiento estándar de vLLM para ciertas arquitecturas). Riesgo mínimo para modelos de proveedores establecidos como Qwen, pero vale la pena tenerlo presente si en el futuro se sirve algún modelo de un repositorio de Hugging Face menos confiable.

### 10.3 Prueba de concurrencia — script de referencia

```bash
#!/bin/bash
N=10  # ajustar según el nivel de concurrencia a probar

echo "Lanzando $N peticiones simultáneas..."
start=$(date +%s.%N)

for i in $(seq 1 $N); do
  curl -s -o /dev/null -w "Request $i: %{time_total}s\n" \
    http://localhost:8001/v1/embeddings \
    -H "Content-Type: application/json" \
    -d '{"model": "/models/model", "input": "Buenos días, le habla el banco A"}' &
done

wait
end=$(date +%s.%N)
echo "---"
echo "Tiempo total del lote: $(echo "$end - $start" | bc)s"
```

### 10.4 Conclusión de la validación

El path rápido del voicebot (`qwen3-embedding:0.6b` en vLLM sobre la GX10, vía imagen comunitaria parcheada) queda **validado funcionalmente y de rendimiento** para continuar con la implementación de la API. Pendiente: la misma validación end-to-end para el path preciso (`qwen3-embedding:8b` + `qwen3-reranker:8b` en Ollama) y para Qdrant con datos reales de las categorías del proyecto (no solo el dataset de práctica).

---

## 11. Pendientes para retomar el desarrollo

- [ ] Validar en el GX10 el path preciso completo: `qwen3-embedding:8b` + `qwen3-reranker:8b` en Ollama, hybrid search y RRF en Qdrant, con datos reales o de prueba representativos del corpus jurídico/código.
- [ ] Crear las dos colecciones reales en Qdrant (`rag_voicebot_0_6b`, `rag_copilotos_8b`) con su configuración de vector, HNSW, e índice de payload `categoria` (`is_tenant=true`).
- [ ] Implementar `rag-api` (capa gRPC + orquestación) siguiendo el contrato `.proto` de la sección 8.
- [ ] Investigar estrategias adicionales de seguridad e integridad de la información en Qdrant/VDBs, más allá de API key y aislamiento de red (encriptación en reposo, encriptación por tenant, auditoría de accesos, integridad de payloads, backups seguros).
- [ ] Definir precedencia entre el marco legal transversal de cobranza y las políticas internas de cada banco cuando ambas aparecen en el mismo contexto de retrieval (decisión de negocio, no técnica).
- [ ] Snapshots/backups de Qdrant y Docker Compose completo del stack.
- [ ] Montar un set de preguntas de prueba por categoría para comparar estrategias de chunking empíricamente antes de fijar defaults por categoría (RAGAS u otro framework de evaluación).
- [ ] Decidir si se activa la API key de Qdrant antes de manejar datos reales (actualmente desactivada, aceptable solo mientras el prototipo permanece aislado).
- [ ] Para producción: migrar el servicio de embeddings del voicebot de la imagen comunitaria parcheada (GX10) a un servidor x86 con RTX 4000/5000 e imágenes oficiales de vLLM.