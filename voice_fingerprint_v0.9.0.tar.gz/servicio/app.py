"""API de voice_fingerprint (FastAPI).

Rutas (todas bajo /api):

  GET  /salud                          estado general, personas en el pool, sincronización
  GET  /sincronizacion                 avance y último resumen de la sincronización
  POST /sincronizacion                 lanza una resincronización (409 si ya hay una)
  GET  /personas                       el pool: nombre, origen, tramos, voz, perfil acústico
  POST /personas/{id}/eliminar         borra definitivamente a una persona (requiere la clave de 4 dígitos)
  GET  /mapa                           proyección 2D de tramos y plantillas
  POST /desafio                        nuevos dígitos para la prueba de vida (un solo uso)
  POST /validar                        audio + id del desafío -> veredicto con todo el detalle
  POST /registro                       nombre, origen, consentimiento y grabaciones -> nueva persona
  GET  /tiempos                        tiempos por paso de la última validación e historial (mediana, p95)
  GET  /recursos                       CPU, RAM e hilos del servicio y de la máquina (últimos 5 min)
  GET  /sistema                        arquitectura, procesador, memoria, versiones y modelos

  Experimento "Umbral" (cuánta voz neta hace falta para identificar):
  POST /umbral/sesion                  abre una sesión: {"tasa": <Hz del navegador>}
  POST /umbral/sesion/{id}/audio       PCM 16 bits mono (application/octet-stream); ?procesar=0|1
  POST /umbral/sesion/{id}/finalizar   barrido preciso, resultado y registro en el historial
  POST /umbral/sesion/{id}/cancelar    descarta la sesión
  GET  /umbral/historial               medianas por persona y por VAD, últimas sesiones

La página (carpeta codigo/frontend) se sirve en "/" si existe. Se envía con
"Cache-Control: no-cache": un cambio en el frontend se ve con solo recargar.

Configuración por variables de ambiente (ver configuracion.env.ejemplo):
  QDRANT_URL, QDRANT_API_KEY, QDRANT_PREFIJO, VF_VAD (silero | ten), VF_DISPOSITIVO (cpu | gpu),
  VF_UMBRAL_ALTO, VF_UMBRAL_BAJO, VF_MARGEN_MINIMO, VF_REFERENCIAS, VF_MODELOS, VF_REGISTROS,
  VF_CLAVE_BORRADO (4 dígitos; sin ella, la eliminación queda deshabilitada)
"""

import os
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from huella_vocal.almacen import VadNoCoincide
from huella_vocal.config import VERSION

from .motor import ErrorDeUso, Motor, PermisoDenegado
from .umbral import ErrorUmbral

RAIZ_PROYECTO = Path(__file__).resolve().parents[2]      # .../voice_fingerprint
DIR_FRONTEND = Path(__file__).resolve().parents[1] / "frontend"


def _ruta(variable, por_defecto):
    return Path(os.environ.get(variable) or por_defecto)


@asynccontextmanager
async def ciclo_de_vida(app):
    app.state.motor = Motor(
        dir_referencias=_ruta("VF_REFERENCIAS", RAIZ_PROYECTO / "referencias_wav"),
        dir_modelos=_ruta("VF_MODELOS", RAIZ_PROYECTO / "modelos"),
        dir_registros=_ruta("VF_REGISTROS", RAIZ_PROYECTO / "registros"),
    )
    app.state.motor.iniciar_sincronizacion()     # al arrancar, en segundo plano
    yield


app = FastAPI(title="voice_fingerprint", version=VERSION, lifespan=ciclo_de_vida)


@app.exception_handler(ErrorDeUso)
@app.exception_handler(ErrorUmbral)
async def _error_de_uso(request: Request, exc: Exception):
    return JSONResponse(status_code=400, content={"detalle": str(exc)})


@app.exception_handler(VadNoCoincide)
async def _vad_no_coincide(request: Request, exc: VadNoCoincide):
    return JSONResponse(status_code=409, content={"detalle": str(exc)})


@app.middleware("http")
async def _sin_cache_en_pagina(request: Request, call_next):
    """La página se revalida en cada carga: los cambios del frontend se ven con solo recargar."""
    respuesta = await call_next(request)
    if not request.url.path.startswith("/api/"):
        respuesta.headers["Cache-Control"] = "no-cache"
    return respuesta


@app.exception_handler(PermisoDenegado)
async def _permiso_denegado(request: Request, exc: PermisoDenegado):
    return JSONResponse(status_code=403, content={"detalle": str(exc)})


def _motor(request: Request) -> Motor:
    return request.app.state.motor


# ---------------------------------------------------------------------------
# Estado y pool
# ---------------------------------------------------------------------------

@app.get("/api/salud")
def salud(request: Request):
    m = _motor(request)
    return {
        "estado": "ok",
        "version": VERSION,
        "vad": m.vad,
        "vad_nombre": m.detector.descripcion,
        "dispositivo_pedido": m.dispositivo_pedido,
        "dispositivos": m.dispositivos,
        "avisos_dispositivo": m.avisos_dispositivo,
        "personas": len(m.almacen.personas()),
        "qdrant": m.almacen.url,
        "colecciones": [m.almacen.col_tramos, m.almacen.col_personas],
        "segundos_carga_modelos": m.segundos_carga,
        "eliminacion_habilitada": m.eliminacion_habilitada,
        "sincronizacion": m.estado_sync,
    }


@app.get("/api/sincronizacion")
def estado_sincronizacion(request: Request):
    return _motor(request).estado_sync


@app.post("/api/sincronizacion", status_code=202)
def resincronizar(request: Request):
    if not _motor(request).iniciar_sincronizacion():
        raise HTTPException(status_code=409, detail="Ya hay una sincronización en curso.")
    return {"detalle": "Sincronización iniciada."}


@app.get("/api/personas")
def personas(request: Request):
    return _motor(request).personas()


class PeticionEliminar(BaseModel):
    clave: str


@app.post("/api/personas/{persona_id}/eliminar")
def eliminar(persona_id: str, peticion: PeticionEliminar, request: Request):
    return _motor(request).eliminar_persona(persona_id, peticion.clave)


@app.get("/api/mapa")
def mapa(request: Request):
    datos = _motor(request).mapa()
    return {k: v for k, v in datos.items() if k not in ("pca", "vectores_personas", "ids_personas")}


# ---------------------------------------------------------------------------
# Prueba de vida y validación
# ---------------------------------------------------------------------------

@app.post("/api/desafio")
def desafio(request: Request):
    return _motor(request).nuevo_desafio()


@app.post("/api/validar")
def validar(request: Request, audio: UploadFile = File(...), desafio_id: str = Form(...)):
    inicio = time.perf_counter()
    motor = _motor(request)
    return motor.validar_subida(audio.file.read(), audio.filename, desafio_id, inicio=inicio)


# ---------------------------------------------------------------------------
# Tiempos y recursos
# ---------------------------------------------------------------------------

@app.get("/api/tiempos")
def tiempos(request: Request):
    return _motor(request).tiempos()


@app.get("/api/recursos")
def recursos(request: Request):
    return _motor(request).monitor.estado()


@app.get("/api/sistema")
def sistema(request: Request):
    return _motor(request).sistema()


# ---------------------------------------------------------------------------
# Experimento "Umbral"
# ---------------------------------------------------------------------------

class PeticionSesionUmbral(BaseModel):
    tasa: int


@app.post("/api/umbral/sesion")
def umbral_abrir(peticion: PeticionSesionUmbral, request: Request):
    return _motor(request).umbral.abrir(peticion.tasa)


@app.post("/api/umbral/sesion/{id_sesion}/audio")
async def umbral_audio(id_sesion: str, request: Request, procesar: int = 1):
    contenido = await request.body()
    return await run_in_threadpool(_motor(request).umbral.agregar, id_sesion, contenido, bool(procesar))


@app.post("/api/umbral/sesion/{id_sesion}/finalizar")
def umbral_finalizar(id_sesion: str, request: Request):
    return _motor(request).umbral.finalizar(id_sesion)


@app.post("/api/umbral/sesion/{id_sesion}/cancelar")
def umbral_cancelar(id_sesion: str, request: Request):
    return _motor(request).umbral.cancelar(id_sesion)


@app.get("/api/umbral/historial")
def umbral_historial(request: Request):
    return _motor(request).umbral.historial()


# ---------------------------------------------------------------------------
# Registro
# ---------------------------------------------------------------------------

@app.post("/api/registro")
def registro(
    request: Request,
    nombre: str = Form(...),
    consentimiento: bool = Form(...),
    origen: Optional[str] = Form(None),
    grabaciones: List[UploadFile] = File(...),
):
    motor = _motor(request)
    rutas = [motor.guardar_subida(g.file.read(), g.filename) for g in grabaciones]
    try:
        return motor.registrar(nombre, origen, consentimiento, rutas)
    finally:
        for ruta in rutas:
            ruta.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Página
# ---------------------------------------------------------------------------

if DIR_FRONTEND.is_dir():
    app.mount("/", StaticFiles(directory=DIR_FRONTEND, html=True), name="frontend")
