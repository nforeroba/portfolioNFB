"""
Cliente de prueba para el servicio TTS gRPC.
Uso:
  python3 client_test.py --text "Hola mundo" [--voice vanessa] [--output output.opus]
"""

import argparse
import sys
import time

import grpc

import tts_service_pb2
import tts_service_pb2_grpc


def main():
    parser = argparse.ArgumentParser(description="Cliente de prueba TTS gRPC")
    parser.add_argument("--host", default="localhost", help="Host del servicio")
    parser.add_argument("--port", default="50051", help="Puerto del servicio")
    parser.add_argument("--text", required=True, help="Texto a sintetizar")
    parser.add_argument("--voice", default="", help="ID de voz (vacío = default del servidor)")
    parser.add_argument("--temperature", type=float, default=0.0, help="Temperatura (0 = default del servidor)")
    parser.add_argument("--top-p", type=float, default=0.0, help="Top-p (0 = default del servidor)")
    parser.add_argument("--repetition-penalty", type=float, default=0.0, help="Penalización de repetición (0 = default)")
    parser.add_argument("--output", default="output.opus", help="Archivo de salida Opus")
    args = parser.parse_args()

    addr = f"{args.host}:{args.port}"
    print(f"[cliente] Conectando a {addr} ...")

    channel = grpc.insecure_channel(addr)
    stub = tts_service_pb2_grpc.TTSServiceStub(channel)

    request = tts_service_pb2.ServeTTSRequest(
        text=args.text,
        reference_id=args.voice,
        temperature=args.temperature,
        top_p=args.top_p,
        repetition_penalty=args.repetition_penalty,
    )

    text_preview = args.text[:80] + "..." if len(args.text) > 80 else args.text
    print(f"[cliente] Texto  : {text_preview}")
    print(f"[cliente] Voz    : '{args.voice or '(default)'}'")
    print(f"[cliente] Salida : {args.output}")
    print(f"[cliente] Enviando request TTS ...")

    t0 = time.perf_counter()
    try:
        response = stub.TTS(request, timeout=120)
    except grpc.RpcError as e:
        print(f"[cliente] ❌ Error gRPC: {e.code()} — {e.details()}")
        sys.exit(1)

    elapsed = time.perf_counter() - t0
    audio_duration = response.audio_duration
    rtf = elapsed / audio_duration if audio_duration > 0 else 0.0

    with open(args.output, "wb") as f:
        f.write(response.audio_bytes)

    print(f"[cliente] ✅ Síntesis completada")
    print(f"[cliente] Duración audio  : {audio_duration:.3f}s")
    print(f"[cliente] Tiempo total    : {elapsed:.3f}s")
    print(f"[cliente] RTF             : {rtf:.4f}")
    print(f"[cliente] Tamaño opus     : {len(response.audio_bytes):,} bytes")
    print(f"[cliente] Audio guardado  : {args.output}")


if __name__ == "__main__":
    main()
