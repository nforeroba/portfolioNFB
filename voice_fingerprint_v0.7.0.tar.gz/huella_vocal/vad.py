"""Detección de voz (Silero VAD) y partición de la voz neta en tramos."""

import numpy as np

from .config import SEGUNDOS_MIN_REFERENCIA, SEGUNDOS_MIN_TRAMO, SEGUNDOS_TRAMO, SR


class DetectorVoz:
    def __init__(self):
        from silero_vad import load_silero_vad

        self.modelo = load_silero_vad(onnx=False)

    def segmentos(self, senal):
        """Lista de (inicio, fin) en muestras donde hay voz."""
        import torch
        from silero_vad import get_speech_timestamps

        marcas = get_speech_timestamps(torch.from_numpy(senal), self.modelo, sampling_rate=SR)
        return [(m["start"], m["end"]) for m in marcas]

    def voz_neta(self, senal):
        """La señal con los silencios removidos."""
        segmentos = self.segmentos(senal)
        if not segmentos:
            return np.zeros(0, dtype=np.float32), segmentos
        return np.concatenate([senal[a:b] for a, b in segmentos]).astype(np.float32), segmentos


def partir_en_tramos(voz, segundos_tramo=SEGUNDOS_TRAMO, segundos_min=SEGUNDOS_MIN_TRAMO):
    """
    Parte la voz neta en tramos de `segundos_tramo`. Un sobrante de al menos
    `segundos_min` queda como tramo propio; uno menor se une al tramo anterior.
    Una voz corta (entre SEGUNDOS_MIN_REFERENCIA y `segundos_min`) es un único tramo.
    """
    largo = int(segundos_tramo * SR)
    minimo = int(segundos_min * SR)
    if len(voz) < minimo:
        return [voz] if len(voz) >= int(SEGUNDOS_MIN_REFERENCIA * SR) else []
    completos = len(voz) // largo
    tramos = [voz[i * largo:(i + 1) * largo] for i in range(completos)]
    sobrante = voz[completos * largo:]
    if len(sobrante) >= minimo or not tramos:
        tramos.append(sobrante)
    elif len(sobrante):
        tramos[-1] = np.concatenate([tramos[-1], sobrante])
    return tramos
