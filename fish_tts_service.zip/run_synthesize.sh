#!/bin/bash
source venv/bin/activate
python synthesize.py --text "Este es un ejemplo de síntesis con la voz clonada." --embedding voz_clonada.pth --output salida.wav
