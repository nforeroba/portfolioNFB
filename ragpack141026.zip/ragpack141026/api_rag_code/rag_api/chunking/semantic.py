"""
Estrategia de chunking semantico.

Divide el texto en oraciones, calcula el embedding de cada una, y
corta donde la similitud coseno entre oraciones consecutivas cae por
debajo de un umbral (configurable via CHUNKING_SEMANTIC_UMBRAL_SIMILITUD)
-- es decir, donde el tema cambia. Los grupos de oraciones resultantes
se combinan respetando (de forma aproximada) el tamano objetivo en
tokens.

A diferencia de las demas estrategias, esta necesita un cliente de
embeddings para funcionar. Se inyecta por constructor (no por
chunkear(), para mantener la misma firma que el resto de estrategias),
ya que el cliente correcto (vLLM u Ollama) depende de que coleccion se
esta ingiriendo -- esa decision la toma quien instancia esta clase
(el servicio de ingesta), no la estrategia misma.
"""

import re

import numpy as np
import tiktoken

from rag_api.chunking.base import ChunkGenerado, EstrategiaChunkingBase
from rag_api.config import settings

_ENCODING = tiktoken.get_encoding("cl100k_base")


class ClienteEmbeddingProtocolo:
    """
    Protocolo minimo que debe cumplir cualquier cliente inyectado:
    un metodo embed_lote(textos) -> list[list[float]]. Tanto
    VllmClient como OllamaClient ya cumplen esta forma.
    """

    def embed_lote(self, textos: list[str]) -> list[list[float]]:
        raise NotImplementedError


class ChunkingSemantic(EstrategiaChunkingBase):
    def __init__(
        self,
        cliente_embeddings: ClienteEmbeddingProtocolo,
        umbral_similitud: float | None = None,
    ) -> None:
        self._cliente_embeddings = cliente_embeddings
        self._umbral_similitud = (
            umbral_similitud if umbral_similitud is not None else settings.chunking.semantic_umbral_similitud
        )

    def chunkear(
        self,
        texto: str,
        tamano_tokens: int,
        overlap_tokens: int,
        lenguaje_codigo: str | None = None,
        fuente: str | None = None,
    ) -> list[ChunkGenerado]:
        oraciones = self._dividir_en_oraciones(texto)

        if len(oraciones) <= 1:
            return [ChunkGenerado(texto=texto)] if texto.strip() else []

        vectores = self._cliente_embeddings.embed_lote(oraciones)
        puntos_de_corte = self._detectar_cambios_de_tema(vectores)
        grupos = self._agrupar_oraciones(oraciones, puntos_de_corte, tamano_tokens)
        grupos_con_overlap = self._aplicar_overlap(grupos, overlap_tokens)

        return [ChunkGenerado(texto=grupo) for grupo in grupos_con_overlap if grupo.strip()]

    @staticmethod
    def _dividir_en_oraciones(texto: str) -> list[str]:
        oraciones = re.split(r"(?<=[.!?])\s+", texto.strip())
        return [oracion for oracion in oraciones if oracion.strip()]

    def _detectar_cambios_de_tema(self, vectores: list[list[float]]) -> set[int]:
        puntos_de_corte = {0}
        matriz = np.array(vectores)

        for i in range(1, len(matriz)):
            similitud = self._similitud_coseno(matriz[i - 1], matriz[i])
            if similitud < self._umbral_similitud:
                puntos_de_corte.add(i)

        return puntos_de_corte

    @staticmethod
    def _similitud_coseno(a: np.ndarray, b: np.ndarray) -> float:
        norma_a = np.linalg.norm(a)
        norma_b = np.linalg.norm(b)
        if norma_a == 0 or norma_b == 0:
            return 0.0
        return float(np.dot(a, b) / (norma_a * norma_b))

    @staticmethod
    def _agrupar_oraciones(
        oraciones: list[str],
        puntos_de_corte: set[int],
        tamano_tokens: int,
    ) -> list[str]:
        grupos: list[str] = []
        grupo_actual: list[str] = []
        tokens_grupo_actual = 0

        for i, oracion in enumerate(oraciones):
            tokens_oracion = len(_ENCODING.encode(oracion))
            es_nuevo_tema = i in puntos_de_corte and i != 0
            excede_tamano = tokens_grupo_actual + tokens_oracion > tamano_tokens

            if grupo_actual and (es_nuevo_tema or excede_tamano):
                grupos.append(" ".join(grupo_actual))
                grupo_actual = []
                tokens_grupo_actual = 0

            grupo_actual.append(oracion)
            tokens_grupo_actual += tokens_oracion

        if grupo_actual:
            grupos.append(" ".join(grupo_actual))

        return grupos

    @staticmethod
    def _aplicar_overlap(grupos: list[str], overlap_tokens: int) -> list[str]:
        if overlap_tokens <= 0 or len(grupos) <= 1:
            return grupos

        con_overlap = [grupos[0]]
        for i in range(1, len(grupos)):
            tokens_anterior = _ENCODING.encode(grupos[i - 1])
            cola_tokens = tokens_anterior[-overlap_tokens:]
            cola_texto = _ENCODING.decode(cola_tokens)
            con_overlap.append(cola_texto + " " + grupos[i])

        return con_overlap
