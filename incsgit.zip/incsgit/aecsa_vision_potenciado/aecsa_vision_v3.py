import streamlit as st
import os
import time
from tempfile import NamedTemporaryFile
import base64
import io
import fitz  # PyMuPDF para previsualización de PDF
import pymupdf4llm  # Para extracción de texto en markdown
import requests
import json
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter

# Función para comprobar si una página PDF contiene texto extraíble
def has_extractable_text(pdf_path, page_num):
    try:
        doc = fitz.open(pdf_path)
        page = doc.load_page(page_num)
        text = page.get_text()
        doc.close()
        
        # Si el texto extraído tiene una longitud significativa, consideramos que es extraíble
        return len(text.strip()) > 50, text
    except Exception as e:
        return False, ""

# Función para extraer texto en formato markdown desde un PDF
def extract_markdown_from_pdf(pdf_path, page_num):
    try:
        # Usamos pymupdf4llm para extraer el texto en formato markdown
        # Primero extraemos todo el documento
        doc = fitz.open(pdf_path)
        
        # Para extraer solo la página específica, creamos un nuevo documento con esa única página
        new_doc = fitz.open()
        new_doc.insert_pdf(doc, from_page=page_num, to_page=page_num)
        
        # Guardamos el documento de una sola página en un archivo temporal
        temp_single_page = f"{pdf_path}_page_{page_num}.pdf"
        new_doc.save(temp_single_page)
        new_doc.close()
        doc.close()
        
        # Extraemos markdown con pymupdf4llm del documento de una sola página
        markdown_text = pymupdf4llm.to_markdown(temp_single_page)
        
        # Limpiamos el archivo temporal
        if os.path.exists(temp_single_page):
            os.remove(temp_single_page)
        
        return markdown_text, None
    except Exception as e:
        return None, f"Error al extraer texto en formato markdown: {str(e)}"

# Función para obtener una página específica del PDF como imagen
def get_pdf_page_image(pdf_path, page_num):
    try:
        # Abrir el PDF con PyMuPDF
        doc = fitz.open(pdf_path)
        
        # Verificar si el número de página es válido
        if page_num < 0 or page_num >= len(doc):
            return None, f"Número de página inválido. El documento tiene {len(doc)} páginas."
        
        # Cargar la página especificada
        page = doc.load_page(page_num)
        
        # Renderizar la página como imagen
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))  # Escala 2x para mejor calidad
        
        # Convertir a imagen
        img_bytes = pix.tobytes("png")
        
        # Limpiar recursos
        doc.close()
        
        return img_bytes, None
    except Exception as e:
        return None, f"Error al procesar la página del PDF: {str(e)}"

# Función para preprocesar una imagen antes del OCR
def preprocess_image(image_bytes):
    try:
        # Convertir bytes a imagen con PIL
        image = Image.open(io.BytesIO(image_bytes))
        
        # Convertir a escala de grises
        gray_image = image.convert('L')
        
        # Aumentar el contraste
        enhancer = ImageEnhance.Contrast(gray_image)
        contrast_image = enhancer.enhance(1.5)  # Factor de 1.5 para aumentar el contraste
        
        # Aumentar la nitidez
        sharp_image = contrast_image.filter(ImageFilter.SHARPEN)
        
        # Umbralización adaptativa para mejorar el texto (usando OpenCV)
        cv_image = np.array(sharp_image)
        blurred = cv2.GaussianBlur(cv_image, (5, 5), 0)
        thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                      cv2.THRESH_BINARY, 11, 2)
        
        # Convertir de nuevo a bytes
        processed_image = Image.fromarray(thresh)
        buffer = io.BytesIO()
        processed_image.save(buffer, format="PNG")
        
        return buffer.getvalue(), image_bytes  # Devolvemos imagen procesada y original para comparación
    except Exception as e:
        # En caso de error, devolver la imagen original
        return image_bytes, image_bytes

# Función para contar páginas en un PDF
def count_pdf_pages(pdf_path):
    try:
        # Abrir el PDF con PyMuPDF
        doc = fitz.open(pdf_path)
        page_count = len(doc)
        doc.close()
        return page_count
    except Exception as e:
        st.error(f"Error al contar páginas del PDF: {str(e)}")
        return 0

# Función para llamar a la API de Ollama con una imagen
def extract_text_from_image(image_bytes, model_name, ollama_endpoint):
    try:
        # Convertir la imagen a base64
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        # Preparar el prompt para extracción de texto
        prompt = "Extrae todo el texto visible en esta imagen. Proporciona solo el texto extraído sin ningún comentario, análisis o explicación adicional."
        
        # Preparar el payload para la API de Ollama
        payload = {
            "model": model_name,
            "messages": [
                {
                    "role": "user",
                    "content": prompt,
                    "images": [base64_image]
                }
            ],
            "stream": False,
            "temperature": 0  # Temperatura establecida a cero
        }
        
        # Llamar a la API de Ollama
        response = requests.post(
            f"{ollama_endpoint}",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        # Verificar si la solicitud fue exitosa
        if response.status_code == 200:
            result = response.json()
            extracted_text = result["message"]["content"]
            return extracted_text, None
        else:
            return None, f"Error en la API: {response.status_code} - {response.text}"
            
    except Exception as e:
        return None, f"Error al procesar la imagen: {str(e)}"

# Configuración de Streamlit
st.set_page_config(layout='wide', page_title="OCR de Documentos PDF")

# Elementos centrados en la parte superior
st.markdown("<h1 style='text-align: center;'>Extracción de Texto de PDF con Modelos de Visión y Lenguaje</h1>", unsafe_allow_html=True)

# Contenedor centrado para los controles
with st.container():
    col_center = st.columns([1, 2, 1])[1]  # Columna central
    
    with col_center:
        st.markdown("<h3 style='text-align: center;'>Configuración</h3>", unsafe_allow_html=True)
        
        # Insertar imagen centrada después del encabezado de configuración
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.image("/api/placeholder/600/200", caption="Logo de la aplicación", use_column_width=True)
        
        uploaded_file = st.file_uploader("Elige un archivo PDF o una imagen", 
                                    type=["pdf", "png", "jpg", "jpeg", "tiff", "bmp"], 
                                    key="file_uploader")
        
        # Endpoint de Ollama
        OLLAMA_ENDPOINT = "http://xxx.xx.xx.xxx:11434/api/chat"
        
        # Lista de modelos de visión disponibles (ordenados alfabéticamente)
        available_models = sorted([
            "granite3.2-vision:2b",
            "llama3.2-vision:11b",
            "llava:7b",
            "llava:13b",
            "moondream:1.8b"
        ])
        
        # Selector de modelo
        selected_model = st.selectbox(
            "Selecciona un modelo de visión:",
            options=available_models,
            key="model_selector"
        )
        
        # Opciones de preprocesamiento para imágenes escaneadas
        use_preprocessing = st.checkbox("Aplicar preprocesamiento en imágenes escaneadas", value=True)

# Variables para el control de páginas
total_pages = 0
current_page = 0
temp_pdf_path = None
is_image = False
temp_image_path = None

if uploaded_file:
    file_extension = uploaded_file.name.split('.')[-1].lower()
    
    # Comprobar si es una imagen o un PDF
    if file_extension in ['png', 'jpg', 'jpeg', 'tiff', 'bmp']:
        is_image = True
        # Guardar la imagen en un archivo temporal
        with NamedTemporaryFile(delete=False, suffix=f".{file_extension}") as tmp:
            tmp.write(uploaded_file.getvalue())
            temp_image_path = tmp.name
            
        # Para imágenes, no hay páginas para navegar
        total_pages = 1
        current_page = 0
    else:
        # Es un PDF
        is_image = False
        # Guardar el PDF en un archivo temporal
        with NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(uploaded_file.getvalue())
            temp_pdf_path = tmp.name
            
        # Contar páginas del PDF
        total_pages = count_pdf_pages(temp_pdf_path)
    
    # Continuar en el contenedor central
    with st.container():
        col_center = st.columns([1, 2, 1])[1]
        
        with col_center:
            if is_image:
                st.markdown(f"<p style='text-align: center;'><b>Imagen cargada:</b> {uploaded_file.name}</p>", unsafe_allow_html=True)
                
                # Para imágenes, solo mostramos el botón de extracción
                extract_text = st.button('Extraer Texto', key="extract_button")
            elif total_pages > 0:
                st.markdown(f"<p style='text-align: center;'><b>Documento cargado:</b> {uploaded_file.name} ({total_pages} páginas)</p>", unsafe_allow_html=True)
                
                # Solo slider para seleccionar la página (eliminado number_input)
                current_page = st.slider("Seleccionar página", 0, total_pages - 1, 0, key="page_slider")
                
                # Botón para extraer texto
                extract_text = st.button('Extraer Texto', key="extract_button")
            else:
                st.error("El archivo PDF no contiene páginas.")
    
    # Vista previa y resultado lado a lado
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("<h3 style='text-align: center;'>Vista Previa</h3>", unsafe_allow_html=True)
        
        # Mostrar vista previa según el tipo de archivo
        if is_image and temp_image_path:
            # Para imágenes, mostrar directamente
            with open(temp_image_path, "rb") as file:
                image_bytes = file.read()
            st.image(image_bytes, caption=f"Imagen: {uploaded_file.name}")
        elif temp_pdf_path:
            # Para PDFs, mostrar la página seleccionada
            preview_image, error = get_pdf_page_image(temp_pdf_path, current_page)
            if error:
                st.error(error)
            elif preview_image:
                st.image(preview_image, caption=f"Página {current_page}")
    
    # Procesar extracción de texto si se solicita
    if extract_text:
        with col2:
            st.markdown("<h3 style='text-align: center;'>Texto Extraído</h3>", unsafe_allow_html=True)
            with st.spinner('Extrayendo texto...'):
                start_time = time.time()
                
                if is_image and temp_image_path:
                    # Procesamiento para imagen
                    st.info("Procesando imagen con OCR.")
                    
                    # Leer la imagen
                    with open(temp_image_path, "rb") as file:
                        image_bytes = file.read()
                    
                    if use_preprocessing:
                        # Aplicar preprocesamiento a la imagen
                        processed_image, original_image = preprocess_image(image_bytes)
                        
                        # Mostrar ambas imágenes para comparación (reducidas)
                        st.markdown("### Comparación de Imágenes")
                        cols = st.columns(2)
                        with cols[0]:
                            st.image(original_image, caption="Imagen Original", width=250)
                        with cols[1]:
                            st.image(processed_image, caption="Imagen Preprocesada", width=250)
                        
                        # Usar la imagen procesada para OCR
                        extracted_text, api_error = extract_text_from_image(processed_image, selected_model, OLLAMA_ENDPOINT)
                    else:
                        # Usar la imagen original para OCR
                        extracted_text, api_error = extract_text_from_image(image_bytes, selected_model, OLLAMA_ENDPOINT)
                    
                    if api_error:
                        st.error(api_error)
                    else:
                        execution_time = time.time() - start_time
                        
                        # Mostrar el texto extraído
                        st.markdown("### Texto Extraído (OCR)")
                        st.text_area("", extracted_text, height=400)
                        
                        # Mostrar tiempo de ejecución
                        st.write(f"⏱️ **Tiempo de ejecución:** {round(execution_time, 2)} segundos")
                        if use_preprocessing:
                            st.write("✅ Método utilizado: **OCR con preprocesamiento de imagen**")
                        else:
                            st.write("✅ Método utilizado: **OCR sin preprocesamiento**")
                
                elif temp_pdf_path:
                    # Comprobar si la página tiene texto extraíble (solo para PDFs)
                    has_text, extracted_text_md = has_extractable_text(temp_pdf_path, current_page)
                    
                    if has_text:
                        # Si la página tiene texto extraíble, usar PyMuPDF4LLM para obtener markdown
                        st.success("Detectado PDF con texto extraíble. Utilizando extracción directa.")
                        extracted_text, extraction_error = extract_markdown_from_pdf(temp_pdf_path, current_page)
                        
                        if extraction_error:
                            st.error(extraction_error)
                        else:
                            execution_time = time.time() - start_time
                            
                            # Mostrar el texto extraído en formato markdown
                            st.markdown("### Texto Extraído (formato markdown)")
                            st.text_area("", extracted_text, height=400)
                            
                            # Mostrar tiempo de ejecución
                            st.write(f"⏱️ **Tiempo de ejecución:** {round(execution_time, 2)} segundos")
                            st.write("✅ Método utilizado: **Extracción directa de texto con PyMuPDF4LLM**")
                    else:
                        # Si no hay texto extraíble, usar OCR con VLM
                        st.info("Detectado PDF escaneado. Utilizando OCR con modelos de visión.")
                        
                        # Obtener la imagen de la página seleccionada
                        page_image, error = get_pdf_page_image(temp_pdf_path, current_page)
                        
                        if error:
                            st.error(error)
                        elif page_image:
                            if use_preprocessing:
                                # Aplicar preprocesamiento a la imagen
                                processed_image, original_image = preprocess_image(page_image)
                                
                                # Mostrar ambas imágenes para comparación (reducidas)
                                st.markdown("### Comparación de Imágenes")
                                cols = st.columns(2)
                                with cols[0]:
                                    st.image(original_image, caption="Imagen Original", width=250)
                                with cols[1]:
                                    st.image(processed_image, caption="Imagen Preprocesada", width=250)
                                
                                # Usar la imagen procesada para OCR
                                extracted_text, api_error = extract_text_from_image(processed_image, selected_model, OLLAMA_ENDPOINT)
                            else:
                                # Usar la imagen original para OCR
                                extracted_text, api_error = extract_text_from_image(page_image, selected_model, OLLAMA_ENDPOINT)
                            
                            if api_error:
                                st.error(api_error)
                            else:
                                execution_time = time.time() - start_time
                                
                                # Mostrar el texto extraído
                                st.markdown("### Texto Extraído (OCR)")
                                st.text_area("", extracted_text, height=400)
                                
                                # Mostrar tiempo de ejecución
                                st.write(f"⏱️ **Tiempo de ejecución:** {round(execution_time, 2)} segundos")
                                if use_preprocessing:
                                    st.write("✅ Método utilizado: **OCR con preprocesamiento de imagen**")
                                else:
                                    st.write("✅ Método utilizado: **OCR sin preprocesamiento**")
    else:
        with col2:
            st.markdown("<h3 style='text-align: center;'>Texto Extraído</h3>", unsafe_allow_html=True)
            if is_image:
                st.info("Haz clic en 'Extraer Texto' para procesar la imagen.")
            else:
                st.info("Selecciona una página y haz clic en 'Extraer Texto' para obtener el texto de la página.")
else:
    # Mensaje cuando no hay archivo
    st.info("Por favor, sube un archivo PDF o una imagen para comenzar.")

# Limpiar archivos temporales al finalizar
if temp_pdf_path and os.path.exists(temp_pdf_path):
    try:
        os.remove(temp_pdf_path)
    except:
        pass

if temp_image_path and os.path.exists(temp_image_path):
    try:
        os.remove(temp_image_path)
    except:
        pass