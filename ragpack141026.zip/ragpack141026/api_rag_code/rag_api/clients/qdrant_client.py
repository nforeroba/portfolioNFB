"""
Cliente de Qdrant para rag-api.

Concentra toda la interaccion con Qdrant: creacion/verificacion de
colecciones (bootstrap), insercion de puntos, busqueda (densa simple
para el camino rapido, hybrid + RRF para el camino preciso), y borrado.

El resto del sistema le pide cosas en terminos de negocio
("busca en la coleccion rapida con este filtro de categoria"), nunca
en terminos directos del SDK de Qdrant.
"""

import logging

from qdrant_client import QdrantClient, models

from rag_api.config import settings

logger = logging.getLogger(__name__)


class DimensionInconsistenteError(Exception):
    """
    Se lanza cuando la dimension configurada por variable de entorno
    no coincide con la dimension real de una coleccion ya existente
    en Qdrant. Esto evita fallos confusos mas adelante en el primer
    upsert o busqueda.
    """


class QdrantWrapper:
    def __init__(self) -> None:
        cfg = settings.qdrant
        self._client = QdrantClient(
            host=cfg.grpc_host,
            grpc_port=cfg.grpc_port,
            prefer_grpc=True,
            api_key=cfg.api_key,
            timeout=cfg.timeout_segundos,
        )
        self._coleccion_rapida = cfg.coleccion_rapida
        self._coleccion_precisa = cfg.coleccion_precisa

    @property
    def coleccion_rapida(self) -> str:
        return self._coleccion_rapida

    @property
    def coleccion_precisa(self) -> str:
        return self._coleccion_precisa

    # -----------------------------------------------------------------
    # Bootstrap de colecciones
    # -----------------------------------------------------------------

    def asegurar_colecciones(self) -> None:
        """
        Verifica si las dos colecciones existen. Si no existen, las
        crea con la dimension configurada. Si ya existen, valida que
        su dimension real coincida con la configurada -- y falla de
        forma explicita si no coincide, en vez de dejar que el
        desajuste aparezca como un error confuso mas adelante.

        Idempotente: se puede llamar en cada arranque sin romper nada
        si las colecciones ya existen y su dimension es consistente.
        """
        self._asegurar_coleccion(
            nombre=self._coleccion_rapida,
            dim_configurada=settings.qdrant.dim_coleccion_rapida,
            vectors_config=models.VectorParams(
                size=settings.qdrant.dim_coleccion_rapida,
                distance=models.Distance.COSINE,
            ),
            sparse_vectors_config=None,
            hnsw_m=settings.qdrant.hnsw_rapida_m,
            hnsw_ef_construct=settings.qdrant.hnsw_rapida_ef_construct,
            nombre_vector_denso=None,
        )
        self._asegurar_coleccion(
            nombre=self._coleccion_precisa,
            dim_configurada=settings.qdrant.dim_coleccion_precisa,
            vectors_config={
                "denso": models.VectorParams(
                    size=settings.qdrant.dim_coleccion_precisa,
                    distance=models.Distance.COSINE,
                ),
            },
            sparse_vectors_config={
                "disperso": models.SparseVectorParams(modifier=models.Modifier.IDF),
            },
            hnsw_m=settings.qdrant.hnsw_precisa_m,
            hnsw_ef_construct=settings.qdrant.hnsw_precisa_ef_construct,
            nombre_vector_denso="denso",
        )

    def _asegurar_coleccion(
        self,
        nombre: str,
        dim_configurada: int,
        vectors_config,
        sparse_vectors_config,
        hnsw_m: int,
        hnsw_ef_construct: int,
        nombre_vector_denso: str | None,
    ) -> None:
        if self._client.collection_exists(nombre):
            self._validar_dimension_existente(nombre, dim_configurada, nombre_vector_denso)
            logger.info("Coleccion ya existe y su dimension es consistente: %s", nombre)
            return

        logger.info("Creando coleccion: %s (dimension=%d)", nombre, dim_configurada)
        self._client.create_collection(
            collection_name=nombre,
            vectors_config=vectors_config,
            sparse_vectors_config=sparse_vectors_config,
            hnsw_config=models.HnswConfigDiff(m=hnsw_m, ef_construct=hnsw_ef_construct),
        )
        self._crear_indice_categoria(nombre)

    def _validar_dimension_existente(
        self,
        nombre: str,
        dim_configurada: int,
        nombre_vector_denso: str | None,
    ) -> None:
        """
        Compara la dimension configurada por variable de entorno contra
        la dimension real ya almacenada en una coleccion existente.
        """
        info = self._client.get_collection(nombre)
        vectores = info.config.params.vectors

        if nombre_vector_denso is not None:
            dim_real = vectores[nombre_vector_denso].size
        else:
            dim_real = vectores.size

        if dim_real != dim_configurada:
            raise DimensionInconsistenteError(
                f"La coleccion '{nombre}' ya existe en Qdrant con dimension {dim_real}, "
                f"pero la configuracion actual (variable de entorno) pide dimension "
                f"{dim_configurada}. Si de verdad quieres cambiar la dimension, la "
                f"coleccion debe borrarse y reingestarse por completo -- Qdrant no admite "
                f"vectores de tamanos distintos en la misma coleccion."
            )

    def _crear_indice_categoria(self, coleccion: str) -> None:
        """
        Indice de payload en el campo `categoria`, marcado como
        is_tenant=true para que Qdrant optimice el filtro dentro del
        recorrido del grafo HNSW.
        """
        self._client.create_payload_index(
            collection_name=coleccion,
            field_name="categoria",
            field_schema=models.KeywordIndexParams(
                type=models.KeywordIndexType.KEYWORD,
                is_tenant=True,
            ),
        )

    # -----------------------------------------------------------------
    # Ingesta
    # -----------------------------------------------------------------

    def upsert_rapida(self, puntos: list[models.PointStruct]) -> None:
        self._client.upsert(collection_name=self._coleccion_rapida, points=puntos)

    def upsert_precisa(self, puntos: list[models.PointStruct]) -> None:
        self._client.upsert(collection_name=self._coleccion_precisa, points=puntos)

    # -----------------------------------------------------------------
    # Busqueda -- camino rapido (denso simple)
    # -----------------------------------------------------------------

    def buscar_rapida(
        self,
        vector_consulta: list[float],
        categorias: list[str],
        top_k: int,
        ef_search: int,
    ) -> list[models.ScoredPoint]:
        filtro = models.Filter(
            must=[models.FieldCondition(key="categoria", match=models.MatchAny(any=categorias))]
        )
        resultados = self._client.query_points(
            collection_name=self._coleccion_rapida,
            query=vector_consulta,
            query_filter=filtro,
            limit=top_k,
            search_params=models.SearchParams(hnsw_ef=ef_search),
        )
        return resultados.points

    # -----------------------------------------------------------------
    # Busqueda -- camino preciso (hybrid: denso + sparse, fusion RRF)
    # -----------------------------------------------------------------

    def buscar_precisa(
        self,
        vector_denso: list[float],
        vector_disperso: models.SparseVector,
        categorias: list[str],
        top_k: int,
        ef_search: int,
    ) -> list[models.ScoredPoint]:
        filtro = models.Filter(
            must=[models.FieldCondition(key="categoria", match=models.MatchAny(any=categorias))]
        )
        resultados = self._client.query_points(
            collection_name=self._coleccion_precisa,
            prefetch=[
                models.Prefetch(
                    query=vector_denso,
                    using="denso",
                    filter=filtro,
                    limit=top_k * 4,
                    params=models.SearchParams(hnsw_ef=ef_search),
                ),
                models.Prefetch(
                    query=vector_disperso,
                    using="disperso",
                    filter=filtro,
                    limit=top_k * 4,
                ),
            ],
            query=models.FusionQuery(fusion=models.Fusion.RRF),
            limit=top_k,
        )
        return resultados.points

    # -----------------------------------------------------------------
    # Borrado
    # -----------------------------------------------------------------

    def contar_por_filtro(self, coleccion: str, filtro: models.Filter) -> int:
        resultado = self._client.count(collection_name=coleccion, count_filter=filtro, exact=True)
        return resultado.count

    def borrar_por_id(self, coleccion: str, punto_id: str) -> None:
        self._client.delete(
            collection_name=coleccion,
            points_selector=models.PointIdsList(points=[punto_id]),
        )

    def borrar_por_filtro(self, coleccion: str, filtro: models.Filter) -> None:
        self._client.delete(
            collection_name=coleccion,
            points_selector=models.FilterSelector(filter=filtro),
        )
