#!/bin/bash

# Activar entorno y cargar variables
source venv/bin/activate
export $(grep -v '^#' config.env | xargs)

# Lanzar servidor
uvicorn tts_server:app --host 0.0.0.0 --port $PORT
