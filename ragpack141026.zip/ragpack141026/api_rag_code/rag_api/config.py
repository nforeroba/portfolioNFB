"""
Configuracion centralizada de rag-api.

Todas las variables de entorno del proyecto se leen unicamente aqui.
El resto del codigo importa el objeto `settings` de este modulo en vez
de leer variables de entorno directamente.
"""

import os
from dataclasses import dataclass, field


def _get_str(nombre: str, default: str) -> str:
    return os.environ.get(nombre, default)


def _get_int(nombre: str, default: int) -> int:
    valor = os.environ.get(nombre)
    if valor is None or valor == "":
        return default
    return int(valor)


def _get_float(nombre: str, default: float) -> float:
    valor = os.environ.get(nombre)
    if valor is None or valor == "":
        return default
    return float(valor)


def _get_bool(nombre: str, default: bool) -> bool:
    valor = os.environ.get(nombre)
    if valor is None or valor == "":
        return default
    return valor.strip().lower() in ("1", "true", "yes", "si", "on")


def _get_optional_str(nombre: str) -> str | None:
    valor = os.environ.get(nombre)
    if valor is None or valor == "":
        return None
    return valor


@dataclass(frozen=True)
class QdrantConfig:
    grpc_host: str = field(default_factory=lambda: _get_str("QDRANT_GRPC_HOST", "localhost"))
    grpc_port: int = field(default_factory=lambda: _get_int("QDRANT_GRPC_PORT", 6334))
    http_host: str = field(default_factory=lambda: _get_str("QDRANT_HTTP_HOST", "localhost"))
    http_port: int = field(default_factory=lambda: _get_int("QDRANT_HTTP_PORT", 6333))
    api_key: str | None = field(default_factory=lambda: _get_optional_str("QDRANT_API_KEY"))

    timeout_segundos: float = field(default_factory=lambda: _get_float("QDRANT_TIMEOUT_SEGUNDOS", 10.0))
    reintentos: int = field(default_factory=lambda: _get_int("QDRANT_REINTENTOS", 3))

    # Nombres de las dos colecciones (variables de entorno, no fijos en codigo,
    # para poder apuntar a colecciones alternativas durante pruebas)
    coleccion_rapida: str = field(default_factory=lambda: _get_str("QDRANT_COLECCION_RAPIDA", "rag_voicebot_0_6b"))
    coleccion_precisa: str = field(default_factory=lambda: _get_str("QDRANT_COLECCION_PRECISA", "rag_copilotos_8b"))

    # Dimension del vector por coleccion. Default = dimension nativa de cada
    # modelo, pero ambos modelos soportan MRL (Matryoshka) y pueden truncarse
    # a un valor menor. Esta variable es la UNICA fuente de verdad de la
    # dimension: qdrant_client.py, vllm_client.py y ollama_client.py la leen
    # de aqui, para que nunca queden desincronizados entre si.
    #
    # ADVERTENCIA: cambiar este valor despues de haber creado la coleccion y
    # cargado datos reales requiere recrear la coleccion desde cero y
    # reingestar todo -- Qdrant no admite vectores de tamanos distintos en
    # una misma coleccion. Ver validacion de arranque en qdrant_client.py.
    dim_coleccion_rapida: int = field(default_factory=lambda: _get_int("QDRANT_DIM_COLECCION_RAPIDA", 1024))
    dim_coleccion_precisa: int = field(default_factory=lambda: _get_int("QDRANT_DIM_COLECCION_PRECISA", 4096))

    # Parametros HNSW - coleccion rapida (prioriza velocidad)
    hnsw_rapida_m: int = field(default_factory=lambda: _get_int("QDRANT_HNSW_RAPIDA_M", 16))
    hnsw_rapida_ef_construct: int = field(default_factory=lambda: _get_int("QDRANT_HNSW_RAPIDA_EF_CONSTRUCT", 100))
    ef_search_rapida_default: int = field(default_factory=lambda: _get_int("QDRANT_EF_SEARCH_RAPIDA_DEFAULT", 64))

    # Parametros HNSW - coleccion precisa (prioriza calidad de retrieval)
    hnsw_precisa_m: int = field(default_factory=lambda: _get_int("QDRANT_HNSW_PRECISA_M", 48))
    hnsw_precisa_ef_construct: int = field(default_factory=lambda: _get_int("QDRANT_HNSW_PRECISA_EF_CONSTRUCT", 400))
    ef_search_precisa_default: int = field(default_factory=lambda: _get_int("QDRANT_EF_SEARCH_PRECISA_DEFAULT", 256))


@dataclass(frozen=True)
class VllmConfig:
    host: str = field(default_factory=lambda: _get_str("VLLM_HOST", "localhost"))
    port: int = field(default_factory=lambda: _get_int("VLLM_PORT", 8001))
    nombre_modelo: str = field(default_factory=lambda: _get_str("VLLM_NOMBRE_MODELO", "/models/model"))

    timeout_segundos: float = field(default_factory=lambda: _get_float("VLLM_TIMEOUT_SEGUNDOS", 5.0))
    reintentos: int = field(default_factory=lambda: _get_int("VLLM_REINTENTOS", 2))


@dataclass(frozen=True)
class OllamaConfig:
    host: str = field(default_factory=lambda: _get_str("OLLAMA_HOST", "localhost"))
    port: int = field(default_factory=lambda: _get_int("OLLAMA_PORT", 11434))

    # Nombre real tal como aparece en `ollama list`
    nombre_modelo_embedding: str = field(default_factory=lambda: _get_str("OLLAMA_NOMBRE_MODELO_EMBEDDING", "qwen3-embedding:8b"))

    timeout_segundos: float = field(default_factory=lambda: _get_float("OLLAMA_TIMEOUT_SEGUNDOS", 30.0))
    reintentos: int = field(default_factory=lambda: _get_int("OLLAMA_REINTENTOS", 2))


@dataclass(frozen=True)
class ChunkingConfig:
    tamano_tokens_default: int = field(default_factory=lambda: _get_int("CHUNKING_TAMANO_TOKENS_DEFAULT", 500))
    overlap_tokens_default: int = field(default_factory=lambda: _get_int("CHUNKING_OVERLAP_TOKENS_DEFAULT", 100))

    # Umbral de similitud coseno para CHUNKING_SEMANTIC: si la similitud
    # entre dos oraciones consecutivas cae por debajo de este valor, se
    # considera un cambio de tema y se corta ahi. Rango [0, 1]. Ajustable
    # para poder experimentar empiricamente contra el corpus real antes
    # de fijar un default de confianza.
    semantic_umbral_similitud: float = field(default_factory=lambda: _get_float("CHUNKING_SEMANTIC_UMBRAL_SIMILITUD", 0.75))


@dataclass(frozen=True)
class ServidorConfig:
    puerto: int = field(default_factory=lambda: _get_int("RAG_API_PUERTO", 50051))
    max_workers: int = field(default_factory=lambda: _get_int("RAG_API_MAX_WORKERS", 10))
    nivel_log: str = field(default_factory=lambda: _get_str("RAG_API_NIVEL_LOG", "INFO"))


@dataclass(frozen=True)
class Settings:
    qdrant: QdrantConfig = field(default_factory=QdrantConfig)
    vllm: VllmConfig = field(default_factory=VllmConfig)
    ollama: OllamaConfig = field(default_factory=OllamaConfig)
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    servidor: ServidorConfig = field(default_factory=ServidorConfig)


settings = Settings()
