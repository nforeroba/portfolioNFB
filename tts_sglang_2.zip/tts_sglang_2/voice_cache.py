"""
Caché de voces precargadas en memoria: VQ codes + transcripción.

load_all() se llama una sola vez al arrancar. Después, ninguna síntesis
vuelve a leer /voices: cada request usa lo ya precargado, con fallback
a default_reference_id si se pide una voz no cargada.
"""

import logging
import os
import time
from pathlib import Path

import torch

logger = logging.getLogger("voice_cache")


def _load_codec(checkpoint_dir: str, device: str = "cpu"):
    from hydra.utils import instantiate
    from omegaconf import OmegaConf

    OmegaConf.register_new_resolver("eval", eval, replace=True)
    codec_path = os.path.join(checkpoint_dir, "codec.pth")
    import sglang_omni.models.fishaudio_s2_pro.fish_speech.models.dac.modded_dac as _dac_mod

    configs_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(_dac_mod.__file__))),
        "configs",
    )
    cfg = OmegaConf.load(os.path.join(configs_dir, "modded_dac_vq.yaml"))
    codec = instantiate(cfg)
    state_dict = torch.load(
        codec_path, map_location=device, mmap=True, weights_only=True
    )
    codec.load_state_dict(state_dict, strict=False, assign=True)
    codec.eval().to(device)
    return codec


def _encode_reference_waveform(codec, audio: torch.Tensor, sr: int) -> torch.Tensor:
    import torchaudio

    if audio.shape[0] > 1:
        audio = audio.mean(0, keepdim=True)
    audio = torchaudio.functional.resample(audio, sr, codec.sample_rate)
    audios = audio.squeeze(0).unsqueeze(0)
    audio_lengths = torch.tensor([audios.shape[1]], dtype=torch.long)
    with torch.no_grad():
        indices, _ = codec.encode(audios, audio_lengths)
        if indices.ndim == 3:
            indices = indices[0]
    return indices.cpu()


def _encode_wav_file(codec, wav_path: Path) -> torch.Tensor:
    import torchaudio

    audio, sr = torchaudio.load(str(wav_path))
    return _encode_reference_waveform(codec, audio, int(sr))


class VoiceCache:
    def __init__(self, checkpoint_dir: str, device: str = "cpu"):
        self.checkpoint_dir = checkpoint_dir
        self.device = device
        self._codec = None
        self._cache: dict[str, tuple[list, str]] = {}
        self.default_reference_id: str | None = None

    def load_all(self, voices_dirs: list[Path], default_reference_id: str) -> None:
        t0 = time.perf_counter()
        self.default_reference_id = default_reference_id

        logger.info("Cargando codec DAC desde %s", self.checkpoint_dir)
        self._codec = _load_codec(self.checkpoint_dir, self.device)

        seen: set[str] = set()
        loaded = 0
        failed: list[str] = []

        for base in voices_dirs:
            if not base.is_dir():
                continue
            for wav_path in sorted(base.glob("*.wav")):
                reference_id = wav_path.stem
                if reference_id in seen:
                    continue
                seen.add(reference_id)

                txt_path = base / f"{reference_id}.txt"
                if not txt_path.exists():
                    logger.error(
                        "PRECARGA | voz '%s' omitida | falta el archivo .txt en %s",
                        reference_id, base,
                    )
                    failed.append(reference_id)
                    continue

                try:
                    transcript = txt_path.read_text(encoding="utf-8").strip()
                    vq_codes = _encode_wav_file(self._codec, wav_path)
                except Exception as e:
                    logger.error(
                        "PRECARGA | voz '%s' omitida | error al procesar %s: %s",
                        reference_id, wav_path, e,
                    )
                    failed.append(reference_id)
                    continue

                self._cache[reference_id] = (vq_codes.tolist(), transcript)
                loaded += 1
                logger.info(
                    "PRECARGA | voz '%s' cargada | shape=%s",
                    reference_id, list(vq_codes.shape),
                )

        elapsed = time.perf_counter() - t0
        logger.info(
            "PRECARGA | completa | voces_cargadas=%d | voces_fallidas=%d%s | elapsed=%.2fs",
            loaded, len(failed),
            f" ({', '.join(failed)})" if failed else "",
            elapsed,
        )

        if default_reference_id not in self._cache:
            raise RuntimeError(
                f"La voz de fallback obligatoria '{default_reference_id}' no "
                f"pudo cargarse durante la precarga. El servicio no puede "
                f"arrancar sin ella."
            )

    def get(self, reference_id: str) -> tuple[list, str]:
        if reference_id in self._cache:
            return self._cache[reference_id]

        logger.warning(
            "Voz '%s' no está precargada, usando fallback '%s'",
            reference_id, self.default_reference_id,
        )
        return self._cache[self.default_reference_id]

    def known_ids(self) -> list[str]:
        return sorted(self._cache.keys())
