#import torch
#from TTS.api import TTS
#from TTS.tts.configs.xtts_config import XttsConfig  # Importar la configuración del modelo
#from TTS.tts.models.xtts import XttsAudioConfig, XttsArgs  # Importar la configuración de audio del modelo y argumentos
#from TTS.config.shared_configs import BaseDatasetConfig  # Importar configuración del dataset

# Permitir la carga segura del modelo en PyTorch 2.6+
#torch.serialization.add_safe_globals([XttsConfig, XttsAudioConfig, BaseDatasetConfig, XttsArgs])

# Obtener el dispositivo disponible ('cuda' o 'cpu')
#device = "cuda" if torch.cuda.is_available() else "cpu"
#print(f"Using device: {device}")

# Definir el texto a sintetizar
#txt = "hola hola hola. esta es la voz clonada de cristina hernandez utilizando coqui en linux. hablo en representacion de nicolas forero. los numeros son uno dos tres cuatro cinco."

# Definir el audio de referencia
#sample = "/home/nfb/Documents/cristina_sample.wav"

# Cargar el modelo y moverlo al dispositivo
#tts1 = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(device)

# Generar el audio clonando la voz del sample
#tts1.tts_to_file(txt, speaker_wav=sample, language="es", file_path="/home/nfb/Documents/cristina_clon.wav")

#print("Síntesis de voz completada. Archivo guardado en /home/nfb/Documents/cristina_clon.wav")


import torch
from TTS.api import TTS
from TTS.tts.configs.xtts_config import XttsConfig
from TTS.tts.models.xtts import XttsAudioConfig, XttsArgs
from TTS.config.shared_configs import BaseDatasetConfig
import cpuinfo
import platform
import psutil
import os
import time
import threading

# Permitir la carga segura del modelo en PyTorch 2.6+
torch.serialization.add_safe_globals([XttsConfig, XttsAudioConfig, BaseDatasetConfig, XttsArgs])

def get_memory_usage():
    """Obtiene el uso actual de memoria RAM y VRAM"""
    # Memoria RAM
    process = psutil.Process(os.getpid())
    ram_usage = process.memory_info().rss / (1024 * 1024 * 1024)  # Convertir a GB
    
    # Memoria VRAM
    vram_usage = 0
    vram_reserved = 0
    if torch.cuda.is_available():
        vram_usage = torch.cuda.memory_allocated() / (1024 * 1024 * 1024)
        vram_reserved = torch.cuda.memory_reserved() / (1024 * 1024 * 1024)
    
    return {
        'ram_gb': ram_usage,
        'vram_gb': vram_usage,
        'vram_reserved_gb': vram_reserved
    }

def print_memory_status(stage=""):
    """Imprime el estado actual de memoria"""
    memory = get_memory_usage()
    print(f"\n=== Uso de Memoria {stage} ===")
    print(f"RAM usado: {memory['ram_gb']:.2f} GB")
    if torch.cuda.is_available():
        print(f"VRAM usado: {memory['vram_gb']:.2f} GB")
        print(f"VRAM reservado: {memory['vram_reserved_gb']:.2f} GB")

class MemoryMonitor:
    def __init__(self, interval=1.0):
        self.interval = interval
        self.running = False
        self.peak_ram = 0
        self.peak_vram = 0
    
    def start(self):
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor)
        self.monitor_thread.start()
    
    def stop(self):
        self.running = False
        self.monitor_thread.join()
        print(f"\n=== Picos de Memoria ===")
        print(f"Pico RAM: {self.peak_ram:.2f} GB")
        print(f"Pico VRAM: {self.peak_vram:.2f} GB")
    
    def _monitor(self):
        while self.running:
            memory = get_memory_usage()
            self.peak_ram = max(self.peak_ram, memory['ram_gb'])
            self.peak_vram = max(self.peak_vram, memory['vram_gb'])
            time.sleep(self.interval)

def get_device_info():
    """Obtiene y muestra información detallada del dispositivo"""
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("\n=== Información del Dispositivo ===")
    
    if device == "cuda":
        # Información de la GPU
        gpu_name = torch.cuda.get_device_name(0)
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / (1024**3)
        cuda_version = torch.version.cuda
        
        print(f"GPU: {gpu_name}")
        print(f"Memoria GPU Total: {gpu_memory:.2f} GB")
        print(f"CUDA Version: {cuda_version}")
    
    # Información de la CPU
    cpu_info = cpuinfo.get_cpu_info()
    print(f"\nCPU: {cpu_info.get('brand_raw', 'No disponible')}")
    print(f"Arquitectura: {platform.machine()}")
    print(f"Núcleos físicos: {cpu_info.get('count', 'No disponible')}")
    
    # Información del sistema
    print(f"Sistema Operativo: {platform.system()} {platform.release()}")
    
    return device

# Obtener y mostrar información del dispositivo
device = get_device_info()
print(f"\nUsando dispositivo: {device}")

# Mostrar memoria inicial
print_memory_status("INICIAL")

# Definir el texto a sintetizar (usando un texto que ejercite diferentes aspectos del habla)
txt = """
Buenos días. ¿Cómo está? Le llamo para recordarle que tiene una obligación de pago pendiente por concepto de su crédito de libre inversión con la entidad financiera Presta Ya. Actualmente, tiene un saldo pendiente de 1.234.567 pesos y 60 días de mora.
Me gustaría asesorarlo para que resuelva su deuda. 
"""

# Definir el audio de referencia
sample = "/home/nfb/Documents/muestra_sara.wav"

# Iniciar monitor de memoria
monitor = MemoryMonitor()
monitor.start()

print("\nCargando modelo XTTS v2...")
# Cargar el modelo y moverlo al dispositivo
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(device)

# Mostrar memoria después de cargar el modelo
print_memory_status("DESPUÉS DE CARGAR MODELO")

# Configuraciones a probar
configs = [
    {
        "name": "esp_base",
        "language": "es",
        "speed": 1.0,
        "temperature": 0.75
    },
    {
        "name": "esp_rapido",
        "language": "es",
        "speed": 1.5,
        "temperature": 0.75
    },
    {
        "name": "esp_lento",
        "language": "es",
        "speed": 0.75,
        "temperature": 0.75
    },
    {
        "name": "esp_temp_1",
        "language": "es",
        "speed": 1.0,
        "temperature": 1.0
    },
    {
        "name": "esp_temp_05",
        "language": "es",
        "speed": 1.0,
        "temperature": 0.5
    },
    {
        "name": "esp_fast_temp_1",
        "language": "es",
        "speed": 1.5,
        "temperature": 1.0
    },
    {
        "name": "esp_slow_temp_1",
        "language": "es",
        "speed": 0.75,
        "temperature": 1.0
    }
]

# Generar el audio con cada configuración
for i, config in enumerate(configs, 1):
    print(f"\n=== Prueba {i}/{len(configs)} ===")
    print(f"Configuración: {config['name']}")
    print(f"Language: {config['language']}")
    print(f"Speed: {config['speed']}")
    print(f"Temperature: {config['temperature']}")
    
    output_file = f"/home/nfb/Documents/sara_clon_texto2_{config['name']}.wav"
    
    try:
        # Mostrar memoria antes de la generación
        print_memory_status(f"ANTES DE GENERAR {config['name']}")
        
        tts.tts_to_file(
            text=txt,
            speaker_wav=sample,
            language=config['language'],
            speed=config['speed'],
            temperature=config['temperature'],
            file_path=output_file
        )
        
        # Mostrar memoria después de la generación
        print_memory_status(f"DESPUÉS DE GENERAR {config['name']}")
        print(f"Audio generado: {output_file}")
        
    except Exception as e:
        print(f"Error en configuración {config['name']}: {str(e)}")

# Detener monitor y mostrar picos
monitor.stop()

print("\nPruebas completadas. Revisa los archivos generados para comparar resultados.")














# Definir el texto a sintetizar (usando un texto que ejercite diferentes aspectos del habla)
#txt = """
#Buenos días. Ésta es una prueba de síntesis de voz con voz clonada.
#Buenas tardes, ésta es una prueba de síntesis de voz.
#Hola hola, ¿cómo estás?
#Los números son 1, 2, 3, 4 y 5.
#Le recordamos que tiene un pago pendiente por concepto de su crédito de consumo con la entidad financiera Bancolombia.
#¿Qué hora es?
#¡Que día tan maravilloso!
#Gracias, buenas noches, cordial saludo.
#$1234567.
#$1.234.567.