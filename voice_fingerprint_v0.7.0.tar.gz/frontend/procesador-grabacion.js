// AudioWorklet: junta muestras del micrófono en bloques y las envía al hilo principal.
class Captura extends AudioWorkletProcessor {
  constructor() {
    super();
    this.bloque = new Float32Array(2048);
    this.n = 0;
  }
  process(entradas) {
    const canal = entradas[0] && entradas[0][0];
    if (canal) {
      for (let i = 0; i < canal.length; i++) {
        this.bloque[this.n++] = canal[i];
        if (this.n === this.bloque.length) {
          this.port.postMessage(this.bloque.slice(0));
          this.n = 0;
        }
      }
    }
    return true;
  }
}
registerProcessor("captura", Captura);
