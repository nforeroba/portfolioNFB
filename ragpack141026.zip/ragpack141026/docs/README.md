# rag-api (api_rag_prototipo)

API gRPC de RAG (Retrieval-Augmented Generation) para servicios internos con LLM. Expone tres operaciones, **Retrieve**, **Ingest** y **Delete**, sobre una base vectorial Qdrant, con dos perfiles de embedding que el cliente elige de forma explicita en cada llamada.

Estado: prototipo funcional, en migracion desde el equipo de desarrollo (Bog2, aislado) a la red interna.

---

## 1. Que hace

| Perfil | Embedding | Busqueda | Coleccion Qdrant | Uso previsto |
|---|---|---|---|---|
| `PERFIL_RAPIDO` | vLLM `Qwen3-Embedding-0.6B`, denso 1024 | Densa simple (HNSW) | `rag_voicebot_0_6b` | Voicebot, mayor volumen y baja latencia |
| `PERFIL_PRECISO` | Ollama `qwen3-embedding:8b`, denso 4096 + BM25 disperso | Hibrida con fusion RRF | `rag_copilotos_8b` | Copilotos no realtime, mayor calidad |

El cliente declara el perfil en cada `Retrieve` e `Ingest`. Lo ingestado con un perfil solo se recupera con ese mismo perfil.

## 2. Arquitectura

```
 Clientes con LLM (voicebot, copilotos)          Streamlit (pruebas)
            |  gRPC :50051                         ingest_ui.py, retrieval_test.py
            v                                              |
      +-----------+  <------------------------------------+
      |  rag-api  |  Retrieve / Ingest / Delete
      +-----------+
        |    |    \
        |    |     +--> Qdrant (gRPC :6334, HTTP :6333)   colecciones rapida y precisa
        |    +--------> Ollama  :11434   /api/embed        qwen3-embedding:8b
        +-------------> vLLM    :8001    /v1/embeddings    Qwen3-Embedding-0.6B
```

Despliegue objetivo:

| Equipo | Servicios |
|---|---|
| ASUS Ascent GX10 "3.130" | Qdrant, rag-api, vLLM 0.6B secundario (imagen `hellohal2064/vllm-dgx-spark-gb10`) |
| Maquina con 2x NVIDIA H200 NVL | Ollama 8B y vLLM 0.6B (endpoints de embedding principales) |

La conmutacion entre endpoint principal y secundario es manual: se cambia `VLLM_HOST` / `VLLM_PORT` en el `.env` y se reinicia rag-api.

## 3. Estructura del proyecto

```
api_rag_code/
  proto/rag.proto                    Contrato gRPC
  rag_api/
    server.py                        Punto de entrada, servicer gRPC, apagado ordenado
    config.py                        Unico lugar donde se leen variables de entorno
    generated/                       rag_pb2.py, rag_pb2_grpc.py (generados con protoc)
    services/
      retrieve_service.py            Logica de Retrieve (rapido / preciso)
      ingest_service.py              Logica de Ingest (modo A / modo B), ids, vectores
      delete_service.py              Logica de Delete (por id / por filtro, dry_run)
    clients/
      qdrant_client.py               Colecciones, upsert, busqueda, borrado
      vllm_client.py                 Embeddings via /v1/embeddings, con reintentos
      ollama_client.py               Embeddings via /api/embed, con reintentos
    chunking/
      base.py                        Interfaz comun y ChunkGenerado
      recursivo.py  fijo.py  semantic.py  ast_codigo.py  clausula_legal.py
  scripts/bootstrap_collections.py   Crea/verifica colecciones sin levantar el servidor
  ingest_ui.py                       UI Streamlit: Ingest y Delete
  retrieval_test.py                  UI Streamlit: chatbot con RAG on/off
  test_ingest_rapido.py              Prueba de humo de Ingest por consola
  requirements.txt
  .env                               Configuracion (ver seccion 6)
```

## 4. Contrato gRPC (resumen)

Definido en `proto/rag.proto`, paquete `rag.v1`, servicio `RagService`.

### Retrieve
Entrada: `query`, `categoria_principal`, `categorias_adicionales[]`, `top_k`, `perfil`, `ef_search` (opcional, sustituye el default de HNSW para esa consulta).
Salida: `resultados[]` (cada `Chunk` trae `id`, `texto`, `fuente`, `categoria`, `score` y `texto_padre` opcional), `categoria_usada`, `perfil_usado`.
La busqueda filtra por `categoria` dentro de `[categoria_principal, *categorias_adicionales]`.

### Ingest
Entrada: `categoria`, `fuente`, `perfil` y uno de estos modos (`oneof contenido`):
- **Modo A, `documento`**: la API chunkea. Requiere `estrategia` explicita; `parametros` (`tamano_tokens`, `overlap_tokens`) y `lenguaje_codigo` son opcionales segun la estrategia.
- **Modo B, `chunks`**: el cliente ya chunkeo. Cada `ChunkEntrante` trae `id` y `texto`.

Salida: `chunks_insertados`, `chunks_actualizados`, `ids_generados[]`.

### Delete
Entrada: `id` puntual o `filtro` (`categoria`, `fuente`, `fecha_antes_de`; al menos uno), mas `dry_run`. Se aplica siempre sobre **ambas** colecciones. Un filtro vacio se rechaza. Con `dry_run=true` solo cuenta.

### Codigos de error
`INVALID_ARGUMENT` para `ValueError` y filtro vacio; `INTERNAL` para el resto de excepciones (se registran con traza en el log del servidor).

## 5. Estrategias de chunking (solo Modo A)

| Estrategia | Como corta | Usa tamano | Usa overlap | `texto_padre` |
|---|---|---|---|---|
| `CHUNKING_RECURSIVO` | Parrafo, luego linea, luego oracion; corte ciego por tokens como ultimo recurso | Si | Si | No |
| `CHUNKING_FIJO` | Corte ciego cada N tokens (control para comparar) | Si | Si | No |
| `CHUNKING_SEMANTIC` | Por cambio de tema: similitud coseno entre oraciones consecutivas bajo un umbral, usando el motor de embeddings del perfil | Si (tope de grupo) | Si | No |
| `CHUNKING_AST_CODIGO` | Tree-sitter (patron cAST): agrupa nodos de nivel superior sin partirlos; recursiona a los hijos si un nodo es demasiado grande | Si | No | Preambulo: archivo, scope, firma |
| `CHUNKING_CLAUSULA_LEGAL_JERARQUICA` | Por articulo/clausula (ver abajo) | Si | No | Articulo completo |

Lenguajes AST: `python`, `javascript`, `html`, `cpp` (gramaticas oficiales) y `sql` (gramatica comunitaria, sin probar contra casos reales).

### Cláusula legal jerárquica

Pensada para leyes, decretos, resoluciones, acuerdos y contratos en Markdown o texto plano.

- **Padre = articulo.** Los hijos son el cuerpo del articulo y cada parrafo. Un articulo sin parrafos que cabe en el tamano es un solo chunk, sin padre. Si el articulo supera 4 veces el tamano, se omite el padre.
- **Considerandos** ("Que ..."): se agrupan en chunks sin padre.
- **Cierre**: PUBLIQUESE, firmas y nombres van en un unico chunk.
- **Citas en bloque** (`>`): quedan dentro del articulo que las contiene, sin generar estructura propia.
- **Prefijo de contexto**: la primera linea de cada chunk es, por ejemplo, `LEY No. 2635 ... | ARTICULO 2. Infraestructura ...`. Forma parte del texto que se vectoriza.
- El texto del chunk sale sin formato Markdown.
- Si el documento no tiene articulos ni clausulas, se registra una advertencia y se divide por parrafos y oraciones, sin padre.
- Nunca corta una palabra por la mitad.

## 6. Configuracion

`config.py` lee **solo** `os.environ`; no carga el `.env` por si mismo. Antes de arrancar:

```bash
set -a; source .env; set +a
```

Variables principales (todas con default en `config.py`):

| Grupo | Variables |
|---|---|
| Qdrant | `QDRANT_GRPC_HOST/PORT` (6334), `QDRANT_HTTP_HOST/PORT` (6333), `QDRANT_API_KEY` (vacio = sin clave), `QDRANT_TIMEOUT_SEGUNDOS`, `QDRANT_REINTENTOS`, `QDRANT_COLECCION_RAPIDA/PRECISA` |
| Dimensiones | `QDRANT_DIM_COLECCION_RAPIDA` (1024), `QDRANT_DIM_COLECCION_PRECISA` (4096). Fuente unica de verdad: la usan Qdrant, vLLM y Ollama |
| HNSW | `QDRANT_HNSW_RAPIDA_M/EF_CONSTRUCT`, `QDRANT_EF_SEARCH_RAPIDA_DEFAULT`, y los equivalentes `PRECISA` |
| vLLM | `VLLM_HOST`, `VLLM_PORT` (8001), `VLLM_NOMBRE_MODELO` (`/models/model`), `VLLM_TIMEOUT_SEGUNDOS`, `VLLM_REINTENTOS` |
| Ollama | `OLLAMA_HOST`, `OLLAMA_PORT` (11434), `OLLAMA_NOMBRE_MODELO_EMBEDDING` (`qwen3-embedding:8b`), `OLLAMA_TIMEOUT_SEGUNDOS`, `OLLAMA_REINTENTOS` |
| Chunking | `CHUNKING_TAMANO_TOKENS_DEFAULT` (500), `CHUNKING_OVERLAP_TOKENS_DEFAULT` (100), `CHUNKING_SEMANTIC_UMBRAL_SIMILITUD` (0.75) |
| Servidor | `RAG_API_PUERTO` (50051), `RAG_API_MAX_WORKERS` (10), `RAG_API_NIVEL_LOG` (`INFO`; en el `.env` actual esta en `DEBUG`) |
| Offline | `FASTEMBED_CACHE_PATH`, `TIKTOKEN_CACHE_DIR`, `HF_HUB_OFFLINE=1` |

**Cambiar una dimension** con la coleccion ya creada obliga a borrar la coleccion y reingestar todo. El servidor lo detecta al arrancar (`DimensionInconsistenteError`) y se niega a iniciar.

## 7. Instalacion y arranque

### 7.1 Entorno Python

```bash
python3 -m venv rag-env
source rag-env/bin/activate
pip install -r requirements.txt
pip install streamlit langchain langchain-ollama langgraph   # solo para las UIs
```

En la GX10 (aarch64) el entorno debe construirse en la propia maquina.

### 7.2 Regenerar los stubs gRPC (solo si cambia el `.proto`)

```bash
python -m grpc_tools.protoc \
  -I proto \
  --python_out=rag_api/generated \
  --grpc_python_out=rag_api/generated \
  proto/rag.proto
```

Despues revisa que el import en `rag_pb2_grpc.py` sea `from rag_api.generated import rag_pb2 as rag__pb2`.

### 7.3 Qdrant (GX10)

```bash
docker run -d --name qdrant --restart unless-stopped \
  -p 6333:6333 -p 6334:6334 \
  -e QDRANT__TELEMETRY_DISABLED=true \
  -v /home/user_ia/api_rag_prototipo/qdrant_storage:/qdrant/storage \
  qdrant/qdrant
```

### 7.4 vLLM secundario (GX10, imagen hellohal2064)

```bash
docker run -d --name vllm-embedding-06b --gpus all --restart unless-stopped \
  --no-healthcheck -p 8001:8000 \
  -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model \
  -e MODEL_PATH=/models/model -e MAX_MODEL_LEN=32768 -e GPU_MEMORY_UTIL=0.3 \
  -e HF_HUB_OFFLINE=1 \
  hellohal2064/vllm-dgx-spark-gb10:latest \
  --hf_overrides '{"matryoshka_dimensions": [32, 64, 128, 256, 512, 1024]}'
```

- `--no-healthcheck` evita el ruido de health checks frecuentes en el log de esa imagen.
- `matryoshka_dimensions` es lo que permite pedir `dimensions=1024` en `/v1/embeddings`.

### 7.5 vLLM y Ollama principales (H200)

- vLLM: imagen `vllm/vllm-openai` (probada la version 0.31.0), modelo `Qwen3-Embedding-0.6B` en modo embeddings (`--runner pooling --convert embed`), con los mismos `matryoshka_dimensions` via `--hf-overrides`.
- Ollama: `ollama pull qwen3-embedding:8b`. Mantener `OLLAMA_KEEP_ALIVE=-1` y `OLLAMA_HOST=0.0.0.0:11434`. La cuantizacion debe ser la misma en Ingest y en Retrieve.

### 7.6 Operacion sin internet

Los equipos tienen internet solo en una ventana corta. Todo debe descargarse una vez y quedar en disco:

| Elemento | Donde queda |
|---|---|
| Pesos Qwen3-Embedding-0.6B | `/home/user_ia/api_rag_prototipo/qwen3_0_6_b` |
| Modelo `qwen3-embedding:8b` | Almacen de Ollama en la H200 |
| Imagenes Docker | Docker local |
| Wheels de Python | Entorno `rag-env` (construido en la GX10) |
| Cache BM25 (fastembed) | `FASTEMBED_CACHE_PATH` |
| Vocabulario tiktoken `cl100k_base` | `TIKTOKEN_CACHE_DIR` |

Prueba estricta sin red: arrancar el servidor con un proxy muerto (`HTTPS_PROXY=http://127.0.0.1:9 HTTP_PROXY=http://127.0.0.1:9 NO_PROXY=localhost,127.0.0.1`) y confirmar que no intenta descargar nada.

### 7.7 Arrancar rag-api

```bash
cd api_rag_code
source ../rag-env/bin/activate
set -a; source .env; set +a
python -m scripts.bootstrap_collections     # opcional: solo verifica/crea colecciones
python -m rag_api.server
```

El servidor crea las colecciones si no existen (con indice `categoria` como tenant y, en la precisa, vector disperso con modificador IDF), y escucha en `RAG_API_PUERTO`. `SIGTERM`/`SIGINT` provocan apagado ordenado (10 s de gracia).

### 7.8 Health checks manuales

```bash
curl -s http://HOST:6333/healthz              # Qdrant
curl -s http://HOST:8001/health               # vLLM
curl -s http://HOST:11434/api/tags            # Ollama (modelos)
curl -s http://HOST:11434/api/ps              # Ollama (modelos cargados)
```

## 8. Interfaces de prueba

Con rag-api corriendo y desde `api_rag_code`:

```bash
streamlit run ingest_ui.py        # Ingest (modo A y B) y Delete
streamlit run retrieval_test.py   # Chatbot con RAG on/off sobre Retrieve
```

**ingest_ui.py**: cubre todos los campos del contrato para Ingest y Delete. En modo A permite pegar texto o **cargar un archivo** (`.txt`, `.md`, `.py`, `.js`, `.html`, `.sql`, `.c`, `.h`, `.cc`, `.cpp`, `.hpp`); al cargarlo llena `texto` y `fuente`, y si es codigo preselecciona AST y el lenguaje. El tamano de chunk se puede fijar para las cinco estrategias; el overlap solo para las que lo usan. Muestra la solicitud y la respuesta crudas en protobuf.

**retrieval_test.py**: chatbot (LangGraph + Ollama) con interruptor de RAG, selector de perfil, categorias, `top_k`, `ef_search` y vista de los chunks recuperados con su score.

**test_ingest_rapido.py**: Ingest de humo por consola (perfil rapido, estrategia recursiva).

## 9. Identificadores y reingesta

En modo A el id de cada chunk es un `uuid5` derivado de `fuente::perfil::indice::sha256(texto)[:16]`.

- Reingestar un documento **identico** actualiza los mismos puntos (upsert), no duplica.
- Reingestar un documento **modificado**, o cambiar de estrategia o de tamano, genera ids nuevos y **deja huerfanos los puntos viejos**.
- Por eso, antes de reingestar: `Delete` por `fuente` (primero con `dry_run=true` para ver cuantos puntos afecta).
- En modo B el id lo pone el cliente (si lo omite, la UI genera un uuid4).

## 10. Limitaciones conocidas y pendientes

Comportamientos del codigo actual a tener presentes:

1. **Perfil por defecto**: `perfil` es un enum proto3 y `PERFIL_RAPIDO = 0`. Un cliente que no lo envie usa el perfil rapido sin error, aunque el contrato lo describa como obligatorio.
2. **Errores de validacion como `INTERNAL`**: `LenguajeNoSoportadoError` (AST sin lenguaje o con lenguaje invalido) no es un `ValueError`, por lo que llega al cliente como `INTERNAL` y no como `INVALID_ARGUMENT`. Lo mismo ocurre con un id no UUID en modo B.
3. **Modo B incompleto**: `metadata_adicional` y `fecha_ingesta` del `ChunkEntrante` se reciben pero no se guardan en el payload (la fecha se asigna al insertar). Un `ChunksPreCortados` vacio probablemente falle al pedir embeddings de una lista vacia.
4. **Sin validacion de entrada en Retrieve**: `top_k = 0` o `categoria_principal` vacia no se rechazan.
5. **`chunks_actualizados` siempre es 0**: Qdrant hace upsert y el prototipo no distingue insercion de actualizacion.
6. **Overlap en recursivo y semantic**: se antepone la cola de tokens del chunk anterior; esa cola puede empezar a mitad de palabra.
7. **`CHUNKING_SEMANTIC`** embebe todas las oraciones en una sola peticion y solo separa por `.`, `!`, `?`.
8. **Comentarios desactualizados**: el `.proto` y `chunking/base.py` aun describen el padre legal como "capitulo/seccion", y el `.proto` dice que `parametros` aplica solo a fijo y recursivo.
9. **Seguridad**: el puerto gRPC es inseguro (sin TLS ni autenticacion). Qdrant opera sin API key. Si se activa la clave en Qdrant, `qdrant_client.py` debe pasar `https=False` al cliente, porque `qdrant-client` asume HTTPS cuando recibe `api_key` y el servidor no usa TLS.
10. **Dependencias sin version fijada** en `requirements.txt`; `retrieval_test.py` e `ingest_ui.py` requieren paquetes que no estan listados (streamlit, langchain, langchain-ollama, langgraph).
11. **SQL en AST**: `tree-sitter-sql` no esta validado contra la interfaz esperada.

Pendientes del proyecto:

- Probar `Delete` real (solo se ha usado `dry_run`) y las estrategias fijo, semantic y AST de extremo a extremo.
- Validar Retrieve e Ingest completos en la GX10 con la prueba estricta sin red.
- Actualizar el `.env` a la topologia final (`VLLM_HOST` / `OLLAMA_HOST` hacia la H200, `RAG_API_NIVEL_LOG=INFO`).
- Exponer las UIs de Streamlit y Qdrant mediante nginx en el servidor .132 (a la espera de la decision del arquitecto: tipo de certificado, autenticacion, consumidores del puerto 50051).
- Decidir la API key de Qdrant.
- Ollama 8B en la H200: etiqueta de cuantizacion, keep-alive persistente y cuidado al reiniciar por ser un equipo de produccion.
