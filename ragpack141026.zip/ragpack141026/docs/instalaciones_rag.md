# Instalaciones en ASUS GX10 3.130

## Descarga imágenes docker

docker pull qdrant/qdrant:latest
docker pull hellohal2064/vllm-dgx-spark-gb10:latest

## Descarga del modelo de embedding qwen3-embedding-0.6b

python3 -m venv ~/hf-env
source ~/hf-env/bin/activate
pip install -U huggingface_hub
hf download Qwen/Qwen3-Embedding-0.6B --local-dir /home/user_ia/api_rag_prototipo/qwen3_0_6_b
deactivate
ls -lh /home/user_ia/api_rag_prototipo/qwen3_0_6_b

## Ejecución Qdrant

docker run -d --name qdrant --restart unless-stopped \
  -p 6333:6333 -p 6334:6334 \
  -e QDRANT__TELEMETRY_DISABLED=true \
  -v /home/user_ia/api_rag_prototipo/qdrant_storage:/qdrant/storage \
  qdrant/qdrant && docker logs -f qdrant

- Prueba rápida: curl -s http://localhost:6333

## Ejecución vLLM 0.6B

docker run -d --name vllm-embedding-06b \
  --gpus all --restart unless-stopped \
  --no-healthcheck \
  -p 8001:8000 \
  -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model \
  -e MODEL_PATH=/models/model \
  -e MAX_MODEL_LEN=32768 \
  -e GPU_MEMORY_UTIL=0.3 \
  -e HF_HUB_OFFLINE=1 \
  hellohal2064/vllm-dgx-spark-gb10:latest \
  --hf_overrides '{"matryoshka_dimensions": [32, 64, 128, 256, 512, 1024]}' && docker logs -f vllm-embedding-06b

- Pruebas rápidas:

curl -s http://localhost:8001/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model": "/models/model", "input": ["prueba de embedding"], "dimensions": 1024}' \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d['data'][0]['embedding']))"

curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8001/health

## Entorno rag-env (con el código ya copiado en api_rag_code)

cd /home/user_ia/api_rag_prototipo/api_rag_code
python3 -m venv rag-env
source rag-env/bin/activate
pip install -U pip
pip install -r requirements.txt
pip install streamlit langchain langchain-ollama langgraph
pip freeze > requirements-freeze.txt
pip download -r requirements.txt streamlit langchain langchain-ollama langgraph -d /home/user_ia/api_rag_prototipo/wheelhouse

- Validar los parsers de tree-sitter (incluido SQL):

python -c "from rag_api.chunking.ast_codigo import _cargar_parser; [print(l, _cargar_parser(l)) for l in ('python','javascript','html','sql','cpp')]"

- Poblar cachés de tiktoken y BM25:

mkdir -p /home/user_ia/api_rag_prototipo/cache/fastembed /home/user_ia/api_rag_prototipo/cache/tiktoken

export FASTEMBED_CACHE_PATH=/home/user_ia/api_rag_prototipo/cache/fastembed
export TIKTOKEN_CACHE_DIR=/home/user_ia/api_rag_prototipo/cache/tiktoken

python -c "import tiktoken; tiktoken.get_encoding('cl100k_base'); from fastembed.sparse.bm25 import Bm25; Bm25(model_name='Qdrant/bm25', language='spanish'); print('ok')"

- Añadir estas líneas al .env (HF_HUB_OFFLINE=1 solo después de que el comando anterior funcione):

FASTEMBED_CACHE_PATH=/home/user_ia/api_rag_prototipo/cache/fastembed
TIKTOKEN_CACHE_DIR=/home/user_ia/api_rag_prototipo/cache/tiktoken
HF_HUB_OFFLINE=1

- Verificar en el .env de rag-api en el 3.130:

QDRANT_GRPC_HOST=localhost
QDRANT_HTTP_HOST=localhost
QDRANT_API_KEY=

VLLM_HOST=IP_DE_LAS_H200
VLLM_PORT=8001
VLLM_NOMBRE_MODELO=/models/model

OLLAMA_HOST=IP_DE_LAS_H200
OLLAMA_PORT=11434


## Prueba final sin internet (en 3.130)

docker restart qdrant vllm-embedding-06b
cd /home/user_ia/api_rag_prototipo/api_rag_code
source rag-env/bin/activate
set -a; source .env; set +a
python -m rag_api.server

No debe aparecer Downloading ni Fetching en el arranque. 

Desde otra terminal, ejecutar test_ingest_rapido.py y una consultar con el perfil preciso para confirmar el camino completo, incluido el Ollama de las H200.

# Pruebas de endpoints en H200

## vLLM 0.6B

curl -s -o /dev/null -w "HTTP %{http_code}\n" --max-time 3 http://IP_H200:PUERTO_VLLM/health

curl -s --max-time 5 http://IP_H200:PUERTO_VLLM/v1/models | python3 -m json.tool

curl -s --max-time 10 -w "\ntiempo: %{time_total}s\n" http://IP_H200:PUERTO_VLLM/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model": "/models/model", "input": ["prueba de embedding"], "dimensions": 1024}' \
  | python3 -c "
import sys
raw = sys.stdin.read()
cuerpo, _, tiempo = raw.rpartition('\ntiempo:')
import json
d = json.loads(cuerpo)
print('dimensiones:', len(d['data'][0]['embedding']))
print('tiempo:' + tiempo.strip())
"

## Ollama 8B

curl -s --max-time 3 http://IP_H200:PUERTO_OLLAMA/

curl -s --max-time 5 http://IP_H200:PUERTO_OLLAMA/api/tags | python3 -m json.tool

curl -s --max-time 30 -w "\ntiempo: %{time_total}s\n" http://IP_H200:PUERTO_OLLAMA/api/embed \
  -d '{"model": "qwen3-embedding:8b", "input": ["prueba de embedding"], "dimensions": 4096}' \
  | python3 -c "
import sys, json
raw = sys.stdin.read()
cuerpo, _, tiempo = raw.rpartition('\ntiempo:')
d = json.loads(cuerpo)
print('dimensiones:', len(d['embeddings'][0]))
print('tiempo:' + tiempo.strip())
"




