"""
Script ejecutado durante el docker build para descargar
los modelos desde HuggingFace Hub a /app/models/
"""

import os
import sys
from huggingface_hub import snapshot_download

HF_TOKEN = os.environ.get("HF_TOKEN")
if not HF_TOKEN:
    print("ERROR: HF_TOKEN no está definido.", file=sys.stderr)
    sys.exit(1)

MODELS_DIR = "/app/models"
os.makedirs(MODELS_DIR, exist_ok=True)

MODELS = [
    "Qwen/Qwen2.5-0.5B-Instruct",
    "Qwen/Qwen2.5-1.5B-Instruct",
    "Qwen/Qwen2.5-3B-Instruct",
    "google/gemma-3-1b-it",
    "HuggingFaceTB/SmolLM2-1.7B-Instruct",
    "microsoft/Phi-3.5-mini-instruct",
]

for model_id in MODELS:
    # Convierte "Qwen/Qwen2.5-1.5B-Instruct" -> "Qwen--Qwen2.5-1.5B-Instruct"
    local_name = model_id.replace("/", "--")
    local_path = os.path.join(MODELS_DIR, local_name)

    print(f"\n{'='*60}")
    print(f"Descargando: {model_id}")
    print(f"Destino:     {local_path}")
    print(f"{'='*60}")

    try:
        snapshot_download(
            repo_id=model_id,
            local_dir=local_path,
            token=HF_TOKEN,
            ignore_patterns=["*.msgpack", "*.h5", "flax_model*", "tf_model*"],
        )
        print(f"OK: {model_id} descargado correctamente.")
    except Exception as e:
        print(f"ERROR descargando {model_id}: {e}", file=sys.stderr)
        sys.exit(1)

print(f"\nTodos los modelos descargados en {MODELS_DIR}")
