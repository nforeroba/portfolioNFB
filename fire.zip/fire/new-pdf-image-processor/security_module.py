#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo de seguridad para manejo de credenciales y operaciones sensibles.
"""

import os
import base64
import logging
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Configurar logging
logger = logging.getLogger("Security")

class SecurityManager:
    """
    Clase para gestionar operaciones de seguridad como encriptación/desencriptación
    de credenciales sensibles.
    """
    
    def __init__(self, key_file=None):
        """
        Inicializa el gestor de seguridad.
        
        Args:
            key_file (str, optional): Ruta al archivo de clave. Si no existe, se generará.
        """
        self.key_file = key_file or os.path.join(os.path.dirname(os.path.abspath(__file__)), '.security_key')
        self.key = self._load_or_generate_key()
        self.cipher_suite = Fernet(self.key)
    
    def _load_or_generate_key(self):
        """
        Carga la clave de encriptación o genera una nueva si no existe.
        
        Returns:
            bytes: Clave de encriptación.
        """
        if os.path.exists(self.key_file):
            try:
                with open(self.key_file, 'rb') as f:
                    return f.read()
            except Exception as e:
                logger.error(f"Error al leer clave de encriptación: {str(e)}")
                # Si hay error al leer, generar nueva clave
        
        # Generar nueva clave
        try:
            key = Fernet.generate_key()
            
            # Guardar la clave con permisos restrictivos
            with open(self.key_file, 'wb') as f:
                f.write(key)
            
            # Establecer permisos (solo lectura para el propietario)
            os.chmod(self.key_file, 0o400)
            
            return key
        except Exception as e:
            logger.error(f"Error al generar clave de encriptación: {str(e)}")
            # Fallback a una clave derivada del hostname (menos seguro, pero funcional)
            salt = b'pdf_processor_salt'
            hostname = os.uname().nodename.encode() if hasattr(os, 'uname') else os.environ.get('COMPUTERNAME', 'unknown').encode()
            
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            
            return base64.urlsafe_b64encode(kdf.derive(hostname))
    
    def encrypt(self, data):
        """
        Encripta datos sensibles.
        
        Args:
            data (str): Datos a encriptar.
            
        Returns:
            str: Datos encriptados en formato base64.
        """
        if not data:
            return ""
            
        try:
            encrypted = self.cipher_suite.encrypt(data.encode())
            return base64.urlsafe_b64encode(encrypted).decode()
        except Exception as e:
            logger.error(f"Error al encriptar datos: {str(e)}")
            return ""
    
    def decrypt(self, encrypted_data):
        """
        Desencripta datos.
        
        Args:
            encrypted_data (str): Datos encriptados en formato base64.
            
        Returns:
            str: Datos desencriptados.
        """
        if not encrypted_data:
            return ""
            
        try:
            decrypted = self.cipher_suite.decrypt(base64.urlsafe_b64decode(encrypted_data))
            return decrypted.decode()
        except Exception as e:
            logger.error(f"Error al desencriptar datos: {str(e)}")
            return ""
    
    def secure_db_config(self, db_config):
        """
        Devuelve una configuración de BD segura, desencriptando la contraseña si es necesario.
        
        Args:
            db_config (dict): Configuración de la base de datos.
            
        Returns:
            dict: Configuración de la base de datos con contraseña desencriptada si es necesario.
        """
        # Comprobar si la contraseña parece estar encriptada
        password = db_config.get('password', '')
        
        # Si la contraseña comienza con 'enc:', desencriptar
        if password and password.startswith('enc:'):
            try:
                # Remover el prefijo 'enc:' y desencriptar
                decrypted_password = self.decrypt(password[4:])
                
                # Crear una copia de la configuración con la contraseña desencriptada
                secure_config = db_config.copy()
                secure_config['password'] = decrypted_password
                
                return secure_config
            except Exception as e:
                logger.error(f"Error al desencriptar contraseña de BD: {str(e)}")
        
        # Si no está encriptada o hay error, devolver configuración original
        return db_config
