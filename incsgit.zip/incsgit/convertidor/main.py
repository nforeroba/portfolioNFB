# main.py
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                            QPushButton, QLabel, QComboBox, QFileDialog, QGroupBox, 
                            QRadioButton, QMessageBox, QSizePolicy, QSlider)
from PyQt6.QtCore import Qt, QSize, QUrl
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput

# Bibliotecas para procesamiento de audio
import librosa
import librosa.display
import soundfile as sf
from pydub import AudioSegment
import subprocess
import tempfile
from pathlib import Path

def setup_ffmpeg():
    """Implementación más robusta para configurar FFmpeg"""
    try:
        # Determinar si estamos en un ejecutable o en modo desarrollo
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.dirname(os.path.abspath(__file__))
        
        # Crear un directorio temporal para extraer los binarios si es necesario
        temp_dir = None
        
        # Intentar encontrar FFmpeg en la carpeta predefinida
        ffmpeg_dir = os.path.join(base_path, 'ffmpeg')
        
        if os.path.exists(ffmpeg_dir):
            # Comprobar que los binarios existen
            ffmpeg_exe = os.path.join(ffmpeg_dir, 'ffmpeg.exe')
            ffprobe_exe = os.path.join(ffmpeg_dir, 'ffprobe.exe')
            
            if os.path.exists(ffmpeg_exe) and os.path.exists(ffprobe_exe):
                print(f"FFmpeg encontrado en: {ffmpeg_dir}")
            else:
                print(f"Binarios de FFmpeg incompletos en: {ffmpeg_dir}")
                return False
        else:
            # Si no se encuentra la carpeta ffmpeg, intentar buscar FFmpeg en el PATH
            try:
                subprocess.run(['ffmpeg', '-version'], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                # Si llegamos aquí, ffmpeg está disponible en el PATH
                ffmpeg_exe = 'ffmpeg'
                ffprobe_exe = 'ffprobe'
                print("Usando FFmpeg disponible en el PATH del sistema")
            except (subprocess.SubprocessError, FileNotFoundError):
                print("FFmpeg no encontrado en el PATH del sistema")
                return False
        
        # Imprimir rutas para depuración
        print(f"FFmpeg path: {ffmpeg_exe}")
        print(f"FFprobe path: {ffprobe_exe}")
        
        # Configurar pydub con las rutas absolutas
        AudioSegment.converter = ffmpeg_exe
        AudioSegment.ffmpeg = ffmpeg_exe
        AudioSegment.ffprobe = ffprobe_exe
        
        # Verificar que FFmpeg funciona correctamente
        try:
            # Crear un pequeño archivo de prueba
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                temp_path = temp_file.name
            
            # Generar un archivo de audio de prueba usando numpy y soundfile
            sample_rate = 44100
            duration = 0.1  # segundos
            t = np.linspace(0, duration, int(sample_rate * duration))
            data = np.sin(2 * np.pi * 440 * t)  # Tono A 440Hz
            sf.write(temp_path, data, sample_rate)
            
            # Intentar cargar el archivo con pydub
            test_audio = AudioSegment.from_wav(temp_path)
            
            # Intentar exportar a MP3 (lo que requerirá FFmpeg)
            test_mp3_path = temp_path.replace('.wav', '.mp3')
            test_audio.export(test_mp3_path, format='mp3')
            
            # Limpiar archivos temporales
            try:
                os.remove(temp_path)
                os.remove(test_mp3_path)
            except:
                pass
                
            print("FFmpeg configurado y probado correctamente")
            return True
            
        except Exception as e:
            print(f"Error al probar FFmpeg: {e}")
            return False
            
    except Exception as e:
        print(f"Error en setup_ffmpeg: {e}")
        return False

# Llamar a la función al inicio
ffmpeg_ready = setup_ffmpeg()

class WaveformCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig, self.ax = plt.subplots(figsize=(width, height), dpi=dpi)
        super().__init__(self.fig)
        self.setParent(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.clear_plot()
        
    def clear_plot(self):
        self.ax.clear()
        self.ax.set_xlabel('Tiempo (s)')
        self.ax.set_ylabel('Amplitud')
        self.ax.set_title('Forma de Onda')
        self.ax.grid(True, linestyle='--', alpha=0.7)
        self.draw()
        
    def plot_waveform(self, audio_file):
        self.clear_plot()
        try:
            # Cargar archivo de audio
            y, sr = librosa.load(audio_file, sr=None)
            
            # Calcular duración en segundos
            duration = librosa.get_duration(y=y, sr=sr)
            
            # Crear eje x en segundos
            time = np.linspace(0, duration, len(y))
            
            # Graficar forma de onda
            self.ax.plot(time, y, color='#2a9df4')
            self.ax.set_xlim(0, duration)
            self.ax.set_title(f'Forma de Onda - {os.path.basename(audio_file)}')
            self.fig.tight_layout()
            self.draw()
            return True
        except Exception as e:
            print(f"Error al graficar forma de onda: {e}")
            return False

class AudioConverter(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Convertidor de Audio MP3/WAV")
        self.setMinimumSize(800, 600)
        
        # Variables para almacenar rutas de archivos
        self.current_file = None
        self.output_file = None
        
        # Configurar reproductor de audio
        self.player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.player.setAudioOutput(self.audio_output)
        
        # Configurar interfaz
        self.setup_ui()
        
    def setup_ui(self):
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Layout principal
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        # Sección de carga de archivo
        load_group = QGroupBox("Cargar Archivo de Audio")
        load_layout = QVBoxLayout()
        
        # Botones de carga
        load_btn_layout = QHBoxLayout()
        
        self.load_mp3_btn = QPushButton("Cargar MP3")
        self.load_mp3_btn.clicked.connect(lambda: self.load_file('mp3'))
        
        self.load_wav_btn = QPushButton("Cargar WAV")
        self.load_wav_btn.clicked.connect(lambda: self.load_file('wav'))
        
        load_btn_layout.addWidget(self.load_mp3_btn)
        load_btn_layout.addWidget(self.load_wav_btn)
        
        # Etiqueta para mostrar archivo cargado
        self.file_label = QLabel("Ningún archivo seleccionado")
        self.file_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        load_layout.addLayout(load_btn_layout)
        load_layout.addWidget(self.file_label)
        load_group.setLayout(load_layout)
        main_layout.addWidget(load_group)
        
        # Sección para visualización y información
        viz_info_layout = QHBoxLayout()
        
        # Grupo para información del audio
        info_group = QGroupBox("Información del Audio")
        info_layout = QVBoxLayout()
        
        self.format_label = QLabel("Formato: -")
        self.channels_label = QLabel("Canales: -")
        self.sample_rate_label = QLabel("Frecuencia de muestreo: -")
        self.bit_depth_label = QLabel("Profundidad de bits: -")
        self.bitrate_label = QLabel("Tasa de bits: -")
        self.duration_label = QLabel("Duración: -")
        
        info_layout.addWidget(self.format_label)
        info_layout.addWidget(self.channels_label)
        info_layout.addWidget(self.sample_rate_label)
        info_layout.addWidget(self.bit_depth_label)
        info_layout.addWidget(self.bitrate_label)
        info_layout.addWidget(self.duration_label)
        info_layout.addStretch()
        
        info_group.setLayout(info_layout)
        viz_info_layout.addWidget(info_group, 1)
        
        # Grupo para visualización de la forma de onda
        viz_group = QGroupBox("Visualización")
        viz_layout = QVBoxLayout()
        
        self.waveform_canvas = WaveformCanvas(self, width=4, height=3)
        viz_layout.addWidget(self.waveform_canvas)
        
        # Control de reproducción
        playback_layout = QHBoxLayout()
        
        self.play_btn = QPushButton("▶ Reproducir")
        self.play_btn.clicked.connect(self.toggle_playback)
        self.play_btn.setEnabled(False)
        
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(70)
        self.volume_slider.valueChanged.connect(self.set_volume)
        
        playback_layout.addWidget(self.play_btn)
        playback_layout.addWidget(QLabel("Volumen:"))
        playback_layout.addWidget(self.volume_slider)
        
        viz_layout.addLayout(playback_layout)
        
        viz_group.setLayout(viz_layout)
        viz_info_layout.addWidget(viz_group, 2)
        
        main_layout.addLayout(viz_info_layout)
        
        # Sección de configuración de conversión
        conversion_group = QGroupBox("Configuración de Conversión")
        conversion_layout = QVBoxLayout()
        
        # Selección de profundidad de bits
        bit_depth_layout = QHBoxLayout()
        bit_depth_layout.addWidget(QLabel("Profundidad de Bits:"))
        
        self.bit_depth_combo = QComboBox()
        self.bit_depth_combo.addItems(["16 bits", "24 bits", "32 bits"])
        bit_depth_layout.addWidget(self.bit_depth_combo)
        
        # Selección de tasa de bits
        bitrate_layout = QHBoxLayout()
        bitrate_layout.addWidget(QLabel("Tasa de Bits:"))
        
        self.bitrate_combo = QComboBox()
        self.bitrate_combo.addItems(["128 kbps", "192 kbps", "256 kbps", "320 kbps", "512 kbps"])
        self.bitrate_combo.setCurrentText("256 kbps")  # Valor predeterminado
        bitrate_layout.addWidget(self.bitrate_combo)
        
        conversion_layout.addLayout(bit_depth_layout)
        conversion_layout.addLayout(bitrate_layout)
        
        conversion_group.setLayout(conversion_layout)
        main_layout.addWidget(conversion_group)
        
        # Botones de conversión
        convert_layout = QHBoxLayout()
        
        self.mp3_to_wav_btn = QPushButton("Convertir MP3 a WAV")
        self.mp3_to_wav_btn.clicked.connect(self.convert_mp3_to_wav)
        self.mp3_to_wav_btn.setEnabled(False)
        
        self.wav_to_mp3_btn = QPushButton("Convertir WAV a MP3")
        self.wav_to_mp3_btn.clicked.connect(self.convert_wav_to_mp3)
        self.wav_to_mp3_btn.setEnabled(False)
        
        convert_layout.addWidget(self.mp3_to_wav_btn)
        convert_layout.addWidget(self.wav_to_mp3_btn)
        
        main_layout.addLayout(convert_layout)
        
        # Configurar estilos
        self.apply_styles()
        
    def apply_styles(self):
        # Estilo para botones
        button_style = """
        QPushButton {
            background-color: #2a9df4;
            color: white;
            border-radius: 4px;
            padding: 8px 16px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #1e88e5;
        }
        QPushButton:disabled {
            background-color: #cccccc;
            color: #666666;
        }
        """
        
        # Estilo para los grupos
        group_style = """
        QGroupBox {
            font-weight: bold;
            border: 1px solid #cccccc;
            border-radius: 6px;
            margin-top: 16px;
            padding-top: 16px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
        """
        
        # Aplicar estilos
        self.load_mp3_btn.setStyleSheet(button_style)
        self.load_wav_btn.setStyleSheet(button_style)
        self.mp3_to_wav_btn.setStyleSheet(button_style)
        self.wav_to_mp3_btn.setStyleSheet(button_style)
        self.play_btn.setStyleSheet(button_style)
        
        for group in self.findChildren(QGroupBox):
            group.setStyleSheet(group_style)
    
    def load_file(self, file_type):
        file_filter = "Archivos MP3 (*.mp3)" if file_type == 'mp3' else "Archivos WAV (*.wav)"
        file_path, _ = QFileDialog.getOpenFileName(self, f"Seleccionar archivo {file_type.upper()}", 
                                                "", file_filter)
        
        if file_path:
            self.current_file = file_path
            self.file_label.setText(f"Archivo: {os.path.basename(file_path)}")
            
            # Habilitar/deshabilitar botones según el tipo de archivo
            is_mp3 = file_path.lower().endswith('.mp3')
            self.mp3_to_wav_btn.setEnabled(is_mp3)
            self.wav_to_mp3_btn.setEnabled(not is_mp3)
            self.play_btn.setEnabled(True)
            self.play_btn.setText("▶ Reproducir")
            
            # Detener reproducción si está activa
            if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
                self.player.stop()
                
            # Cargar el nuevo archivo en el reproductor
            self.player.setSource(QUrl.fromLocalFile(file_path))
            self.set_volume(self.volume_slider.value())
            
            # Mostrar información del archivo
            self.display_audio_info(file_path)
            
            # Mostrar forma de onda
            self.waveform_canvas.plot_waveform(file_path)
    
    def display_audio_info(self, file_path):
        try:
            # Intenta cargar información básica con librosa
            y, sr = librosa.load(file_path, sr=None)
            duration = librosa.get_duration(y=y, sr=sr)
            
            # Determinar formato
            format_name = "MP3" if file_path.lower().endswith('.mp3') else "WAV"
            
            # Usar método alternativo para obtener información si pydub falla
            try:
                # Intenta con pydub primero
                if format_name == "MP3":
                    audio = AudioSegment.from_mp3(file_path)
                else:  # WAV
                    audio = AudioSegment.from_wav(file_path)
                    
                bit_depth = getattr(audio, "sample_width", 0) * 8
                bitrate = getattr(audio, "frame_rate", 0) * getattr(audio, "sample_width", 0) * 8 * getattr(audio, "channels", 0) / 1000
                channels = audio.channels
            except Exception as e:
                print(f"Error al usar pydub para info: {e}")
                # Fallback a librosa para la información
                channels = 1 if y.ndim == 1 else y.shape[1]
                bit_depth = 16  # Valor predeterminado, difícil de detectar con librosa
                bitrate = sr * 16 * channels / 1000  # Aproximación
            
            # Actualizar etiquetas de información
            self.format_label.setText(f"Formato: {format_name}")
            self.channels_label.setText(f"Canales: {channels}")
            self.sample_rate_label.setText(f"Frecuencia de muestreo: {sr} Hz")
            self.bit_depth_label.setText(f"Profundidad de bits: {bit_depth} bits")
            self.bitrate_label.setText(f"Tasa de bits: {bitrate:.2f} kbps")
            self.duration_label.setText(f"Duración: {duration:.2f} segundos")
            
        except Exception as e:
            print(f"Error detallado al obtener información: {e}")
            QMessageBox.warning(self, "Error", f"No se pudo obtener información del archivo: {e}")
            
    def convert_mp3_to_wav(self):
        if not self.current_file or not self.current_file.lower().endswith('.mp3'):
            QMessageBox.warning(self, "Error", "Por favor, cargue un archivo MP3 válido.")
            return
        
        # Obtener configuraciones
        bit_depth = int(self.bit_depth_combo.currentText().split()[0])
        bitrate = int(self.bitrate_combo.currentText().split()[0])
        
        # Solicitar ubicación para guardar
        output_file, _ = QFileDialog.getSaveFileName(self, "Guardar archivo WAV", 
                                                  os.path.splitext(self.current_file)[0] + ".wav",
                                                  "Archivos WAV (*.wav)")
        
        if not output_file:
            return
            
        try:
            # Método alternativo usando librosa y soundfile si pydub falla
            try:
                # Intenta primero con pydub
                audio = AudioSegment.from_mp3(self.current_file)
                
                # Configurar parámetros
                audio = audio.set_frame_rate(44100)
                audio = audio.set_channels(2 if audio.channels > 1 else 1)
                audio = audio.set_sample_width(bit_depth // 8)
                
                # Guardar como WAV
                audio.export(output_file, format="wav", bitrate=f"{bitrate}k")
                print("Conversión MP3 a WAV completada con pydub")
                
            except Exception as pydub_error:
                print(f"Error al usar pydub para MP3->WAV: {pydub_error}")
                
                # Intentar método alternativo con ffmpeg directo
                try:
                    print("Intentando método alternativo con ffmpeg directo...")
                    
                    # Determinar ruta de ffmpeg
                    if getattr(sys, 'frozen', False):
                        ffmpeg_path = os.path.join(sys._MEIPASS, 'ffmpeg', 'ffmpeg.exe')
                    else:
                        ffmpeg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ffmpeg', 'ffmpeg.exe')
                        
                    if not os.path.exists(ffmpeg_path):
                        ffmpeg_path = 'ffmpeg'  # Intentar usar el del PATH
                    
                    # Construir comando para ffmpeg
                    cmd = [
                        ffmpeg_path,
                        '-i', self.current_file,
                        '-acodec', 'pcm_s16le' if bit_depth == 16 else 'pcm_s24le' if bit_depth == 24 else 'pcm_s32le',
                        '-ar', '44100',  # Frecuencia de muestreo
                        '-ab', f'{bitrate}k',
                        '-y',  # Sobrescribir si existe
                        output_file
                    ]
                    
                    # Ejecutar ffmpeg
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    
                    if result.returncode != 0:
                        raise Exception(f"Error en ffmpeg: {result.stderr}")
                        
                    print(f"Conversión MP3 a WAV completada con ffmpeg directo a {output_file}")
                
                except Exception as ffmpeg_error:
                    print(f"Error con ffmpeg directo: {ffmpeg_error}")
                    
                    # Último intento con librosa
                    print("Intentando método final con librosa...")
                    y, sr = librosa.load(self.current_file, sr=44100, mono=False)
                    
                    # Ajustar canales si es necesario
                    if y.ndim == 1:
                        # El audio es mono, dejarlo como está
                        pass
                    elif y.ndim > 2:
                        # Reducir a estéreo si hay más de 2 canales
                        y = y[:2, :]
                    
                    # Guardar como WAV
                    subtype = f'PCM_{bit_depth}'
                    sf.write(output_file, y.T if y.ndim > 1 else y, sr, subtype=subtype)
                    print(f"Conversión MP3 a WAV completada con librosa a {output_file}")
            
            QMessageBox.information(self, "Éxito", f"Archivo WAV guardado como:\n{output_file}")
            
            # Preguntar si quiere cargar el nuevo archivo
            reply = QMessageBox.question(self, "Cargar archivo convertido", 
                                         "¿Desea cargar el archivo WAV recién convertido?",
                                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            
            if reply == QMessageBox.StandardButton.Yes:
                self.current_file = output_file
                self.file_label.setText(f"Archivo: {os.path.basename(output_file)}")
                self.mp3_to_wav_btn.setEnabled(False)
                self.wav_to_mp3_btn.setEnabled(True)
                self.play_btn.setEnabled(True)
                self.play_btn.setText("▶ Reproducir")
                
                # Cargar el nuevo archivo en el reproductor
                self.player.setSource(QUrl.fromLocalFile(output_file))
                
                self.display_audio_info(output_file)
                self.waveform_canvas.plot_waveform(output_file)
                
        except Exception as e:
            print(f"Error detallado en la conversión MP3->WAV: {e}")
            QMessageBox.critical(self, "Error de Conversión", f"No se pudo convertir el archivo: {e}")
    
    def convert_wav_to_mp3(self):
        if not self.current_file or not self.current_file.lower().endswith('.wav'):
            QMessageBox.warning(self, "Error", "Por favor, cargue un archivo WAV válido.")
            return
        
        # Obtener configuraciones
        bit_depth = int(self.bit_depth_combo.currentText().split()[0])
        bitrate = int(self.bitrate_combo.currentText().split()[0])
        
        # Solicitar ubicación para guardar
        output_file, _ = QFileDialog.getSaveFileName(self, "Guardar archivo MP3", 
                                                  os.path.splitext(self.current_file)[0] + ".mp3",
                                                  "Archivos MP3 (*.mp3)")
        
        if not output_file:
            return
            
        try:
            # Método alternativo usando ffmpeg directamente si pydub falla
            try:
                # Intenta primero con pydub
                audio = AudioSegment.from_wav(self.current_file)
                
                # Configurar parámetros (los aplicables a MP3)
                audio = audio.set_frame_rate(44100)
                audio = audio.set_channels(2 if audio.channels > 1 else 1)
                
                # Guardar como MP3
                audio.export(output_file, format="mp3", bitrate=f"{bitrate}k")
                print("Conversión WAV a MP3 completada con pydub")
                
            except Exception as pydub_error:
                print(f"Error al usar pydub para WAV->MP3: {pydub_error}")
                
                # Método alternativo ejecutando ffmpeg directamente
                print("Intentando método alternativo con subprocess...")
                
                # Determinar ruta de ffmpeg
                if getattr(sys, 'frozen', False):
                    ffmpeg_path = os.path.join(sys._MEIPASS, 'ffmpeg', 'ffmpeg.exe')
                else:
                    ffmpeg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ffmpeg', 'ffmpeg.exe')
                    
                if not os.path.exists(ffmpeg_path):
                    ffmpeg_path = 'ffmpeg'  # Intentar usar el del PATH
                
                # Construir comando para ffmpeg
                cmd = [
                    ffmpeg_path,
                    '-i', self.current_file,
                    '-ab', f'{bitrate}k',
                    '-f', 'mp3',
                    '-y',  # Sobrescribir si existe
                    output_file
                ]
                
                # Ejecutar ffmpeg
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if result.returncode != 0:
                    raise Exception(f"Error en ffmpeg: {result.stderr}")
                    
                print(f"Conversión WAV a MP3 completada con ffmpeg a {output_file}")
            
            QMessageBox.information(self, "Éxito", f"Archivo MP3 guardado como:\n{output_file}")
            
            # Preguntar si quiere cargar el nuevo archivo
            reply = QMessageBox.question(self, "Cargar archivo convertido", 
                                         "¿Desea cargar el archivo MP3 recién convertido?",
                                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            
            if reply == QMessageBox.StandardButton.Yes:
                self.current_file = output_file
                self.file_label.setText(f"Archivo: {os.path.basename(output_file)}")
                self.mp3_to_wav_btn.setEnabled(True)
                self.wav_to_mp3_btn.setEnabled(False)
                self.play_btn.setEnabled(True)
                self.play_btn.setText("▶ Reproducir")
                
                # Cargar el nuevo archivo en el reproductor
                self.player.setSource(QUrl.fromLocalFile(output_file))
                
                self.display_audio_info(output_file)
                self.waveform_canvas.plot_waveform(output_file)
                
        except Exception as e:
            print(f"Error detallado en la conversión WAV->MP3: {e}")
            QMessageBox.critical(self, "Error de Conversión", f"No se pudo convertir el archivo: {e}")
    
    def toggle_playback(self):
        if not self.current_file:
            return
            
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
            self.play_btn.setText("▶ Reproducir")
        else:
            self.player.play()
            self.play_btn.setText("⏸ Pausar")
    
    def set_volume(self, value):
        volume = value / 100.0
        self.audio_output.setVolume(volume)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AudioConverter()
    window.show()
    sys.exit(app.exec())
