"""Parámetros compartidos del núcleo de huella vocal.

Lo que cambia por despliegue se lee de variables de ambiente (ver
configuracion.env.ejemplo); lo demás son constantes del método.
"""

import os
from pathlib import Path

VERSION = "0.9.0"

SR = 16000                      # frecuencia de trabajo de toda la cadena (Hz)

MODELO_HUELLA = "speechbrain/spkrec-ecapa-voxceleb"
DIM_HUELLA = 192

MODELO_STT = "base"             # faster-whisper, int8 en CPU (elegido en la Fase 0)

# ---------------------------------------------------------------------------
# Modelos locales: la imagen Docker los trae en /opt/modelos (VF_MODELOS) y el
# servicio los carga SIEMPRE desde ahí, en modo offline. Nunca descarga nada.
# Las revisiones y los hashes esperados están en construccion/descargar_modelos.py.
# ---------------------------------------------------------------------------
SUBDIR_ECAPA = "ecapa"                  # archivos de speechbrain/spkrec-ecapa-voxceleb
SUBDIR_WHISPER = "whisper-base"         # modelo CTranslate2 de Systran/faster-whisper-base
ARCHIVO_TEN_VAD = "ten-vad/ten-vad.onnx"

# Prohíbe a Hugging Face (SpeechBrain, faster-whisper) cualquier consulta a internet.
# Debe quedar fijado antes de importar esas librerías.
for _variable, _valor in (("HF_HUB_OFFLINE", "1"), ("TRANSFORMERS_OFFLINE", "1"),
                          ("HF_HUB_DISABLE_TELEMETRY", "1"), ("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")):
    os.environ.setdefault(_variable, _valor)

# ---------------------------------------------------------------------------
# Detección de voz (VAD), elegida por despliegue con VF_VAD.
# Cada VAD tiene sus propias colecciones en Qdrant: <prefijo>_<vad>_tramos y _personas.
# ---------------------------------------------------------------------------
VADS = {
    "silero": "Silero VAD",
    "ten": "TEN VAD",
}


def vad_configurado():
    nombre = (os.environ.get("VF_VAD") or "silero").strip().lower()
    if nombre not in VADS:
        raise ValueError(f"VF_VAD='{nombre}' no es válido. Use uno de: {', '.join(VADS)}.")
    return nombre


# ---------------------------------------------------------------------------
# Dispositivo de cómputo, elegido por despliegue con VF_DISPOSITIVO (cpu | gpu).
# Con "gpu", cada modelo que puede usarla lo intenta y, si no hay GPU o falla, sigue en
# CPU con una advertencia. ECAPA usa la GPU en x86_64 y arm64; Whisper solo en x86_64
# (la rueda de CTranslate2 para arm64 no trae CUDA). Los VAD y Praat siempre van en CPU.
# ---------------------------------------------------------------------------
DISPOSITIVOS = ("cpu", "gpu")


def dispositivo_configurado():
    nombre = (os.environ.get("VF_DISPOSITIVO") or "cpu").strip().lower()
    nombre = {"cuda": "gpu"}.get(nombre, nombre)
    if nombre not in DISPOSITIVOS:
        raise ValueError(f"VF_DISPOSITIVO='{nombre}' no es válido. Use cpu o gpu.")
    return nombre


# Parámetros comunes a los dos VAD (los mismos que usa Silero por defecto).
VAD_UMBRAL = 0.5
VAD_SILENCIO_MIN_S = 0.10       # silencios más cortos no cortan un segmento
VAD_VOZ_MIN_S = 0.25            # segmentos más cortos se descartan
VAD_RELLENO_S = 0.03            # margen que se agrega a cada lado del segmento

# ---------------------------------------------------------------------------
# Decisión de identidad: identificado si el mejor score supera UMBRAL_ALTO y le
# saca MARGEN_MINIMO al segundo; zona gris entre UMBRAL_BAJO y UMBRAL_ALTO.
# Calibrados con Silero; se pueden ajustar por despliegue (p. ej. para TEN).
# ---------------------------------------------------------------------------


def _flotante(variable, por_defecto):
    valor = (os.environ.get(variable) or "").strip()
    if not valor:
        return por_defecto
    try:
        return float(valor.replace(",", "."))
    except ValueError as exc:
        raise ValueError(f"{variable}='{valor}' no es un número.") from exc


UMBRAL_ALTO = _flotante("VF_UMBRAL_ALTO", 0.65)
UMBRAL_BAJO = _flotante("VF_UMBRAL_BAJO", 0.50)
MARGEN_MINIMO = _flotante("VF_MARGEN_MINIMO", 0.10)
if not 0 < UMBRAL_BAJO <= UMBRAL_ALTO < 1:
    raise ValueError("Los umbrales deben cumplir 0 < VF_UMBRAL_BAJO <= VF_UMBRAL_ALTO < 1.")

SEGUNDOS_MIN_VALIDACION = 3.0   # por debajo: "muestra insuficiente"

# Prueba de vida (Fase 2): la persona dice su nombre y repite una secuencia de
# dígitos al azar. Se aprueba si los dígitos oídos coinciden con los pedidos,
# admitiendo como mucho ERRORES_DIGITOS_PERMITIDOS (un dígito omitido, cambiado o de más).
DIGITOS_DESAFIO = 6
ERRORES_DIGITOS_PERMITIDOS = 1

SEGUNDOS_TRAMO = 10.0          # longitud de cada tramo de voz neta en las referencias
SEGUNDOS_MIN_TRAMO = 5.0        # un sobrante menor que esto se une al tramo anterior
SEGUNDOS_MIN_REFERENCIA = 3.0   # un archivo de referencia con menos voz neta que esto se rechaza

# Sufijos de país reconocidos en los nombres de archivo existentes (nombre_pais.wav).
PAISES = {
    "arg": "Argentina",
    "bol": "Bolivia",
    "chi": "Chile",
    "col": "Colombia",
    "cri": "Costa Rica",
    "cub": "Cuba",
    "dom": "República Dominicana",
    "ecu": "Ecuador",
    "esp": "España",
    "gua": "Guatemala",
    "mex": "México",
    "pan": "Panamá",
    "par": "Paraguay",
    "pe": "Perú",
    "peru": "Perú",
    "pr": "Puerto Rico",
    "uru": "Uruguay",
    "ven": "Venezuela",
}


def config_qdrant():
    """
    Conexión a Qdrant desde variables de ambiente, para usar otro host o puerto
    sin tocar el código. QDRANT_URL=":memory:" usa una base temporal en memoria.
    """
    return {
        "url": os.environ.get("QDRANT_URL", "http://localhost:6333"),
        "api_key": os.environ.get("QDRANT_API_KEY") or None,
        "prefijo": os.environ.get("QDRANT_PREFIJO", "huella_vocal"),
    }


def rutas_modelos(dir_modelos):
    """Rutas de cada modelo dentro de la carpeta de modelos locales."""
    dir_modelos = Path(dir_modelos).resolve()
    return {
        "ecapa": dir_modelos / SUBDIR_ECAPA,
        "whisper": dir_modelos / SUBDIR_WHISPER,
        "ten_vad": dir_modelos / ARCHIVO_TEN_VAD,
    }


def comprobar_modelos(dir_modelos):
    """
    Falla con un mensaje claro si falta algún modelo local, en lugar de dejar que
    una librería intente descargarlo.
    """
    rutas = rutas_modelos(dir_modelos)
    requeridos = [rutas["ecapa"] / n for n in ("hyperparams.yaml", "embedding_model.ckpt")]
    requeridos += [rutas["whisper"] / n for n in ("model.bin", "config.json", "tokenizer.json")]
    requeridos.append(rutas["ten_vad"])
    faltan = [str(r) for r in requeridos if not r.is_file()]
    if faltan:
        raise FileNotFoundError(
            "Faltan modelos locales (el servicio no los descarga). Revise VF_MODELOS="
            f"{Path(dir_modelos).resolve()} o reconstruya la imagen. Faltan: " + ", ".join(faltan)
        )
    return rutas
