# llm-tipificador — Documentación Técnica

**Fecha:** 21 de junio de 2026  
**Versión:** 1.0.0  
**Autor:** AECSA BPO — Área de IA

---

## Tabla de contenidos

1. [Descripción general](#1-descripción-general)
2. [Arquitectura del proyecto](#2-arquitectura-del-proyecto)
3. [Descripción de archivos](#3-descripción-de-archivos)
4. [Modelos incluidos](#4-modelos-incluidos)
5. [Resultados de evaluación](#5-resultados-de-evaluación)
6. [Requisitos de hardware](#6-requisitos-de-hardware)
7. [Construcción de la imagen](#7-construcción-de-la-imagen)
8. [Ejecución del servicio](#8-ejecución-del-servicio)
9. [Variables de entorno](#9-variables-de-entorno)
10. [API — Endpoints](#10-api--endpoints)
11. [Pruebas de inferencia](#11-pruebas-de-inferencia)
12. [Notas de compatibilidad por hardware](#12-notas-de-compatibilidad-por-hardware)
13. [Consideraciones para producción](#13-consideraciones-para-producción)

---

## 1. Descripción general

`llm-tipificador` es un servicio de inferencia LLM dockerizado, diseñado para tipificar llamadas de cobranza en español. Recibe como entrada un prompt largo con instrucciones y la transcripción de una llamada telefónica, y devuelve la clasificación generada por el modelo.

El servicio fue diseñado para reemplazar el uso de modelos muy grandes (como GPT-OSS 120B) en tareas de clasificación/extracción estructurada simple, usando modelos pequeños de 0.5B–3.8B parámetros que operan con mayor velocidad y menor consumo de recursos.

**Características principales:**

- FastAPI asíncrona con cola máxima de 3 solicitudes simultáneas
- Un modelo a la vez, seleccionable por variable de entorno
- 6 modelos incluidos dentro de la imagen Docker
- Soporte de cuantización FP16, INT8, INT4 y FP8 (opcional)
- Compatible con NVIDIA DGX Spark (aarch64, sm_121), RTX 5000-series (sm_120) y H200 NVL (sm_90)
- Funciona 100% offline una vez construida la imagen

---

## 2. Arquitectura del proyecto

```
tipificador/
├── Dockerfile              # Definición de la imagen Docker
├── requirements.txt        # Dependencias Python
├── download_models.py      # Script de descarga de modelos (ejecutado en build time)
└── app/
    ├── __init__.py         # Marca app/ como paquete Python
    ├── main.py             # API FastAPI — endpoints y lógica de inferencia
    └── model_loader.py     # Carga del modelo según variables de entorno
```

**Flujo de datos:**

```
Cliente HTTP
    │
    ▼
POST /inference {"prompt": "..."}
    │
    ▼
asyncio.Semaphore(3) — cola máxima de 3 requests
    │
    ▼
run_in_executor → _run_inference() [threadpool]
    │
    ▼
tokenizer(prompt) → model.generate() → decode()
    │
    ▼
{"respuesta": "..."}
```

---

## 3. Descripción de archivos

### `Dockerfile`

Construye la imagen a partir de `pytorch/pytorch:2.7.0-cuda12.8-cudnn9-runtime`. Durante el build:

1. Instala herramientas del sistema: `nano`, `git`, `curl`
2. Instala dependencias Python desde `requirements.txt`
3. Ejecuta `download_models.py` para descargar los 6 modelos desde HuggingFace
4. Limpia el token HF de las variables de entorno (`ENV HF_TOKEN=""`)
5. Copia el código de la aplicación en `/app/app/`

El token HF se pasa como `--build-arg` y nunca queda grabado en la imagen final.

**Imagen base:** `pytorch/pytorch:2.7.0-cuda12.8-cudnn9-runtime`  
**Python:** 3.11  
**CUDA:** 12.8  
**cuDNN:** 9  
**Puerto expuesto:** 8000

---

### `requirements.txt`

| Paquete | Versión | Propósito |
|---|---|---|
| fastapi | 0.115.0 | Framework API |
| uvicorn[standard] | 0.30.6 | Servidor ASGI |
| transformers | 4.51.0 | Carga y uso de modelos HuggingFace |
| huggingface_hub | 0.30.2 | Descarga de modelos desde HF Hub |
| accelerate | 1.3.0 | Gestión de dispositivos (device_map) |
| tokenizers | 0.21.1 | Tokenización rápida |
| bitsandbytes | 0.45.0 | Cuantización INT8/INT4/FP8 (opcional) |
| safetensors | 0.4.5 | Carga de pesos en formato seguro |
| sentencepiece | 0.2.0 | Tokenizador para Qwen y Gemma |
| protobuf | 5.29.0 | Dependencia de tokenizadores |

**Nota:** PyTorch no se lista aquí — viene preinstalado en la imagen base para evitar conflictos de versión con CUDA.

---

### `download_models.py`

Script ejecutado durante el `docker build`. Descarga los 6 modelos desde HuggingFace Hub hacia `/app/models/` usando `snapshot_download`.

**Comportamiento:**
- Falla inmediatamente (`sys.exit(1)`) si `HF_TOKEN` no está definido
- Falla si cualquier modelo no puede descargarse — garantiza imagen completa o build fallido
- Ignora pesos de TensorFlow y Flax (`*.h5`, `flax_model*`, `tf_model*`) para ahorrar espacio
- Convierte el ID del modelo a nombre de carpeta local: `Qwen/Qwen2.5-3B-Instruct` → `Qwen--Qwen2.5-3B-Instruct`

---

### `app/model_loader.py`

Carga el modelo y tokenizador al inicio del contenedor según las variables de entorno `MODEL_NAME` y `QUANTIZATION`.

**Mapa de nombres cortos a rutas locales:**

| MODEL_NAME | Ruta en /app/models/ |
|---|---|
| qwen2.5-0.5b-instruct | Qwen--Qwen2.5-0.5B-Instruct |
| qwen2.5-1.5b-instruct | Qwen--Qwen2.5-1.5B-Instruct |
| qwen2.5-3b-instruct | Qwen--Qwen2.5-3B-Instruct |
| gemma-3-1b-it | google--gemma-3-1b-it |
| smollm2-1.7b-instruct | HuggingFaceTB--SmolLM2-1.7B-Instruct |
| phi-3.5-mini-instruct | microsoft--Phi-3.5-mini-instruct |

**Validaciones al inicio:**
- `MODEL_NAME` no definido → error con lista de modelos disponibles
- `MODEL_NAME` no reconocido → error con lista de modelos disponibles
- `QUANTIZATION` inválido → error con valores válidos
- Carpeta del modelo no encontrada en disco → error

**Cuantización por tipo:**

| QUANTIZATION | Implementación | Notas |
|---|---|---|
| none / fp16 (default) | `torch.float16` | Sin dependencias extra |
| int8 | `BitsAndBytesConfig(load_in_8bit=True)` | Requiere bitsandbytes |
| int4 | `BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4")` | Requiere bitsandbytes |
| fp8 | `torch.float8_e4m3fn` | Requiere GPU con compute ≥ 8.9 |

---

### `app/main.py`

API FastAPI con dos endpoints. El modelo se carga una sola vez al arrancar el contenedor vía `lifespan`.

**Parámetros de generación:**

| Parámetro | Valor | Razón |
|---|---|---|
| max_new_tokens | 1024 | Límite de tokens generados |
| temperature | 0.1 | Respuestas deterministas y consistentes |
| do_sample | True | Requerido para temperature < 1 |
| truncation | False | No truncar el prompt de entrada |

**Concurrencia:** `asyncio.Semaphore(3)` — máximo 3 requests simultáneos. El cuarto request espera automáticamente en cola.

**Inferencia en threadpool:** `run_in_executor` — PyTorch es bloqueante; se ejecuta en un threadpool para no bloquear el event loop de FastAPI.

**Decodificación:** Solo se decodifican los tokens nuevos (`outputs[0][input_len:]`), nunca el prompt de entrada.

---

## 4. Modelos incluidos

### Familia Qwen2.5 (Alibaba Cloud)

| Modelo | Parámetros | Contexto | Español | Licencia |
|---|---|---|---|---|
| Qwen2.5-0.5B-Instruct | 0.5B | 32K tokens | ✅ 29+ idiomas | Apache 2.0 |
| Qwen2.5-1.5B-Instruct | 1.5B | 128K tokens | ✅ 29+ idiomas | Apache 2.0 |
| Qwen2.5-3B-Instruct | 3B | 128K tokens | ✅ 29+ idiomas | Qwen Research License |

Todos los modelos Qwen2.5 generan hasta 8K tokens por respuesta y tienen soporte explícito para español, portugués, francés, alemán, árabe, japonés, coreano y más de 29 idiomas.

### Gemma 3 (Google)

| Modelo | Parámetros | Contexto | Español | Licencia |
|---|---|---|---|---|
| gemma-3-1b-it | 1B | 32K tokens | ⚠️ Principalmente inglés | Gemma License |

Solo texto (sin visión). La variante 1B tiene cobertura multilingüe limitada comparada con los modelos 4B+ de la misma familia.

### SmolLM2 (HuggingFace)

| Modelo | Parámetros | Contexto | Español | Licencia |
|---|---|---|---|---|
| SmolLM2-1.7B-Instruct | 1.7B | 8K tokens | ⚠️ Principalmente inglés | Apache 2.0 |

Diseñado para tareas en inglés. Contexto corto (8K) puede ser insuficiente para prompts largos + transcripciones.

### Phi-3.5-mini (Microsoft)

| Modelo | Parámetros | Contexto | Español | Licencia |
|---|---|---|---|---|
| Phi-3.5-mini-instruct | 3.8B | 128K tokens | ✅ 22 idiomas explícitos | MIT |

Español incluido explícitamente entre los 22 idiomas soportados. Contexto de 128K tokens — el más amplio de la lista junto con Qwen2.5-1.5B y 3B. Competitivo con modelos de 7B–8B en varios benchmarks.

---

## 5. Resultados de evaluación

### Prompt de prueba utilizado

```
Clasifica esta llamada de cobranza. Responde solo si hubo acuerdo de pago o no.

Asesor: Buenos días, le llamo por su deuda pendiente de $500.000.
Cliente: No tengo dinero ahora.
Asesor: ¿Podemos acordar un pago para el viernes?
Cliente: Está bien, el viernes pago.
```

**Respuesta esperada:** Sí hubo acuerdo de pago.

### Resultados por modelo

| Modelo | Clasificación | Tokens generados | Tiempo | Tok/s | Veredicto |
|---|---|---|---|---|---|
| Qwen2.5-0.5B | ✅ Correcta (True) | 1024 | ~19s | ~54 | ❌ Loop infinito |
| Qwen2.5-1.5B | ⚠️ Correcta pero contradictoria | 118 | ~3s | ~39 | ⚠️ Inestable |
| Qwen2.5-3B | ✅ Correcta y concisa | 62 | ~2s | ~31 | ✅ **Recomendado** |
| Gemma-3-1B | ⚠️ Correcta (A) | 151 | ~6s | ~25 | ⚠️ Inestable |
| SmolLM2-1.7B | ❌ Alucinación grave | 1024 | ~17s | ~60 | ❌ Descartar |
| Phi-3.5-mini | ✅ Correcta | 1024 | ~22s | ~47 | ⚠️ Fuga de training data |

### Análisis detallado

**Qwen2.5-3B — Recomendado para producción**  
Genera la clasificación correcta de forma concisa (62 tokens, ~2 segundos). Agrega un pequeño fragmento de diálogo ficticio antes de la conclusión, pero la tipificación es clara. Con prompts bien estructurados de producción este comportamiento mejora significativamente.

**Qwen2.5-1.5B — Candidato con prompt mejorado**  
Entiende la tarea y razona correctamente, pero su conclusión final es la opuesta a su propio razonamiento. Potencialmente útil con un prompt más directivo que fuerce el formato de salida.

**Qwen2.5-0.5B — Descartar**  
Llega a la conclusión correcta pero entra en un loop repitiendo los mismos párrafos hasta llenar el límite de tokens. Inutilizable en producción.

**Gemma-3-1B — Descartar**  
Identifica la clasificación correcta pero genera diálogo ficticio contradictorio antes de responder. Comportamiento inestable incluso con prompts simples.

**SmolLM2-1.7B — Descartar**  
Genera conversaciones ficticias completamente inventadas (en un caso, iteró por días de la semana en loop; en otro, dividió la deuda a la mitad repetidamente hasta llegar a centavos). No tiene capacidad para esta tarea.

**Phi-3.5-mini — Candidato con prompt mejorado**  
Clasifica correctamente pero luego genera múltiples ejemplos adicionales de su dataset de entrenamiento. Necesita un prompt que ancle fuertemente el formato de salida.

### Recomendación final

**Modelo recomendado para producción: `qwen2.5-3b-instruct`**

Es el único modelo que clasifica correctamente, termina en tiempo razonable y no alucina. Los demás modelos requieren prompts significativamente más estructurados para comportarse de manera confiable.

**Nota importante:** Estas pruebas se realizaron con un prompt muy simple y genérico. Con los prompts reales de producción — más largos, con instrucciones específicas de formato y ejemplos — Phi-3.5-mini y Qwen2.5-1.5B podrían mejorar considerablemente.

---

## 6. Requisitos de hardware

| Hardware | Arquitectura | CUDA | VRAM | Estado |
|---|---|---|---|---|
| NVIDIA RTX 5070 Ti | x86_64, sm_120 | 12.8 | 16 GB | ✅ Probado |
| NVIDIA DGX Spark (GB10) | aarch64, sm_121 | 12.8 | 128 GB unificada | ✅ Compatible* |
| NVIDIA H200 NVL | x86_64, sm_90 | 12.8 | 94 GB | ✅ Compatible* |

*Compatible por arquitectura y drivers — no probado directamente.

**Consumo de VRAM por modelo en FP16:**

| Modelo | VRAM aprox. |
|---|---|
| Qwen2.5-0.5B | ~1 GB |
| Qwen2.5-1.5B | ~3 GB |
| Qwen2.5-3B | ~6 GB |
| Gemma-3-1B | ~2 GB |
| SmolLM2-1.7B | ~3.5 GB |
| Phi-3.5-mini | ~7.5 GB |

Todos los modelos caben en cualquier GPU de la lista incluso en FP16 sin cuantización.

---

## 7. Construcción de la imagen

### Prerrequisitos

- Docker instalado con soporte GPU (`nvidia-container-toolkit`)
- Token de lectura de HuggingFace con acceso a `google/gemma-3-1b-it`
- Acceso a internet durante el build
- ~50 GB de espacio libre en disco

### Aceptar términos de Gemma (una sola vez)

Antes del primer build, aceptar los términos en:  
`https://huggingface.co/google/gemma-3-1b-it`

### Comando de build

Ejecutar desde el directorio `tipificador/`:

```bash
docker build \
  --build-arg HF_TOKEN="$(cat '../HF Token TTS Service.txt')" \
  -t llm-tipificador:1.0.0 .
```

**Build desde cero (sin caché):**

```bash
docker build --no-cache \
  --build-arg HF_TOKEN="$(cat '../HF Token TTS Service.txt')" \
  -t llm-tipificador:1.0.0 .
```

**Tiempo estimado:** 30–45 minutos (descarga de ~20 GB de modelos + exportación de capas)  
**Tamaño final de imagen:** ~34 GB

### Notas sobre el build

- El `HF_TOKEN` solo existe durante el build y no queda grabado en la imagen final
- Los modelos se descargan en `/app/models/` dentro de la imagen
- Si el build falla durante la descarga de modelos, relanzar el comando — las capas anteriores quedan cacheadas
- Cambios solo en `app/` se reconstruyen en segundos (última capa)

### Compatibilidad multi-arquitectura

La imagen construida en x86_64 **no corre en aarch64** (DGX Spark). Para el DGX Spark, construir la imagen directamente en el Spark — el mismo Dockerfile funciona sin modificaciones ya que `pytorch/pytorch:2.7.0-cuda12.8-cudnn9-runtime` tiene variante nativa para aarch64.

---

## 8. Ejecución del servicio

### Comando básico

```bash
docker run -d \
  --gpus device=0 \
  -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-3b-instruct \
  -e QUANTIZATION=none \
  --name tipificador \
  llm-tipificador:1.0.0
```

### Ejemplos por modelo

```bash
# Qwen2.5-0.5B (más rápido, menor calidad)
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-0.5b-instruct -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0

# Qwen2.5-1.5B
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-1.5b-instruct -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0

# Qwen2.5-3B (recomendado)
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-3b-instruct -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0

# Gemma-3-1B
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=gemma-3-1b-it -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0

# SmolLM2-1.7B
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=smollm2-1.7b-instruct -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0

# Phi-3.5-mini (mayor calidad, más lento)
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=phi-3.5-mini-instruct -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0
```

### Ver logs en tiempo real

```bash
docker logs -f tipificador
```

El servicio está listo cuando aparece:
```
Modelo listo. Servicio disponible.
INFO: Application startup complete.
```

### Detener y eliminar el contenedor

```bash
docker rm -f tipificador
```

### Cambiar de modelo

```bash
docker rm -f tipificador && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=phi-3.5-mini-instruct -e QUANTIZATION=none \
  --name tipificador llm-tipificador:1.0.0
```

### Instanciar múltiples contenedores simultáneos

```bash
# Instancia 1 — GPU 0, puerto 8080
docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-3b-instruct \
  --name tipificador-1 llm-tipificador:1.0.0

# Instancia 2 — GPU 1, puerto 8081
docker run -d --gpus device=1 -p 8081:8000 \
  -e MODEL_NAME=qwen2.5-3b-instruct \
  --name tipificador-2 llm-tipificador:1.0.0
```

---

## 9. Variables de entorno

| Variable | Requerida | Valores válidos | Default | Descripción |
|---|---|---|---|---|
| MODEL_NAME | ✅ Sí | Ver tabla de modelos | — | Modelo a cargar al inicio |
| QUANTIZATION | No | none, fp16, int8, int4, fp8 | none | Tipo de cuantización |

**Notas sobre QUANTIZATION:**
- `none` y `fp16` son equivalentes — ambos cargan el modelo en `torch.float16`
- `int8` e `int4` requieren `bitsandbytes` (incluido en la imagen)
- `fp8` requiere GPU con compute capability ≥ 8.9 (Ada Lovelace, Hopper, Blackwell)
- Para el DGX Spark se recomienda `none` (FP16) — máxima calidad, 128 GB de memoria unificada sobran

---

## 10. API — Endpoints

### POST /inference

Ejecuta inferencia con el modelo cargado.

**Request:**
```json
{
  "prompt": "string — prompt largo con instrucciones + transcripción de la llamada"
}
```

**Response:**
```json
{
  "respuesta": "string — texto generado por el modelo"
}
```

**Errores:**
- `400` — prompt vacío
- `500` — error durante la inferencia (detalle en el campo `detail`)
- El cuarto request cuando hay 3 en curso espera en cola automáticamente

**Ejemplo curl:**
```bash
curl -X POST http://localhost:8080/inference \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Tu prompt aquí"}'
```

---

### GET /health

Retorna el estado del servicio y el modelo cargado.

**Response:**
```json
{
  "status": "ok",
  "modelo": {
    "model_name": "qwen2.5-3b-instruct",
    "quantization": "none",
    "cuda_available": true,
    "device": "NVIDIA GeForce RTX 5070 Ti"
  },
  "slots_disponibles": 3
}
```

`slots_disponibles` indica cuántos de los 3 slots de concurrencia están libres.

**Ejemplo curl:**
```bash
curl http://localhost:8080/health
```

---

## 11. Pruebas de inferencia

### Health check

```bash
curl http://localhost:8080/health
```

### Inferencia básica

```bash
curl -X POST http://localhost:8080/inference \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Clasifica esta llamada de cobranza. Responde solo si hubo acuerdo de pago o no.\n\nAsesor: Buenos días, le llamo por su deuda pendiente de $500.000. Cliente: No tengo dinero ahora. Asesor: ¿Podemos acordar un pago para el viernes? Cliente: Está bien, el viernes pago."}'
```

### Probar todos los modelos en secuencia

```bash
# Qwen2.5-0.5B
docker rm -f tipificador-test && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-0.5b-instruct -e QUANTIZATION=none \
  --name tipificador-test llm-tipificador:1.0.0 && docker logs -f tipificador-test

# Qwen2.5-1.5B
docker rm -f tipificador-test && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-1.5b-instruct -e QUANTIZATION=none \
  --name tipificador-test llm-tipificador:1.0.0 && docker logs -f tipificador-test

# Qwen2.5-3B
docker rm -f tipificador-test && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=qwen2.5-3b-instruct -e QUANTIZATION=none \
  --name tipificador-test llm-tipificador:1.0.0 && docker logs -f tipificador-test

# Gemma-3-1B
docker rm -f tipificador-test && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=gemma-3-1b-it -e QUANTIZATION=none \
  --name tipificador-test llm-tipificador:1.0.0 && docker logs -f tipificador-test

# SmolLM2-1.7B
docker rm -f tipificador-test && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=smollm2-1.7b-instruct -e QUANTIZATION=none \
  --name tipificador-test llm-tipificador:1.0.0 && docker logs -f tipificador-test

# Phi-3.5-mini
docker rm -f tipificador-test && docker run -d --gpus device=0 -p 8080:8000 \
  -e MODEL_NAME=phi-3.5-mini-instruct -e QUANTIZATION=none \
  --name tipificador-test llm-tipificador:1.0.0 && docker logs -f tipificador-test
```

Cuando aparezca `Servicio disponible` hacer `Ctrl+C` y lanzar el curl de prueba.

---

## 12. Notas de compatibilidad por hardware

### RTX 5000-series (sm_120) — Probado ✅

Requiere PyTorch 2.7+ con CUDA 12.8. Versiones anteriores (PyTorch 2.5.1) no tienen kernels compilados para sm_120 y fallan con `CUDA error: no kernel image is available for execution on the device`.

La imagen usa `pytorch/pytorch:2.7.0-cuda12.8-cudnn9-runtime` — compatible.

### DGX Spark (aarch64, sm_121) — Compatible por diseño

- La imagen debe construirse directamente en el Spark (no transferir imagen x86_64)
- El mismo Dockerfile funciona sin modificaciones
- `bitsandbytes` puede tener soporte limitado en sm_121 — usar `QUANTIZATION=none` (FP16) como default
- Con 128 GB de memoria unificada, FP16 es suficiente para cualquier modelo de esta lista

### H200 NVL (sm_90) — Compatible ✅

Arquitectura Hopper ampliamente soportada. Sin restricciones conocidas. FP8 nativo disponible si se requiere.

---

## 13. Consideraciones para producción

**Prompts estructurados:** Los modelos pequeños responden mejor a prompts que especifican explícitamente el formato de salida. Ejemplo:

```
Analiza la siguiente transcripción y responde ÚNICAMENTE con el resultado de la tipificación en el formato indicado. No agregues explicaciones adicionales.

[INSTRUCCIONES DE TIPIFICACIÓN]
...

[TRANSCRIPCIÓN]
...

[RESPUESTA]
```

**Modelo recomendado:** `qwen2.5-3b-instruct` con `QUANTIZATION=none`

**Concurrencia:** El semáforo de 3 slots es apropiado para un modelo 3B en FP16 en RTX 5000 o DGX Spark. En H200 podría aumentarse.

**Monitoreo:** El endpoint `/health` expone `slots_disponibles` en tiempo real — útil para balanceo de carga externo.

**Escalabilidad horizontal:** Cada contenedor es independiente. Para mayor throughput, instanciar múltiples contenedores en diferentes GPUs con diferentes puertos y balancear con nginx o un load balancer externo.

**Edición de código en producción:** `nano` está disponible dentro del contenedor:
```bash
docker exec -it tipificador bash
nano /app/app/main.py
```
Después de editar, reiniciar el contenedor para que los cambios tomen efecto.
