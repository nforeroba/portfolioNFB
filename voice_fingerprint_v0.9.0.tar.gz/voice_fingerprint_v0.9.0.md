# voice_fingerprint — Documentación del proyecto (versión 0.9.0)

Prueba de concepto completa, del backend al frontend, de **validación de identidad por voz**: la voz se trata como una huella digital. Una persona dice su nombre y unos números que aparecen en pantalla; el sistema comprueba que los dijo en vivo (prueba de vida) y busca a quién del registro corresponde su voz (identificación 1:N).

Este documento sirve para retomar el proyecto en otro chat o para desplegarlo en otro equipo. Describe el estado del checkpoint `voice_fingerprint_v0.9.0.tar.gz`.

**Novedades de la 0.9.0:** el servicio puede usar **CPU o GPU** según `VF_DISPOSITIVO`. Con `gpu`, ECAPA (huella) usa la GPU en x86_64 y arm64, y Whisper solo en x86_64; si no hay GPU o falla, sigue en CPU con una advertencia. La imagen pasa a `voice_fingerprint-entorno:0.9.0`, con PyTorch y CUDA adentro: sirve para los dos modos, pesa varios GB más y **hay que construirla de nuevo, con internet** (sección 11.7). El acceso del contenedor a la GPU se activa con `docker-compose.gpu.yml` (sección 11.16).

**Novedades de la 0.8.2:** en Umbral, la voz mínima para calcular una huella pasa a 250 ms, la misma duración mínima de un segmento en el VAD (la franja gris vertical llega a 250 ms). El historial muestra, para el primer cruce y el cruce estable, n, media, mediana, p90, p95, mínimo y máximo. Misma imagen `voice_fingerprint-entorno:0.8.0`.

**Novedades de la 0.8.1:** en la pestaña Umbral, la voz mínima para calcular una huella baja de 500 a 100 ms (la franja gris vertical de la gráfica llega a 100 ms). Cada sesión guarda su mínimo y el historial agrupa por mínimo. La validación y el registro siguen exigiendo 3 s de voz. Usa la misma imagen `voice_fingerprint-entorno:0.8.0`.

**Novedades de la 0.8.0:**
- **100 % sin internet** después de una única construcción: la imagen trae dependencias y modelos, y el código se monta desde `codigo/`. Un cambio estético en el frontend se ve con solo recargar el navegador.
- **Silero VAD o TEN VAD**, elegido por despliegue con `VF_VAD`, con colecciones de Qdrant separadas por VAD.
- **x86_64 y arm64** con el mismo Dockerfile y exactamente las mismas versiones de dependencias.
- **Pestaña "Umbral"**: mide en vivo cuántos milisegundos de voz neta hacen falta para identificar a alguien con confianza.

---

## Contenido

1. [Resumen](#1-resumen)
2. [Decisiones de diseño](#2-decisiones-de-diseño)
3. [Arquitectura](#3-arquitectura)
4. [Flujo de una validación](#4-flujo-de-una-validación)
5. [Componentes en detalle](#5-componentes-en-detalle)
6. [La página web](#6-la-página-web)
7. [API](#7-api)
8. [Estructura de carpetas y archivos](#8-estructura-de-carpetas-y-archivos)
9. [Configuración y parámetros](#9-configuración-y-parámetros)
10. [Tecnologías y versiones](#10-tecnologías-y-versiones)
11. [Despliegue desde cero](#11-despliegue-desde-cero-en-homeuser_ia)
12. [Operación diaria](#12-operación-diaria)
13. [Solución de problemas](#13-solución-de-problemas)
14. [Limitaciones conocidas](#14-limitaciones-conocidas)
15. [Pendientes y hoja de ruta](#15-pendientes-y-hoja-de-ruta)
16. [Historial de versiones y decisiones](#16-historial-de-versiones-y-decisiones)
17. [Diagramas (Mermaid)](#17-diagramas-mermaid)
18. [Glosario](#18-glosario)

---

## 1. Resumen

| Aspecto | Decisión actual |
|---|---|
| Tipo de identificación | 1:N de conjunto abierto: se busca entre todas las personas registradas y se admite que la voz no sea de nadie |
| Huella vocal | ECAPA-TDNN (SpeechBrain, entrenado en VoxCeleb): vector de 192 valores |
| Detección de voz (VAD) | **Silero VAD** o **TEN VAD**, elegido por despliegue con `VF_VAD`. Los dos con los mismos parámetros |
| Base vectorial | Qdrant, distancia coseno, dos colecciones **por VAD** (`huella_vocal_silero_*` o `huella_vocal_ten_*`) |
| Prueba de vida | Desafío de 6 dígitos al azar, de un solo uso, con 2 minutos de vigencia; se transcribe con faster-whisper `base` int8 y se admite 1 error |
| Perfil acústico | Praat (parselmouth): F0, HNR, jitter, shimmer, formantes y longitud estimada del tracto vocal. **Explica** el resultado, **no decide** |
| Fuente de verdad | La carpeta `referencias_wav/`. Qdrant es un índice derivado que se reconstruye desde ella |
| Backend | FastAPI + uvicorn (1 proceso) |
| Dispositivo | CPU o GPU por despliegue con `VF_DISPOSITIVO`. Con GPU: ECAPA en GPU (x86_64 y arm64), Whisper en GPU solo en x86_64; VAD y Praat siempre en CPU. Si la GPU no está o falla, sigue en CPU con advertencia |
| Frontend | HTML/CSS/JS sin framework, Plotly para los gráficos, cinco pestañas |
| Despliegue | Docker Compose con **una imagen del entorno** (dependencias + modelos, sin código) construida **una sola vez con internet**. El código se monta en solo lectura desde `codigo/`. Después, todo funciona sin internet |
| Arquitecturas | x86_64 y arm64 (DGX Spark), con el mismo Dockerfile y las mismas versiones (`restricciones.txt`) |
| Experimento Umbral | Identificación repetida cada 250 ms mientras la persona habla; barrido preciso al final; historial con medianas por persona y por VAD |
| Captura de la demo | Micrófono del PC desde el navegador. La telefonía a 8 kHz queda para después |
| Idioma | Español (interfaz, mensajes y código) |

**Entornos:**
- **Casa (x86_64):** desarrollo inicial, usuario `nfb`. Ensayo de la 0.8.0 con Docker pendiente (también puede ser un equipo x86 del trabajo).
- **DGX Spark de desarrollo:** arm64, con internet, usuario `admin`, proyecto en `/home/user_ia/voice_fingerprint`. Tiene Qdrant en Docker con los puertos por defecto (6333/6334). Funciona por HTTP y se accede desde otro equipo con un túnel SSH. Se usa para ensayar el procedimiento completo antes de producción.
- **DGX Spark de producción:** arm64. **Tiene internet una sola vez**, para construir la imagen; después queda sin internet y el servicio debe seguir estable, incluso al hacer cambios estéticos. Qdrant está en **otro servidor** (solo se configura su IP y puerto). El servicio queda detrás de un proxy reverso nginx con certificados reales.

---

## 2. Decisiones de diseño

**Funcionamiento sin internet (0.8.0)**
- **Una imagen del entorno, sin código.** La imagen `voice_fingerprint-entorno:0.9.0` contiene el sistema, el entorno de Python y los modelos. El código (`huella_vocal/`, `servicio/`, `frontend/`) se monta en solo lectura desde `codigo/`. Un cambio de código nunca obliga a reconstruir la imagen.
- **El día a día no construye nada.** `docker-compose.yml` no tiene sección `build` y usa `pull_policy: never`: `up -d`, `restart`, `down` e incluso `up -d --build` funcionan sin internet. La construcción va en un script aparte (`construir_imagen.sh`) que solo se corre con internet.
- **Modelos cargados por ruta local, en modo offline.** ECAPA, Whisper y TEN VAD se cargan desde `/opt/modelos` dentro de la imagen, con `HF_HUB_OFFLINE=1`. Silero viene dentro de su paquete. Si falta un modelo, el servicio falla al arrancar con un mensaje claro y nunca intenta descargarlo.
- **Versiones fijas y verificadas.** Los modelos se descargan en revisiones exactas de Hugging Face y cada archivo se compara con su hash, los mismos que usó la 0.7.0. Las dependencias de Python, directas e indirectas, quedan fijas en `restricciones.txt`. Una construcción hecha meses después instala exactamente lo mismo.
- **Verificación sin red al construir.** El script arranca la imagen recién construida con el contenedor **sin red** y comprueba que todo cargue y funcione. Si algo faltara, se descubre mientras todavía hay internet.
- **Respaldo de la imagen.** El script la guarda en `imagenes/*.tar.gz`. Si alguien la borra (por ejemplo con `docker system prune -a`), se recupera sin internet con `docker load`.
- **El frontend se sirve sin caché** (`Cache-Control: no-cache`): basta recargar para ver un cambio, sin Ctrl+Shift+R.

**Detección de voz (0.8.0)**
- **VAD por despliegue, no por petición.** `VF_VAD=silero` o `VF_VAD=ten`. El VAD elegido se usa en todo: sincronización de referencias, validación, registro y Umbral. Así la muestra y el pool siempre se recortan igual.
- **Colecciones separadas por VAD.** Cada VAD recorta la voz a su manera, así que sus huellas viven en colecciones distintas y nunca se comparan entre sí. Cambiar de VAD es inmediato después de la primera sincronización con cada uno. Cada punto guarda el VAD en su payload y al arrancar se comprueba que coincida.
- **TEN VAD con sherpa-onnx.** El paquete `ten-vad` de PyPI solo trae la librería de x86_64; en arm64 falla. Se usa el modelo ONNX oficial de TEN VAD ejecutado con sherpa-onnx (Apache 2.0), que tiene ruedas para las dos arquitecturas. Se usa la misma implementación en x86 y en arm64 para que los resultados no dependan de la máquina.
- **Mismos parámetros para los dos VAD:** umbral 0,5, silencio mínimo 100 ms, voz mínima 250 ms y 30 ms de relleno a cada lado (los valores por defecto de Silero).
- **Umbrales configurables.** Se calibraron con Silero; con TEN las huellas cambian un poco, así que `VF_UMBRAL_ALTO`, `VF_UMBRAL_BAJO` y `VF_MARGEN_MINIMO` permiten ajustarlos por despliegue.

**CPU o GPU (0.9.0)**
- **`VF_DISPOSITIVO=cpu` o `gpu`, por despliegue.** Con `gpu`, cada modelo que puede usarla la prueba al cargar, con un audio corto; si no hay GPU o la prueba falla, ese modelo queda en CPU y el servicio lo advierte en el log, en el encabezado de la página y en la ficha del sistema. Nunca deja de arrancar por la GPU.
- **Qué usa la GPU:** ECAPA (PyTorch) en x86_64 y arm64; Whisper (CTranslate2) solo en x86_64, porque la rueda de CTranslate2 para arm64 no trae CUDA (se verificó). Compilar CTranslate2 con CUDA para la Spark se descartó por ahora. Silero y TEN son tan pequeños que la GPU no aporta, y Praat solo corre en CPU.
- **Una sola imagen con CUDA** para los dos modos: PyTorch de PyPI (CUDA 13.2) con sus librerías NVIDIA adentro, más cuBLAS de CUDA 12 en x86_64 para CTranslate2. Pesa varios GB más, pero cambiar de modo no exige reconstruir.
- **El acceso a la GPU va en un archivo aparte** (`docker-compose.gpu.yml`), activado desde `.env` con `COMPOSE_FILE`: en un equipo sin GPU NVIDIA ese bloque haría fallar el arranque.
- **Los tiempos de CPU y GPU no se mezclan:** la bitácora guarda el dispositivo de cada modelo y el historial de tiempos solo cuenta las validaciones con el VAD y los dispositivos actuales.

**Experimento Umbral (0.8.0)**
- **Peticiones HTTP normales, sin WebSocket**, para no tocar la configuración de nginx de producción. La página envía cada 250 ms el audio nuevo; las peticiones son pequeñas.
- **Sin elegir de antemano quién habla.** La persona del resultado es la que el sistema identificó al final; quienes hacen el experimento saben si fue correcto.
- **Dos cifras:** primer cruce y cruce estable (sección 5.8). El barrido preciso solo refina alrededor de los cruces, porque recalcular la huella cada 50 ms sobre toda la sesión tardaría más de un minuto.

**Decisiones que se mantienen de versiones anteriores**
- **Prueba de vida solo contra repetición (replay), no contra clonación.** Los dígitos al azar impiden reutilizar una grabación vieja; burlarlos exigiría un sistema de clonación que genere en vivo, con la voz de la víctima, los dígitos exactos en menos de 2 minutos.
- **Dígitos en vez de frases.** La primera versión pedía leer frases largas y se descartó por impráctica. La persona dice su nombre completo y luego 6 dígitos (590.490 combinaciones posibles, sin dos dígitos iguales seguidos).
- **Zona gris en la decisión.** Entre los umbrales bajo y alto, o cuando dos personas quedan muy cerca, la respuesta es "no concluyente, repita", en lugar de forzar un sí o un no.
- **La carpeta manda.** Los WAV de `referencias_wav/` son la verdad; Qdrant se sincroniza al arrancar y con el botón "Resincronizar". Si se borra Qdrant, se reconstruye sin perder nada.
- **Huella de persona = plantilla.** Cada archivo se parte en tramos de 10 s de voz neta; cada tramo da una huella; la plantilla de la persona es el promedio normalizado de todas sus huellas de tramo.
- **El perfil acústico es explicativo.** Ayuda a entender por qué dos voces se parecen, pero la decisión depende solo de la similitud entre huellas.
- **HTTP sin certificados autofirmados.** El navegador solo permite el micrófono en HTTPS o en `localhost`; en desarrollo se usa un túnel SSH y en producción nginx pone el HTTPS.
- **Borrado definitivo protegido.** Eliminar a una persona desde la página borra sus WAV, su JSON de consentimiento y su huella, y exige una clave de 4 dígitos.

---

## 3. Arquitectura

```
 Navegador (página)                       Contenedor voice_fingerprint (FastAPI, puerto 8000)
 ───────────────────                      ──────────────────────────────────────────────────
 Captura con AudioWorklet ── WAV ──▶ /api/validar ──▶ Motor
 (sin AGC, sin supresión   ── PCM ──▶ /api/umbral/*      ├─ VAD configurado ........ voz neta (Silero o TEN)
  de ruido ni cancelación                                ├─ ECAPA-TDNN ............. huella 192-d ─┐
  de eco)                                                ├─ faster-whisper (paralelo) dígitos    │
                                                         ├─ Praat .................. perfil       │
 Plotly: espectrograma,     ◀── JSON ──                  ├─ PCA .................... mapa 2D      │
 huellas, mapa, umbral,                                  └─ Umbral ................. sesiones     │
 tiempos                                                                                          ▼
                                                                    Qdrant  (huella_vocal_<vad>_tramos, huella_vocal_<vad>_personas)

 Imagen voice_fingerprint-entorno:0.9.0          Equipo anfitrión (/home/user_ia/voice_fingerprint)
 ──────────────────────────────────────          ─────────────────────────────────────────────────
 /opt/huellavoz_env  dependencias (PyTorch+CUDA) codigo/          montado en solo lectura en /app
 /opt/modelos        ECAPA, Whisper, TEN VAD     referencias_wav/ fuente de verdad del pool
                     (hashes verificados)        registros/       validaciones.jsonl, umbral.jsonl (sin audio)
                                                 imagenes/        respaldo .tar.gz de la imagen
```

- **Un solo proceso** (`workers=1`): los modelos se cargan una vez al arrancar.
- **Hilos:** la transcripción y la huella corren en paralelo. Un candado de inferencia evita que una sincronización, una validación y una sesión de Umbral usen los modelos al mismo tiempo.
- **Monitor de recursos:** un hilo en segundo plano muestrea CPU, RAM e hilos cada segundo.
- **GPU opcional:** con `VF_DISPOSITIVO=gpu` y el contenedor con acceso a la GPU (`docker-compose.gpu.yml`), ECAPA y, en x86_64, Whisper corren en la GPU (sección 5.11).

---

## 4. Flujo de una validación

1. **Pedir números.** La página llama a `POST /api/desafio`. El servidor genera 6 dígitos, los guarda con un identificador y una vigencia de 2 minutos, y los devuelve.
2. **Grabar.** La persona dice su nombre completo y luego los 6 números. El botón "Detener y validar" se activa solo cuando el medidor del navegador cuenta 3,5 s de voz; el máximo es 12 s. Siempre hay un botón **Cancelar** (y la tecla Esc).
3. **Enviar.** `POST /api/validar` con el audio WAV y el identificador del desafío.
4. **En el servidor** (cada paso queda medido para la pestaña "Tiempos y recursos"):

| Paso | Qué hace |
|---|---|
| Recepción del audio | Guarda el audio recibido en un archivo temporal |
| Verificación del desafío | Comprueba que el desafío exista, no haya vencido y no se haya usado; lo marca como gastado y recupera los dígitos pedidos. No escucha el audio |
| Lectura y conversión a 16 kHz | Decodifica el audio, lo pasa a mono y lo remuestrea a 16 kHz |
| Espera de turno de inferencia | Espera el candado de los modelos (solo se nota si hay una sincronización o una sesión de Umbral en curso) |
| Detección de voz (Silero VAD o TEN VAD) | Quita los silencios con el VAD configurado; si queda menos de 3 s de voz neta, responde "muestra insuficiente" |
| Huella vocal (ECAPA-TDNN) | Extrae la huella de 192 valores |
| Transcripción (Whisper) | En paralelo con la huella: transcribe con marcas de tiempo por palabra |
| Búsqueda 1:N en Qdrant | Los 3 candidatos más parecidos entre las plantillas de personas del VAD configurado |
| Decisión y prueba de vida | Compara los dígitos oídos con los pedidos (1 error permitido) y aplica los umbrales de identidad |
| Perfil acústico (Praat) | F0, HNR, jitter, shimmer, formantes, tracto vocal |
| Espectrograma mel | Datos del espectrograma para dibujarlo en la página |
| Trayectoria del tono (F0) | La línea de tono sobre el espectrograma |
| Huella del mejor candidato | Recupera de Qdrant la plantilla del primer candidato para compararla visualmente |
| Proyección en el mapa 2D | Ubica la muestra en el mapa PCA y calcula su similitud con cada persona |
| Registro en la bitácora | Escribe una línea en `registros/validaciones.jsonl` (sin audio), con el VAD usado |

5. **Veredicto:**

| Veredicto | Condición |
|---|---|
| `validado` | Prueba de vida aprobada **y** identidad identificada |
| `rechazado_prueba_de_vida` | Los dígitos oídos no coinciden con los pedidos (más de 1 error) |
| `no_concluyente` | Zona gris, o dos candidatos demasiado cercanos |
| `no_identificado` | Ningún candidato llega al umbral bajo |
| `muestra_insuficiente` | Menos de 3 s de voz neta |

**Regla de identidad** (sobre la similitud coseno con las plantillas; valores por defecto, configurables):
- **Identificado:** mejor score ≥ 0,65 **y** margen sobre el segundo ≥ 0,10.
- **No concluyente:** mejor score ≥ 0,65 pero margen < 0,10, o mejor score entre 0,50 y 0,65.
- **No identificado:** mejor score < 0,50.

Calibración observada con Silero (0.7.0): la misma persona con el mismo canal da entre 0,73 y 0,82; con distinto canal (grabación con `arecord` frente a navegador) bajó a 0,67. Esa sensibilidad al canal es la razón del pendiente AS-norm. Con TEN VAD conviene volver a revisar estos valores.

---

## 5. Componentes en detalle

### 5.1 Pool de referencias y sincronización

La carpeta `referencias_wav/` admite tres convenciones de nombre:

| Formato | Ejemplo | Interpretación |
|---|---|---|
| Archivos existentes | `andres_col.wav`, `andres_col_2.wav`, `maria.wav` | Nombre; sufijo de país opcional (`col`, `arg`, `mex`, `ven`, `chi`, `pe`, `peru`, `pr`, etc.); un número final (si hay nombre y país) es otra grabación de la misma persona |
| Corpus OpenSLR | `cof_01523.wav` | `co` = Colombia, `f` = mujer, `01523` = hablante; se muestra como "Mujer 01523", origen Colombia. Prefijos: co, ar, cl, pe, pr, ve |
| Registro web | `ana_maria_rojas__web__20261109-162732__1.wav` + `ana_maria_rojas__web__20261109-162732.json` | El identificador es el nombre en minúsculas, sin tildes y con guion bajo. El JSON guarda el nombre para mostrar, el origen y el consentimiento |

Todos los archivos con el mismo identificador de persona se suman a la misma persona.

**Sincronización** (al arrancar, en segundo plano, y con el botón "Resincronizar"):
- Trabaja sobre las colecciones del VAD configurado. Antes de empezar comprueba que no tengan huellas de otro VAD (sección 5.2).
- Identifica cada archivo por el hash SHA-256 de su contenido; el ID del punto en Qdrant es un uuid5 de ese hash.
- Detecta archivos nuevos, eliminados, modificados y renombrados (mismo contenido, otro nombre) y solo procesa lo que cambió.
- Por archivo: carga → VAD → voz neta → tramos de 10 s (un sobrante de menos de 5 s se une al tramo anterior; una voz de entre 3 y 5 s queda como un solo tramo; menos de 3 s se rechaza) → una huella por tramo.
- Recalcula la plantilla y el perfil de cada persona afectada.
- El resumen muestra nuevos, actualizados, eliminados, renombrados, duplicados, errores, sin cambios, personas recalculadas y duración.
- La primera vez que se arranca con un VAD, sus colecciones están vacías y se procesa toda la carpeta.

**Qdrant:** dos colecciones por VAD, con el prefijo configurable (por defecto `huella_vocal`):
- `huella_vocal_<vad>_tramos`: un punto por tramo, con persona, archivo, hash, segundos y `vad`.
- `huella_vocal_<vad>_personas`: un punto por persona, con su plantilla, nombre, origen, número de tramos, voz total, perfil acústico y `vad`.

Con los dos VAD en uso conviven cuatro colecciones: `huella_vocal_silero_tramos`, `huella_vocal_silero_personas`, `huella_vocal_ten_tramos` y `huella_vocal_ten_personas`. Las de la 0.7.0 (`huella_vocal_tramos` y `huella_vocal_personas`) ya no se usan y se pueden borrar.

### 5.2 Detección de voz: Silero VAD o TEN VAD

`huella_vocal/vad.py` define dos detectores con la misma interfaz (`segmentos(senal)` y `voz_neta(senal)`), y `crear_detector(nombre)` entrega el configurado:

| | Silero VAD | TEN VAD |
|---|---|---|
| Modelo | El que trae el paquete `silero-vad` (PyTorch JIT) | Modelo ONNX oficial de TEN VAD (`/opt/modelos/ten-vad/ten-vad.onnx`, 332 KB) |
| Motor | PyTorch | sherpa-onnx (onnxruntime) |
| Ventana | 512 muestras (32 ms) | 256 muestras (16 ms), la recomendada por TEN |
| Estado | Guarda estado: una inferencia a la vez (candado) | Se crea un detector por llamada |
| Arquitecturas | x86_64 y arm64 | x86_64 y arm64 (el paquete `ten-vad` de PyPI no sirve en arm64) |

Parámetros comunes (`config.py`): umbral 0,5; silencio mínimo 100 ms (silencios más cortos no cortan un segmento); voz mínima 250 ms; 30 ms de relleno a cada lado de cada segmento (en TEN se agrega a mano y se unen los segmentos que se tocan).

**Protección contra mezclas:** cada punto en Qdrant guarda `vad`. Al arrancar, `Almacen.verificar_vad()` revisa un punto de cada colección; si no coincide con `VF_VAD`, el servicio no arranca y explica qué colección borrar.

Prueba rápida de referencia (x86, 272 s de habla, TEN contra Silero en su versión ONNX): 162,9 s contra 159,5 s de voz detectada; coinciden en el 91,8 % del audio; los dos procesan unas 190 veces más rápido que el tiempo real.

### 5.3 Prueba de vida

- `desafio.py` genera 6 dígitos con `secrets.SystemRandom`, sin dos iguales seguidos.
- Whisper transcribe; `prueba_vida.py` normaliza el texto y extrae los dígitos, tanto escritos como cifras ("4") como en palabras ("cuatro", "cuarenta y siete" → 4, 7).
- Se compara con distancia de Levenshtein contra cualquier tramo contiguo de lo oído, así que lo que la persona diga antes (su nombre) no estorba. Se aprueba con 1 error como máximo.
- Con las marcas de tiempo por palabra se ubica cada dígito en el espectrograma.

### 5.4 Huella e identificación

- `huella.py`: ECAPA-TDNN produce una huella de 192 valores normalizada a norma 1. Acepta fragmentos desde 100 ms (`MINIMO_HUELLA_S`); la validación y el registro exigen mucho más (3 s). La similitud es el coseno (producto punto entre vectores normalizados).
- El modelo se carga desde su carpeta local con SpeechBrain (`savedir=None` y `pretrained_path` apuntando a esa carpeta): usa los archivos donde están, sin copiarlos, sin crear enlaces y sin consultar Hugging Face.
- `almacen.py`: búsqueda de los 3 candidatos más cercanos en la colección de personas del VAD.
- `decision.py`: aplica la regla de la sección 4.

### 5.5 Perfil acústico

`perfil.py` con Praat calcula, sobre la voz neta (mínimo 1 s):
- F0 mediana y percentiles 5 y 95 (piso 75 Hz, techo 500 Hz).
- HNR (dB), jitter (%), shimmer (%).
- Formantes F1 a F4 (Hz).
- Longitud estimada del tracto vocal (cm) a partir del espaciamiento entre formantes: VTL = c / (2·ΔF), con c = 35.000 cm/s.

En habla continua, el jitter y el shimmer salen más altos que las normas clínicas (que usan vocales sostenidas); solo deben compararse entre muestras.

Rangos de referencia que muestra la página (aproximados, adultos hablando):
- F0: hombres 85–155 Hz, mujeres 165–255 Hz.
- Tracto vocal: mujeres 13,5–15,5 cm, hombres 16–18,5 cm.

### 5.6 Registro web

- Tres grabaciones: dos de habla libre (unos 10 s cada una, sobre un tema sugerido) y una de "nombre completo y contar del uno al diez". Mínimo 4 s de voz por grabación en el medidor del navegador; máximo 15 s.
- Exige nombre y consentimiento.
- El servidor revisa **todas** las grabaciones antes de guardar nada: si alguna tiene menos de 3 s de voz neta (según el VAD configurado) o más de 1 % de muestras saturadas, rechaza el registro completo e indica cuál repetir.
- Si todas sirven, guarda los WAV (16 kHz, mono) y el JSON en `referencias_wav/` y sincroniza.
- Si la sincronización rechaza algún archivo, lo informa como advertencia; si la persona no queda en el pool, responde con error y el detalle por archivo.
- Registrar dos veces el mismo nombre suma las grabaciones a la misma persona.

### 5.7 Eliminación de personas

- Solo está activa si `VF_CLAVE_BORRADO` tiene exactamente 4 dígitos; si no, los botones no aparecen y la pestaña explica cómo activarlos.
- La clave se compara con `hmac.compare_digest`. Tras 5 intentos fallidos, el borrado queda bloqueado 5 minutos.
- Borra todos los WAV de la persona, sus JSON de consentimiento y su huella, y luego resincroniza. No se puede deshacer.
- Los WAV son comunes a los dos VAD: la persona desaparece de las colecciones del VAD actual al resincronizar, y de las del otro VAD la próxima vez que el servicio arranque con él.

### 5.8 Experimento Umbral

Objetivo: saber cuántos milisegundos de **voz neta** hacen falta para que el sistema identifique a alguien con confianza. Código: `servicio/umbral.py`.

**Flujo:**
1. Al oprimir "Empezar", la página abre una sesión (`POST /api/umbral/sesion` con la frecuencia del navegador). El servidor fija las plantillas del pool en ese momento. No se puede abrir una sesión mientras se sincroniza el pool.
2. Mientras la persona habla, la página envía cada 250 ms lo grabado desde el envío anterior, como PCM de 16 bits mono a la frecuencia del navegador. En cada envío, el servidor:
   1. junta todo el audio recibido y lo pasa a 16 kHz;
   2. aplica el VAD configurado;
   3. si hay al menos 250 ms de voz neta (la duración mínima de un segmento en el VAD), saca la huella. Por el relleno de 30 ms a cada lado, el primer segmento suele llegar con unos 310 ms;
   4. la compara con las plantillas y aplica la misma regla de decisión que la validación;
   5. devuelve un punto: ms de voz neta, estado, las 3 personas más parecidas con su score, margen y tiempo de cálculo.
   Si una respuesta tarda, el siguiente envío lleva todo lo acumulado (en trozos de máximo 4 s, y solo el último se procesa): la página nunca se atrasa.
3. Al oprimir "Detener" (o al llegar a 30 s), la página envía lo que faltaba y pide `finalizar`. El servidor hace el **barrido preciso**, guarda una línea en `registros/umbral.jsonl` y cierra la sesión.

**Las dos cifras:**
- **Primer cruce:** los primeros ms de voz neta en que la decisión es "identificado" (con cualquier persona).
- **Cruce estable:** desde qué ms la decisión es "identificado" con la persona final, sin interrupción, hasta el final de la sesión.
- **Estado de la sesión:** `confirmado` si después del cruce estable hubo al menos 2.000 ms de voz neta; `sin_confirmar` si hubo menos; `sin_identificar` si al final no se identificó a nadie.

**Barrido preciso:** se calcula sobre la voz neta final (el VAD aplicado a todo el audio), con una rejilla común de 50 ms:
- Para el primer cruce, la ventana va del último punto en vivo sin identificación al primero con identificación; dentro de ella se evalúa cada 50 ms y el primero identificado es la cifra. Si en la voz final el cruce quedó un poco antes o después de la ventana, esta se corre en pasos de 250 ms.
- Para el cruce estable, la ventana va del último punto en vivo que no era la persona final al siguiente; desde su borde derecho se retrocede cada 50 ms mientras siga identificada la persona final.
- El primer cruce nunca queda después del cruce estable.
- Con menos de 250 ms no se calcula una huella: un cruce justo en 250 ms se muestra como **"≤ 250 ms"** (con el mínimo medible ya alcanzaba; el valor real puede ser menor). Con trozos tan cortos la similitud es muy inestable: el primer cruce puede salir temprano o con otra persona, y la cifra a mirar es el cruce estable.
- Suele bastar con 7 a 15 cálculos (menos de 1 s).

**Historial** (`GET /api/umbral/historial`): por VAD (y voz mínima) y por persona identificada: número de sesiones, identificadas y confirmadas, y para cada cifra (`primer_cruce`: todas las sesiones con cruce; `cruce_estable`: solo las confirmadas) **n, media, mediana, p90, p95, mínimo y máximo** en ms. Los percentiles usan interpolación lineal; con pocas sesiones, el p90 y el p95 quedan cerca del máximo. Además, las últimas 15 sesiones. Las sesiones sin identificación se agrupan como "Sin identificar". Para fijar un mínimo de voz conviene mirar el p90 o el p95 del cruce estable, no la mediana.

**Voz mínima por sesión:** cada sesión guarda `voz_min_ms`. Las sesiones de la 0.8.0, que no lo guardaban, cuentan como 500 ms. El historial agrupa por VAD **y** por voz mínima (primero el mínimo actual), porque los cruces medidos con mínimos distintos no son comparables.

**Línea de `umbral.jsonl`:** fecha, sesión, VAD, umbrales, voz mínima, estado, persona final, score y margen finales, primer cruce (con su persona), cruce estable, marcas de "en el mínimo", voz neta y audio totales, personas en el pool, cálculos y duración del barrido, y la curva en vivo como `[ms de voz, estado, persona, score, margen]`. No guarda audio ni huellas.

**Parámetros** (`servicio/umbral.py`):

| Constante | Valor | Significado |
|---|---|---|
| `INTERVALO_ENVIO_S` | 0,25 | Cada cuánto envía audio la página |
| `VOZ_MIN_MS` | 250 | Voz neta mínima para calcular una huella; se toma de `VAD_VOZ_MIN_S` (500 en la 0.8.0, 100 en la 0.8.1) |
| `PASO_FINO_MS` | 50 | Resolución del barrido preciso |
| `PASO_GRUESO_MS` | 250 | Corrimiento de la ventana del barrido |
| `CONFIRMACION_MS` | 2.000 | Voz neta posterior al cruce estable para confirmarlo |
| `MAX_SEGUNDOS_AUDIO` | 30 | Tope de audio por sesión |
| `VENCIMIENTO_S` | 120 | Una sesión sin actividad se descarta |
| `MAX_SESIONES` | 4 | Sesiones abiertas a la vez |

Prueba de referencia en un equipo x86 de 2 núcleos, con 7 voces sintéticas (sección 14): cálculo en vivo de 150 a 250 ms por punto con hasta 20 s de voz; barrido de 7 a 8 cálculos en menos de 1 s.

### 5.9 Tiempos y recursos

- `servicio/recursos.py`:
  - `Cronometro`: inicio y duración de cada paso, y en qué carril corrió (principal o paralelo).
  - `Monitor`: muestras cada segundo de los últimos 5 minutos, más el consumo de cada validación (segundos de CPU del proceso y pico de RAM, muestreado cada 50 ms).
  - `ficha_sistema` y `estadisticas`: mediana y p95 por paso.
- El paso de detección de voz lleva el nombre del VAD configurado ("Detección de voz (TEN VAD)").
- El historial de tiempos solo cuenta las validaciones del VAD actual, para no mezclar Silero con TEN.
- Los pasos y el consumo se guardan en la bitácora, así que el historial sobrevive a los reinicios.
- El CPU se expresa como porcentaje de la máquina completa (100 % = todos los núcleos ocupados). Dentro de Docker, "máquina" es la vista del anfitrión.
- El CPU no se puede separar por paso, porque PyTorch, onnxruntime y CTranslate2 usan hilos internos propios.

### 5.10 Modelos locales y modo offline

| Modelo | Origen y versión fija | Dónde queda | Cómo se carga |
|---|---|---|---|
| ECAPA-TDNN | `speechbrain/spkrec-ecapa-voxceleb`, revisión `0f99f2d0ebe89ac095bcc5903c4dd8f72b367286` | `/opt/modelos/ecapa/` | SpeechBrain desde la carpeta, `savedir=None`, `pretrained_path` = carpeta |
| faster-whisper base | `Systran/faster-whisper-base`, revisión `ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66` | `/opt/modelos/whisper-base/` | `WhisperModel(<carpeta>)`: una carpeta no consulta internet |
| TEN VAD | `ten-vad.onnx` de la publicación `asr-models` de sherpa-onnx, sha256 `718cb7ee…b486206` | `/opt/modelos/ten-vad/ten-vad.onnx` | sherpa-onnx con la ruta del archivo |
| Silero VAD | Dentro del paquete `silero-vad` 6.2.3 | En el entorno de Python | `load_silero_vad()` |

- `construccion/descargar_modelos.py` descarga cada archivo y lo compara con su hash: sha256 para los archivos grandes y el hash de git para los pequeños, que es como Hugging Face identifica cada archivo. Son los mismos archivos que usó la 0.7.0. Si algo no coincide, la construcción falla.
- Junto a los modelos quedan `manifiesto.json` (qué se descargó y cuándo) y una copia de `descargar_modelos.py` con la tabla de hashes, para volver a verificarlos sin internet.
- `huella_vocal/config.py` fija `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1` y `HF_HUB_DISABLE_TELEMETRY=1` antes de importar las librerías (la imagen también los fija).
- Al arrancar, `comprobar_modelos()` verifica que estén todos los archivos; si falta alguno, el servicio no arranca y dice cuál.
- `python -m servicio.verificar` comprueba los hashes, carga los dos VAD, ECAPA y Whisper, y los hace procesar una señal de prueba. `construir_imagen.sh` la corre con el contenedor sin red.

### 5.11 CPU o GPU

`VF_DISPOSITIVO` (en `configuracion.env`) elige el dispositivo: `cpu` (por defecto) o `gpu` (también se acepta `cuda`).

| Modelo | Con `VF_DISPOSITIVO=gpu` en x86_64 | En arm64 (DGX Spark) |
|---|---|---|
| ECAPA-TDNN (PyTorch) | GPU | GPU |
| faster-whisper (CTranslate2) | GPU, float16 | CPU, int8: la rueda de CTranslate2 para arm64 no trae CUDA |
| Silero / TEN VAD | CPU | CPU |
| Praat | CPU | CPU |

**Cómo decide cada modelo:**
- ECAPA: si PyTorch ve una GPU (`torch.cuda.is_available()`), carga en `cuda:0` y calcula una huella de prueba. Si no hay GPU, o la prueba falla (controlador antiguo, GPU no soportada...), carga en CPU.
- Whisper: si CTranslate2 ve una GPU (`get_cuda_device_count() > 0`), carga en CUDA con float16 y transcribe un audio de prueba; si no, o si falla, carga en CPU con int8.
- Cada vez que un modelo vuelve a CPU queda una advertencia: en el log (`ADVERTENCIA: ...`), en `/api/salud` (`avisos_dispositivo`), en el encabezado de la página (al pasar el mouse) y en la ficha del sistema.

**Para que el contenedor vea la GPU** hacen falta tres cosas:
1. GPU NVIDIA con un controlador reciente, compatible con CUDA 13.
2. NVIDIA Container Toolkit en el equipo (DGX OS ya lo trae).
3. `COMPOSE_FILE=docker-compose.yml:docker-compose.gpu.yml` en `codigo/.env`, que agrega la reserva de la GPU al contenedor.

Sin el punto 3, aunque `VF_DISPOSITIVO=gpu`, el servicio no ve la GPU y sigue en CPU con advertencia. En un equipo sin GPU NVIDIA o sin el toolkit, no active `docker-compose.gpu.yml`: el contenedor no arrancaría.

**Dónde se ve:** el encabezado termina en "· GPU" si algún modelo quedó en la GPU, o "· CPU" si no. La ficha del sistema muestra el dispositivo pedido, el nombre y la memoria de la GPU, la memoria que usa PyTorch y las advertencias; la tabla de modelos tiene la columna "Dispositivo"; en la línea de tiempo, los pasos de huella y transcripción dicen "en GPU" cuando aplica.

---

## 6. La página web

Cinco pestañas. El encabezado muestra cuántas personas hay en el pool, el VAD y si se usa la GPU (por ejemplo, «N personas registradas · TEN VAD · GPU»); al pasar el mouse muestra las advertencias de dispositivo, si las hay.

**Validar identidad**
- Botón "Pedir números", los 6 dígitos en grande y la vigencia en cuenta regresiva.
- "Grabar respuesta" con medidor de nivel y de segundos de voz, y botón Cancelar.
- Resultado:
  - Veredicto.
  - Dos capas: prueba de vida (dígitos pedidos frente a oídos) e identidad (candidatos con score y margen).
  - Espectrograma mel de la voz de entrada: eje de frecuencia logarítmico de 50 Hz a 8 kHz, línea de F0 y cada dígito marcado en verde o rojo.
  - Huellas como código de barras (muestra frente a candidato), más una franja de aporte de cada posición a la similitud, con detalle al pasar el mouse.
  - Tabla del perfil acústico con explicación de cada medida al pasar el mouse, y escalas de referencia de tono y tracto con los rangos de hombres y mujeres.
  - Mapa 2D (PCA) interactivo: la muestra como estrella unida a sus 3 voces más parecidas, colores por tono mediano, opción de mostrar todos los nombres.

**Registrar voz**
- Nombre, origen opcional, consentimiento y tres grabaciones guiadas, cada una con Cancelar y opción de repetir.

**Personas registradas**
- Estado de la sincronización y botón "Resincronizar".
- Mapa de las voces.
- Tabla del pool, con botón "Eliminar" y confirmación con clave si el borrado está habilitado.

**Umbral** (nueva en 0.8.0)
- Botón "Empezar"; "Detener" se activa con 1 s de voz según el medidor del navegador. Cancelar o Esc descartan la sesión sin guardar nada. Tope de 30 s.
- En vivo: voz neta analizada (ms), estado, persona más parecida con su similitud, ventaja sobre la segunda y tiempo del último cálculo.
- Gráfica: ms de voz neta en el eje horizontal y similitud en el vertical, una línea por cada persona que llegó a estar entre las tres más parecidas (la principal resaltada), la zona gris, la línea de coincidencia clara y la franja gris vertical de "sin huella" (menos de 250 ms, la voz mínima de un segmento en el VAD).
- Al terminar: marcas verticales del primer cruce y del cruce estable, los puntos del barrido preciso y un panel con las dos cifras, la persona final, la voz neta total y el tiempo del barrido. Si el primer cruce fue con otra persona, lo advierte.
- Historial: tablas por VAD y por persona identificada, con la voz mínima de cada grupo y, para el primer cruce y el cruce estable, n, media, mediana, p90, p95, mínimo y máximo; y la tabla de las últimas sesiones.

**Tiempos y recursos**
- Línea de tiempo de la última validación (el paso de VAD con el nombre del VAD configurado).
- Consumo de esa validación.
- Historial (mediana y p95 de las últimas 200 con el VAD y los dispositivos actuales).
- Recursos en vivo: CPU y RAM, actualizados cada 2 s solo mientras la pestaña está abierta.
- Ficha del sistema: versión, imagen del entorno, VAD, colecciones, carpeta de modelos y modo offline, dispositivo pedido, GPU (nombre, memoria, uso de PyTorch) y advertencias, arquitectura, procesador, memoria, versiones; y los modelos con su dispositivo y su tiempo de carga.

**Detalles técnicos del frontend**
- Captura con AudioWorklet (`procesador-grabacion.js`) y codificación WAV en el navegador, a la frecuencia del navegador (normalmente 48 kHz). Se desactivan AGC, supresión de ruido y cancelación de eco para no deformar la voz.
- En Umbral, `Grabadora` entrega cada bloque al llegar (`alBloque`); la página lo convierte a PCM de 16 bits y lo envía; el servidor remuestrea.
- El medidor de voz del navegador usa un umbral de energía de max(0,008, ruido × 2,5), con 200 ms de retención.
- Plotly `plotly-cartesian` 4.1.2 vendorizado (funciona sin internet), con la configuración regional en español.
- Fuente Public Sans incluida (licencia OFL).
- Los contenedores de los gráficos tienen alto fijo para que el zoom no los encoja.
- La página se sirve con `Cache-Control: no-cache`: recargar basta para ver un cambio.

---

## 7. API

Todas las rutas van bajo `/api`. La página se sirve en `/`.

| Método y ruta | Uso |
|---|---|
| `GET /salud` | Estado general, versión, VAD, dispositivo pedido y en uso por modelo, advertencias de dispositivo, personas en el pool, colecciones, estado de la sincronización, si el borrado está habilitado |
| `GET /sincronizacion` | Avance y último resumen de la sincronización |
| `POST /sincronizacion` | Lanza una resincronización (409 si ya hay una en curso) |
| `GET /personas` | El pool: nombre, origen, tramos, segundos de voz, perfil acústico |
| `POST /personas/{id}/eliminar` | Cuerpo JSON `{"clave": "1234"}`. Borra definitivamente (403 si la clave es incorrecta o el borrado está bloqueado) |
| `GET /mapa` | Proyección 2D de tramos y personas |
| `POST /desafio` | Nuevos dígitos de un solo uso: identificador, dígitos, textos, vigencia |
| `POST /validar` | Formulario con `audio` (archivo) y `desafio_id`. Devuelve veredicto, prueba de vida, identificación, muestra (huella, perfil, espectrograma, posición en el mapa, similitudes), mejor candidato y tiempos |
| `POST /registro` | Formulario con `nombre`, `origen`, `consentimiento` y varios archivos de audio |
| `POST /umbral/sesion` | Cuerpo JSON `{"tasa": 48000}`. Abre una sesión: id, VAD, personas en el pool, intervalo de envío, mínimos, umbrales |
| `POST /umbral/sesion/{id}/audio?procesar=1` | Cuerpo: PCM 16 bits mono little-endian (`application/octet-stream`). Con `procesar=1` devuelve un punto (ms de voz neta, estado, top 3, margen, tiempo de cálculo); con `procesar=0` solo acumula |
| `POST /umbral/sesion/{id}/finalizar` | Barrido preciso y resultado (cruces, estado, persona final, curva, refinamiento); lo guarda en `umbral.jsonl` |
| `POST /umbral/sesion/{id}/cancelar` | Descarta la sesión sin guardar nada |
| `GET /umbral/historial` | Por VAD y por persona identificada: sesiones y, para cada cifra, n, media, mediana, p90, p95, mínimo y máximo; últimas sesiones |
| `GET /tiempos` | Última validación paso a paso e historial (mediana y p95) del VAD actual |
| `GET /recursos` | Muestras de CPU, RAM e hilos (últimos 5 min) |
| `GET /sistema` | Versión, imagen, VAD, colecciones, dispositivo y GPU, modelos con su dispositivo, arquitectura, procesador, memoria, versiones y tiempos de carga |

Errores: 400 con `{"detalle": "..."}` para errores de uso (también los de Umbral); 403 para la clave de borrado; 409 si las colecciones tienen huellas de otro VAD.

---

## 8. Estructura de carpetas y archivos

En cada equipo:

```
/home/user_ia/voice_fingerprint/
├── codigo/                     ← contenido de voice_fingerprint_v0.9.0.tar.gz
│   ├── Dockerfile              ← imagen del entorno (dependencias + modelos, sin código)
│   ├── .dockerignore
│   ├── docker-compose.yml      ← operación diaria, sin construcción
│   ├── docker-compose.gpu.yml  ← acceso a la GPU (se activa con COMPOSE_FILE en .env)
│   ├── construir_imagen.sh     ← único paso con internet: construir, verificar sin red, respaldar
│   ├── requirements.txt
│   ├── restricciones.txt       ← versiones exactas de todas las dependencias (x86_64 y arm64)
│   ├── configuracion.env.ejemplo
│   ├── configuracion.env       ← se crea en cada equipo (no viene en el paquete)
│   ├── .env                    ← se crea en cada equipo (no viene en el paquete)
│   ├── construccion/
│   │   └── descargar_modelos.py
│   ├── huella_vocal/           ← núcleo: audio, VAD, modelos, sincronización, decisión
│   ├── servicio/               ← API, motor, Umbral, verificación y medición de recursos
│   └── frontend/               ← página web
├── referencias_wav/            ← fuente de verdad del pool (WAV + JSON de registros web)
├── registros/                  ← validaciones.jsonl y umbral.jsonl (bitácoras sin audio)
└── imagenes/                   ← respaldo de la imagen (.tar.gz + .sha256); lo crea construir_imagen.sh
```

La carpeta `modelos_cache/` de la 0.7.0 ya no se usa: los modelos van dentro de la imagen.

**Dentro de la imagen** (`voice_fingerprint-entorno:0.9.0`):

```
/opt/huellavoz_env/             ← entorno de Python con todas las dependencias (PyTorch con CUDA y librerías NVIDIA)
/opt/modelos/
├── ecapa/                      ← hyperparams.yaml, embedding_model.ckpt, mean_var_norm_emb.ckpt, classifier.ckpt, label_encoder.txt
├── whisper-base/               ← config.json, model.bin, tokenizer.json, vocabulary.txt
├── ten-vad/ten-vad.onnx
├── manifiesto.json             ← qué se descargó, de dónde y cuándo
└── descargar_modelos.py        ← copia con la tabla de hashes, para verificar sin internet
/app/                           ← aquí se montan huella_vocal/, servicio/ y frontend/ (solo lectura)
```

**`huella_vocal/` (núcleo, sin dependencia de la web)**

| Archivo | Contenido |
|---|---|
| `config.py` | Versión, constantes (frecuencia, tramos, desafío, países), VAD configurado y sus parámetros, umbrales (con variables de ambiente), conexión a Qdrant, rutas de los modelos locales, `comprobar_modelos`, modo offline |
| `audio.py` | `cargar_audio`: mono, 16 kHz, float32; informa pico, dBFS, saturación. Respaldo con PyAV para webm y m4a |
| `vad.py` | `DetectorSilero`, `DetectorTen`, `crear_detector` y `partir_en_tramos` |
| `huella.py` | `ExtractorHuella` (ECAPA-TDNN desde carpeta local), `normalizar`, `plantilla`, `similitud` |
| `perfil.py` | `perfil_acustico` y `trayectoria_tono` (Praat) |
| `referencias.py` | Convenciones de nombre, listado de la carpeta, hash de archivos |
| `desafio.py` | Generación de los dígitos |
| `prueba_vida.py` | Normalización del texto, extracción de dígitos, Levenshtein, `Transcriptor` (faster-whisper desde carpeta local) con marcas de tiempo |
| `almacen.py` | `Almacen`: colecciones de Qdrant por VAD, tramos, personas, búsqueda, `verificar_vad` |
| `sincronizacion.py` | Sincronización carpeta → Qdrant |
| `decision.py` | Regla de decisión con zona gris |
| `visual.py` | Datos del espectrograma mel y PCA para el mapa |

**`servicio/`**

| Archivo | Contenido |
|---|---|
| `__main__.py` | Arranque con uvicorn (`python -m servicio`); HTTPS opcional con `VF_SSL_CERT` y `VF_SSL_KEY` |
| `app.py` | Rutas FastAPI, manejo de errores, página sin caché, montaje del frontend |
| `motor.py` | `Motor`: carga de modelos locales, sincronización, desafíos, validación medida, registro, eliminación, mapa, tiempos y ficha |
| `umbral.py` | `SesionesUmbral`: sesiones, evaluación en vivo, barrido preciso, historial |
| `verificar.py` | Verificación sin red del entorno (`python -m servicio.verificar`) |
| `recursos.py` | Cronómetro de pasos, monitor de CPU y RAM, ficha del sistema, estadísticas |

**`frontend/`**

| Archivo | Contenido |
|---|---|
| `index.html` | Estructura de las cinco pestañas |
| `estilos.css` | Estilos (variables de color, paneles, tablas, ayudas emergentes, escalas) |
| `app.js` | Lógica de la página: pestañas, desafío, grabación controlada con Cancelar, resultado, registro, personas, Umbral, tiempos y recursos |
| `grabadora.js` | Clase `Grabadora` (captura, cancelación, WAV, entrega de bloques) y medidor de voz |
| `procesador-grabacion.js` | AudioWorklet de captura |
| `graficos.js` | Espectrograma, mapa, huellas, gráfica de Umbral, línea de tiempo y gráficos de recursos con Plotly |
| `vendor/plotly-cartesian.min.js` | Plotly 4.1.2 (licencia MIT) |
| `fuentes/` | Public Sans (licencia OFL) |

**Scripts de desarrollo** (no vienen en el paquete; estaban en el equipo de casa): `fase0/` verificación del entorno y elección de modelos, `fase1/analizar_pool.py` análisis del pool y curvas EER, `fase2/calibrar_prueba_vida.py` calibración de los dígitos, `fase3/sincronizar.py` e `identificar.py` pruebas por consola, `fase4/probar_api.py` prueba de la API.

---

## 9. Configuración y parámetros

### 9.1 Variables de ambiente

**`codigo/.env`** (lo usan Docker Compose y `construir_imagen.sh`):

| Variable | Uso | Ejemplo |
|---|---|---|
| `VF_UID`, `VF_GID` | Usuario con el que corre el contenedor; debe ser el dueño de las carpetas | `id -u`, `id -g` |
| `VF_PUERTO_HOST` | Puerto publicado en el equipo. Con `127.0.0.1:8000` solo es accesible desde el propio equipo (útil detrás de nginx) | `8000` |
| `VF_IMAGEN` | Opcional. Nombre de la imagen del entorno | `voice_fingerprint-entorno:0.9.0` |
| `COMPOSE_FILE` | Opcional. Para dar acceso a la GPU: `docker-compose.yml:docker-compose.gpu.yml` | vacío (sin GPU) |

**`codigo/configuracion.env`** (la carga el contenedor):

| Variable | Uso | Por defecto |
|---|---|---|
| `QDRANT_URL` | URL de Qdrant. Otro servidor: `http://<host>:<puerto>`. Mismo equipo, desde Docker: `http://host.docker.internal:<puerto>`. `:memory:` usa una base temporal | `http://localhost:6333` |
| `QDRANT_API_KEY` | Llave de Qdrant si tiene autenticación | vacía |
| `QDRANT_PREFIJO` | Prefijo de las colecciones | `huella_vocal` |
| `VF_VAD` | Detección de voz: `silero` o `ten` | `silero` |
| `VF_DISPOSITIVO` | `cpu` o `gpu` (sección 5.11) | `cpu` |
| `VF_UMBRAL_ALTO` | Score mínimo para identificar | `0,65` |
| `VF_UMBRAL_BAJO` | Por debajo: no identificado | `0,50` |
| `VF_MARGEN_MINIMO` | Ventaja mínima sobre el segundo candidato | `0,10` |
| `VF_CLAVE_BORRADO` | Clave de 4 dígitos para eliminar personas; vacía = borrado deshabilitado | vacía |
| `VF_HOST`, `VF_PUERTO` | Solo sin Docker | `0.0.0.0`, `8000` |
| `VF_MODELOS` | Solo sin Docker: carpeta de los modelos | carpeta `modelos` junto a `codigo/` |
| `VF_SSL_CERT`, `VF_SSL_KEY` | Solo sin Docker y sin nginx: certificado y llave para servir HTTPS directo | — |

Los umbrales vacíos toman el valor por defecto; se aceptan con coma o punto decimal. Deben cumplir 0 < bajo ≤ alto < 1, o el servicio no arranca.

Las fija `docker-compose.yml`: `VF_REFERENCIAS`, `VF_REGISTROS` (rutas dentro del contenedor, `/datos/...`). Las fija la imagen: `VF_MODELOS=/opt/modelos`, `VF_ENTORNO` (nombre de la imagen), `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`, `HF_HUB_DISABLE_TELEMETRY=1`, `NVIDIA_VISIBLE_DEVICES=all`, `NVIDIA_DRIVER_CAPABILITIES=compute,utility` y `LD_LIBRARY_PATH` (cuBLAS 12 para CTranslate2 en x86_64). Sin Docker, por defecto las carpetas son las hermanas de `codigo/`.

### 9.2 Parámetros del núcleo (`huella_vocal/config.py`)

| Constante | Valor | Significado |
|---|---|---|
| `SR` | 16000 | Frecuencia de trabajo (Hz) |
| `DIM_HUELLA` | 192 | Tamaño de la huella |
| `MODELO_STT` | `base` | Modelo de faster-whisper |
| `UMBRAL_ALTO` | 0,65 (`VF_UMBRAL_ALTO`) | Score mínimo para identificar |
| `UMBRAL_BAJO` | 0,50 (`VF_UMBRAL_BAJO`) | Por debajo: no identificado |
| `MARGEN_MINIMO` | 0,10 (`VF_MARGEN_MINIMO`) | Ventaja mínima sobre el segundo candidato |
| `VAD_UMBRAL` | 0,5 | Probabilidad de voz a partir de la cual un cuadro es voz (los dos VAD) |
| `VAD_SILENCIO_MIN_S` | 0,10 | Silencios más cortos no cortan un segmento |
| `VAD_VOZ_MIN_S` | 0,25 | Segmentos de voz más cortos se descartan |
| `VAD_RELLENO_S` | 0,03 | Margen a cada lado de cada segmento |
| `SEGUNDOS_MIN_VALIDACION` | 3,0 | Voz neta mínima para validar |
| `DIGITOS_DESAFIO` | 6 | Dígitos del desafío |
| `ERRORES_DIGITOS_PERMITIDOS` | 1 | Errores tolerados en los dígitos |
| `SEGUNDOS_TRAMO` | 10,0 | Largo de cada tramo de referencia |
| `SEGUNDOS_MIN_TRAMO` | 5,0 | Sobrante mínimo para ser tramo propio |
| `SEGUNDOS_MIN_REFERENCIA` | 3,0 | Voz neta mínima de un archivo de referencia |

Otros parámetros:
- `servicio/motor.py`: vigencia del desafío 120 s; 5 intentos de clave antes de bloquear; 5 minutos de bloqueo.
- `servicio/umbral.py`: ver la tabla de la sección 5.8.
- `huella_vocal/huella.py`: `MINIMO_HUELLA_S` = 0,1 s (voz mínima para calcular una huella).
- `frontend/app.js`: mínimo de voz para validar 3,5 s y máximo 12 s; mínimo para registrar 4 s y máximo 15 s; Umbral: "Detener" desde 1 s y máximo 30 s.

---

## 10. Tecnologías y versiones

**Imagen Docker (`voice_fingerprint-entorno:0.9.0`):**
- Base `python:3.12-slim-bookworm`, construcción en dos etapas.
- La primera etapa tiene `build-essential` y `cmake`, porque en arm64 `praat-parselmouth` no tiene rueda y se compila desde el código fuente (unos 8–10 minutos). En x86_64 hay rueda y la construcción es más rápida.
- Entorno virtual en `/opt/huellavoz_env`.
- PyTorch de PyPI **con CUDA 13.2** y sus librerías NVIDIA (`nvidia-*`), para poder usar la GPU. La misma imagen corre en CPU. En x86_64 se agrega `nvidia-cublas-cu12`, porque CTranslate2 usa cuBLAS de CUDA 12 en GPU.
- `pip install -r requirements.txt -c restricciones.txt`: las dependencias indirectas también quedan fijas. `restricciones.txt` se generó con `uv pip compile --universal --python-version 3.12` y vale para Linux x86_64 y aarch64. Todas sus dependencias compiladas tienen rueda para las dos arquitecturas, salvo `praat-parselmouth` en arm64.
- Los modelos se descargan en la primera etapa y se copian a `/opt/modelos`. La imagen final no tiene compilador ni código.

| Paquete | Versión |
|---|---|
| torch / torchaudio | 2.15.0 / 2.11.1 (PyPI, CUDA 13.2) |
| nvidia-cublas-cu12 | 12.9.3.13 (solo x86_64, para Whisper en GPU) |
| speechbrain | 1.1.2 |
| faster-whisper | 1.2.1 (con ctranslate2 4.9.0) |
| silero-vad | 6.2.3 |
| sherpa-onnx | 2.0.1 (con sherpa-onnx-core 2.0.1 y onnxruntime 1.32.0) |
| praat-parselmouth | 0.4.7 |
| soundfile | 0.14.0 |
| numpy / scipy | 2.5.4 / 1.18.1 |
| matplotlib | 3.11.2 |
| qdrant-client | 1.19.1 |
| huggingface-hub | 2.4.0 (solo para descargar los modelos al construir) |
| fastapi / uvicorn | 0.162.2 / 0.54.0 |
| python-multipart | 0.0.33 |
| httpx | 0.28.1 |
| psutil | 7.2.2 |

**Modelos** (dentro de la imagen, sección 5.10):

| Modelo | Revisión / origen | Archivos y hash verificado |
|---|---|---|
| `speechbrain/spkrec-ecapa-voxceleb` | `0f99f2d0ebe89ac095bcc5903c4dd8f72b367286` | `embedding_model.ckpt` sha256 `0575cb64…0126a2`; `classifier.ckpt` sha256 `fd9e3634…60d535`; `hyperparams.yaml`, `mean_var_norm_emb.ckpt`, `label_encoder.txt` por hash de git |
| `Systran/faster-whisper-base` | `ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66` | `model.bin` sha256 `d01c3014…a0a6a9`; `config.json`, `tokenizer.json`, `vocabulary.txt` por hash de git |
| TEN VAD (ONNX) | publicación `asr-models` de sherpa-onnx en GitHub | `ten-vad.onnx` sha256 `718cb7eef47e3cf5ddbe7e967a7503f46b8b469c0706872f494dfa921b486206` |
| Silero VAD | dentro de `silero-vad` 6.2.3 | — |

Los hashes completos están en `construccion/descargar_modelos.py`.

Licencias: TEN VAD, Apache 2.0 con condiciones adicionales (archivo LICENSE del proyecto TEN); sherpa-onnx, Apache 2.0.

Por defecto todo corre en CPU. Con `VF_DISPOSITIVO=gpu`, ECAPA usa la GPU (x86_64 y arm64) y Whisper también en x86_64 (sección 5.11).

---

## 11. Despliegue desde cero en `/home/user_ia/`

**Idea general:** internet hace falta **una sola vez**, en el paso 11.7 (construir la imagen). Todo lo anterior se puede preparar sin conexión y todo lo posterior funciona sin conexión. El mismo procedimiento sirve en x86_64 y en arm64. Conviene ensayarlo completo en la Spark de desarrollo antes de hacerlo en producción.

### 11.1 Requisitos del equipo

- Linux arm64 o x86_64 con Docker Engine y el plugin Docker Compose v2 (`docker compose version`).
- El usuario que despliega (por ejemplo `admin`) debe pertenecer al grupo `docker` y no trabajar como root.
- **Internet solo durante el paso 11.7**: Docker Hub (imagen base de Python), Debian, PyPI (incluye PyTorch con CUDA), Hugging Face y GitHub (modelos).
- Qdrant accesible (puede estar en el mismo equipo o en otro servidor).
- Unos 25 GB libres en disco (construcción, imagen con CUDA, respaldo y margen).
- Para usar la GPU (opcional): GPU NVIDIA con controlador compatible con CUDA 13 y NVIDIA Container Toolkit.

Si Docker responde "permission denied":

```bash
sudo usermod -aG docker "$USER"
newgrp docker
docker ps
```

### 11.2 Qdrant

En producción, Qdrant está en otro servidor: solo hace falta su IP y su puerto para `QDRANT_URL` (paso 11.6) y que el firewall permita el tráfico desde este equipo.

Si Qdrant tuviera que correr en este mismo equipo, descargue su imagen **durante la ventana con internet** y arránquelo:

```bash
mkdir -p /home/user_ia/qdrant_storage

docker run -d \
  --name qdrant \
  --restart unless-stopped \
  -p 6333:6333 \
  -p 6334:6334 \
  -v /home/user_ia/qdrant_storage:/qdrant/storage \
  qdrant/qdrant:v1.19.1

curl -s http://localhost:6333/ | head -c 200
```

### 11.3 Carpetas del proyecto

```bash
sudo mkdir -p /home/user_ia/voice_fingerprint
sudo chown -R "$USER":"$USER" /home/user_ia/voice_fingerprint

cd /home/user_ia/voice_fingerprint
mkdir -p codigo referencias_wav registros
```

Las tres carpetas deben existir antes de arrancar: `docker-compose.yml` no las crea (`create_host_path: false`) para evitar que Docker las cree como root. `imagenes/` la crea `construir_imagen.sh`.

### 11.4 Código

Copie `voice_fingerprint_v0.9.0.tar.gz` a `/home/user_ia/voice_fingerprint/` y extráigalo dentro de `codigo/`:

```bash
cd /home/user_ia/voice_fingerprint
tar xzf voice_fingerprint_v0.9.0.tar.gz -C codigo
ls codigo
# Dockerfile  configuracion.env.ejemplo  construccion  construir_imagen.sh  docker-compose.yml
# frontend  huella_vocal  requirements.txt  restricciones.txt  servicio
```

### 11.5 Referencias (pool inicial)

Copie los WAV de referencia a `referencias_wav/`, con las convenciones de la sección 5.1. Recomendaciones:
- Una persona por archivo y más de 30 s de voz por persona.
- Si vienen de otro equipo con registros web, copie también los `.json` que acompañan a los WAV `__web__`.

```bash
cp /ruta/origen/*.wav /ruta/origen/*.json /home/user_ia/voice_fingerprint/referencias_wav/
```

También puede arrancar con la carpeta vacía y registrar voces desde la página.

### 11.6 Configuración

```bash
cd /home/user_ia/voice_fingerprint/codigo

cat > .env <<EOF
VF_UID=$(id -u)
VF_GID=$(id -g)
VF_PUERTO_HOST=8000
EOF

cp configuracion.env.ejemplo configuracion.env
chmod 600 configuracion.env
nano configuracion.env
```

En `configuracion.env` ajuste:
- `QDRANT_URL`:
  - Qdrant en otro servidor (producción): `http://<IP>:<puerto>`.
  - Qdrant en el mismo equipo (Spark de desarrollo): `http://host.docker.internal:6333` (o el puerto que use).
  - **No use `http://localhost:6333`**: aunque `curl` responda desde el equipo, dentro del contenedor `localhost` es el propio contenedor y el servicio no arranca (`Connection refused`).
- `QDRANT_API_KEY`, si Qdrant la exige.
- `VF_VAD`: `silero` o `ten`.
- `VF_CLAVE_BORRADO`: 4 dígitos para poder eliminar personas desde la página.
- Los umbrales solo si se quieren cambiar.

### 11.7 Construir la imagen (el único paso con internet)

```bash
cd /home/user_ia/voice_fingerprint/codigo
./construir_imagen.sh
```

El script hace tres cosas:
1. **Construye** `voice_fingerprint-entorno:0.9.0`: sistema, dependencias (PyTorch con CUDA) con las versiones de `restricciones.txt` y los modelos con sus hashes verificados. Descarga varios GB; en arm64 tarda unos 15–25 minutos por la compilación de parselmouth; en x86_64, menos.
2. **Verifica** la imagen con el contenedor **sin red** (`--network none`): comprueba los hashes, carga Silero, TEN, ECAPA y Whisper, y los hace procesar una señal de prueba. Lo hace en CPU y, si el equipo tiene NVIDIA Container Toolkit, otra vez en GPU, indicando qué modelo quedó en cada dispositivo. Cada pasada debe terminar con:
   ```
   VERIFICACIÓN COMPLETA: todo carga y funciona sin internet.
   ```
3. **Respalda** la imagen en `../imagenes/voice_fingerprint-entorno_0.9.0_<arquitectura>.tar.gz` (más su `.sha256`). Con CUDA pesa varios GB (del orden de 4–6 GB comprimida).

Si algún paso falla, el script se detiene con el error: corríjalo mientras haya internet. Al terminar, el internet ya no hace falta.

### 11.8 Arrancar (sin internet desde aquí)

```bash
cd /home/user_ia/voice_fingerprint/codigo
docker compose up -d
docker compose logs -f
```

- En el primer arranque con un VAD, el servicio procesa toda la carpeta de referencias hacia las colecciones de ese VAD (`huella_vocal_<vad>_*`); el registro muestra el avance. Con unos 60 archivos tarda pocos minutos.
- Salga del registro con Ctrl+C (el servicio sigue corriendo).

Verifique:

```bash
curl -s http://localhost:8000/api/salud
docker compose ps        # debe decir "healthy" después de unos minutos
```

`/api/salud` debe mostrar `"vad"` con el VAD configurado, las colecciones con ese VAD en el nombre y el número de personas.

### 11.9 Ensayo sin internet

Después de construir, corte el internet del equipo (o pruebe directamente en producción, cuando ya no lo tenga) y compruebe:

| Prueba | Comando | Resultado esperado |
|---|---|---|
| Reiniciar | `docker compose restart` | Vuelve a "healthy" |
| Detener y arrancar | `docker compose down && docker compose up -d` | Vuelve a "healthy" |
| Costumbre de reconstruir | `docker compose up -d --build` | No construye ni descarga nada; arranca igual |
| Cambio estético | Editar `frontend/estilos.css` y recargar el navegador | Se ve el cambio; el contenedor no se toca |
| Cambio en Python | Editar un archivo de `servicio/` y `docker compose restart` | Arranca con el cambio |
| Reiniciar el equipo | `sudo reboot` | El contenedor vuelve solo (`restart: unless-stopped`) |
| Recuperar la imagen | `docker compose down`, `docker rmi voice_fingerprint-entorno:0.9.0`, `docker load -i ../imagenes/voice_fingerprint-entorno_0.9.0_<arq>.tar.gz`, `docker compose up -d` | Vuelve a funcionar |
| Verificación | `./construir_imagen.sh --verificar` | "VERIFICACIÓN COMPLETA" |
| Validación completa | En la página | Veredicto con espectrograma, huellas, perfil y mapa |

### 11.10 Acceso desde el navegador

El navegador solo permite el micrófono en HTTPS o en `localhost`.

- **En el mismo equipo:** abra `http://localhost:8000`.
- **Desde otro equipo (desarrollo):** abra un túnel SSH y luego `http://localhost:8000` en ese equipo:

  ```bash
  ssh -L 8000:localhost:8000 admin@<IP_DEL_SERVIDOR>
  ```

- **Producción (nginx con certificados):** vea la sección 11.15, con dos configuraciones completas. Dos puntos clave:
  - `client_max_body_size` de al menos `20m`. Las grabaciones viajan como WAV a la frecuencia del navegador (normalmente 48 kHz): una validación de 12 s pesa más de 1 MB y un registro de tres grabaciones, más de 4 MB, y el límite por defecto de nginx es 1 MB.
  - Si el nginx corre en el mismo equipo que el servicio, ponga `VF_PUERTO_HOST=127.0.0.1:8000` en `codigo/.env` para que el contenedor no sea accesible desde la red.
- La pestaña Umbral usa peticiones HTTP normales y pequeñas (unos 24 KB cada 250 ms a 48 kHz): no requiere ningún cambio en nginx.

### 11.11 Actualizar el código (sin internet)

**De la 0.8.x a la 0.9.0 sí hace falta internet**, porque la imagen cambió (PyTorch con CUDA):

```bash
cd /home/user_ia/voice_fingerprint
tar xzf voice_fingerprint_v0.9.0.tar.gz -C codigo
cd codigo
./construir_imagen.sh                 # con internet: voice_fingerprint-entorno:0.9.0
docker compose up -d                  # recrea el contenedor con la imagen nueva
curl -s http://localhost:8000/api/salud | jq '{version, dispositivo_pedido, dispositivos, avisos_dispositivo}'
```

La imagen 0.8.0 y su respaldo se pueden borrar después (`docker rmi voice_fingerprint-entorno:0.8.0`).

En general:

```bash
cd /home/user_ia/voice_fingerprint
tar xzf voice_fingerprint_vX.Y.Z.tar.gz -C codigo
cd codigo
docker compose restart          # si cambió algo de Python
```

- `configuracion.env` y `.env` no se tocan. Si la versión nueva trae variables nuevas, compárelas con `configuracion.env.ejemplo`.
- Si solo cambió el frontend, basta recargar el navegador.
- Si la versión nueva cambia `requirements.txt`, `restricciones.txt` o los modelos, necesita una imagen nueva (`./construir_imagen.sh`, con internet). Las notas de cada versión lo dirán.

### 11.12 Cambiar de VAD

1. Cambie `VF_VAD` en `configuracion.env`.
2. `docker compose up -d` (recrea el contenedor con la nueva configuración).
3. La primera vez con ese VAD se procesa toda la carpeta hacia sus colecciones; las del otro VAD quedan intactas para cuando se vuelva a él.
4. Si se cambian los umbrales para TEN, conviene anotar el cambio: el historial de Umbral guarda los umbrales de cada sesión.

### 11.13 Migrar desde la 0.7.0 (Spark de desarrollo)

- La imagen `voice_fingerprint:0.7.0` y la carpeta `modelos_cache/` ya no se usan; se pueden borrar.
- Las colecciones `huella_vocal_tramos` y `huella_vocal_personas` tampoco se usan: la 0.8.0 crea `huella_vocal_silero_*` o `huella_vocal_ten_*` desde `referencias_wav/`. Se pueden borrar en Qdrant cuando se quiera:
  ```bash
  curl -X DELETE http://localhost:6333/collections/huella_vocal_tramos
  curl -X DELETE http://localhost:6333/collections/huella_vocal_personas
  ```
- `referencias_wav/` se conserva tal cual. `registros/validaciones.jsonl` de la 0.7.0 se puede conservar; sus líneas sin VAD cuentan como Silero.

### 11.14 Sin Docker (opcional, para desarrollo)

```bash
cd /home/user_ia/voice_fingerprint/codigo
uv venv --python 3.12 huellavoz_env
source huellavoz_env/bin/activate
uv pip install -r requirements.txt -c restricciones.txt     # incluye PyTorch con CUDA
python construccion/descargar_modelos.py ../modelos      # con internet, una vez

cp configuracion.env.ejemplo configuracion.env      # QDRANT_URL=http://localhost:6333
set -a; source configuracion.env; set +a
python -m servicio.verificar
python -m servicio
```

Sin `uv`, se puede usar `python3.12 -m venv` con `pip install --break-system-packages` si hiciera falta.

### 11.15 Proxy reverso con nginx en la red interna

Escenario: el servicio corre en el servidor **xxx.xx.x.xxx** (puerto 8000). Ese equipo tiene su propio nginx, pero los certificados están en el nginx de otro equipo, **yyy.yy.y.yyy**, que es el que atiende a los usuarios por HTTPS. Reemplace las IP, nombres, puertos y rutas de ejemplo por los reales. Esta sección no cambia respecto a la 0.7.0.

**Condición del servicio:** la página llama a la API con rutas absolutas (`/api/...`). Por eso necesita un **nombre propio** (por ejemplo `huellavocal.empresa.local`) o un **puerto propio** en yyy. No funciona en una subruta como `https://servidor/huella/` sin cambiar el código.

#### Opción A: yyy → xxx:8000 directo (la más simple)

```
Usuarios ──HTTPS──▶ nginx yyy (certificados) ──HTTP red interna──▶ xxx:8000 (contenedor)
```

**En xxx** no cambia nada: `VF_PUERTO_HOST=8000` en `codigo/.env`.

**En yyy**, cree `/etc/nginx/conf.d/huella_vocal.conf`:

```nginx
upstream huella_vocal {
    server xxx.xx.x.xxx:8000;
    keepalive 8;
}

server {
    listen 80;
    server_name huellavocal.empresa.local;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name huellavocal.empresa.local;

    ssl_certificate     /ruta/al/certificado.crt;
    ssl_certificate_key /ruta/a/la/llave.key;

    client_max_body_size 20m;      # los WAV de validación y registro superan el 1 MB por defecto
    proxy_read_timeout   120s;     # registrar y eliminar esperan una sincronización
    proxy_send_timeout   120s;

    location / {
        proxy_pass         http://huella_vocal;
        proxy_http_version 1.1;
        proxy_set_header   Connection "";
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
    }
}
```

```bash
sudo nginx -t
sudo systemctl reload nginx
```

**Limitación:** el puerto 8000 de xxx queda abierto a toda la red, por HTTP y sin control de acceso. Además, **ufw no lo bloquea**, porque Docker publica los puertos con sus propias reglas de iptables y se salta ufw. Para cerrarlo hay que filtrar en la cadena `DOCKER-USER`:

```bash
sudo iptables -I DOCKER-USER -p tcp -m conntrack --ctorigdstport 8000 ! -s yyy.yy.y.yyy -j DROP
```

Esa regla se pierde al reiniciar el equipo si no se guarda (con `iptables-persistent` o el mecanismo del equipo). Por eso se recomienda la opción B.

#### Opción B: el nginx de xxx como portero (recomendada)

```
Usuarios ──HTTPS──▶ nginx yyy ──HTTP──▶ nginx xxx :8080 (solo acepta a yyy) ──▶ 127.0.0.1:8000 (contenedor)
```

El contenedor deja de ser accesible desde la red y el control de acceso queda en nginx, que es explícito y no depende de iptables.

**En xxx:**

1. En `codigo/.env` ponga `VF_PUERTO_HOST=127.0.0.1:8000` y reinicie:

   ```bash
   cd /home/user_ia/voice_fingerprint/codigo
   docker compose up -d
   ```

2. Cree `/etc/nginx/conf.d/huella_vocal_interno.conf`. El puerto 8080 es de ejemplo: use uno libre.

   ```nginx
   server {
       listen 8080;

       allow yyy.yy.y.yyy;      # solo el nginx con los certificados
       deny  all;

       client_max_body_size 20m;
       proxy_read_timeout   120s;
       proxy_send_timeout   120s;

       location / {
           proxy_pass       http://127.0.0.1:8000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $http_x_forwarded_proto;
       }
   }
   ```

3. Recargue nginx:

   ```bash
   sudo nginx -t
   sudo systemctl reload nginx
   ```

**En yyy**, use el mismo archivo de la opción A cambiando solo el upstream:

```nginx
upstream huella_vocal {
    server xxx.xx.x.xxx:8080;
    keepalive 8;
}
```

Este 8080 sí puede filtrarse además con ufw, porque lo atiende nginx y no Docker.

#### Nombre y certificado

- **Con un nombre propio:** el nombre (por ejemplo `huellavocal.empresa.local`) debe resolver a **yyy** en el DNS interno, y el certificado debe cubrirlo, ya sea con un comodín `*.empresa.local` o con ese nombre incluido.
- **Si no puede crear un nombre nuevo:** use el nombre que yyy ya tiene en otro puerto. En el bloque 443 cambie `listen 443 ssl;` por `listen 8443 ssl;` y ponga en `server_name` el nombre actual de yyy. Los usuarios entrarían por `https://nombre-actual:8443`.
- **El certificado debe ser de confianza** en los equipos de los usuarios (CA interna instalada). Si el navegador muestra advertencia, puede bloquear el micrófono.

#### Verificación

```bash
# Desde yyy: llega al servicio
curl -s http://xxx.xx.x.xxx:8000/api/salud     # opción A
curl -s http://xxx.xx.x.xxx:8080/api/salud     # opción B

# Opción B, desde otro equipo de la red: debe responder 403
curl -s -o /dev/null -w "%{http_code}\n" http://xxx.xx.x.xxx:8080/api/salud

# Desde el equipo de un usuario
curl -s https://huellavocal.empresa.local/api/salud
```

Después abra la página en el navegador y haga una validación completa. Así se prueban a la vez el micrófono (requiere el HTTPS), la subida de audio (el `client_max_body_size`) y el registro, que es el que más tarda. Pruebe también una sesión de Umbral.

### 11.16 Usar la GPU

1. Compruebe que Docker ve la GPU (sin internet, con la imagen ya construida):
   ```bash
   docker run --rm --gpus all voice_fingerprint-entorno:0.9.0 python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"
   ```
2. En `codigo/.env` agregue:
   ```
   COMPOSE_FILE=docker-compose.yml:docker-compose.gpu.yml
   ```
3. En `codigo/configuracion.env` ponga `VF_DISPOSITIVO=gpu`.
4. `docker compose up -d` y revise:
   ```bash
   docker compose logs | grep -E "Dispositivo pedido|ADVERTENCIA"
   curl -s http://localhost:8000/api/salud | jq '{dispositivos, avisos_dispositivo}'
   ```
   En la Spark lo esperado es `huella: "cuda"` y `stt: "cpu"` (con la advertencia de que CTranslate2 para arm64 no trae CUDA); en x86_64 con GPU, los dos en `"cuda"`.

Para volver a CPU: `VF_DISPOSITIVO=cpu` y `docker compose up -d` (el `COMPOSE_FILE` puede quedarse). Compare los tiempos en la pestaña "Tiempos y recursos": el historial se separa por dispositivo.

---

## 12. Operación diaria

Todo lo de esta tabla funciona sin internet.

| Tarea | Cómo |
|---|---|
| Ver el registro | `docker compose logs -f` (desde `codigo/`) |
| Reiniciar | `docker compose restart` |
| Detener / arrancar | `docker compose down` / `docker compose up -d` |
| Cambio estético en el frontend | Editar en `codigo/frontend/` y recargar el navegador |
| Cambio en el código Python | Editar en `codigo/huella_vocal/` o `codigo/servicio/` y `docker compose restart` |
| Cambiar la configuración (VAD, Qdrant, dispositivo, umbrales, clave) | Editar `configuracion.env` y `docker compose up -d` |
| Pasar de CPU a GPU | Sección 11.16 |
| Agregar referencias | Copiar WAV a `referencias_wav/` y pulsar "Resincronizar" en la pestaña Personas |
| Quitar referencias | Borrar el WAV de la carpeta y resincronizar, o usar "Eliminar" en la página (con la clave) |
| Respaldar | `referencias_wav/`, `registros/` e `imagenes/`. Qdrant no hace falta: se reconstruye |
| Reconstruir Qdrant | Borrar las dos colecciones `huella_vocal_<vad>_*` en Qdrant y reiniciar el servicio |
| Recuperar la imagen borrada | `docker load -i ../imagenes/voice_fingerprint-entorno_0.9.0_<arq>.tar.gz` y `docker compose up -d` |
| Verificar el entorno | `./construir_imagen.sh --verificar` |
| Revisar validaciones | `registros/validaciones.jsonl`: una línea JSON por validación (fecha, VAD, veredicto, dígitos pedidos y oídos, candidatos, pasos, consumo). No guarda audio |
| Revisar el experimento Umbral | Pestaña Umbral o `registros/umbral.jsonl`: una línea por sesión (sección 5.8). No guarda audio |

---

## 13. Solución de problemas

| Síntoma | Causa probable y solución |
|---|---|
| `permission denied ... docker.sock` | El usuario no está en el grupo `docker` (ver 11.1) |
| `bind source path does not exist` | Falta alguna carpeta de 11.3; créela con el usuario que despliega |
| `No such image: voice_fingerprint-entorno:0.9.0` o `pull access denied` | La imagen no está en el equipo. Sin internet: `docker load -i ../imagenes/...tar.gz`. Con internet y sin respaldo: `./construir_imagen.sh` |
| El contenedor no arranca: "Faltan modelos locales" | La imagen está incompleta o `VF_MODELOS` apunta a otra carpeta. Corra `./construir_imagen.sh --verificar`; si falla, reconstruya la imagen con internet |
| El contenedor no arranca: "La colección ... tiene huellas hechas con el VAD ..." | Una colección del VAD configurado contiene huellas de otro VAD. Borre esa colección en Qdrant y reinicie: se reconstruye desde `referencias_wav/` |
| El contenedor no arranca: "VF_VAD='...' no es válido" o error en los umbrales | Revise `VF_VAD` (`silero` o `ten`) y que los umbrales cumplan 0 < bajo ≤ alto < 1 |
| `construir_imagen.sh` falla con "no coincide con la versión esperada" | Un modelo descargado no es el esperado (descarga incompleta o cambio en el origen). Vuelva a correr el script; si persiste, revise la tabla de hashes de `descargar_modelos.py` |
| `Permission denied` al escribir en `referencias_wav/` o `registros/` | `VF_UID` y `VF_GID` no corresponden al dueño de las carpetas; revise `.env` y `ls -ln` |
| No conecta con Qdrant (`Connection refused` al arrancar) | Revise `QDRANT_URL`; si dice `localhost`, cámbiela por `host.docker.internal` (Qdrant en el mismo equipo) o por la IP del servidor. En otro servidor: IP, puerto y firewall. En el mismo equipo, dentro del contenedor `localhost` es el propio contenedor: use `host.docker.internal:<puerto>` y revise que Qdrant escuche en todas las interfaces |
| El navegador no ofrece el micrófono | La página no está en HTTPS ni en `localhost`: use el túnel SSH o nginx con certificados |
| Error 413 al validar o registrar detrás de nginx | Suba `client_max_body_size` (ver 11.15) |
| Error 504 al registrar o eliminar detrás de nginx | Suba `proxy_read_timeout` (ver 11.15): esas acciones esperan una sincronización |
| El puerto 8000 sigue accesible desde la red pese a ufw | Docker publica puertos saltándose ufw: use la opción B de 11.15 o la regla `DOCKER-USER` |
| Error 409 al resincronizar | Ya hay una sincronización en curso; espere |
| Umbral: "Hay una sincronización del pool en curso" | Espere a que termine la sincronización y empiece de nuevo |
| Umbral: "La sesión no existe o venció" | La sesión estuvo más de 2 minutos sin actividad o el servicio se reinició; empiece de nuevo |
| "Muestra insuficiente" aunque la persona habló | El medidor del navegador y el VAD del servidor no cuentan igual los segundos (puede pasar con 3,5 s en el navegador y 2,9 s en el servidor). Hable un poco más o suba `MINIMO_VOZ_VALIDACION` en `app.js` |
| Tras actualizar desde la 0.7.0, una pestaña nueva aparece pero sus botones no responden (por ejemplo "Empezar" en Umbral) | El navegador sigue usando el `app.js` de la 0.7.0, que guardó en caché (la 0.7.0 no enviaba `Cache-Control`). Recargue una vez con Ctrl+Shift+R; desde ahí basta una recarga normal. Señal: el encabezado no muestra el VAD al final |
| Un cambio del frontend no se ve | Recargue la página. Si hay un proxy intermedio con caché propia, revise que respete `Cache-Control: no-cache` |
| Puerto 8000 ocupado | Cambie `VF_PUERTO_HOST` en `.env` |
| Se pidió GPU y en la ficha o en el log aparece "PyTorch no ve ninguna" | El contenedor no tiene acceso a la GPU: falta `COMPOSE_FILE=docker-compose.yml:docker-compose.gpu.yml` en `.env`, el NVIDIA Container Toolkit, o el controlador no es compatible con CUDA 13. Pruebe el comando del paso 1 de 11.16 |
| "La GPU falló al probarla (...)" | La GPU se ve pero el modelo no pudo correr en ella (controlador antiguo, memoria insuficiente, GPU no soportada). El servicio sigue en CPU; revise el mensaje completo en `docker compose logs` |
| "Whisper: CTranslate2 para arm64 no trae soporte de CUDA" | Esperado en la DGX Spark: la transcripción sigue en CPU y ECAPA usa la GPU |
| `could not select device driver "nvidia"` al arrancar | `docker-compose.gpu.yml` está activo en un equipo sin NVIDIA Container Toolkit. Quite `COMPOSE_FILE` de `.env` o instale el toolkit |
| El contenedor no queda `healthy` | Revise `docker compose logs`: el primer arranque con un VAD sincroniza toda la carpeta y puede tardar más que el `start_period` de 180 s |

---

## 14. Limitaciones conocidas

- **Sensibilidad al canal:** la misma persona grabada con otro micrófono u otra cadena de audio obtiene scores más bajos (0,67 frente a 0,73–0,82). En condiciones reales cada persona hablará desde un dispositivo distinto.
- **No detecta voces clonadas ni sintéticas**; solo impide reutilizar grabaciones.
- **Umbrales provisionales**, calibrados con Silero y un pool pequeño; con TEN VAD aún no se han revisado.
- **TEN VAD por sherpa-onnx:** usa el modelo ONNX oficial, pero el preprocesamiento lo implementa sherpa-onnx, no la librería compilada de TEN. Puede haber diferencias pequeñas frente a la librería oficial.
- **Umbral:** la resolución del barrido es de 50 ms y no se mide por debajo de 250 ms de voz neta (la voz mínima de un segmento en el VAD); el primer dato suele llegar hacia los 310 ms por el relleno, y por debajo de 1 s la similitud es muy ruidosa. El barrido usa la voz neta final; sus ms pueden diferir un poco de los mostrados en vivo. Las plantillas del pool quedan fijas al empezar cada sesión. Sin una lista de quién habló, el historial agrupa por la persona identificada.
- **Probado en este checkpoint:** el código se probó en x86_64, sin red, con los dos VAD (sincronización, validación, registro, eliminación, Umbral, historial e interfaz en Chromium con micrófono simulado), con modelos sustitutos para ECAPA y Whisper porque Hugging Face no estaba disponible en el entorno de desarrollo. ECAPA se probó cargando desde carpeta local sin red. **Falta construir la imagen con Docker** en la Spark de desarrollo (arm64) y en un equipo x86_64: `construir_imagen.sh` lo verifica al terminar.
- **Solo micrófono de PC a 16 kHz;** la telefonía a 8 kHz no está probada.
- **Un solo proceso:** pensado para una demo; validaciones y sesiones simultáneas se atienden, pero comparten el candado de inferencia y los consumos medidos se mezclan.
- **GPU parcial en la Spark:** en arm64, solo ECAPA usa la GPU; Whisper sigue en CPU porque CTranslate2 no publica ruedas arm64 con CUDA.
- **GPU sin probar en este checkpoint:** el entorno de desarrollo no tenía GPU. Se probó que, con `VF_DISPOSITIVO=gpu` y sin GPU (o con una GPU que falla), cada modelo vuelve a CPU con su advertencia. El uso real de la GPU lo comprueba `construir_imagen.sh` en un equipo con NVIDIA Container Toolkit, y la sección 11.16.
- **Imagen más pesada:** PyTorch con CUDA y sus librerías suman varios GB, también en equipos sin GPU.
- **Desafíos y sesiones de Umbral en memoria:** si el servicio se reinicia, se pierden (hay que empezar de nuevo).

---

## 15. Pendientes y hoja de ruta

1. **Ensayo de la 0.8.0** en la Spark de desarrollo (construir, cortar internet, tabla de 11.9) y luego en un equipo x86_64.
2. **Despliegue en la Spark de producción:** construir en la ventana con internet, Qdrant del otro servidor, nginx con certificados reales (opción B de 11.15).
3. **Revisar los umbrales con TEN VAD** y comparar Silero frente a TEN con la pestaña Umbral (medianas por VAD).
4. **AS-norm** (normalización adaptativa de scores contra una cohorte), para reducir el efecto del canal.
5. Medir el rendimiento con distintos dispositivos (cross-device) y recalibrar los umbrales.
6. Telefonía a 8 kHz (contact center, canales separados por hablante).
7. Menores:
   - Renombrar en la pestaña de tiempos "Verificación del desafío" y "Decisión y prueba de vida" para que no se confundan.
   - Ajustar el mínimo de voz del navegador frente al VAD del servidor.
8. Medir CPU frente a GPU con la pestaña "Tiempos y recursos" (ya separa el historial por dispositivo) en la Spark y en x86_64.
9. Evaluar compilar CTranslate2 con CUDA para arm64, si Whisper en CPU resulta el cuello de botella en la Spark.

**Observaciones abiertas de la revisión de la 0.7.0** (no acordadas como cambios):
- La prueba de vida no comprueba que quien dice los dígitos sea la persona identificada: la huella sale de toda la voz neta (nombre + dígitos). Las marcas de tiempo por palabra permitirían comparar la huella del tramo de los dígitos.
- Registrar un nombre que ya existe suma las grabaciones a esa persona aunque sea otra.
- El espectrograma y la línea de tono cortan a los 10 s de voz neta; la validación admite hasta 12 s y los últimos dígitos pueden quedar fuera.
- La API no tiene autenticación y el bloqueo de la clave de borrado es para todos.

---

## 16. Historial de versiones y decisiones

| Versión | Cambios principales |
|---|---|
| Fases 0–3 | Elección de modelos y verificación de ruedas arm64; análisis del pool; prueba de vida con frases (descartada por impráctica) → dígitos; sincronización con Qdrant |
| 0.5.x | Servicio FastAPI + página, Docker multi-arquitectura, despliegue en la Spark de desarrollo por HTTP y túnel SSH; reconocimiento de códigos OpenSLR |
| 0.6.0 | Paso 3 del registro "nombre + uno al diez" con botón Detener automático; espectrograma de la entrada con ejes, F0 y dígitos; huellas más grandes con franja de aporte; mapas Plotly interactivos; eliminación con clave; ayudas y rangos hombre/mujer en el perfil; arreglo del registro con grabaciones cortas; arreglo del zoom que encogía los gráficos; botón Cancelar en toda grabación |
| 0.7.0 | Pestaña "Tiempos y recursos": pasos del servidor medidos, historial con mediana y p95, CPU/RAM en vivo, consumo por validación, ficha del sistema; `psutil` |
| 0.9.0 | **CPU o GPU** con `VF_DISPOSITIVO`: ECAPA en GPU (x86_64 y arm64), Whisper en GPU solo en x86_64, vuelta a CPU con advertencia si la GPU no está o falla; imagen `voice_fingerprint-entorno:0.9.0` con PyTorch y CUDA (sirve para los dos modos; requiere construirse de nuevo); `docker-compose.gpu.yml` activado con `COMPOSE_FILE`; verificación en CPU y GPU; dispositivo en la ficha, el encabezado y la bitácora; historial de tiempos separado por dispositivo |
| 0.8.2 | Umbral: voz mínima para la huella en 250 ms, tomada del mínimo de segmento del VAD; historial con n, media, mediana, p90, p95, mínimo y máximo de las dos cifras. Misma imagen del entorno |
| 0.8.1 | Umbral: voz mínima para la huella de 500 a 100 ms (franja gris vertical en 100 ms); `voz_min_ms` guardado por sesión; historial agrupado por VAD y voz mínima. Validación y registro sin cambios (3 s). Misma imagen del entorno |
| 0.8.0 | **Sin internet tras una construcción:** imagen del entorno con dependencias y modelos (revisiones y hashes fijos), código montado en solo lectura, compose sin construcción y con `pull_policy: never`, `construir_imagen.sh` (construir, verificar sin red, respaldar), `servicio.verificar`, `restricciones.txt`, página sin caché. **VAD por despliegue:** Silero o TEN (modelo ONNX con sherpa-onnx), colecciones por VAD con comprobación al arrancar, umbrales configurables. **x86_64 y arm64** con las mismas versiones. **Pestaña Umbral:** identificación en vivo cada 250 ms por HTTP, barrido preciso de primer cruce y cruce estable, historial con medianas por persona y VAD |

Decisiones tomadas para la 0.8.0:
- En producción se pide internet una sola vez, para construir; después todo debe funcionar sin conexión, incluidos los cambios estéticos del frontend.
- Un solo contenedor para voice_fingerprint; Qdrant de producción en otro servidor (solo se configura su IP y puerto).
- Ambos VAD como variable de configuración por despliegue (requisito); colecciones separadas por VAD, construidas desde cero.
- Funcionamiento en x86_64 y arm64 (requisito).
- 0.9.0: CPU o GPU por variable de ambiente (requisito). En la Spark, ECAPA en GPU y Whisper en CPU; en x86, los dos en GPU. Una sola imagen con CUDA para los dos modos aunque pese más. Si se pide GPU y no se puede usar, seguir en CPU con advertencia. La instalación en producción (que tiene NVIDIA Container Toolkit) se hará solo con la versión final, probada en la Spark de desarrollo y en el PC x86.
- 0.8.2: la franja gris vertical de Umbral coincide con la voz mínima de un segmento en el VAD (250 ms); estadística completa en el historial.
- 0.8.1: en el experimento Umbral, franja de "sin huella" en 100 ms para ver datos desde el primer momento; la exigencia de la validación se mantiene en unos 3 s (nombre + dígitos de la prueba de vida).
- Umbral: sin elegir de antemano quién habla y sin preguntar al final si era la persona; dos cifras (primer cruce y cruce estable); vista en vivo más barrido preciso; historial con medianas por persona y por VAD; peticiones HTTP normales, sin cambios en nginx.

---

## 17. Diagramas (Mermaid)

Respaldo gráfico de los procesos descritos arriba. Se ven directamente en GitHub, GitLab, VS Code (con la extensión de Mermaid) u Obsidian, o en https://mermaid.live pegando cada bloque.

### 17.1 Arquitectura

Componentes del navegador, del contenedor y del equipo anfitrión. La imagen trae dependencias y modelos; el código se monta desde codigo/.

```mermaid
flowchart LR
    subgraph NAV["Navegador"]
        UI["Página web<br/>HTML + JS + Plotly"]
        MIC["Captura AudioWorklet<br/>sin AGC, ruido ni eco"]
    end

    subgraph CONT["Contenedor voice_fingerprint · FastAPI :8000"]
        API["API /api/*"]
        MOTOR["Motor"]
        VAD["VAD configurado<br/>Silero o TEN"]
        ECAPA["ECAPA-TDNN<br/>huella 192-d<br/>CPU o GPU"]
        WHISPER["faster-whisper base<br/>CPU, o GPU en x86_64"]
        PRAAT["Praat<br/>perfil acústico"]
        UMB["Umbral<br/>sesiones y barrido"]
        MON["Monitor<br/>CPU · RAM · hilos"]
    end

    subgraph IMG["Imagen del entorno (sin código)"]
        ENV[("/opt/huellavoz_env<br/>dependencias + CUDA")]
        MOD[("/opt/modelos<br/>ECAPA · Whisper · TEN")]
    end

    subgraph HOST["Equipo anfitrión"]
        COD[("codigo/<br/>montado en solo lectura")]
        REF[("referencias_wav/<br/>fuente de verdad")]
        LOG[("registros/<br/>validaciones.jsonl · umbral.jsonl")]
        RES[("imagenes/<br/>respaldo .tar.gz")]
    end

    QD[("Qdrant<br/>huella_vocal_VAD_tramos<br/>huella_vocal_VAD_personas")]

    MIC -- "WAV / PCM" --> UI
    UI -- "HTTP" --> API
    API --> MOTOR
    MOTOR --> VAD & ECAPA & WHISPER & PRAAT & UMB
    MOTOR --- MON
    COD -. "código" .-> CONT
    MOD -. "modelos locales, modo offline" .-> CONT
    MOTOR -- "sincroniza" --> REF
    MOTOR -- "índice derivado por VAD" --> QD
    MOTOR --> LOG
    IMG -. "docker save" .-> RES
```

### 17.2 Secuencia de una validación

De pedir los números al veredicto, con los pasos del servidor en orden.

```mermaid
sequenceDiagram
    autonumber
    actor P as Persona
    participant N as Navegador
    participant A as API FastAPI
    participant M as Motor
    participant Q as Qdrant
    participant B as Bitácora

    P->>N: Pulsa "Pedir números"
    N->>A: POST /api/desafio
    A->>M: nuevo_desafio()
    M-->>A: id, 6 dígitos, vigencia 120 s
    A-->>N: desafío
    N-->>P: Muestra los números

    P->>N: Graba nombre completo + 6 dígitos
    Note over N: Detener se activa con 3,5 s de voz<br/>Cancelar o Esc disponibles siempre
    N->>A: POST /api/validar (audio WAV + desafio_id)
    A->>M: validar_subida()
    M->>M: Recepción del audio
    M->>M: Verificación del desafío (vigente, un solo uso)
    M->>M: Lectura y conversión a 16 kHz mono
    M->>M: Espera de turno de inferencia
    M->>M: VAD configurado (voz neta)

    alt voz neta menor a 3 s
        M->>B: anota muestra_insuficiente
        M-->>A: muestra_insuficiente
    else voz suficiente
        par Huella
            M->>M: ECAPA-TDNN (192 valores)
        and Prueba de vida
            M->>M: faster-whisper con marcas por palabra
        end
        M->>Q: buscar_personas(huella, k=3) en las colecciones del VAD
        Q-->>M: top 3 candidatos con score coseno
        M->>M: Decisión de identidad + comparación de dígitos
        M->>M: Perfil Praat, espectrograma, F0
        M->>Q: plantilla del mejor candidato
        M->>M: Proyección PCA y similitudes
        M->>B: anota veredicto, VAD, pasos y consumo
        M-->>A: resultado completo
    end
    A-->>N: JSON
    N-->>P: Veredicto, capas, espectrograma, huellas, perfil, mapa
```

### 17.3 Árbol de decisión

Cómo se llega a cada veredicto. Los umbrales son los valores por defecto (configurables con VF_UMBRAL_ALTO, VF_UMBRAL_BAJO y VF_MARGEN_MINIMO).

```mermaid
flowchart TD
    A(["Audio + desafío"]) --> B{"¿Desafío vigente<br/>y sin usar?"}
    B -- No --> E1["Error 400:<br/>pida números de nuevo"]
    B -- Sí --> C{"¿Voz neta ≥ 3 s?"}
    C -- No --> V0["muestra_insuficiente"]
    C -- Sí --> D{"Prueba de vida:<br/>¿dígitos oídos vs pedidos<br/>con ≤ 1 error?"}
    D -- No --> V1["rechazado_prueba_de_vida"]
    D -- Sí --> F{"Mejor score"}
    F -- "< 0,50" --> V2["no_identificado"]
    F -- "0,50 a 0,65" --> V3["no_concluyente<br/>zona gris"]
    F -- "≥ 0,65" --> G{"¿Margen sobre el<br/>segundo ≥ 0,10?"}
    G -- No --> V4["no_concluyente<br/>dos candidatos cercanos"]
    G -- Sí --> V5["validado"]

    classDef ok fill:#e5f2ea,stroke:#1e7a46,color:#1c2329
    classDef alerta fill:#fbf0d9,stroke:#8a5700,color:#1c2329
    classDef error fill:#fbe8e6,stroke:#b42318,color:#1c2329
    class V5 ok
    class V0,V3,V4 alerta
    class V1,V2,E1 error
```

### 17.4 Sincronización carpeta → Qdrant

Al arrancar el servicio y con el botón Resincronizar. Trabaja sobre las colecciones del VAD configurado.

```mermaid
flowchart TD
    S(["Arranque del servicio<br/>o botón Resincronizar"]) --> V{"¿Las colecciones del VAD<br/>tienen huellas de otro VAD?"}
    V -- Sí --> X1["El servicio no arranca:<br/>borre esa colección"]
    V -- No --> L["Listar referencias_wav/<br/>y calcular SHA-256 de cada archivo"]
    L --> I["Leer inventario de hashes<br/>en huella_vocal_VAD_tramos"]
    I --> CMP{"Comparar carpeta<br/>con Qdrant"}
    CMP -- "hash nuevo" --> N["Procesar archivo"]
    CMP -- "mismo nombre,<br/>contenido nuevo" --> U["Actualizado:<br/>borrar tramos viejos"]
    U --> N
    CMP -- "hash conocido,<br/>otro nombre" --> R["Renombrado:<br/>actualizar datos"]
    CMP -- "hash ausente<br/>en la carpeta" --> D["Eliminado:<br/>borrar sus tramos"]
    CMP -- "sin cambios" --> X["Omitir"]

    N --> C1["cargar_audio<br/>mono 16 kHz"]
    C1 --> C2["VAD configurado<br/>voz neta"]
    C2 --> C3{"¿Voz neta ≥ 3 s?"}
    C3 -- No --> ER["Error: referencia rechazada"]
    C3 -- Sí --> C4["Partir en tramos de 10 s<br/>sobrante menor a 5 s se une al anterior"]
    C4 --> C5["ECAPA-TDNN<br/>una huella por tramo"]
    C5 --> C6["Guardar tramos con vad en el payload"]

    C6 & R & D --> P["Recalcular personas afectadas:<br/>plantilla = promedio normalizado<br/>+ perfil acústico"]
    P --> Q["Guardar en<br/>huella_vocal_VAD_personas"]
    Q --> F(["Resumen: nuevos, actualizados,<br/>eliminados, renombrados, errores"])
```

### 17.5 Registro web

Todas las grabaciones se revisan antes de guardar nada.

```mermaid
flowchart TD
    A(["Pestaña Registrar voz"]) --> B["Nombre, origen opcional<br/>y consentimiento"]
    B --> G1["Grabación 1: habla libre ~10 s"]
    B --> G2["Grabación 2: otro tema ~10 s"]
    B --> G3["Grabación 3: nombre completo<br/>y contar del uno al diez"]
    G1 & G2 & G3 --> E["POST /api/registro"]
    E --> V{"Cada grabación:<br/>voz neta ≥ 3 s y<br/>saturación ≤ 1 %"}
    V -- "alguna no cumple" --> X["Error 400: indica<br/>qué grabación repetir"]
    V -- "todas cumplen" --> W["Guardar persona__web__fecha__n.wav<br/>+ persona__web__fecha.json"]
    W --> S["Sincronizar"]
    S --> C{"¿La persona<br/>quedó en el pool?"}
    C -- No --> X2["Error 400 con<br/>detalle por archivo"]
    C -- Sí --> OK(["Persona en el pool<br/>+ advertencias si la sincronización<br/>descartó algún archivo"])
```

### 17.6 Eliminación de personas

```mermaid
flowchart TD
    A(["Eliminar en la pestaña Personas"]) --> H{"¿VF_CLAVE_BORRADO<br/>tiene 4 dígitos?"}
    H -- No --> N["Botones ocultos<br/>y aviso de configuración"]
    H -- Sí --> K["Escribir la clave"]
    K --> BL{"¿Bloqueado por<br/>5 intentos fallidos?"}
    BL -- Sí --> E1["403: espere 5 min"]
    BL -- No --> C{"¿Clave correcta?<br/>hmac.compare_digest"}
    C -- No --> E2["403: clave incorrecta<br/>y suma un intento"]
    C -- Sí --> D["Borrar WAV de la persona<br/>y JSON de consentimiento"]
    D --> S["Sincronizar: se borran<br/>sus tramos y su plantilla"]
    S --> F(["Persona eliminada<br/>sin posibilidad de deshacer"])
```

### 17.7 Despliegue desde cero

Resumen visual de la sección 11. Internet solo hace falta en el paso de construir la imagen.

```mermaid
flowchart TD
    A(["Equipo nuevo<br/>x86_64 o arm64"]) --> B{"¿Docker y usuario<br/>en el grupo docker?"}
    B -- No --> B1["Instalar Docker<br/>usermod -aG docker"] --> D
    B -- Sí --> D["Crear /home/user_ia/voice_fingerprint/<br/>codigo, referencias_wav, registros"]
    D --> E["tar xzf voice_fingerprint_v0.9.0.tar.gz -C codigo"]
    E --> F["Copiar WAV de referencia"]
    F --> G["Crear codigo/.env y configuracion.env<br/>QDRANT_URL, VF_VAD, VF_DISPOSITIVO, VF_CLAVE_BORRADO<br/>(GPU: COMPOSE_FILE con docker-compose.gpu.yml)"]
    G --> H["./construir_imagen.sh<br/>ÚNICO paso con internet"]
    H --> H1["Construye la imagen<br/>dependencias + modelos verificados"]
    H1 --> H2["Verifica con el contenedor SIN red<br/>en CPU y, si hay toolkit NVIDIA, en GPU"]
    H2 --> H3["Respalda la imagen en<br/>imagenes/*.tar.gz"]
    H3 --> I(["Desde aquí, sin internet"])
    I --> J["docker compose up -d"]
    J --> K["Primer arranque: sincroniza<br/>referencias hacia las colecciones del VAD"]
    K --> L["curl /api/salud"]
    L --> M{"Acceso"}
    M -- "mismo equipo" --> M1["http://localhost:8000"]
    M -- "desarrollo remoto" --> M2["ssh -L 8000:localhost:8000<br/>y http://localhost:8000"]
    M -- "producción" --> M3["nginx con certificados<br/>client_max_body_size 20m<br/>VF_PUERTO_HOST=127.0.0.1:8000"]
```

### 17.8 Operación sin internet

Qué hace falta según lo que cambie.

```mermaid
flowchart TD
    A(["Cambio"]) --> B{"¿Qué cambió?"}
    B -- "frontend/" --> F["Recargar el navegador"]
    B -- "huella_vocal/ o servicio/" --> R["docker compose restart"]
    B -- "configuracion.env<br/>(VAD, CPU o GPU...)" --> U["docker compose up -d"]
    B -- "requirements.txt,<br/>restricciones.txt o modelos" --> I["Imagen nueva:<br/>./construir_imagen.sh<br/>(necesita internet)"]
    B -- "se borró la imagen" --> L["docker load -i imagenes/...tar.gz<br/>y docker compose up -d"]
    F & R & U & L --> OK(["Sigue sin internet"])
```

### 17.9 Experimento Umbral

Una sesión de la pestaña Umbral, de Empezar al resultado.

```mermaid
sequenceDiagram
    autonumber
    actor P as Persona
    participant N as Navegador
    participant A as API FastAPI
    participant U as Umbral
    participant H as umbral.jsonl

    P->>N: Pulsa "Empezar" y habla
    N->>A: POST /api/umbral/sesion {tasa}
    A->>U: abrir(): fija las plantillas del pool
    U-->>N: id, intervalo 250 ms, umbrales, VAD
    loop cada 250 ms mientras habla
        N->>A: POST /audio?procesar=1 (PCM 16 bits nuevo)
        A->>U: agregar()
        U->>U: todo el audio a 16 kHz, VAD, voz neta
        U->>U: huella ECAPA, 1:N contra las plantillas, decisión
        U-->>N: ms de voz neta, estado, top 3, margen
        N-->>P: Gráfica y cifras en vivo
    end
    P->>N: Pulsa "Detener" (o 30 s)
    N->>A: POST /audio (lo que faltaba)
    N->>A: POST /finalizar
    A->>U: finalizar()
    U->>U: VAD sobre todo el audio
    U->>U: Barrido preciso cada 50 ms<br/>alrededor de los dos cruces
    U->>H: una línea: VAD, persona, cruces, curva
    U-->>N: primer cruce, cruce estable, estado
    N-->>P: Resultado, marcas en la gráfica e historial
```

### 17.10 Barrido preciso

Cómo se refinan las dos cifras a partir de los puntos en vivo.

```mermaid
flowchart TD
    S(["Finalizar"]) --> V["Voz neta final<br/>(VAD sobre todo el audio)"]
    V --> F{"¿Identificado al final?"}
    F -- No --> SI["estado: sin_identificar"]
    F -- Sí --> P1["Primer cruce: primer punto en vivo identificado<br/>y el punto anterior acotan la ventana"]
    P1 --> P2["Evaluar cada 50 ms dentro de la ventana<br/>el primero identificado es el primer cruce"]
    F -- Sí --> E1["Cruce estable: último punto en vivo que NO era<br/>la persona final y el siguiente acotan la ventana"]
    E1 --> E2["Desde el borde derecho hacia atrás cada 50 ms<br/>mientras siga identificada la persona final"]
    E2 --> C{"¿Hay ≥ 2 s de voz neta<br/>después del cruce estable?"}
    C -- Sí --> OK["estado: confirmado"]
    C -- No --> SC["estado: sin_confirmar"]
    P2 & E2 --> MIN["Si un cruce cae en el mínimo (250 ms)<br/>se muestra como ≤ 250 ms"]
```

### 17.11 Código Mermaid sin renderizar

Los mismos 10 diagramas como texto plano, para copiarlos en cualquier herramienta aunque el visor de Markdown dibuje los bloques de arriba.

**17.1 Arquitectura**

```text
flowchart LR
    subgraph NAV["Navegador"]
        UI["Página web<br/>HTML + JS + Plotly"]
        MIC["Captura AudioWorklet<br/>sin AGC, ruido ni eco"]
    end

    subgraph CONT["Contenedor voice_fingerprint · FastAPI :8000"]
        API["API /api/*"]
        MOTOR["Motor"]
        VAD["VAD configurado<br/>Silero o TEN"]
        ECAPA["ECAPA-TDNN<br/>huella 192-d<br/>CPU o GPU"]
        WHISPER["faster-whisper base<br/>CPU, o GPU en x86_64"]
        PRAAT["Praat<br/>perfil acústico"]
        UMB["Umbral<br/>sesiones y barrido"]
        MON["Monitor<br/>CPU · RAM · hilos"]
    end

    subgraph IMG["Imagen del entorno (sin código)"]
        ENV[("/opt/huellavoz_env<br/>dependencias + CUDA")]
        MOD[("/opt/modelos<br/>ECAPA · Whisper · TEN")]
    end

    subgraph HOST["Equipo anfitrión"]
        COD[("codigo/<br/>montado en solo lectura")]
        REF[("referencias_wav/<br/>fuente de verdad")]
        LOG[("registros/<br/>validaciones.jsonl · umbral.jsonl")]
        RES[("imagenes/<br/>respaldo .tar.gz")]
    end

    QD[("Qdrant<br/>huella_vocal_VAD_tramos<br/>huella_vocal_VAD_personas")]

    MIC -- "WAV / PCM" --> UI
    UI -- "HTTP" --> API
    API --> MOTOR
    MOTOR --> VAD & ECAPA & WHISPER & PRAAT & UMB
    MOTOR --- MON
    COD -. "código" .-> CONT
    MOD -. "modelos locales, modo offline" .-> CONT
    MOTOR -- "sincroniza" --> REF
    MOTOR -- "índice derivado por VAD" --> QD
    MOTOR --> LOG
    IMG -. "docker save" .-> RES
```

**17.2 Secuencia de una validación**

```text
sequenceDiagram
    autonumber
    actor P as Persona
    participant N as Navegador
    participant A as API FastAPI
    participant M as Motor
    participant Q as Qdrant
    participant B as Bitácora

    P->>N: Pulsa "Pedir números"
    N->>A: POST /api/desafio
    A->>M: nuevo_desafio()
    M-->>A: id, 6 dígitos, vigencia 120 s
    A-->>N: desafío
    N-->>P: Muestra los números

    P->>N: Graba nombre completo + 6 dígitos
    Note over N: Detener se activa con 3,5 s de voz<br/>Cancelar o Esc disponibles siempre
    N->>A: POST /api/validar (audio WAV + desafio_id)
    A->>M: validar_subida()
    M->>M: Recepción del audio
    M->>M: Verificación del desafío (vigente, un solo uso)
    M->>M: Lectura y conversión a 16 kHz mono
    M->>M: Espera de turno de inferencia
    M->>M: VAD configurado (voz neta)

    alt voz neta menor a 3 s
        M->>B: anota muestra_insuficiente
        M-->>A: muestra_insuficiente
    else voz suficiente
        par Huella
            M->>M: ECAPA-TDNN (192 valores)
        and Prueba de vida
            M->>M: faster-whisper con marcas por palabra
        end
        M->>Q: buscar_personas(huella, k=3) en las colecciones del VAD
        Q-->>M: top 3 candidatos con score coseno
        M->>M: Decisión de identidad + comparación de dígitos
        M->>M: Perfil Praat, espectrograma, F0
        M->>Q: plantilla del mejor candidato
        M->>M: Proyección PCA y similitudes
        M->>B: anota veredicto, VAD, pasos y consumo
        M-->>A: resultado completo
    end
    A-->>N: JSON
    N-->>P: Veredicto, capas, espectrograma, huellas, perfil, mapa
```

**17.3 Árbol de decisión**

```text
flowchart TD
    A(["Audio + desafío"]) --> B{"¿Desafío vigente<br/>y sin usar?"}
    B -- No --> E1["Error 400:<br/>pida números de nuevo"]
    B -- Sí --> C{"¿Voz neta ≥ 3 s?"}
    C -- No --> V0["muestra_insuficiente"]
    C -- Sí --> D{"Prueba de vida:<br/>¿dígitos oídos vs pedidos<br/>con ≤ 1 error?"}
    D -- No --> V1["rechazado_prueba_de_vida"]
    D -- Sí --> F{"Mejor score"}
    F -- "< 0,50" --> V2["no_identificado"]
    F -- "0,50 a 0,65" --> V3["no_concluyente<br/>zona gris"]
    F -- "≥ 0,65" --> G{"¿Margen sobre el<br/>segundo ≥ 0,10?"}
    G -- No --> V4["no_concluyente<br/>dos candidatos cercanos"]
    G -- Sí --> V5["validado"]

    classDef ok fill:#e5f2ea,stroke:#1e7a46,color:#1c2329
    classDef alerta fill:#fbf0d9,stroke:#8a5700,color:#1c2329
    classDef error fill:#fbe8e6,stroke:#b42318,color:#1c2329
    class V5 ok
    class V0,V3,V4 alerta
    class V1,V2,E1 error
```

**17.4 Sincronización carpeta → Qdrant**

```text
flowchart TD
    S(["Arranque del servicio<br/>o botón Resincronizar"]) --> V{"¿Las colecciones del VAD<br/>tienen huellas de otro VAD?"}
    V -- Sí --> X1["El servicio no arranca:<br/>borre esa colección"]
    V -- No --> L["Listar referencias_wav/<br/>y calcular SHA-256 de cada archivo"]
    L --> I["Leer inventario de hashes<br/>en huella_vocal_VAD_tramos"]
    I --> CMP{"Comparar carpeta<br/>con Qdrant"}
    CMP -- "hash nuevo" --> N["Procesar archivo"]
    CMP -- "mismo nombre,<br/>contenido nuevo" --> U["Actualizado:<br/>borrar tramos viejos"]
    U --> N
    CMP -- "hash conocido,<br/>otro nombre" --> R["Renombrado:<br/>actualizar datos"]
    CMP -- "hash ausente<br/>en la carpeta" --> D["Eliminado:<br/>borrar sus tramos"]
    CMP -- "sin cambios" --> X["Omitir"]

    N --> C1["cargar_audio<br/>mono 16 kHz"]
    C1 --> C2["VAD configurado<br/>voz neta"]
    C2 --> C3{"¿Voz neta ≥ 3 s?"}
    C3 -- No --> ER["Error: referencia rechazada"]
    C3 -- Sí --> C4["Partir en tramos de 10 s<br/>sobrante menor a 5 s se une al anterior"]
    C4 --> C5["ECAPA-TDNN<br/>una huella por tramo"]
    C5 --> C6["Guardar tramos con vad en el payload"]

    C6 & R & D --> P["Recalcular personas afectadas:<br/>plantilla = promedio normalizado<br/>+ perfil acústico"]
    P --> Q["Guardar en<br/>huella_vocal_VAD_personas"]
    Q --> F(["Resumen: nuevos, actualizados,<br/>eliminados, renombrados, errores"])
```

**17.5 Registro web**

```text
flowchart TD
    A(["Pestaña Registrar voz"]) --> B["Nombre, origen opcional<br/>y consentimiento"]
    B --> G1["Grabación 1: habla libre ~10 s"]
    B --> G2["Grabación 2: otro tema ~10 s"]
    B --> G3["Grabación 3: nombre completo<br/>y contar del uno al diez"]
    G1 & G2 & G3 --> E["POST /api/registro"]
    E --> V{"Cada grabación:<br/>voz neta ≥ 3 s y<br/>saturación ≤ 1 %"}
    V -- "alguna no cumple" --> X["Error 400: indica<br/>qué grabación repetir"]
    V -- "todas cumplen" --> W["Guardar persona__web__fecha__n.wav<br/>+ persona__web__fecha.json"]
    W --> S["Sincronizar"]
    S --> C{"¿La persona<br/>quedó en el pool?"}
    C -- No --> X2["Error 400 con<br/>detalle por archivo"]
    C -- Sí --> OK(["Persona en el pool<br/>+ advertencias si la sincronización<br/>descartó algún archivo"])
```

**17.6 Eliminación de personas**

```text
flowchart TD
    A(["Eliminar en la pestaña Personas"]) --> H{"¿VF_CLAVE_BORRADO<br/>tiene 4 dígitos?"}
    H -- No --> N["Botones ocultos<br/>y aviso de configuración"]
    H -- Sí --> K["Escribir la clave"]
    K --> BL{"¿Bloqueado por<br/>5 intentos fallidos?"}
    BL -- Sí --> E1["403: espere 5 min"]
    BL -- No --> C{"¿Clave correcta?<br/>hmac.compare_digest"}
    C -- No --> E2["403: clave incorrecta<br/>y suma un intento"]
    C -- Sí --> D["Borrar WAV de la persona<br/>y JSON de consentimiento"]
    D --> S["Sincronizar: se borran<br/>sus tramos y su plantilla"]
    S --> F(["Persona eliminada<br/>sin posibilidad de deshacer"])
```

**17.7 Despliegue desde cero**

```text
flowchart TD
    A(["Equipo nuevo<br/>x86_64 o arm64"]) --> B{"¿Docker y usuario<br/>en el grupo docker?"}
    B -- No --> B1["Instalar Docker<br/>usermod -aG docker"] --> D
    B -- Sí --> D["Crear /home/user_ia/voice_fingerprint/<br/>codigo, referencias_wav, registros"]
    D --> E["tar xzf voice_fingerprint_v0.9.0.tar.gz -C codigo"]
    E --> F["Copiar WAV de referencia"]
    F --> G["Crear codigo/.env y configuracion.env<br/>QDRANT_URL, VF_VAD, VF_DISPOSITIVO, VF_CLAVE_BORRADO<br/>(GPU: COMPOSE_FILE con docker-compose.gpu.yml)"]
    G --> H["./construir_imagen.sh<br/>ÚNICO paso con internet"]
    H --> H1["Construye la imagen<br/>dependencias + modelos verificados"]
    H1 --> H2["Verifica con el contenedor SIN red<br/>en CPU y, si hay toolkit NVIDIA, en GPU"]
    H2 --> H3["Respalda la imagen en<br/>imagenes/*.tar.gz"]
    H3 --> I(["Desde aquí, sin internet"])
    I --> J["docker compose up -d"]
    J --> K["Primer arranque: sincroniza<br/>referencias hacia las colecciones del VAD"]
    K --> L["curl /api/salud"]
    L --> M{"Acceso"}
    M -- "mismo equipo" --> M1["http://localhost:8000"]
    M -- "desarrollo remoto" --> M2["ssh -L 8000:localhost:8000<br/>y http://localhost:8000"]
    M -- "producción" --> M3["nginx con certificados<br/>client_max_body_size 20m<br/>VF_PUERTO_HOST=127.0.0.1:8000"]
```

**17.8 Operación sin internet**

```text
flowchart TD
    A(["Cambio"]) --> B{"¿Qué cambió?"}
    B -- "frontend/" --> F["Recargar el navegador"]
    B -- "huella_vocal/ o servicio/" --> R["docker compose restart"]
    B -- "configuracion.env<br/>(VAD, CPU o GPU...)" --> U["docker compose up -d"]
    B -- "requirements.txt,<br/>restricciones.txt o modelos" --> I["Imagen nueva:<br/>./construir_imagen.sh<br/>(necesita internet)"]
    B -- "se borró la imagen" --> L["docker load -i imagenes/...tar.gz<br/>y docker compose up -d"]
    F & R & U & L --> OK(["Sigue sin internet"])
```

**17.9 Experimento Umbral**

```text
sequenceDiagram
    autonumber
    actor P as Persona
    participant N as Navegador
    participant A as API FastAPI
    participant U as Umbral
    participant H as umbral.jsonl

    P->>N: Pulsa "Empezar" y habla
    N->>A: POST /api/umbral/sesion {tasa}
    A->>U: abrir(): fija las plantillas del pool
    U-->>N: id, intervalo 250 ms, umbrales, VAD
    loop cada 250 ms mientras habla
        N->>A: POST /audio?procesar=1 (PCM 16 bits nuevo)
        A->>U: agregar()
        U->>U: todo el audio a 16 kHz, VAD, voz neta
        U->>U: huella ECAPA, 1:N contra las plantillas, decisión
        U-->>N: ms de voz neta, estado, top 3, margen
        N-->>P: Gráfica y cifras en vivo
    end
    P->>N: Pulsa "Detener" (o 30 s)
    N->>A: POST /audio (lo que faltaba)
    N->>A: POST /finalizar
    A->>U: finalizar()
    U->>U: VAD sobre todo el audio
    U->>U: Barrido preciso cada 50 ms<br/>alrededor de los dos cruces
    U->>H: una línea: VAD, persona, cruces, curva
    U-->>N: primer cruce, cruce estable, estado
    N-->>P: Resultado, marcas en la gráfica e historial
```

**17.10 Barrido preciso**

```text
flowchart TD
    S(["Finalizar"]) --> V["Voz neta final<br/>(VAD sobre todo el audio)"]
    V --> F{"¿Identificado al final?"}
    F -- No --> SI["estado: sin_identificar"]
    F -- Sí --> P1["Primer cruce: primer punto en vivo identificado<br/>y el punto anterior acotan la ventana"]
    P1 --> P2["Evaluar cada 50 ms dentro de la ventana<br/>el primero identificado es el primer cruce"]
    F -- Sí --> E1["Cruce estable: último punto en vivo que NO era<br/>la persona final y el siguiente acotan la ventana"]
    E1 --> E2["Desde el borde derecho hacia atrás cada 50 ms<br/>mientras siga identificada la persona final"]
    E2 --> C{"¿Hay ≥ 2 s de voz neta<br/>después del cruce estable?"}
    C -- Sí --> OK["estado: confirmado"]
    C -- No --> SC["estado: sin_confirmar"]
    P2 & E2 --> MIN["Si un cruce cae en el mínimo (250 ms)<br/>se muestra como ≤ 250 ms"]
```

---

## 18. Glosario

### Audio y señal

| Término | Definición |
|---|---|
| **Frecuencia de muestreo** | Cuántas muestras por segundo tiene el audio digital. El sistema trabaja a 16 kHz (16.000 muestras/s), suficiente para la voz; el navegador suele capturar a 48 kHz y el servidor remuestrea |
| **8 kHz (telefonía)** | Frecuencia de muestreo de la telefonía tradicional; corta los agudos por encima de 4 kHz. Pendiente para el contact center |
| **Mono / canal** | Una sola pista de audio. "Canal" también se usa para la cadena micrófono → procesamiento → codificación, que deja su huella en la señal |
| **WAV / PCM** | Formato de audio sin compresión; PCM es la representación de las muestras como números enteros |
| **Remuestreo** | Cambiar la frecuencia de muestreo de una señal (por ejemplo, de 48 a 16 kHz) |
| **RMS / dBFS** | RMS: energía promedio de la señal. dBFS: decibeles respecto al máximo digital (0 dBFS es el tope) |
| **Saturación (clipping)** | Cuando la señal supera el máximo y se recorta; deforma la voz. Se rechazan grabaciones con más de 1 % de muestras saturadas |
| **VAD (detección de actividad de voz)** | Algoritmo que separa los tramos con voz de los silencios y ruidos |
| **Voz neta** | La señal después de quitar los silencios con el VAD; es la que se mide en segundos |
| **Tramo** | Trozo de 10 s de voz neta de un archivo de referencia; cada tramo produce una huella |
| **Espectrograma** | Imagen del sonido: tiempo en horizontal, frecuencia en vertical, intensidad en color |
| **Escala mel** | Escala de frecuencias que imita la percepción humana: más detalle en los graves que en los agudos |
| **STFT** | Transformada de Fourier de tiempo corto: analiza la señal por ventanas pequeñas para obtener el espectrograma |
| **F0 (frecuencia fundamental / tono)** | Frecuencia de vibración de las cuerdas vocales; se percibe como la altura de la voz |
| **Formantes (F1–F4)** | Resonancias del tracto vocal que dan el timbre y distinguen las vocales |
| **Tracto vocal (VTL)** | Tubo de la laringe a los labios. Su longitud se estima por el espaciamiento entre formantes; tiende a ser mayor en hombres |
| **HNR** | Relación armónicos-ruido (dB): cuánta voz "limpia" hay frente a ruido de aire. Alto = voz clara |
| **Jitter** | Variación ciclo a ciclo del periodo de vibración (%); inestabilidad en el tono |
| **Shimmer** | Variación ciclo a ciclo de la amplitud (%); inestabilidad en la intensidad |
| **AGC, supresión de ruido, cancelación de eco** | Procesos automáticos del navegador para llamadas; se desactivan porque alteran la voz y la huella |
| **AudioWorklet** | Mecanismo del navegador para procesar audio en tiempo real en un hilo aparte; aquí captura las muestras |

### Modelos y aprendizaje automático
| **TEN VAD** | Modelo de detección de voz del proyecto TEN (Agora), de baja latencia, con ventanas de 16 ms; el otro VAD que se puede elegir con `VF_VAD` |
| **ONNX / onnxruntime** | Formato estándar para guardar modelos de aprendizaje automático y el motor que los ejecuta en CPU en cualquier arquitectura |
| **sherpa-onnx** | Librería de voz (Apache 2.0) que ejecuta modelos ONNX; aquí ejecuta TEN VAD en x86_64 y arm64 |
| **Revisión de un modelo** | Identificador exacto (commit) de una versión de un modelo en Hugging Face; fijarla garantiza descargar siempre los mismos archivos |

| Término | Definición |
|---|---|
| **Embedding / huella vocal** | Vector de números que resume las características de una voz; voces parecidas dan vectores parecidos |
| **ECAPA-TDNN** | Red neuronal para reconocer hablantes; produce la huella de 192 valores |
| **SpeechBrain** | Librería de PyTorch para audio y voz; provee el modelo ECAPA usado |
| **VoxCeleb** | Corpus de voces de celebridades usado para entrenar el modelo de hablantes |
| **Silero VAD** | Modelo ligero de detección de voz (PyTorch); uno de los dos VAD que se pueden elegir con `VF_VAD` |
| **Whisper** | Modelo de OpenAI de reconocimiento de voz (voz a texto); se usa la variante `base` |
| **faster-whisper / CTranslate2** | Implementación de Whisper sobre CTranslate2, un motor de inferencia optimizado para CPU |
| **Cuantización int8** | Representar los pesos del modelo con enteros de 8 bits: más rápido y con menos memoria, con pérdida mínima de precisión |
| **Marcas de tiempo por palabra** | Inicio y fin de cada palabra transcrita; permiten ubicar los dígitos en el espectrograma |
| **STT** | Speech-to-text: transcripción de voz a texto |
| **Inferencia** | Ejecutar un modelo ya entrenado sobre datos nuevos |
| **PCA** | Análisis de componentes principales: reduce los 192 valores a 2 para dibujar el mapa, conservando la mayor variación posible |
| **Normalización (L2)** | Escalar un vector para que su longitud sea 1; así el coseno equivale al producto punto |
| **Praat / parselmouth** | Praat es el programa de referencia en fonética; parselmouth lo expone en Python |

### Biometría y decisión
| **Primer cruce** | En la pestaña Umbral: los primeros milisegundos de voz neta con los que el sistema identificó a alguien |
| **Cruce estable** | En la pestaña Umbral: desde qué milisegundo el sistema identifica a la misma persona sin interrupción hasta el final de la sesión |
| **Sesión confirmada** | Sesión de Umbral con al menos 2 s de voz neta después del cruce estable |
| **Voz mínima de la huella** | Voz neta mínima para calcular una huella en la pestaña Umbral (250 ms desde la 0.8.2; 100 ms en la 0.8.1; 500 ms en la 0.8.0) |
| **Barrido preciso** | Recalcular la decisión cada 50 ms de voz neta alrededor de los cruces, al terminar una sesión de Umbral |

| Término | Definición |
|---|---|
| **Verificación 1:1** | Comprobar si la voz corresponde a una identidad declarada |
| **Identificación 1:N** | Buscar a quién de N personas registradas corresponde la voz (lo que hace el sistema) |
| **Conjunto abierto** | La identificación admite que la persona no esté registrada |
| **Pool** | El conjunto de personas registradas con sus referencias |
| **Plantilla** | Huella representativa de una persona: promedio normalizado de las huellas de sus tramos |
| **Similitud coseno / score** | Medida de parecido entre dos huellas, de −1 a 1; en la práctica, entre 0 y 1 para voces |
| **Umbral** | Valor de score que separa decisiones (0,65 alto, 0,50 bajo) |
| **Margen** | Diferencia entre el mejor score y el segundo; evita confundir a dos personas parecidas |
| **Zona gris** | Rango de scores donde no se decide y se pide repetir |
| **FAR / FRR** | Tasa de falsa aceptación (aceptar a un impostor) y de falso rechazo (rechazar a la persona legítima) |
| **EER** | Tasa de error igual: el punto donde FAR = FRR; resume la calidad del sistema |
| **Leave-one-out** | Evaluación que saca una muestra, la compara con el resto y repite con cada muestra |
| **Desajuste de canal** | Pérdida de similitud cuando la misma voz se graba con dispositivos o cadenas de audio distintas |
| **AS-norm** | Normalización adaptativa de scores: compara cada score con los de una cohorte de impostores para hacerlo más estable entre canales (pendiente) |
| **Cohorte** | Conjunto de voces de referencia que no son la persona evaluada, usado para normalizar |
| **Registro (enrollment)** | Proceso de grabar a una persona y crear su plantilla |
| **Prueba de vida (liveness)** | Comprobar que hay una persona hablando en vivo y no una grabación |
| **Desafío-respuesta** | Pedir algo impredecible (los dígitos) que solo se puede responder en el momento |
| **Ataque de repetición (replay)** | Reproducir una grabación de la víctima para suplantarla; es lo que bloquea la prueba de vida |
| **Clonación de voz / deepfake** | Voz sintética que imita a una persona; no se detecta en esta versión |
| **Distancia de Levenshtein** | Número mínimo de inserciones, borrados o cambios para pasar de una secuencia a otra; mide los errores en los dígitos |

### Infraestructura y software
| **Imagen del entorno** | La imagen Docker de la 0.8.0: sistema, dependencias de Python y modelos, sin el código del servicio |
| **Montaje en solo lectura** | Carpeta del equipo que el contenedor puede leer pero no modificar; así se monta el código |
| **Modo offline (HF_HUB_OFFLINE)** | Variable que prohíbe a las librerías de Hugging Face cualquier consulta a internet; solo usan archivos locales |
| **pull_policy: never** | Opción de Docker Compose que impide buscar la imagen en internet; si no está en el equipo, falla con un error claro |
| **docker save / docker load** | Guardar una imagen en un archivo .tar y volver a cargarla, sin internet |
| **--network none** | Arrancar un contenedor sin ninguna red; se usa para verificar que el entorno no necesita internet |
| **Restricciones (`restricciones.txt`)** | Lista de las versiones exactas de todas las dependencias, directas e indirectas, para que cada construcción instale lo mismo |
| **Hash sha256 / hash de git** | Huellas digitales de un archivo; si cambia un solo byte, cambian. Se usan para verificar los modelos descargados |
| **Cache-Control: no-cache** | Indicación al navegador de revalidar la página en cada carga, para ver de inmediato los cambios del frontend |

| Término | Definición |
|---|---|
| **Qdrant** | Base de datos vectorial: guarda las huellas y busca las más parecidas |
| **Colección / punto / payload** | En Qdrant: una colección agrupa puntos; cada punto es un vector con un ID y datos asociados (payload) |
| **SHA-256 / uuid5** | Hash del contenido de cada archivo (detecta cambios y renombres) e identificador determinístico derivado de él |
| **FastAPI / uvicorn** | Framework web de Python para la API y servidor que la ejecuta |
| **Docker / imagen / contenedor** | Empaquetado del servicio con todas sus dependencias; la imagen es la plantilla y el contenedor, la instancia en ejecución |
| **Docker Compose** | Herramienta para describir y arrancar el servicio con su configuración (`docker-compose.yml`) |
| **Construcción multietapa** | Dockerfile con una etapa de compilación y una final más liviana sin compilador |
| **Bind mount** | Carpeta del equipo montada dentro del contenedor; así los datos viven fuera de la imagen |
| **host.docker.internal / host-gateway** | Nombre con el que el contenedor llega a servicios del propio equipo anfitrión |
| **Healthcheck** | Comprobación periódica de que el servicio responde |
| **Túnel SSH** | Redirige un puerto local a uno remoto por SSH; permite usar `localhost` (y el micrófono) contra el servidor |
| **Proxy reverso (nginx)** | Servidor delante del servicio que atiende HTTPS con certificados y reenvía las peticiones |
| **arm64 / aarch64, x86_64** | Arquitecturas de procesador: ARM (DGX Spark) e Intel/AMD (PC de casa) |
| **Rueda (wheel)** | Paquete de Python precompilado para una arquitectura; si no existe, se compila desde el código fuente |
| **DGX Spark** | Equipo de NVIDIA con procesador ARM y GPU (GB10); con `VF_DISPOSITIVO=gpu`, ECAPA usa su GPU |
| **CUDA** | Plataforma de NVIDIA para cómputo en GPU; PyTorch y CTranslate2 la usan para correr modelos en la GPU |
| **NVIDIA Container Toolkit** | Componente del equipo que permite a los contenedores Docker usar la GPU y su controlador |
| **cuBLAS** | Librería de álgebra lineal de CUDA; CTranslate2 en x86_64 necesita la versión de CUDA 12 |
| **float16 / int8** | Precisión numérica de un modelo: float16 (media precisión) es lo usual en GPU; int8 (enteros de 8 bits) es lo más rápido en CPU |
| **COMPOSE_FILE** | Variable de Docker Compose que indica qué archivos combinar; se usa para sumar `docker-compose.gpu.yml` |
| **Plotly** | Librería de gráficos interactivos en el navegador |
| **psutil** | Librería de Python para medir CPU, memoria e hilos |
| **RSS** | Memoria física que ocupa un proceso; es la "RAM del servicio" |
| **Segundos de CPU** | Tiempo de procesador consumido sumando todos los hilos; si supera el tiempo real, se usó más de un núcleo |
| **Media / mediana / p90 / p95** | Media: promedio. Mediana: valor típico (la mitad está por debajo). p90 y p95: valores que solo se superan en el 10 % y el 5 % de los casos |
| **Bitácora (JSONL)** | Archivo con un objeto JSON por línea; aquí, una línea por validación |
| **GIL** | Candado global del intérprete de Python; las librerías de modelos lo sueltan, por eso la transcripción y la huella corren de verdad en paralelo |
