// Captura del micrófono como WAV (PCM 16 bits, mono), con nivel y segundos de voz en vivo.
// Se desactivan cancelación de eco, supresión de ruido y control de ganancia del navegador:
// alteran la voz y la huella debe calcularse sobre el sonido real.

const UMBRAL_MINIMO_VOZ = 0.008;   // RMS por debajo del cual nunca se cuenta como voz
const RETENCION_S = 0.2;           // tras un bloque con voz, los 200 ms siguientes también cuentan
                                   // (consonantes suaves y finales de sílaba, como hace el VAD del servidor)

export class Grabadora {
  constructor({ alActualizar, maxSegundos = 10 } = {}) {
    this.alActualizar = alActualizar || (() => {});
    this.maxSegundos = maxSegundos;
    this.grabando = false;      // recibiendo audio
    this.activa = false;        // desde que se pide el micrófono hasta detener o cancelar
  }

  async iniciar() {
    this.activa = true;
    this.cancelada = false;
    this.flujo = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false },
    });
    this._siCancelada();                      // se pudo cancelar mientras el navegador pedía permiso
    this.contexto = new AudioContext();
    await this.contexto.audioWorklet.addModule("procesador-grabacion.js");
    this._siCancelada();
    const fuente = this.contexto.createMediaStreamSource(this.flujo);
    this.nodo = new AudioWorkletNode(this.contexto, "captura");
    this.bloques = [];
    this.muestras = 0;
    this.segundosVoz = 0;
    this.ruido = null;          // estimación del ruido de fondo (primeros bloques)
    this.retencion = 0;
    this.nodo.port.onmessage = (e) => this._recibir(e.data);
    fuente.connect(this.nodo);
    this.grabando = true;
    this.tasa = this.contexto.sampleRate;
  }

  _siCancelada() {
    if (!this.cancelada) return;
    this._liberar();
    const error = new Error("Grabación cancelada");
    error.name = "GrabacionCancelada";
    throw error;
  }

  // Suelta el micrófono (se apaga el indicador del navegador) y el contexto de audio.
  _liberar() {
    if (this.flujo) this.flujo.getTracks().forEach((t) => t.stop());
    if (this.contexto && this.contexto.state !== "closed") this.contexto.close().catch(() => {});
  }

  _finalizar() {
    this.activa = false;
    this.grabando = false;
    if (this.alFinalizar) this.alFinalizar();
  }

  // Descarta lo grabado sin codificarlo ni enviarlo. Sirve también mientras se pide el permiso.
  cancelar() {
    if (!this.activa) return;
    this.cancelada = true;
    this.bloques = [];
    this.muestras = 0;
    this._liberar();
    this._finalizar();
  }

  _recibir(bloque) {
    if (!this.grabando) return;
    this.bloques.push(bloque);
    this.muestras += bloque.length;
    let suma = 0;
    for (let i = 0; i < bloque.length; i++) suma += bloque[i] * bloque[i];
    const rms = Math.sqrt(suma / bloque.length);
    if (this.ruido === null) this.ruido = rms;
    else if (rms < this.ruido) this.ruido = rms;                     // el mínimo observado
    else this.ruido = this.ruido * 0.999 + rms * 0.001;
    const duracion = bloque.length / this.tasa;
    if (rms > Math.max(UMBRAL_MINIMO_VOZ, this.ruido * 2.5)) {
      this.segundosVoz += duracion;
      this.retencion = RETENCION_S;
    } else if (this.retencion > 0) {
      this.segundosVoz += duracion;
      this.retencion -= duracion;
    }
    const segundos = this.muestras / this.tasa;
    this.alActualizar({ nivel: Math.min(1, rms * 6), segundos, segundosVoz: this.segundosVoz });
    if (segundos >= this.maxSegundos && this.alLimite) this.alLimite();
  }

  async detener() {
    this._finalizar();
    this.flujo.getTracks().forEach((t) => t.stop());
    await this.contexto.close();
    const total = new Float32Array(this.muestras);
    let desde = 0;
    for (const b of this.bloques) { total.set(b, desde); desde += b.length; }
    return { blob: codificarWav(total, this.tasa), segundos: this.muestras / this.tasa, segundosVoz: this.segundosVoz };
  }
}

function codificarWav(muestras, tasa) {
  const buffer = new ArrayBuffer(44 + muestras.length * 2);
  const v = new DataView(buffer);
  const texto = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  texto(0, "RIFF"); v.setUint32(4, 36 + muestras.length * 2, true); texto(8, "WAVE");
  texto(12, "fmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, tasa, true); v.setUint32(28, tasa * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  texto(36, "data"); v.setUint32(40, muestras.length * 2, true);
  for (let i = 0; i < muestras.length; i++) {
    const s = Math.max(-1, Math.min(1, muestras[i]));
    v.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}

// Medidor visual reutilizable: nivel, segundos de voz frente al mínimo y tiempo.
export function crearMedidor(contenedor, { minimoVoz, maxSegundos }) {
  contenedor.innerHTML = `
    <div class="medidor-nivel" aria-hidden="true"><span></span></div>
    <div class="medidor-voz" role="progressbar" aria-label="Segundos de voz captada"
         aria-valuemin="0" aria-valuemax="${maxSegundos}"><span></span><i style="left:${(minimoVoz / maxSegundos) * 100}%"></i></div>
    <div class="medidor-texto"><span class="voz"></span><span class="tiempo"></span></div>`;
  const nivel = contenedor.querySelector(".medidor-nivel span");
  const voz = contenedor.querySelector(".medidor-voz span");
  const barraVoz = contenedor.querySelector(".medidor-voz");
  const textoVoz = contenedor.querySelector(".voz");
  const textoTiempo = contenedor.querySelector(".tiempo");
  const f1 = (x) => x.toLocaleString("es-CO", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  const pintar = ({ nivel: n = 0, segundos = 0, segundosVoz = 0 }) => {
    nivel.style.width = `${n * 100}%`;
    voz.style.width = `${Math.min(1, segundosVoz / maxSegundos) * 100}%`;
    barraVoz.setAttribute("aria-valuenow", segundosVoz.toFixed(1));
    textoVoz.textContent = `Voz captada: ${f1(segundosVoz)} s (mínimo ${minimoVoz} s)`;
    textoTiempo.textContent = `${f1(segundos)} de ${maxSegundos} s`;
  };
  pintar({});
  return pintar;
}
