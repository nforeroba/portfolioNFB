#!/bin/bash
set -e

PORT="${PORT:-8009}"
SGLANG_OMNI_PORT="${SGLANG_OMNI_PORT:-8000}"
SGLANG_OMNI_MODEL="${SGLANG_OMNI_MODEL:-/app/checkpoints/s2-pro}"
SGLANG_OMNI_CONFIG="${SGLANG_OMNI_CONFIG:-/app/configs/s2pro_tts.yaml}"

echo "[entrypoint] Fish Audio S2-Pro TTS gRPC Service (SGLang-Omni)"

if [ -n "$CUDA_VISIBLE_DEVICES" ]; then
    echo "[entrypoint] GPU device(s): $CUDA_VISIBLE_DEVICES"
else
    echo "[entrypoint] CUDA_VISIBLE_DEVICES no definido, usando todas las GPU visibles"
fi

echo "[entrypoint] Diagnóstico de GPU..."
/opt/venv-omni/bin/sgl-omni check-gpu || echo "[entrypoint] check-gpu falló"

echo "[entrypoint] Iniciando sgl-omni serve en puerto interno ${SGLANG_OMNI_PORT}"
echo "[entrypoint] Modelo: ${SGLANG_OMNI_MODEL}"
echo "[entrypoint] Config: ${SGLANG_OMNI_CONFIG}"

: > /tmp/sglang_omni.log

/opt/venv-omni/bin/sgl-omni serve \
    --model-path "${SGLANG_OMNI_MODEL}" \
    --config "${SGLANG_OMNI_CONFIG}" \
    --port "${SGLANG_OMNI_PORT}" \
    > /tmp/sglang_omni.log 2>&1 &

SGLANG_OMNI_PID=$!
echo "[entrypoint] sgl-omni serve PID ${SGLANG_OMNI_PID}"

tail -n +1 -f /tmp/sglang_omni.log | sed 's/^/[sglang-omni] /' &
TAIL_PID=$!

cleanup() {
    echo "[entrypoint] Señal de cierre recibida"
    kill -TERM "$SGLANG_OMNI_PID" "$TAIL_PID" 2>/dev/null || true
    wait "$SGLANG_OMNI_PID" 2>/dev/null || true
    exit 0
}
trap cleanup SIGTERM SIGINT

sleep 5
if ! kill -0 "$SGLANG_OMNI_PID" 2>/dev/null; then
    echo "[entrypoint] sgl-omni serve murió tras arrancar"
    kill -TERM "$TAIL_PID" 2>/dev/null || true
    exit 1
fi

echo "[entrypoint] Iniciando wrapper gRPC en puerto ${PORT}"
export PYTHONPATH="/app"

/opt/venv-omni/bin/python /app/server.py \
    --port "${PORT}" \
    --config /app/config_tts.json &

SERVER_PID=$!

wait -n "$SGLANG_OMNI_PID" "$SERVER_PID"
EXIT_CODE=$?

echo "[entrypoint] Proceso terminado (exit code $EXIT_CODE), deteniendo el resto"
kill -TERM "$SGLANG_OMNI_PID" "$SERVER_PID" "$TAIL_PID" 2>/dev/null || true
wait 2>/dev/null || true

exit $EXIT_CODE
