"""Almacenamiento de huellas en Qdrant.

Dos colecciones (192 dimensiones, distancia coseno):

  <prefijo>_tramos    Un punto por tramo de voz de cada archivo de referencia.
                      El payload guarda la persona, el archivo y su hash, que es
                      lo que permite sincronizar con la carpeta.
  <prefijo>_personas  Un punto por persona con su plantilla (promedio de sus
                      tramos). Las validaciones buscan aquí.
"""

import uuid

from .config import DIM_HUELLA, MODELO_HUELLA, config_qdrant

_ESPACIO_IDS = uuid.UUID("6f1c2a52-0d3e-4c1e-9a43-6b2f6a3d9e11")


def id_tramo(hash_archivo, indice):
    return str(uuid.uuid5(_ESPACIO_IDS, f"tramo:{hash_archivo}:{indice}"))


def id_persona(persona_id):
    return str(uuid.uuid5(_ESPACIO_IDS, f"persona:{persona_id}"))


class Almacen:
    def __init__(self, url=None, api_key=None, prefijo=None):
        from qdrant_client import QdrantClient

        cfg = config_qdrant()
        url = url or cfg["url"]
        self.url = url
        if url == ":memory:":
            self.cliente = QdrantClient(location=":memory:")
        else:
            self.cliente = QdrantClient(url=url, api_key=api_key or cfg["api_key"], timeout=30)
        prefijo = prefijo or cfg["prefijo"]
        self.col_tramos = f"{prefijo}_tramos"
        self.col_personas = f"{prefijo}_personas"

    # -- estructura ---------------------------------------------------------

    def asegurar_colecciones(self):
        from qdrant_client import models

        for nombre, indices in ((self.col_tramos, ("persona_id", "hash_archivo")), (self.col_personas, ("persona_id",))):
            if self.cliente.collection_exists(nombre):
                continue
            self.cliente.create_collection(
                nombre, vectors_config=models.VectorParams(size=DIM_HUELLA, distance=models.Distance.COSINE)
            )
            for campo in indices:
                self.cliente.create_payload_index(nombre, campo, field_schema=models.PayloadSchemaType.KEYWORD)

    def borrar_colecciones(self):
        for nombre in (self.col_tramos, self.col_personas):
            if self.cliente.collection_exists(nombre):
                self.cliente.delete_collection(nombre)

    # -- utilidades -----------------------------------------------------------

    def _recorrer(self, coleccion, filtro=None, con_vectores=False):
        """Todos los puntos de una colección (paginando)."""
        siguiente = None
        while True:
            puntos, siguiente = self.cliente.scroll(
                coleccion, scroll_filter=filtro, limit=256, offset=siguiente,
                with_payload=True, with_vectors=con_vectores,
            )
            yield from puntos
            if siguiente is None:
                break

    @staticmethod
    def _filtro(campo, valor):
        from qdrant_client import models

        return models.Filter(must=[models.FieldCondition(key=campo, match=models.MatchValue(value=valor))])

    # -- tramos ---------------------------------------------------------------

    def inventario_archivos(self):
        """hash_archivo -> payload de uno de sus tramos (archivo, persona_id, ...)."""
        inventario = {}
        for punto in self._recorrer(self.col_tramos):
            inventario.setdefault(punto.payload["hash_archivo"], punto.payload)
        return inventario

    def guardar_tramos(self, hash_archivo, huellas, payload_archivo, segundos_tramos):
        from qdrant_client import models

        puntos = [
            models.PointStruct(
                id=id_tramo(hash_archivo, i),
                vector=[float(x) for x in huella],
                payload={**payload_archivo, "hash_archivo": hash_archivo, "indice_tramo": i,
                         "segundos": segundos_tramos[i], "modelo": MODELO_HUELLA},
            )
            for i, huella in enumerate(huellas)
        ]
        self.cliente.upsert(self.col_tramos, points=puntos, wait=True)

    def borrar_archivo(self, hash_archivo):
        from qdrant_client import models

        self.cliente.delete(
            self.col_tramos,
            points_selector=models.FilterSelector(filter=self._filtro("hash_archivo", hash_archivo)),
            wait=True,
        )

    def actualizar_archivo(self, hash_archivo, payload):
        self.cliente.set_payload(self.col_tramos, payload=payload, points=self._filtro("hash_archivo", hash_archivo), wait=True)

    def tramos_de_persona(self, persona_id):
        return list(self._recorrer(self.col_tramos, self._filtro("persona_id", persona_id), con_vectores=True))

    def todos_los_tramos(self):
        return list(self._recorrer(self.col_tramos, con_vectores=True))

    # -- personas -------------------------------------------------------------

    def guardar_persona(self, persona_id, plantilla, payload):
        from qdrant_client import models

        self.cliente.upsert(
            self.col_personas,
            points=[models.PointStruct(id=id_persona(persona_id), vector=[float(x) for x in plantilla],
                                       payload={**payload, "persona_id": persona_id, "modelo": MODELO_HUELLA})],
            wait=True,
        )

    def borrar_persona(self, persona_id):
        from qdrant_client import models

        self.cliente.delete(self.col_personas, points_selector=models.PointIdsList(points=[id_persona(persona_id)]), wait=True)

    def personas(self):
        return [p.payload for p in self._recorrer(self.col_personas)]

    def plantillas(self):
        return list(self._recorrer(self.col_personas, con_vectores=True))

    def plantilla_de(self, persona_id):
        """(vector, payload) de una persona, o None si no existe."""
        puntos = self.cliente.retrieve(self.col_personas, ids=[id_persona(persona_id)], with_vectors=True, with_payload=True)
        return (puntos[0].vector, puntos[0].payload) if puntos else None

    def buscar_personas(self, huella, k=3):
        """Las k personas más parecidas: lista de (score, payload), de mayor a menor."""
        respuesta = self.cliente.query_points(
            self.col_personas, query=[float(x) for x in huella], limit=k, with_payload=True
        )
        return [(float(p.score), p.payload) for p in respuesta.points]
