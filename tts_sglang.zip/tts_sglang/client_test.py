"""
Cliente de prueba para el servicio TTS gRPC (S2-Pro + SGLang-Omni).
Uso:
  # Modo unary (comportamiento original, compatible con el cliente actual)
  python3 client_test.py --text "Hola mundo" [--voice vanessa] [--output output.opus]

  # Modo streaming (nuevo RPC TTSStream)
  python3 client_test.py --text "Hola mundo" --stream [--voice vanessa] [--output output.opus]
"""

import argparse
import sys
import time

import grpc

import tts_service_pb2
import tts_service_pb2_grpc


def run_unary(stub, args):
    request = tts_service_pb2.ServeTTSRequest(
        text=args.text,
        reference_id=args.voice,
        temperature=args.temperature,
        top_p=args.top_p,
        top_k=args.top_k,
    )

    print(f"[cliente] Enviando request TTS (unary) ...")
    t0 = time.perf_counter()
    try:
        response = stub.TTS(request, timeout=args.timeout)
    except grpc.RpcError as e:
        print(f"[cliente] ❌ Error gRPC: {e.code()} — {e.details()}")
        sys.exit(1)
    elapsed = time.perf_counter() - t0

    audio_duration = response.audio_duration
    rtf = elapsed / audio_duration if audio_duration > 0 else 0.0

    with open(args.output, "wb") as f:
        f.write(response.audio_bytes)

    print(f"[cliente] ✅ Síntesis completada")
    print(f"[cliente] Duración audio  : {audio_duration:.3f}s")
    print(f"[cliente] Tiempo total    : {elapsed:.3f}s")
    print(f"[cliente] RTF             : {rtf:.4f}")
    print(f"[cliente] Tamaño opus     : {len(response.audio_bytes):,} bytes")
    print(f"[cliente] Audio guardado  : {args.output}")


def run_stream(stub, args):
    request = tts_service_pb2.ServeTTSRequest(
        text=args.text,
        reference_id=args.voice,
        temperature=args.temperature,
        top_p=args.top_p,
        top_k=args.top_k,
    )

    print(f"[cliente] Enviando request TTSStream ...")
    t0 = time.perf_counter()
    t_first_chunk = None
    chunks = []

    try:
        for i, response in enumerate(stub.TTSStream(request, timeout=args.timeout)):
            if t_first_chunk is None:
                t_first_chunk = time.perf_counter()
                ttfa = t_first_chunk - t0
                print(f"[cliente] Primer chunk recibido | time-to-first-audio={ttfa:.3f}s")
            chunks.append(response.audio_bytes)
            print(
                f"[cliente]   chunk #{i+1} | dur={response.audio_duration:.3f}s | "
                f"size={len(response.audio_bytes):,} bytes"
            )
    except grpc.RpcError as e:
        print(f"[cliente] ❌ Error gRPC: {e.code()} — {e.details()}")
        sys.exit(1)

    elapsed = time.perf_counter() - t0

    # Cada chunk es un Opus independiente — para reproducir/guardar como un
    # solo archivo reproducible, concatenamos los bytes crudos. Nota: esto
    # produce un archivo con múltiples streams Opus concatenados, que la
    # mayoría de reproductores manejan bien (igual que una concatenación de
    # archivos .ogg/.opus), pero no es un único "stream Opus" en el sentido
    # estricto del formato — si hace falta un solo stream Opus válido,
    # habría que remuxear con ffmpeg en vez de concatenar bytes crudos.
    with open(args.output, "wb") as f:
        for chunk in chunks:
            f.write(chunk)

    total_bytes = sum(len(c) for c in chunks)
    print(f"[cliente] ✅ Streaming completado")
    print(f"[cliente] Chunks recibidos: {len(chunks)}")
    print(f"[cliente] Tiempo total    : {elapsed:.3f}s")
    print(f"[cliente] Tamaño total    : {total_bytes:,} bytes")
    print(f"[cliente] Audio guardado  : {args.output}")


def main():
    parser = argparse.ArgumentParser(description="Cliente de prueba TTS gRPC (S2-Pro + SGLang-Omni)")
    parser.add_argument("--host", default="localhost", help="Host del servicio")
    parser.add_argument("--port", default="50051", help="Puerto del servicio")
    parser.add_argument("--text", required=True, help="Texto a sintetizar")
    parser.add_argument("--voice", default="", help="ID de voz (vacío = default del servidor)")
    parser.add_argument("--temperature", type=float, default=0.0, help="Temperatura (0 = default del servidor)")
    parser.add_argument("--top-p", type=float, default=0.0, help="Top-p (0 = default del servidor)")
    parser.add_argument("--top-k", type=int, default=0, help="Top-k (0 = default del servidor)")
    parser.add_argument("--stream", action="store_true", help="Usar TTSStream en vez de TTS unary")
    parser.add_argument("--timeout", type=float, default=180.0, help="Timeout en segundos")
    parser.add_argument("--output", default="output.opus", help="Archivo de salida")
    args = parser.parse_args()

    addr = f"{args.host}:{args.port}"
    print(f"[cliente] Conectando a {addr} ...")
    print(f"[cliente] Modo    : {'streaming (TTSStream)' if args.stream else 'unary (TTS)'}")

    channel = grpc.insecure_channel(addr)
    stub = tts_service_pb2_grpc.TTSServiceStub(channel)

    text_preview = args.text[:80] + "..." if len(args.text) > 80 else args.text
    print(f"[cliente] Texto  : {text_preview}")
    print(f"[cliente] Voz    : '{args.voice or '(default)'}'")
    print(f"[cliente] Salida : {args.output}")

    if args.stream:
        run_stream(stub, args)
    else:
        run_unary(stub, args)


if __name__ == "__main__":
    main()
