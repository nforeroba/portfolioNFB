import asyncio
import websockets
import json
import base64

async def test_tts():
    uri = "ws://localhost:8000/ws/tts"
    async with websockets.connect(uri) as websocket:
        await websocket.send(json.dumps({ "text": "Hola, esta es una prueba de voz sintetizada." }))
        response = await websocket.recv()
        data = json.loads(response)
        print("Métricas:", data.get("metricas"))
        audio_b64 = data.get("base64")
        if audio_b64:
            with open("respuesta.wav", "wb") as f:
                f.write(base64.b64decode(audio_b64))
            print("Audio guardado como respuesta.wav")

asyncio.run(test_tts())
