# -*- coding: utf-8 -*-
"""
Angie Paola Osorio Rivera
angie.osorio.R@tigo.com.co
"""
#Importar las librerias

import pandas as pd           
import os                     
import matplotlib.pyplot as plt 
import math
from datetime import datetime
import numpy as np            
from statsmodels.tsa.filters.hp_filter import hpfilter 
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_pacf
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.arima_process import ArmaProcess
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import pacf
from statsmodels.tsa.stattools import acf
from keras.models import Sequential
from keras.layers import Dense 
from keras.layers import LSTM
from keras.layers import Bidirectional
from keras.layers import Dropout
from keras.layers import Flatten
from keras.layers import ConvLSTM2D
from keras.layers import TimeDistributed
from keras.layers.convolutional import Conv1D
from keras.layers.convolutional import MaxPooling1D
from keras.callbacks import EarlyStopping
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
from statsmodels.tsa.api import ExponentialSmoothing
from tqdm import tqdm_notebook
from itertools import product
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import warnings
import seaborn as sns 
import datetime
import talib as ta
from sklearn.decomposition import PCA 
from pandas.plotting import lag_plot

# Ignorar las alertas

warnings.filterwarnings('ignore') 

# Entorno grafico

plt.style.use('ggplot')

#Definir el directorio de trabajo 

os.chdir('D:/Users/aosoriri/Documents/')

"""
Funcion para poder traducir el formato de tiempo (Año/Mes/Dia) a python.

Ejemplo: Tiempo('20201103')
"""
# Funcion para ajustar el tiempo

def Tiempo(x):
    x = str(x)
    y = '20'+x[6:]
    m = x[3:5]
    d = x[:2]
    t = y + '-' + m + '-' + d
    return(np.datetime64(t))

# Separar el conjunto de datos en muestras de n pasos

# split a univariate sequence into samples
def split_sequence(sequence, n_steps):
	X, y = list(), list()
	for i in range(len(sequence)):
		# find the end of this pattern
		end_ix = i + n_steps
		# check if we are beyond the sequence
		if end_ix > len(sequence)-1:
			break
		# gather input and output parts of the pattern
		seq_x, seq_y = sequence[i:end_ix], sequence[end_ix]
		X.append(seq_x)
		y.append(seq_y)
	return(np.array(X), np.array(y))



        
"""
Lectura de la base de datos en fomrato csv extraida de sql Developer
"""

# Lectura de la base de datos

df = pd.read_csv('DATA_TIGO_1.csv') 

"""
Extraer los datos reales de Gross Total en corcondancia con la tabla dinamica de excel
"""
L1 = []

for i in list(df["FECHA"].unique()):
    prueba_VN = df[df["FECHA"]==i]
    prueba1_VN = prueba_VN[prueba_VN["MOV"]=="GROSS"]
    prueba2_VN = prueba1_VN[prueba1_VN["AR_ST_GRP_NM"]=="VENTAS"]
    
   
    final_VN = prueba2_VN["USRS"].sum()
    L1.append(final_VN)
    
Real_VN = dict(zip(list(df["FECHA"].unique()),L1))

#DataFrame de los datos

df_Real_VN = pd.DataFrame(Real_VN.values(),index=Real_VN.keys(),columns=['Gross Total'])
df_Real_VN.index = list(map(Tiempo,df_Real_VN.index))
df_Real_VN.sort_index(inplace = True)

# Grafica de los datos

%matplotlib qt
df_Real_VN.plot()

# Separar los datos omitiendo las fechas de la pandemia


Inicio = np.datetime64("2020-03-01")
Fin = np.datetime64("2020-07-01")

if Inicio in df_Real_VN.index and Fin in df_Real_VN.index:

    # Indice de las fechas
    Idx_Inicio = list(df_Real_VN.index).index(Inicio)
    Idx_Fin = list(df_Real_VN.index).index(Fin)
    
    # Dataframes de los cortes
    df_Real_VN_inicio = df_Real_VN.iloc[:Idx_Inicio]
    df_Real_VN_fin = df_Real_VN.iloc[Idx_Fin:]
    
    # Datafame con el corte
    df_Real_VN_corte = pd.concat([df_Real_VN_inicio, df_Real_VN_fin])

# Grafica de los datos

%matplotlib qt

df_Real_VN_corte.plot()
plt.show()



"""
Partir el DataFrame en un conjunto de entrenamiento para ajustar los distintos modelos 
y en otro de prueba para validar las respectivas predicciones (Forecasting)
"""

#Partir conjunto de entramineto y prueba
#Fecha donde empieza el mes anterior

corte =  np.datetime64("2021-03-01")
Idx_corte = list(df_Real_VN_corte.index).index(corte)

train = df_Real_VN_corte[ :Idx_corte]
train = df_Real_VN_corte[list(df_Real_VN_corte.index).index(np.datetime64("2021-02-01")) :Idx_corte]

test = df_Real_VN_corte[Idx_corte: ]
test.sort_index(inplace = True)

#------------------------------------
#------------------------------------
#RED NEURONAL
#------------------------------------
#------------------------------------


#---------------------------------------------------------------------------------
"""
pred_days = 37
fecha_inicial = datetime.datetime.strptime(test.index[0].strftime('%Y-%m-%d'), '%Y-%m-%d')
test =test.append(pd.DataFrame([[None]]*pred_days,columns=test.columns),ignore_index=True)
Index_test = []
for i in range(0,len(test)):
    Index_test.append(fecha_inicial + datetime.timedelta(i))

test.index = Index_test
"""
#---------------------------------------------------------------------------------

n = int(input('neuronas = '))
# define input sequence
raw_seq = train['Gross Total']
# choose a number of time steps
n_steps = 1
# split into samples
X, y = split_sequence(raw_seq, n_steps)
# split into validation
X_test, y_test = split_sequence(test['Gross Total'], n_steps)
# reshape from [samples, timesteps] into [samples, timesteps, features]
n_features = 1
X = X.reshape((X.shape[0], X.shape[1], n_features))
# define model
model = Sequential()
model.add(Bidirectional(LSTM(n, activation='relu'), input_shape=(n_steps, n_features)))
model.add(Dropout(0.2))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mse')
# Epech selection

Earlystop = EarlyStopping(monitor = 'val_loss',patience = 15)


# fit model
model.fit(X, y, epochs = 1000,validation_split = 0.2,batch_size = 20, shuffle = False, callbacks = [Earlystop])

Init = train['Gross Total'][-n_steps:]

Data_test = list(Init) + list(test['Gross Total'][:-pred_days])
pred_LSTM = []

control = 0

for i in range(0,len(Data_test)-n_steps+1+2*pred_days):
    if control >= pred_days:
        Data_test.append(int(yhat))
    
    Aux = Data_test[i:i+n_steps]
    x_input = np.array(Aux)
    x_input = x_input.reshape((1, n_steps, n_features))
    yhat = model.predict(x_input, verbose=0)
    pred_LSTM.append(int(yhat))
    control += 1

pred_LSTM.pop(0)

test['Pred'] =  pred_LSTM   
test.plot()

print('RMSE =',math.sqrt(mean_squared_error(test['Gross Total'][:-pred_days], test['Pred'][:-pred_days])))
print('A_real = ',test['Gross Total'][:-pred_days].sum(),'A_ped = ',test['Pred'][:-pred_days].sum(),
      'Dif = ',test['Gross Total'][:-pred_days].sum()-test['Pred'][:-pred_days].sum())
print(list(test['Pred'][-(len(test)):]))

#test.to_excel('D:/Users/aosoriri/Documents/RED NEURONAL/Forecast-Prepago/FC-GROSS/Gross_Julio_02/Forecast.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------

"""
Extraer los datos reales de Disconnection Total en corcondancia con la tabla dinamica de excel
"""

L2=[]

for j in list(df["FECHA"].unique()):
    prueba_DIS = df[df["FECHA"]==j]
    prueba1_DIS = prueba_DIS[prueba_DIS["MOV"]=="DISCONNECTION"]
   
    final_DIS = prueba1_DIS["USRS"].sum()
    L2.append(final_DIS)
    
Real_DIS = dict(zip(list(df["FECHA"].unique()),L2))
  
#DataFrame de los datos
   
df_Real_DIS = pd.DataFrame(Real_DIS.values(),index=Real_DIS.keys(),columns=['Disconnection total'])
df_Real_DIS.index = list(map(Tiempo,df_Real_DIS.index))
df_Real_DIS.sort_index(inplace = True)

# Grafica de los datos

%matplotlib qt
df_Real_DIS.plot()

# Separar los datos omitiendo las fechas de la pandemia


Inicio = np.datetime64("2020-03-01")
Fin = np.datetime64("2020-07-01")

if Inicio in df_Real_DIS.index and Fin in df_Real_DIS.index:

    # Indice de las fechas
    Idx_Inicio = list(df_Real_DIS.index).index(Inicio)
    Idx_Fin = list(df_Real_DIS.index).index(Fin)
    
    # Dataframes de los cortes
    df_Real_DIS_inicio = df_Real_DIS.iloc[:Idx_Inicio]
    df_Real_DIS_fin = df_Real_DIS.iloc[Idx_Fin:]
    
    # Datafame con el corte
    df_Real_DIS_corte = pd.concat([df_Real_DIS_inicio, df_Real_DIS_fin])

# Grafica de los datos

%matplotlib qt

df_Real_DIS_corte.plot()
plt.show()

"""
Partir el DataFrame en un conjunto de entrenamiento para ajustar los distintos modelos 
y en otro de prueba para validar las respectivas predicciones (Forecasting)
"""

#Partir conjunto de entramineto y prueba

corte =  np.datetime64("2021-03-01")
Idx_corte = list(df_Real_DIS_corte.index).index(corte)

train = df_Real_DIS_corte[ :Idx_corte]
train = df_Real_DIS_corte[list(df_Real_DIS_corte.index).index(np.datetime64("2021-02-01")) :Idx_corte]

test = df_Real_DIS_corte[Idx_corte: ]
test.sort_index(inplace = True)

#------------------------------------
#------------------------------------
#RED NEURONAL
#------------------------------------
#------------------------------------


#---------------------------------------------------------------------------------
"""
pred_days = 37
fecha_inicial = datetime.datetime.strptime(test.index[0].strftime('%Y-%m-%d'), '%Y-%m-%d')
test =test.append(pd.DataFrame([[None]]*pred_days,columns=test.columns),ignore_index=True)
Index_test = []
for i in range(0,len(test)):
    Index_test.append(fecha_inicial + datetime.timedelta(i))

test.index = Index_test
"""
#---------------------------------------------------------------------------------

n = int(input('neuronas = '))
# define input sequence
raw_seq = train['Disconnection total']
# choose a number of time steps
n_steps = 1
# split into samples
X, y = split_sequence(raw_seq, n_steps)
# split into validation
X_test, y_test = split_sequence(test['Disconnection total'], n_steps)
# reshape from [samples, timesteps] into [samples, timesteps, features]
n_features = 1
X = X.reshape((X.shape[0], X.shape[1], n_features))
# define model
model = Sequential()
model.add(Bidirectional(LSTM(n, activation='relu'), input_shape=(n_steps, n_features)))
model.add(Dropout(0.2))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mse')
# Epech selection

Earlystop = EarlyStopping(monitor = 'val_loss',patience = 15)


# fit model
model.fit(X, y, epochs = 1000,validation_split = 0.2,batch_size = 20, shuffle = False, callbacks = [Earlystop])

Init = train['Disconnection total'][-n_steps:]

Data_test = list(Init) + list(test['Disconnection total'][:-pred_days])
longitud = len(Data_test)
pred_LSTM = []

control = 0

for i in range(0,len(Data_test)-n_steps+1+pred_days):
    if control >= min(pred_days,longitud):
        Data_test.append(int(yhat))
    
    Aux = Data_test[i:i+n_steps]
    x_input = np.array(Aux)
    x_input = x_input.reshape((1, n_steps, n_features))
    yhat = model.predict(x_input, verbose=0)-6328
    pred_LSTM.append(int(yhat))
    control += 1

pred_LSTM.pop(0)

test['Pred'] =  pred_LSTM   
test.plot()

print('RMSE =',math.sqrt(mean_squared_error(test['Disconnection total'][:-pred_days], test['Pred'][:-pred_days])))
print('A_real = ',test['Disconnection total'][:-pred_days].sum(),'A_ped = ',test['Pred'][:-pred_days].sum(),'Dif = ',test['Disconnection total'][:-pred_days].sum()-test['Pred'][:-pred_days].sum())
print(list(test['Pred'][-(len(test)):]))

#test.to_excel('D:/Users/aosoriri/Documents/RED NEURONAL/Forecast-Prepago/FC-DISCONNECTION/Disconnection_Julio_02/Forecast.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------

"""
Extraer los datos reales de Reconnection Total en corcondancia con la tabla dinamica de excel
"""
L3=[]

for j in list(df["FECHA"].unique()):
    prueba_REC = df[df["FECHA"]==j]
    prueba1_REC = prueba_REC[prueba_REC["MOV"]=="RECONNECTION"]
   
    final_REC = prueba1_REC["USRS"].sum()
    L3.append(final_REC)
    
Real_REC = dict(zip(list(df["FECHA"].unique()),L3))

#DataFrame de los datos
   
df_Real_REC = pd.DataFrame(Real_REC.values(),index=Real_REC.keys(),columns=['Reconnection total'])
df_Real_REC.index = list(map(Tiempo,df_Real_REC.index))
df_Real_REC.sort_index(inplace = True)

# Grafica de los datos

df_Real_REC.plot()

# Separar los datos omitiendo las fechas de la pandemia


Inicio = np.datetime64("2020-03-01")
Fin = np.datetime64("2020-07-01")

if Inicio in df_Real_REC.index and Fin in df_Real_REC.index:

    # Indice de las fechas
    Idx_Inicio = list(df_Real_REC.index).index(Inicio)
    Idx_Fin = list(df_Real_REC.index).index(Fin)
    
    # Dataframes de los cortes
    df_Real_REC_inicio = df_Real_REC.iloc[:Idx_Inicio]
    df_Real_REC_fin = df_Real_REC.iloc[Idx_Fin:]
    
    # Datafame con el corte
    df_Real_REC_corte = pd.concat([df_Real_REC_inicio, df_Real_REC_fin])

# Grafica de los datos

%matplotlib qt

df_Real_REC_corte.plot()
plt.show()


"""
Partir el DataFrame en un conjunto de entrenamiento para ajustar los distintos modelos 
y en otro de prueba para validar las respectivas predicciones (Forecasting)
"""

#Partir conjunto de entramineto y prueba

corte =  np.datetime64("2021-03-01")
Idx_corte = list(df_Real_REC_corte.index).index(corte)

train = df_Real_REC_corte[ :Idx_corte]
train = df_Real_REC_corte[list(df_Real_REC_corte.index).index(np.datetime64("2021-02-01")) :Idx_corte]

test = df_Real_REC_corte[Idx_corte: ]
test.sort_index(inplace = True)

#------------------------------------
#------------------------------------
#RED NEURONAL
#------------------------------------
#------------------------------------


#---------------------------------------------------------------------------------
"""
pred_days = 37
fecha_inicial = datetime.datetime.strptime(test.index[0].strftime('%Y-%m-%d'), '%Y-%m-%d')
test =test.append(pd.DataFrame([[None]]*pred_days,columns=test.columns),ignore_index=True)
Index_test = []
for i in range(0,len(test)):
    Index_test.append(fecha_inicial + datetime.timedelta(i))

test.index = Index_test
"""
#---------------------------------------------------------------------------------

n = int(input('neuronas = '))
# define input sequence
raw_seq = train['Reconnection total']
# choose a number of time steps
n_steps = 1
# split into samples
X, y = split_sequence(raw_seq, n_steps)
# split into validation
X_test, y_test = split_sequence(test['Reconnection total'], n_steps)
# reshape from [samples, timesteps] into [samples, timesteps, features]
n_features = 1
X = X.reshape((X.shape[0], X.shape[1], n_features))
# define model
model = Sequential()
model.add(Bidirectional(LSTM(n, activation='relu'), input_shape=(n_steps, n_features)))
model.add(Dropout(0.2))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mse')
# Epech selection

Earlystop = EarlyStopping(monitor = 'val_loss',patience = 15)


# fit model
model.fit(X, y, epochs = 1000,validation_split = 0.2,batch_size = 20, shuffle = False, callbacks = [Earlystop])

Init = train['Reconnection total'][-n_steps:]

Data_test = list(Init) + list(test['Reconnection total'][:-pred_days])
pred_LSTM = []

control = 0

for i in range(0,len(Data_test)-n_steps+1+2*pred_days):
    if control >= pred_days:
        Data_test.append(int(yhat))
    
    Aux = Data_test[i:i+n_steps]
    x_input = np.array(Aux)
    x_input = x_input.reshape((1, n_steps, n_features))
    yhat = model.predict(x_input, verbose=0) +1400
    pred_LSTM.append(int(yhat))
    control += 1

pred_LSTM.pop(0)

test['Pred'] =  pred_LSTM   
test.plot()

print('RMSE =',math.sqrt(mean_squared_error(test['Reconnection total'][:-pred_days], test['Pred'][:-pred_days])))
print('A_real = ',test['Reconnection total'][:-pred_days].sum(),'A_ped = ',test['Pred'][:-pred_days].sum(),'Dif = ',test['Reconnection total'][:-pred_days].sum()-test['Pred'][:-pred_days].sum())
print(list(test['Pred'][-(len(test)):]))

#test.to_excel('D:/Users/aosoriri/Documents/RED NEURONAL/Forecast-Prepago/FC-RECONECTION/Reconnection_Julio_02/Forecast.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------
