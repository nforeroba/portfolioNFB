"""Sincronización de la carpeta de referencias con Qdrant.

La carpeta es la fuente de verdad; Qdrant es un índice derivado. Se compara
el hash de contenido de cada WAV con los que ya están en Qdrant:

  nuevo        hash en la carpeta y no en Qdrant        -> se procesa y se carga
  eliminado    hash en Qdrant y no en la carpeta        -> se borran sus tramos
  actualizado  mismo nombre de archivo, hash distinto   -> (eliminado + nuevo)
  renombrado   mismo hash, otro nombre o persona        -> solo se corrigen sus datos
  sin cambios  todo igual                               -> no se toca

Al final se recalcula la plantilla de cada persona afectada.
"""

import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .audio import cargar_audio
from .config import SEGUNDOS_MIN_REFERENCIA, SR
from .huella import plantilla
from .perfil import perfil_acustico
from .referencias import hash_archivo, listar_referencias
from .vad import partir_en_tramos

CAMPOS_PERFIL = ["f0_mediana_hz", "f0_p5_hz", "f0_p95_hz", "hnr_db", "jitter_pct", "shimmer_pct",
                 "f1_hz", "f2_hz", "f3_hz", "f4_hz", "tracto_vocal_cm"]


def _payload_archivo(ref):
    return {
        "persona_id": ref.persona_id,
        "nombre": ref.nombre_mostrar,
        "origen": ref.origen,
        "fuente": ref.fuente,
        "sesion": ref.sesion,
        "consentimiento": ref.consentimiento,
        "archivo": ref.archivo.name,
    }


def procesar_archivo(ref, detector, extractor):
    """Audio -> voz neta -> tramos -> huellas + perfil del archivo."""
    senal, info = cargar_audio(ref.archivo)
    voz, _ = detector.voz_neta(senal)
    neta = len(voz) / SR
    if neta < SEGUNDOS_MIN_REFERENCIA:
        raise ValueError(f"solo {neta:.1f} s de voz neta (mínimo {SEGUNDOS_MIN_REFERENCIA:.0f} s)")
    tramos = partir_en_tramos(voz)
    huellas = np.stack([extractor.extraer(t) for t in tramos])
    try:
        perfil = perfil_acustico(voz)
    except Exception:  # noqa: BLE001 — el perfil es informativo, no bloquea
        perfil = None
    return huellas, [round(len(t) / SR, 2) for t in tramos], {
        "voz_neta_archivo_s": round(neta, 2),
        "perfil_archivo": perfil,
        "audio": info,
    }


def recalcular_persona(almacen, persona_id):
    """Plantilla, totales y perfil promedio de una persona a partir de sus tramos."""
    tramos = almacen.tramos_de_persona(persona_id)
    if not tramos:
        almacen.borrar_persona(persona_id)
        return False
    vectores = np.array([t.vector for t in tramos], dtype=np.float32)
    por_archivo = {}
    for t in tramos:
        por_archivo.setdefault(t.payload["hash_archivo"], t.payload)
    archivos = sorted(por_archivo.values(), key=lambda p: (p["fuente"] != "web", p["archivo"]))
    base = archivos[0]   # los registros web traen nombre con tildes y consentimiento

    perfil = {}
    for campo in CAMPOS_PERFIL:
        pares = [(p["voz_neta_archivo_s"], p["perfil_archivo"][campo]) for p in archivos
                 if p.get("perfil_archivo") and p["perfil_archivo"].get(campo) is not None]
        if pares:
            perfil[campo] = round(sum(w * v for w, v in pares) / sum(w for w, _ in pares), 2)

    almacen.guardar_persona(persona_id, plantilla(vectores), {
        "nombre": base["nombre"],
        "origen": base["origen"],
        "fuente": base["fuente"],
        "consentimiento": base.get("consentimiento"),
        "archivos": sorted(p["archivo"] for p in archivos),
        "tramos": len(tramos),
        "voz_neta_s": round(sum(p["voz_neta_archivo_s"] for p in archivos), 1),
        "perfil": perfil,
        "actualizado_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    })
    return True


def sincronizar(dir_referencias, almacen, detector, extractor, progreso=None):
    """
    Deja Qdrant igual a la carpeta. `progreso(hechos, total, archivo)` se llama
    por cada archivo procesado, para mostrar el avance en la interfaz.
    """
    inicio = time.perf_counter()
    almacen.asegurar_colecciones()
    resumen = {"nuevos": [], "actualizados": [], "eliminados": [], "renombrados": [], "errores": [],
               "duplicados": [], "sin_cambios": 0}

    # 1. Estado de la carpeta y de Qdrant
    en_carpeta = {}
    for ref in listar_referencias(dir_referencias):
        h = hash_archivo(ref.archivo)
        if h in en_carpeta:
            resumen["duplicados"].append(f"{ref.archivo.name} (igual a {en_carpeta[h].archivo.name})")
            continue
        en_carpeta[h] = ref
    en_qdrant = almacen.inventario_archivos()
    nombres_previos = {p["archivo"]: h for h, p in en_qdrant.items()}
    afectadas = set()

    # 2. Eliminados (incluye la versión vieja de los actualizados)
    for h, payload in en_qdrant.items():
        if h not in en_carpeta:
            almacen.borrar_archivo(h)
            afectadas.add(payload["persona_id"])
            if payload["archivo"] not in {r.archivo.name for r in en_carpeta.values()}:
                resumen["eliminados"].append(payload["archivo"])

    # 3. Renombrados: mismo contenido, datos distintos
    for h, ref in en_carpeta.items():
        if h in en_qdrant:
            nuevo = _payload_archivo(ref)
            viejo = {k: en_qdrant[h].get(k) for k in nuevo}
            if nuevo != viejo:
                almacen.actualizar_archivo(h, nuevo)
                afectadas.update({viejo["persona_id"], nuevo["persona_id"]})
                resumen["renombrados"].append(f"{viejo['archivo']} -> {ref.archivo.name}")
            else:
                resumen["sin_cambios"] += 1

    # 4. Nuevos y actualizados
    pendientes = [(h, ref) for h, ref in en_carpeta.items() if h not in en_qdrant]
    for n, (h, ref) in enumerate(pendientes, start=1):
        try:
            huellas, segundos, extra = procesar_archivo(ref, detector, extractor)
            almacen.guardar_tramos(h, huellas, {**_payload_archivo(ref), **extra,
                                                "procesado_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")},
                                   segundos)
            afectadas.add(ref.persona_id)
            clave = "actualizados" if ref.archivo.name in nombres_previos else "nuevos"
            resumen[clave].append(ref.archivo.name)
        except Exception as exc:  # noqa: BLE001 — un archivo malo no detiene la sincronización
            resumen["errores"].append({"archivo": ref.archivo.name, "error": str(exc)})
        if progreso:
            progreso(n, len(pendientes), ref.archivo.name)

    # 5. Plantillas de las personas afectadas
    for persona_id in sorted(afectadas):
        recalcular_persona(almacen, persona_id)

    resumen["personas_recalculadas"] = len(afectadas)
    resumen["personas_total"] = len(almacen.personas())
    resumen["duracion_s"] = round(time.perf_counter() - inicio, 2)
    return resumen
