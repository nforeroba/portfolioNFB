// Gráficos de la página: espectrograma y mapa con Plotly (incluido en vendor/), huellas en canvas.
/* global Plotly */

const FUENTE = { family: '"Public Sans", system-ui, sans-serif', size: 12, color: "#1c2329" };
const TINTA_2 = "#57606a";
const REJILLA = "#e4e7ea";

Plotly.register({
  moduleType: "locale",
  name: "es",
  dictionary: {
    "Zoom in": "Acercar", "Zoom out": "Alejar", "Reset axes": "Restablecer vista", "Autoscale": "Ajustar",
    "Pan": "Desplazar", "Zoom": "Zoom", "Download plot as a png": "Descargar como imagen",
    "Download plot as a PNG": "Descargar como imagen", "Double-click to zoom back out": "Doble clic para alejar",
  },
  format: { decimal: ",", thousands: "." },
});

const CONFIG = {
  locale: "es", responsive: true, displaylogo: false, scrollZoom: true,
  modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d", "toggleSpikelines", "hoverClosestCartesian", "hoverCompareCartesian"],
  toImageButtonOptions: { format: "png", scale: 2 },
};

const fmt = (n, d = 2) => Number(n).toLocaleString("es-CO", { minimumFractionDigits: d, maximumFractionDigits: d });
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// ---------------------------------------------------------------------------
// Espectrograma de la muestra
// ---------------------------------------------------------------------------

const MAGMA = [[0, "#000004"], [0.13, "#1c1044"], [0.25, "#4f127b"], [0.38, "#812581"], [0.5, "#b5367a"],
  [0.63, "#e55064"], [0.75, "#fb8761"], [0.88, "#fec287"], [1, "#fcfdbf"]];

export function dibujarEspectrograma(div, datos, { pedidos = null, oidos = null } = {}) {
  if (!datos) { div.innerHTML = `<p class="vacio">No hay suficiente voz para dibujar el espectrograma.</p>`; return; }
  const trazos = [{
    type: "heatmap", x: datos.tiempos_s, y: datos.frecuencias_hz, z: datos.db,
    colorscale: MAGMA, zmin: -80, zmax: 0,
    colorbar: { title: { text: "Nivel (dB)", side: "right" }, thickness: 12, len: 0.9, tickfont: { size: 11 } },
    hovertemplate: "%{x:.2f} s · %{y:.0f} Hz<br>%{z} dB<extra></extra>",
  }];
  if (datos.f0) {
    const base = { type: "scatter", mode: "lines", x: datos.f0.tiempos_s, y: datos.f0.f0_hz, connectgaps: false };
    trazos.push({ ...base, line: { color: "rgba(0,0,0,.55)", width: 5 }, hoverinfo: "skip", showlegend: false });
    trazos.push({ ...base, name: "Tono (F0)", line: { color: "#ffffff", width: 2 }, showlegend: false,
      hovertemplate: "Tono: %{y:.0f} Hz<extra></extra>" });
  }
  // Marcas de los dígitos: una franja por dígito, con el número arriba.
  const alineados = pedidos && oidos && oidos.length === pedidos.length;
  const shapes = [], annotations = [];
  (datos.digitos || []).forEach((m, i) => {
    const color = !alineados ? "#cfd6dc" : (m.digito === pedidos[i] ? "#7fd39b" : "#ff8a80");
    shapes.push({ type: "rect", xref: "x", yref: "paper", x0: m.inicio, x1: m.fin, y0: 0, y1: 1,
      fillcolor: "rgba(255,255,255,.07)", line: { color: "rgba(255,255,255,.35)", width: 1, dash: "dot" } });
    annotations.push({ x: (m.inicio + m.fin) / 2, y: 1.0, xref: "x", yref: "paper", yanchor: "bottom",
      text: `<b>${m.digito}</b>`, showarrow: false, font: { size: 15, color: "#1c2329" },
      bgcolor: color, borderpad: 3 });
  });
  const layout = {
    font: FUENTE, height: 360, margin: { l: 64, r: 16, t: 34, b: 46 },
    paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "#000004",
    xaxis: { title: { text: "Tiempo (s)" }, showgrid: false, zeroline: false, range: [0, datos.duracion_s] },
    yaxis: { title: { text: "Frecuencia" }, type: "log", range: [Math.log10(datos.frecuencias_hz[0]), Math.log10(8000)], showgrid: false,
      tickvals: [100, 200, 500, 1000, 2000, 4000, 8000],
      ticktext: ["100 Hz", "200 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz"] },
    shapes, annotations, separators: ",.", hoverlabel: { font: FUENTE, bgcolor: "#ffffff" },
  };
  div.style.height = `${layout.height}px`;
  Plotly.react(div, trazos, layout, { ...CONFIG, scrollZoom: false, modeBarButtonsToRemove: [...CONFIG.modeBarButtonsToRemove, "zoomIn2d", "zoomOut2d"] });
}

// ---------------------------------------------------------------------------
// Mapa 2D (PCA) de las voces
// ---------------------------------------------------------------------------

// Escala divergente por tono mediano: azul = grave, gris = ~160 Hz, rojo = agudo.
const ESCALA_TONO = [[0, "#1f5fae"], [0.25, "#7ea6d8"], [0.5, "#e6e5e1"], [0.75, "#e39a90"], [1, "#b8322a"]];
const TONO_MIN = 80, TONO_MAX = 260;

export function dibujarMapa(div, mapa, { muestra = null, similitudes = null, destacados = [], todosLosNombres = false, alto = 560 } = {}) {
  if (!mapa || !mapa.personas || mapa.personas.length === 0) {
    Plotly.purge(div);
    div.innerHTML = `<p class="vacio">Todavía no hay voces registradas para dibujar el mapa.</p>`;
    return;
  }
  const porId = Object.fromEntries(mapa.personas.map((p) => [p.persona_id, p]));
  const tono = (p) => (p && p.f0_mediana_hz != null ? p.f0_mediana_hz : null);

  // Líneas de cada tramo a la huella promedio de su persona
  const lx = [], ly = [];
  for (const t of mapa.tramos) {
    const c = porId[t.persona_id];
    if (c) { lx.push(t.x, c.x, null); ly.push(t.y, c.y, null); }
  }
  const lineas = { type: "scatter", mode: "lines", x: lx, y: ly, line: { color: "#d5dade", width: 1 },
    hoverinfo: "skip", showlegend: false };

  const tramos = {
    type: "scatter", mode: "markers", x: mapa.tramos.map((t) => t.x), y: mapa.tramos.map((t) => t.y),
    marker: { size: 6, opacity: 0.55, color: mapa.tramos.map((t) => tono(porId[t.persona_id]) ?? 160),
      colorscale: ESCALA_TONO, cmin: TONO_MIN, cmax: TONO_MAX, line: { width: 0 } },
    text: mapa.tramos.map((t) => esc(porId[t.persona_id] ? porId[t.persona_id].nombre : t.persona_id)),
    hovertemplate: "%{text}: tramo de voz<extra></extra>", showlegend: false,
  };

  const textoHover = (p) => {
    const lineasHover = [`<b>${esc(p.nombre)}</b>`];
    if (p.origen) lineasHover.push(esc(p.origen));
    if (tono(p) != null) lineasHover.push(`Tono mediano: ${fmt(tono(p), 0)} Hz`);
    if (p.tramos) lineasHover.push(`Tramos de voz: ${p.tramos}`);
    if (similitudes && similitudes[p.persona_id] != null) lineasHover.push(`Similitud con la muestra: ${fmt(similitudes[p.persona_id], 2)}`);
    return lineasHover.join("<br>");
  };
  const conNombre = (p) => todosLosNombres || destacados.includes(p.persona_id);
  const posiciones = ubicarEtiquetas(div, mapa, conNombre, destacados, muestra);
  const personas = {
    type: "scatter", mode: "markers+text", x: mapa.personas.map((p) => p.x), y: mapa.personas.map((p) => p.y),
    text: mapa.personas.map((p) => (conNombre(p) ? esc(p.nombre) : "")),
    textposition: posiciones, textfont: { size: 12, color: "#1c2329" },
    hovertext: mapa.personas.map(textoHover), hovertemplate: "%{hovertext}<extra></extra>",
    marker: {
      size: mapa.personas.map((p) => (destacados.includes(p.persona_id) ? 15 : 11)),
      color: mapa.personas.map((p) => tono(p) ?? 160), colorscale: ESCALA_TONO, cmin: TONO_MIN, cmax: TONO_MAX,
      line: { color: mapa.personas.map((p) => (destacados[0] === p.persona_id ? "#1c2329" : "#ffffff")),
        width: mapa.personas.map((p) => (destacados[0] === p.persona_id ? 2.5 : 1.5)) },
      colorbar: { title: { text: "Tono mediano (Hz)", side: "right" }, thickness: 12, len: 0.85,
        tickvals: [100, 130, 160, 190, 220, 250], tickfont: { size: 11 } },
    },
    showlegend: false,
  };
  const trazos = [lineas, tramos, personas];

  if (muestra) {
    const vecinos = destacados.map((id) => porId[id]).filter(Boolean);
    const vx = [], vy = [];
    vecinos.forEach((p) => { vx.push(muestra.x, p.x, null); vy.push(muestra.y, p.y, null); });
    trazos.splice(1, 0, { type: "scatter", mode: "lines", x: vx, y: vy, hoverinfo: "skip", showlegend: false,
      line: { color: "#1c2329", width: 1.2, dash: "dot" } });
    trazos.push({
      type: "scatter", mode: "markers+text", x: [muestra.x], y: [muestra.y], text: ["<b>Muestra</b>"],
      textposition: "bottom center", textfont: { size: 13, color: "#1c2329" },
      marker: { symbol: "star", size: 24, color: "#1c2329", line: { color: "#ffffff", width: 2 } },
      hovertemplate: "<b>La muestra</b><extra></extra>", showlegend: false,
    });
  }

  const v = mapa.varianza_pct || [0, 0];
  const layout = {
    font: FUENTE, height: alto, margin: { l: 56, r: 16, t: 16, b: 52 },
    paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "#ffffff", dragmode: "pan", separators: ",.",
    xaxis: { title: { text: `Componente principal 1 (${fmt(v[0], 1)} % de la variación)`, font: { size: 12, color: TINTA_2 } },
      gridcolor: REJILLA, zeroline: false, showticklabels: false, constrain: "range" },
    yaxis: { title: { text: `Componente principal 2 (${fmt(v[1], 1)} %)`, font: { size: 12, color: TINTA_2 } },
      gridcolor: REJILLA, zeroline: false, showticklabels: false, scaleanchor: "x", scaleratio: 1, constrain: "range" },
    hoverlabel: { font: FUENTE, bgcolor: "#ffffff", bordercolor: "#d3d8dd" },
  };
  if (!div._fullLayout) div.innerHTML = "";   // quita el aviso de "sin voces", nunca un gráfico ya dibujado
  // Alto fijo en el contenedor: en modo "responsive" Plotly vuelve a medir el
  // contenedor al hacer zoom, y sin alto propio el gráfico se encogía.
  div.style.height = `${alto}px`;
  Plotly.react(div, trazos, layout, CONFIG);
}

// Elige para cada nombre la posición (arriba, abajo, a un lado) que menos se
// cruza con los nombres ya ubicados y con los puntos. Es una estimación en
// píxeles a partir del tamaño del contenedor; basta para que no se encimen.
const POSICIONES = [
  ["top center", 0, -1], ["bottom center", 0, 1], ["middle right", 1, 0], ["middle left", -1, 0],
  ["top right", 1, -1], ["top left", -1, -1], ["bottom right", 1, 1], ["bottom left", -1, 1],
];
function ubicarEtiquetas(div, mapa, conNombre, destacados, muestra) {
  const puntos = mapa.personas.map((p) => [p.x, p.y]).concat(mapa.tramos.map((t) => [t.x, t.y]));
  if (muestra) puntos.push([muestra.x, muestra.y]);
  const xs = puntos.map((q) => q[0]), ys = puntos.map((q) => q[1]);
  const anchoPx = Math.max((div.clientWidth || 800) - 160, 200), altoPx = 460;
  const escala = Math.min(anchoPx / ((Math.max(...xs) - Math.min(...xs)) || 1), altoPx / ((Math.max(...ys) - Math.min(...ys)) || 1)) * 0.9;
  const px = (x, y) => [x * escala, -y * escala];
  const ocupados = mapa.personas.map((p) => { const [cx, cy] = px(p.x, p.y); return [cx - 7, cy - 7, cx + 7, cy + 7]; });
  if (muestra) { const [cx, cy] = px(muestra.x, muestra.y); ocupados.push([cx - 12, cy - 12, cx + 12, cy + 30]); }
  const cruce = (a, b) => Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));
  const orden = mapa.personas.map((p, i) => i)
    .sort((a, b) => (destacados.includes(mapa.personas[b].persona_id) ? 1 : 0) - (destacados.includes(mapa.personas[a].persona_id) ? 1 : 0));
  const resultado = mapa.personas.map(() => "top center");
  for (const i of orden) {
    const p = mapa.personas[i];
    if (!conNombre(p)) continue;
    const [cx, cy] = px(p.x, p.y);
    const w = 7 * String(p.nombre).length + 4, h = 16, sep = 9;
    let mejor = null;
    for (const [nombre, dx, dy] of POSICIONES) {
      const x0 = dx === 0 ? cx - w / 2 : dx > 0 ? cx + sep : cx - sep - w;
      const y0 = dy === 0 ? cy - h / 2 : dy > 0 ? cy + sep : cy - sep - h;
      const caja = [x0, y0, x0 + w, y0 + h];
      const choque = ocupados.reduce((s, o) => s + cruce(caja, o), 0);
      if (!mejor || choque < mejor.choque) mejor = { nombre, caja, choque };
      if (choque === 0) break;
    }
    resultado[i] = mejor.nombre;
    ocupados.push(mejor.caja);
  }
  return resultado;
}

// ---------------------------------------------------------------------------
// Huellas como código de barras + aporte de cada posición a la similitud
// ---------------------------------------------------------------------------

const AZUL = [42, 120, 214], NARANJA = [235, 104, 52], NEUTRO = [236, 239, 241];
const mezcla = (a, b, t) => a.map((x, i) => Math.round(x + (b[i] - x) * t));

function prepararCanvas(canvas) {
  const ancho = canvas.clientWidth || 600, alto = canvas.clientHeight || 60;
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.round(ancho * ratio);
  canvas.height = Math.round(alto * ratio);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.clearRect(0, 0, ancho, alto);
  return { ctx, ancho, alto };
}

function barras(canvas, vector, escala) {
  const { ctx, ancho, alto } = prepararCanvas(canvas);
  if (!vector) return;
  const paso = ancho / vector.length;
  vector.forEach((v, i) => {
    const [r, g, b] = mezcla(NEUTRO, v >= 0 ? AZUL : NARANJA, Math.min(1, Math.abs(v) / escala));
    ctx.fillStyle = `rgb(${r},${g},${b})`;
    ctx.fillRect(i * paso, 0, Math.max(paso - (paso > 3 ? 1 : 0), 1), alto);
  });
}

function aportes(canvas, valores) {
  const { ctx, ancho, alto } = prepararCanvas(canvas);
  const paso = ancho / valores.length, medio = alto / 2;
  const maximo = Math.max(1e-9, ...valores.map(Math.abs));
  ctx.fillStyle = "#c9cfd4";
  ctx.fillRect(0, medio - 0.5, ancho, 1);
  valores.forEach((v, i) => {
    const h = (Math.abs(v) / maximo) * (medio - 2);
    ctx.fillStyle = v >= 0 ? "#284b63" : "#a3abb3";
    ctx.fillRect(i * paso, v >= 0 ? medio - h : medio, Math.max(paso - (paso > 3 ? 1 : 0), 1), h);
  });
}

export function crearHuellas(contenedor) {
  const lienzos = [...contenedor.querySelectorAll("canvas")];
  const cursor = contenedor.querySelector(".huellas-cursor");
  const globo = contenedor.querySelector(".huellas-globo");
  let estado = null;

  function pintar() {
    if (!estado) return;
    const [cMuestra, cCandidato, cAporte] = lienzos;
    barras(cMuestra, estado.muestra, estado.escala);
    barras(cCandidato, estado.candidato, estado.escala);
    if (estado.aporte) aportes(cAporte, estado.aporte); else prepararCanvas(cAporte);
  }

  function mover(evento) {
    if (!estado) return;
    const marco = lienzos[0].getBoundingClientRect();
    const x = evento.clientX - marco.left;
    if (x < 0 || x > marco.width) { ocultar(); return; }
    const i = Math.min(estado.muestra.length - 1, Math.floor((x / marco.width) * estado.muestra.length));
    const base = contenedor.getBoundingClientRect();
    cursor.style.left = `${marco.left - base.left + ((i + 0.5) / estado.muestra.length) * marco.width}px`;
    cursor.hidden = false;
    const filas = [`<b>Posición ${i + 1} de ${estado.muestra.length}</b>`, `Muestra: ${fmt(estado.muestra[i], 3)}`];
    if (estado.candidato) {
      filas.push(`${esc(estado.nombreCandidato)}: ${fmt(estado.candidato[i], 3)}`);
      const a = estado.aporte[i];
      filas.push(`Aporte a la similitud: ${a >= 0 ? "+" : "−"}${fmt(Math.abs(a), 4)}`);
    }
    globo.innerHTML = filas.join("<br>");
    globo.hidden = false;
    const izquierda = Math.min(evento.clientX - base.left + 14, base.width - globo.offsetWidth - 4);
    globo.style.left = `${Math.max(4, izquierda)}px`;
    globo.style.top = `${evento.clientY - base.top + 14}px`;
  }
  function ocultar() { cursor.hidden = true; globo.hidden = true; }
  contenedor.addEventListener("mousemove", mover);
  contenedor.addEventListener("mouseleave", ocultar);
  window.addEventListener("resize", pintar);

  return function actualizar(muestra, candidato, nombreCandidato) {
    let aporte = null, similitud = null;
    if (candidato) {
      const na = Math.hypot(...muestra), nb = Math.hypot(...candidato);
      aporte = muestra.map((v, i) => (v * candidato[i]) / (na * nb));
      similitud = aporte.reduce((s, v) => s + v, 0);
    }
    const escala = Math.max(1e-6, ...[...muestra, ...(candidato || [])].map(Math.abs)) * 0.8;
    estado = { muestra, candidato, nombreCandidato, aporte, escala };
    requestAnimationFrame(pintar);
    return similitud;
  };
}

// ---------------------------------------------------------------------------
// Tiempos por paso (línea de tiempo) y recursos en vivo
// ---------------------------------------------------------------------------

const COLOR_PRINCIPAL = "#284b63", COLOR_PARALELO = "#c47a2c", COLOR_MAQUINA = "#a3abb3";

// Duración legible: milisegundos por debajo de 1 s, segundos por encima.
export function fmtDuracion(s) {
  if (s === null || s === undefined) return "—";
  if (s < 0.001) return "< 1 ms";
  if (s < 1) return `${Math.round(s * 1000).toLocaleString("es-CO")} ms`;
  return `${fmt(s, 2)} s`;
}

export function dibujarLineaTiempo(div, ultima, nombres) {
  if (!ultima || !ultima.pasos || !ultima.pasos.length) {
    Plotly.purge(div);
    div.style.height = "";
    div.innerHTML = `<p class="vacio">Todavía no hay validaciones. Haga una en la pestaña Validar identidad y vuelva aquí.</p>`;
    return;
  }
  const pasos = [...ultima.pasos].sort((a, b) => a.inicio_s - b.inicio_s || (a.carril === "paralelo") - (b.carril === "paralelo"));
  const etiqueta = (p) => nombres[p.paso] || p.paso;
  const total = ultima.total_s || Math.max(...pasos.map((p) => p.inicio_s + p.duracion_s));
  const carriles = [["principal", "Hilo principal", COLOR_PRINCIPAL], ["paralelo", "En paralelo", COLOR_PARALELO]];
  const trazos = carriles.map(([carril, nombre, color]) => {
    const de = pasos.filter((p) => p.carril === carril);
    return {
      type: "bar", orientation: "h", name: nombre, showlegend: de.length > 0,
      y: de.map(etiqueta), x: de.map((p) => Math.max(p.duracion_s, total / 800)), base: de.map((p) => p.inicio_s),
      marker: { color }, width: 0.62,
      text: de.map((p) => fmtDuracion(p.duracion_s)), textposition: "outside", cliponaxis: false,
      textfont: { size: 11, color: "#1c2329" },
      customdata: de.map((p) => [fmtDuracion(p.inicio_s), fmtDuracion(p.duracion_s), fmt(100 * p.duracion_s / total, 1)]),
      hovertemplate: "<b>%{y}</b><br>Empieza en %{customdata[0]}<br>Dura %{customdata[1]} (%{customdata[2]} % del total)<extra></extra>",
    };
  });
  const layout = {
    font: FUENTE, height: 64 + 30 * pasos.length, margin: { l: div.clientWidth < 600 ? 120 : 230, r: 70, t: 8, b: 44 },
    paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "#ffffff", barmode: "overlay", separators: ",.",
    xaxis: { title: { text: "Segundos desde que llega el audio", font: { size: 12, color: TINTA_2 } },
      range: [0, total * 1.12], gridcolor: REJILLA, zeroline: false, ticksuffix: " s" },
    yaxis: { type: "category", categoryorder: "array", categoryarray: pasos.map(etiqueta), autorange: "reversed",
      tickfont: { size: div.clientWidth < 600 ? 10 : 12 }, automargin: true },
    legend: { orientation: "h", x: 0, y: 1, yanchor: "bottom", font: { size: 12 } },
    shapes: [{ type: "line", xref: "x", yref: "paper", x0: total, x1: total, y0: 0, y1: 1, line: { color: "#1c2329", width: 1, dash: "dot" } }],
    annotations: [{ xref: "x", yref: "paper", x: total, y: 1, yanchor: "bottom", showarrow: false,
      text: `Total ${fmtDuracion(total)}`, font: { size: 12, color: "#1c2329" } }],
    hoverlabel: { font: FUENTE, bgcolor: "#ffffff", bordercolor: "#d3d8dd" },
  };
  layout.margin.t = 30;
  if (!div._fullLayout) div.innerHTML = "";
  div.style.height = `${layout.height}px`;
  Plotly.react(div, trazos, layout, { ...CONFIG, scrollZoom: false, displayModeBar: false });
}

export function dibujarRecursos(divCpu, divRam, historia) {
  if (!historia || !historia.length) return;
  const t = historia.map((m) => new Date(m.t * 1000));
  const base = (titulo, sufijo) => ({
    font: FUENTE, height: 260, margin: { l: 56, r: 12, t: 34, b: 36 },
    paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "#ffffff", separators: ",.",
    title: { text: titulo, x: 0, xanchor: "left", font: { size: 13 } },
    xaxis: { type: "date", gridcolor: REJILLA, tickformat: "%H:%M:%S", zeroline: false, nticks: 6, ticks: "outside", ticklen: 6, tickcolor: "#ffffff" },
    yaxis: { gridcolor: REJILLA, zeroline: false, ticksuffix: sufijo, rangemode: "tozero" },
    legend: { orientation: "h", x: 1, xanchor: "right", y: 1.02, yanchor: "bottom", font: { size: 11 } },
    hovermode: "x unified", hoverlabel: { font: FUENTE, bgcolor: "#ffffff", bordercolor: "#d3d8dd" },
  });
  const linea = (nombre, y, color, formato) => ({ type: "scatter", mode: "lines", name: nombre, x: t, y,
    line: { color, width: 2 }, hovertemplate: `${nombre}: %{y:${formato}}<extra></extra>` });
  const cpu = base("CPU", " %");
  cpu.yaxis.range = [0, 100];
  const conf = { ...CONFIG, scrollZoom: false, displayModeBar: false };
  divCpu.style.height = divRam.style.height = "260px";
  Plotly.react(divCpu, [
    linea("Máquina", historia.map((m) => m.cpu_maquina_pct), COLOR_MAQUINA, ".1f"),
    linea("Servicio", historia.map((m) => m.cpu_servicio_pct), COLOR_PRINCIPAL, ".1f"),
  ], cpu, conf);
  const totalGb = historia[historia.length - 1].ram_maquina_total_mb / 1024;
  const ram = base(`RAM (de ${fmt(totalGb, 0)} GB)`, " GB");
  ram.yaxis.range = [0, totalGb];
  Plotly.react(divRam, [
    linea("Máquina", historia.map((m) => m.ram_maquina_usada_mb / 1024), COLOR_MAQUINA, ".1f"),
    linea("Servicio", historia.map((m) => m.ram_servicio_mb / 1024), COLOR_PRINCIPAL, ".2f"),
  ], ram, conf);
}
