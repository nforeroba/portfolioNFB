"""
Estrategia de chunking fijo.

Corta el texto ciegamente cada N tokens, sin mirar separadores
naturales ni estructura del contenido. No es la estrategia que se
espera que gane en calidad -- existe como punto de comparacion/control
frente al chunking recursivo, para poder medir empiricamente si la
complejidad adicional de respetar separadores realmente aporta algo
sobre este corpus especifico.

Usa tiktoken (cl100k_base) para el conteo/corte de tokens, igual que
el chunking recursivo.
"""

import tiktoken

from rag_api.chunking.base import ChunkGenerado, EstrategiaChunkingBase

_ENCODING = tiktoken.get_encoding("cl100k_base")


class ChunkingFijo(EstrategiaChunkingBase):
    def chunkear(
        self,
        texto: str,
        tamano_tokens: int,
        overlap_tokens: int,
        lenguaje_codigo: str | None = None,
        fuente: str | None = None,
    ) -> list[ChunkGenerado]:
        tokens = _ENCODING.encode(texto)

        if not tokens:
            return []

        paso = max(tamano_tokens - overlap_tokens, 1)

        fragmentos: list[str] = []
        inicio = 0
        while inicio < len(tokens):
            fin = inicio + tamano_tokens
            fragmento_tokens = tokens[inicio:fin]
            fragmento_texto = _ENCODING.decode(fragmento_tokens)
            fragmentos.append(fragmento_texto)
            inicio += paso

        return [ChunkGenerado(texto=fragmento) for fragmento in fragmentos if fragmento.strip()]
