"""Perfil acústico interpretable con Praat (parselmouth).

Sirve para EXPLICAR una comparación, no para decidirla. Jitter y shimmer en
habla continua salen más altos que las normas clínicas (medidas con vocales
sostenidas): compárense solo entre muestras, no contra esas normas.
"""

import numpy as np

from .config import SR

PISO_F0 = 75
TECHO_F0 = 500
VELOCIDAD_SONIDO_CM_S = 35000


def perfil_acustico(voz):
    import parselmouth
    from parselmouth.praat import call

    if len(voz) < SR:
        raise ValueError("Se necesita al menos 1 s de voz para el perfil acústico.")

    sonido = parselmouth.Sound(np.asarray(voz, dtype=np.float64), sampling_frequency=SR)

    tono = sonido.to_pitch(time_step=0.01, pitch_floor=PISO_F0, pitch_ceiling=TECHO_F0)
    f0_cuadros = tono.selected_array["frequency"]
    f0 = f0_cuadros[f0_cuadros > 0]
    if f0.size == 0:
        raise ValueError("No se detectaron cuadros sonoros.")

    armonicidad = sonido.to_harmonicity_cc(time_step=0.01, minimum_pitch=PISO_F0)
    hnr = armonicidad.values[armonicidad.values != -200]

    pulsos = call(sonido, "To PointProcess (periodic, cc)", PISO_F0, TECHO_F0)
    jitter = call(pulsos, "Get jitter (local)", 0, 0, 0.0001, 0.02, 1.3)
    shimmer = call([sonido, pulsos], "Get shimmer (local)", 0, 0, 0.0001, 0.02, 1.3, 1.6)

    # Techo de formantes recomendado por Praat según el registro de la voz.
    mediana_f0 = float(np.median(f0))
    techo_formantes = 5500 if mediana_f0 > 165 else 5000
    formantes = sonido.to_formant_burg(
        time_step=0.01, max_number_of_formants=5, maximum_formant=techo_formantes
    )
    valores = {k: [] for k in ("F1", "F2", "F3", "F4")}
    for i, valor in enumerate(f0_cuadros):
        if valor <= 0:
            continue
        t = tono.get_time_from_frame_number(i + 1)
        for n, clave in enumerate(valores, start=1):
            v = formantes.get_value_at_time(n, t)
            if not np.isnan(v):
                valores[clave].append(v)
    medianas = {k: round(float(np.median(v)), 1) if v else None for k, v in valores.items()}

    # Longitud del tracto vocal (modelo de tubo uniforme): L = c / (2·ΔF).
    longitud_tracto = None
    if all(medianas.values()):
        dispersion = (medianas["F4"] - medianas["F1"]) / 3
        longitud_tracto = round(VELOCIDAD_SONIDO_CM_S / (2 * dispersion), 2)

    return {
        "f0_mediana_hz": round(mediana_f0, 1),
        "f0_p5_hz": round(float(np.percentile(f0, 5)), 1),
        "f0_p95_hz": round(float(np.percentile(f0, 95)), 1),
        "hnr_db": round(float(np.mean(hnr)), 2) if hnr.size else None,
        "jitter_pct": round(jitter * 100, 3),
        "shimmer_pct": round(shimmer * 100, 3),
        "f1_hz": medianas["F1"],
        "f2_hz": medianas["F2"],
        "f3_hz": medianas["F3"],
        "f4_hz": medianas["F4"],
        "tracto_vocal_cm": longitud_tracto,
    }


def trayectoria_tono(voz, segundos=10.0, paso=0.01):
    """Tono (F0) en el tiempo, para dibujarlo sobre el espectrograma. None donde no hay voz sonora."""
    import parselmouth

    voz = np.asarray(voz, dtype=np.float64)[: int(segundos * SR)]
    if len(voz) < SR // 4:
        return None
    tono = parselmouth.Sound(voz, sampling_frequency=SR).to_pitch(
        time_step=paso, pitch_floor=PISO_F0, pitch_ceiling=TECHO_F0
    )
    f0 = tono.selected_array["frequency"]
    return {
        "tiempos_s": [round(float(t), 3) for t in tono.xs()],
        "f0_hz": [round(float(v), 1) if v > 0 else None for v in f0],
    }
