#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import json
import logging
import traceback
import re
import pymupdf4llm
import fitz  # PyMuPDF
import requests
import base64
import io
from PIL import Image
import multiprocessing
from datetime import datetime
from pathlib import Path
from functools import partial

class PDFImageProcessor:
    """
    Clase para procesar archivos PDF e imágenes y convertirlos a formato Markdown.
    Mantiene un registro de archivos procesados para evitar duplicados.
    Procesa solo archivos que contienen palabras clave específicas en su nombre.
    Incorpora fallback a procesamiento VLM para PDFs problemáticos.
    """
    
    # Lista de palabras clave para filtrar archivos PDF
    KEYWORDS = [
        'solicitud', 'solisitud', 'solicitud credito', 'solicitud de credito',
        'solicitud financiera', 'solicitud servicios financieros',
        'solicitud de servicios financieros', 'solicitud prestamo',
        'solicitud de prestamo', 'solic', 'sol credito', 'sol de credito',
        'SOLICITUD', 'SOL', 'nos interesa conocerlo', 'SOLCREDITO', 'SF'
    ]
    
    # Formatos de imagen soportados
    SUPPORTED_IMAGE_FORMATS = ['tiff', 'tif', 'jpg', 'jpeg', 'png', 'bmp', 'gif']
    
    # Tiempo límite para procesar un archivo (en segundos)
    PDF_PROCESSING_TIMEOUT = 300  # 5 minutos para el procesamiento completo
    PDF_EXTRACTION_TIMEOUT = 10   # 10 segundos para extracción directa antes de fallback
    
    # URL del endpoint Ollama
    OLLAMA_ENDPOINT = None
    OLLAMA_MODEL = None
    
    def __init__(self, input_dir, output_dir, log_dir=None, ollama_endpoint=None, ollama_model=None, extraction_timeout=10):
        """
        Inicializa el procesador.
        
        Args:
            input_dir (str): Directorio de entrada para buscar archivos.
            output_dir (str): Directorio de salida para guardar archivos Markdown.
            log_dir (str, optional): Directorio para archivos de registro.
            ollama_endpoint (str, optional): URL del endpoint de Ollama.
            ollama_model (str, optional): Modelo de visión a utilizar.
            extraction_timeout (int, optional): Tiempo máximo para extracción directa.
        """
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        
        # Configurar directorio de logs
        if log_dir is None:
            self.log_dir = Path.cwd() / "logs"
        else:
            self.log_dir = Path(log_dir)
            
        # Configurar Ollama
        self.OLLAMA_ENDPOINT = ollama_endpoint
        self.OLLAMA_MODEL = ollama_model
        
        # Configurar timeout para extracción directa
        self.PDF_EXTRACTION_TIMEOUT = extraction_timeout
            
        # Crear directorios si no existen
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Archivo para registro de procesamiento
        self.processed_file = self.log_dir / "processed_files.json"
        self.processed_records = self._load_processed_records()
        
        # Configurar logging
        self._setup_logging()
        
    def _setup_logging(self):
        """Configura el sistema de logging"""
        log_file = self.log_dir / f"processor_{datetime.now().strftime('%Y%m%d')}.log"
        
        # Configurar handler para archivo
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        
        # Configurar handler para consola
        console_handler = logging.StreamHandler()
        
        # Configurar formato
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Configurar logger
        self.logger = logging.getLogger("PDFImageProcessor")
        self.logger.setLevel(logging.INFO)
        
        # Eliminar handlers anteriores si existen
        if self.logger.handlers:
            self.logger.handlers.clear()
            
        # Agregar handlers
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        self.logger.info(f"Iniciando procesador. Entrada: {self.input_dir}, Salida: {self.output_dir}")
        if self.OLLAMA_ENDPOINT:
            self.logger.info(f"Configurado endpoint Ollama: {self.OLLAMA_ENDPOINT}, Modelo: {self.OLLAMA_MODEL}")
        self.logger.info(f"Timeout para extracción directa: {self.PDF_EXTRACTION_TIMEOUT} segundos")
    
    def _load_processed_records(self):
        """
        Carga el registro de archivos procesados.
        
        Returns:
            dict: Registro de archivos procesados con su estado
        """
        if self.processed_file.exists():
            try:
                with open(self.processed_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {"processed": [], "failed": []}
        return {"processed": [], "failed": []}
    
    def _save_processed_records(self):
        """Guarda el registro de archivos procesados"""
        with open(self.processed_file, 'w', encoding='utf-8') as f:
            json.dump(self.processed_records, f, indent=2, ensure_ascii=False)
    
    def _is_already_processed(self, file_path):
        """
        Verifica si un archivo ya ha sido procesado.
        
        Args:
            file_path (Path): Ruta al archivo
            
        Returns:
            bool: True si ya se procesó, False en caso contrario
        """
        rel_path = str(file_path.relative_to(self.input_dir))
        return rel_path in self.processed_records["processed"] or rel_path in self.processed_records["failed"]
    
    def _record_processed_file(self, file_path, success=True, error_msg=None, method=None):
        """
        Registra un archivo como procesado.
        
        Args:
            file_path (Path): Ruta al archivo
            success (bool): Si el procesamiento fue exitoso
            error_msg (str, optional): Mensaje de error en caso de fallo
            method (str, optional): Método utilizado para procesar el archivo
        """
        rel_path = str(file_path.relative_to(self.input_dir))
        
        if success:
            if rel_path not in self.processed_records["processed"]:
                self.processed_records["processed"].append(rel_path)
                # También registrar el método utilizado si se proporciona
                if "methods" not in self.processed_records:
                    self.processed_records["methods"] = {}
                if method:
                    self.processed_records["methods"][rel_path] = method
        else:
            if rel_path not in self.processed_records["failed"]:
                self.processed_records["failed"].append(rel_path)
                # Registrar el error si se proporciona
                if "errors" not in self.processed_records:
                    self.processed_records["errors"] = {}
                if error_msg:
                    self.processed_records["errors"][rel_path] = error_msg
                
        self._save_processed_records()
    
    def is_keyword_in_filename(self, filename):
        """
        Verifica si alguna de las palabras clave está presente en el nombre del archivo.
        
        Args:
            filename (str): Nombre del archivo a verificar
            
        Returns:
            bool: True si alguna palabra clave está presente, False en caso contrario
        """
        filename_lower = filename.lower()
        return any(keyword.lower() in filename_lower for keyword in self.KEYWORDS)
        
    def find_files_to_process(self):
        """
        Busca archivos PDF e imágenes en el directorio de entrada y subdirectorios
        que contengan alguna de las palabras clave especificadas en su nombre.
        
        Returns:
            tuple: (pdf_files, image_files) Listas de rutas a archivos encontrados que cumplen con los criterios
        """
        # Buscar archivos PDF
        pdf_pattern = "**/*.pdf"
        all_pdf_files = list(self.input_dir.glob(pdf_pattern))
        
        # Buscar archivos de imagen en formatos soportados
        all_image_files = []
        for img_format in self.SUPPORTED_IMAGE_FORMATS:
            img_pattern = f"**/*.{img_format}"
            all_image_files.extend(list(self.input_dir.glob(img_pattern)))
            # También buscar versiones en mayúsculas
            img_pattern_upper = f"**/*.{img_format.upper()}"
            all_image_files.extend(list(self.input_dir.glob(img_pattern_upper)))
        
        self.logger.info(f"Se encontraron {len(all_pdf_files)} archivos PDF y {len(all_image_files)} imágenes en total")
        
        # Filtrar por palabras clave en el nombre
        filtered_pdfs = []
        filtered_images = []
        
        for pdf_file in all_pdf_files:
            if self.is_keyword_in_filename(pdf_file.name):
                filtered_pdfs.append(pdf_file)
                
        for image_file in all_image_files:
            if self.is_keyword_in_filename(image_file.name):
                filtered_images.append(image_file)
                
        self.logger.info(f"De los cuales {len(filtered_pdfs)} PDFs y {len(filtered_images)} imágenes contienen palabras clave para procesar")
        return filtered_pdfs, filtered_images
    
    def has_extractable_text(self, pdf_path, page_num=0):
        """
        Verifica si un PDF tiene texto extraíble en una página específica.
        
        Args:
            pdf_path (Path): Ruta al archivo PDF
            page_num (int): Número de página a verificar (base 0)
            
        Returns:
            tuple: (bool, str) True si tiene texto extraíble, y el texto extraído
        """
        try:
            doc = fitz.open(str(pdf_path))
            if page_num >= len(doc):
                doc.close()
                return False, ""
                
            page = doc.load_page(page_num)
            text = page.get_text()
            doc.close()
            
            # Verificar si el texto tiene contenido significativo
            # 1. Longitud mínima
            if len(text.strip()) < 50:
                return False, text
                
            # 2. Contiene caracteres alfanuméricos (no solo símbolos o espacios)
            if not re.search(r'[a-zA-Z0-9]', text):
                return False, text
                
            # 3. Proporción razonable de caracteres alfanuméricos
            alpha_ratio = sum(c.isalnum() for c in text) / max(len(text), 1)
            if alpha_ratio < 0.3:  # Menos del 30% son caracteres alfanuméricos
                return False, text
            
            return True, text
        except Exception as e:
            self.logger.warning(f"Error al verificar texto extraíble: {str(e)}")
            return False, ""
    
    def _convert_pdf_to_markdown_direct(self, pdf_path_str):
        """
        Función para convertir directamente un PDF a Markdown usando pymupdf4llm.
        Esta función se ejecuta con límite de tiempo.
        
        Args:
            pdf_path_str (str): Ruta al archivo PDF como string
            
        Returns:
            str: Contenido markdown
        """
        return pymupdf4llm.to_markdown(pdf_path_str)
    
    def _convert_pdf_to_image(self, pdf_path, page_num=0):
        """
        Convierte una página de PDF a imagen.
        
        Args:
            pdf_path (str): Ruta al archivo PDF
            page_num (int): Número de página (base 0)
            
        Returns:
            bytes: Datos de la imagen en formato PNG
        """
        try:
            # Abrir el PDF con PyMuPDF
            doc = fitz.open(pdf_path)
            
            # Verificar si el número de página es válido
            if page_num < 0 or page_num >= len(doc):
                doc.close()
                return None
            
            # Cargar la página especificada
            page = doc.load_page(page_num)
            
            # Renderizar la página como imagen con alta resolución
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))  # Escala 2x para mejor calidad
            
            # Convertir a bytes de imagen
            img_bytes = pix.tobytes("png")
            
            # Limpiar recursos
            doc.close()
            
            return img_bytes
        except Exception as e:
            self.logger.error(f"Error al convertir PDF a imagen: {str(e)}")
            return None
    
    def _read_image_file(self, image_path, page=0):
        """
        Lee un archivo de imagen y lo convierte a bytes.
        Maneja formatos multipágina como TIFF.
        
        Args:
            image_path (str): Ruta al archivo de imagen
            page (int): Número de página para imágenes multipágina (base 0)
            
        Returns:
            bytes: Datos de la imagen en formato PNG
        """
        try:
            # Abrir la imagen con PIL
            with Image.open(image_path) as img:
                # Manejar imágenes multipágina (como TIFF)
                if hasattr(img, 'n_frames') and img.n_frames > 1:
                    # Si es multipágina y la página solicitada existe
                    if page < img.n_frames:
                        img.seek(page)
                    else:
                        self.logger.warning(f"Página {page} no existe en {image_path}. Usando primera página.")
                        img.seek(0)
                
                # Convertir a RGB si es necesario (para formatos como CMYK)
                if img.mode not in ('RGB', 'L'):
                    img = img.convert('RGB')
                
                # Guardar como PNG en un buffer de memoria
                buffer = io.BytesIO()
                img.save(buffer, format="PNG")
                
                return buffer.getvalue()
        except Exception as e:
            self.logger.error(f"Error al leer archivo de imagen {image_path}: {str(e)}")
            return None
            
    def _count_tiff_pages(self, image_path):
        """
        Cuenta el número de páginas en un archivo TIFF.
        
        Args:
            image_path (str): Ruta al archivo TIFF
            
        Returns:
            int: Número de páginas, 1 si no es multipágina o hay error
        """
        try:
            with Image.open(image_path) as img:
                if hasattr(img, 'n_frames'):
                    return img.n_frames
                return 1
        except Exception as e:
            self.logger.error(f"Error al contar páginas de TIFF {image_path}: {str(e)}")
            return 1
    
    def _extract_text_from_image_ollama(self, image_bytes):
        """
        Extrae texto de una imagen usando el servicio de Ollama.
        
        Args:
            image_bytes (bytes): Datos de la imagen
            
        Returns:
            tuple: (text, error_message)
        """
        if not self.OLLAMA_ENDPOINT or not self.OLLAMA_MODEL:
            return None, "No se ha configurado el endpoint de Ollama"
            
        try:
            # Convertir la imagen a base64
            base64_image = base64.b64encode(image_bytes).decode('utf-8')
            
            # Preparar el prompt para extracción de texto
            prompt = ("Eres un experto en extracción y transcripción de texto a partir de PDFs "
                      "e imágenes. Extrae y transcribe con exactitud todo el texto visible en "
                      "esta imagen. El documento está en ESPAÑOL, por lo que debes proporcionar "
                      "ÚNICAMENTE el texto extraído en español. Mantén el formato markdown para "
                      "preservar la estructura del documento original. NO agregues ningún tipo de "
                      "comentario, interpretación, parafraseo, traducción, análisis, explicación o "
                      "contenido adicional. Transcribe EXACTAMENTE lo que ves, sin modificar el "
                      "contenido original. Si hay texto que no estás seguro, indica [ilegible] en "
                      "su lugar, pero trata de transcribir todo lo posible.")
            
            # Preparar el payload para la API de Ollama
            payload = {
                "model": self.OLLAMA_MODEL,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt,
                        "images": [base64_image]
                    }
                ],
                "stream": False,
                "temperature": 0
            }
            
            # Llamar a la API de Ollama
            response = requests.post(
                f"{self.OLLAMA_ENDPOINT}",
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=60  # Timeout de 60 segundos para la llamada API
            )
            
            # Verificar si la solicitud fue exitosa
            if response.status_code == 200:
                result = response.json()
                extracted_text = result["message"]["content"]
                return extracted_text, None
            else:
                return None, f"Error en la API: {response.status_code} - {response.text}"
                
        except Exception as e:
            return None, f"Error al procesar la imagen con Ollama: {str(e)}"
    
    def process_image_file(self, image_path):
        """
        Procesa un archivo de imagen y extrae su texto usando VLM.
        
        Args:
            image_path (Path): Ruta al archivo de imagen
            
        Returns:
            bool: True si el procesamiento fue exitoso, False en caso contrario
        """
        # Verificar si ya fue procesado
        if self._is_already_processed(image_path):
            self.logger.info(f"Imagen ya procesada anteriormente: {image_path}")
            return True
        
        # Preparar ruta de salida
        rel_path = image_path.relative_to(self.input_dir)
        output_dir = self.output_dir / rel_path.parent
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Nombre de archivo de salida (nombre original + .md)
        output_file = output_dir / f"{image_path.name}.md"
        
        self.logger.info(f"Procesando imagen: {image_path}")
        
        try:
            # Determinar si es un archivo TIFF multipágina
            is_tiff = image_path.suffix.lower() in ['.tiff', '.tif']
            
            if is_tiff:
                # Contar páginas para archivos TIFF
                num_pages = self._count_tiff_pages(image_path)
                self.logger.info(f"El archivo TIFF tiene {num_pages} páginas")
                
                # Si es multipágina, procesar cada página y guardar en un único archivo
                if num_pages > 1:
                    all_text = []
                    
                    for page in range(num_pages):
                        self.logger.info(f"Procesando página {page+1}/{num_pages} del TIFF")
                        
                        # Leer la página como imagen
                        image_bytes = self._read_image_file(str(image_path), page)
                        
                        if not image_bytes:
                            self.logger.error(f"No se pudo leer la página {page+1} del TIFF")
                            continue
                        
                        # Extraer texto con Ollama
                        extracted_text, error = self._extract_text_from_image_ollama(image_bytes)
                        
                        if error:
                            self.logger.error(f"Error en la página {page+1}: {error}")
                            all_text.append(f"# Página {page+1}\n\n*Error al procesar esta página: {error}*\n\n")
                        else:
                            all_text.append(f"# Página {page+1}\n\n{extracted_text}\n\n")
                    
                    # Guardar todas las páginas en un único archivo markdown
                    with open(output_file, 'w', encoding='utf-8') as f:
                        f.write("\n---\n\n".join(all_text))
                    
                    self.logger.info(f"✓ TIFF multipágina procesado y guardado como: {output_file}")
                    self._record_processed_file(image_path, success=True, method="VLM-Ollama-TIFF-Multipágina")
                    return True
            
            # Para imágenes normales o TIFF de una página
            image_bytes = self._read_image_file(str(image_path))
            
            if not image_bytes:
                self.logger.error(f"No se pudo leer la imagen: {image_path}")
                self._record_processed_file(image_path, success=False, 
                                     error_msg="Error al leer la imagen")
                return False
            
            # Extraer texto con Ollama
            extracted_text, error = self._extract_text_from_image_ollama(image_bytes)
            
            if error:
                self.logger.error(f"✗ Error al procesar la imagen con VLM: {error}")
                self._record_processed_file(image_path, success=False, 
                                     error_msg=f"Error VLM: {error}")
                return False
            
            # Guardar el texto extraído
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(extracted_text)
            
            img_type = "TIFF" if is_tiff else image_path.suffix[1:].upper()
            self.logger.info(f"✓ Imagen {img_type} procesada y guardada como: {output_file}")
            self._record_processed_file(image_path, success=True, method=f"VLM-Ollama-{img_type}")
            return True
            
        except Exception as e:
            # Capturar cualquier otro error
            error_details = traceback.format_exc()
            self.logger.error(f"✗ Error al procesar imagen {image_path}: {str(e)}")
            self.logger.debug(error_details)
            self._record_processed_file(image_path, success=False, error_msg=str(e))
            return False
    
    def _process_with_ollama(self, pdf_path, output_path):
        """
        Procesa un PDF usando el servicio de Ollama.
        
        Args:
            pdf_path (str): Ruta al archivo PDF
            output_path (str): Ruta del archivo de salida
            
        Returns:
            dict: Resultado del procesamiento con estado y posible error
        """
        try:
            # Convertir la primera página a imagen
            image_bytes = self._convert_pdf_to_image(pdf_path)
            
            if not image_bytes:
                return {"success": False, "error": "No se pudo convertir el PDF a imagen"}
            
            # Extraer texto de la imagen usando Ollama
            extracted_text, error = self._extract_text_from_image_ollama(image_bytes)
            
            if error:
                return {"success": False, "error": error}
                
            # Guardar el texto extraído
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(extracted_text)
                
            return {"success": True, "error": None, "method": "VLM-Ollama-PDF"}
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def process_pdf_file(self, pdf_path):
        """
        Procesa un archivo PDF y lo convierte a Markdown.
        Primero intenta con pymupdf4llm, si falla o tarda demasiado usa VLM.
        
        Args:
            pdf_path (Path): Ruta al archivo PDF
            
        Returns:
            bool: True si el procesamiento fue exitoso, False en caso contrario
        """
        # Verificar si ya fue procesado
        if self._is_already_processed(pdf_path):
            self.logger.info(f"Archivo ya procesado anteriormente: {pdf_path}")
            return True
        
        # Preparar ruta de salida
        rel_path = pdf_path.relative_to(self.input_dir)
        output_dir = self.output_dir / rel_path.parent
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Nombre de archivo de salida (nombre original + .md)
        output_file = output_dir / f"{pdf_path.name}.md"
        
        self.logger.info(f"Procesando PDF: {pdf_path}")
        
        # Verificar si el PDF tiene texto extraíble
        has_text, sample_text = self.has_extractable_text(pdf_path)
        
        if not has_text:
            self.logger.info(f"El PDF parece no tener texto extraíble. Usando VLM...")
            # Si no tiene texto extraíble, usar directamente el método de Ollama
            if self.OLLAMA_ENDPOINT:
                try:
                    result = self._process_with_ollama(str(pdf_path), str(output_file))
                    
                    if result["success"]:
                        self.logger.info(f"✓ Convertido con VLM y guardado como: {output_file}")
                        self._record_processed_file(pdf_path, success=True, method="VLM-Ollama-PDF-No-Editable")
                        return True
                    else:
                        self.logger.error(f"✗ Error al procesar con VLM: {result['error']}")
                        self._record_processed_file(pdf_path, success=False, 
                                             error_msg=f"Error VLM: {result['error']}")
                        return False
                except Exception as e:
                    self.logger.error(f"✗ Error en proceso VLM: {str(e)}")
                    self._record_processed_file(pdf_path, success=False, 
                                         error_msg=f"Error VLM: {str(e)}")
                    return False
            else:
                self.logger.error("No se ha configurado el endpoint de Ollama para procesar PDFs no editables")
                self._record_processed_file(pdf_path, success=False, 
                                     error_msg="PDF no editable y Ollama no configurado")
                return False
        
        # Intentar procesar con pymupdf4llm primero, con límite de tiempo
        try:
            # Usar multiprocessing para implementar timeout
            ctx = multiprocessing.get_context('spawn')
            
            # Crear un proceso para la extracción directa
            with ctx.Pool(processes=1) as pool:
                try:
                    # Intentar extraer con timeout
                    start_time = time.time()
                    self.logger.info(f"Intentando extracción directa con pymupdf4llm (timeout: {self.PDF_EXTRACTION_TIMEOUT}s)...")
                    
                    md_text = pool.apply_async(self._convert_pdf_to_markdown_direct, (str(pdf_path),))
                    # Esperar con timeout
                    md_result = md_text.get(timeout=self.PDF_EXTRACTION_TIMEOUT)
                    
                    extraction_time = time.time() - start_time
                    self.logger.info(f"Extracción directa completada en {extraction_time:.2f} segundos")
                    
                    # Verificar si el resultado es válido
                    if not md_result or len(md_result.strip()) < 50:
                        self.logger.warning("Texto extraído insuficiente. Intentando con VLM...")
                        raise TimeoutError("Resultado de baja calidad")
                    
                    # Si llegamos aquí, la extracción fue exitosa
                    with open(output_file, 'w', encoding='utf-8') as f:
                        f.write(md_result)
                    
                    self.logger.info(f"✓ Convertido directamente y guardado como: {output_file}")
                    self._record_processed_file(pdf_path, success=True, method="pymupdf4llm-direct")
                    return True
                    
                except TimeoutError:
                    # Si se excede el tiempo, intentar con VLM
                    self.logger.warning(f"Tiempo excedido para extracción directa ({self.PDF_EXTRACTION_TIMEOUT}s). Intentando con VLM...")
                    
                    if self.OLLAMA_ENDPOINT:
                        result = self._process_with_ollama(str(pdf_path), str(output_file))
                        
                        if result["success"]:
                            self.logger.info(f"✓ Convertido con VLM después de timeout y guardado como: {output_file}")
                            self._record_processed_file(pdf_path, success=True, method="VLM-Ollama-After-Timeout")
                            return True
                        else:
                            self.logger.error(f"✗ Error al procesar con VLM: {result['error']}")
                            self._record_processed_file(pdf_path, success=False, 
                                                 error_msg=f"Error VLM después de timeout: {result['error']}")
                            return False
                    else:
                        self.logger.error("No se ha configurado el endpoint de Ollama para fallback")
                        self._record_processed_file(pdf_path, success=False, 
                                             error_msg="Timeout en extracción directa y Ollama no configurado")
                        return False
                
        except Exception as e:
            # Capturar cualquier otro error
            error_details = traceback.format_exc()
            self.logger.error(f"✗ Error al procesar {pdf_path}: {str(e)}")
            self.logger.debug(error_details)
            self._record_processed_file(pdf_path, success=False, error_msg=str(e))
            return False
    
    def process_all(self):
        """
        Procesa todos los archivos PDF e imágenes encontrados en el directorio de entrada
        que coincidan con los criterios de palabras clave en el nombre.
        
        Returns:
            dict: Estadísticas de procesamiento
        """
        # Buscar archivos a procesar
        pdf_files, image_files = self.find_files_to_process()
        start_time = time.time()
        
        stats = {
            "pdf_processed": 0,
            "pdf_failed": 0,
            "pdf_skipped": 0,
            "image_processed": 0,
            "image_failed": 0,
            "image_skipped": 0
        }
        
        # Procesar archivos PDF
        total_pdfs = len(pdf_files)
        if total_pdfs > 0:
            self.logger.info(f"Iniciando procesamiento de {total_pdfs} archivos PDF")
            
            for i, pdf_file in enumerate(pdf_files):
                # Mostrar progreso
                progress = f"[{i+1}/{total_pdfs}]"
                self.logger.info(f"Procesando PDF {progress}: {pdf_file.name}")
                
                # Verificar si ya ha sido procesado
                if self._is_already_processed(pdf_file):
                    self.logger.info(f"  PDF ya procesado anteriormente, omitiendo...")
                    stats["pdf_skipped"] += 1
                    continue
                
                # Procesar el archivo
                file_start_time = time.time()
                success = self.process_pdf_file(pdf_file)
                file_elapsed_time = time.time() - file_start_time
                
                if success:
                    self.logger.info(f"  PDF procesado exitosamente en {file_elapsed_time:.2f} segundos")
                    stats["pdf_processed"] += 1
                else:
                    self.logger.info(f"  Error al procesar PDF (tiempo: {file_elapsed_time:.2f} segundos)")
                    stats["pdf_failed"] += 1
        
        # Procesar archivos de imagen
        total_images = len(image_files)
        if total_images > 0:
            self.logger.info(f"Iniciando procesamiento de {total_images} archivos de imagen")
            
            for i, image_file in enumerate(image_files):
                # Mostrar progreso
                progress = f"[{i+1}/{total_images}]"
                self.logger.info(f"Procesando imagen {progress}: {image_file.name}")
                
                # Verificar si ya ha sido procesado
                if self._is_already_processed(image_file):
                    self.logger.info(f"  Imagen ya procesada anteriormente, omitiendo...")
                    stats["image_skipped"] += 1
                    continue
                
                # Procesar el archivo
                file_start_time = time.time()
                success = self.process_image_file(image_file)
                file_elapsed_time = time.time() - file_start_time
                
                if success:
                    self.logger.info(f"  Imagen procesada exitosamente en {file_elapsed_time:.2f} segundos")
                    stats["image_processed"] += 1
                else:
                    self.logger.info(f"  Error al procesar imagen (tiempo: {file_elapsed_time:.2f} segundos)")
                    stats["image_failed"] += 1
        
        # Calcular estadísticas totales
        elapsed_time = time.time() - start_time
        total_processed = stats["pdf_processed"] + stats["image_processed"]
        total_failed = stats["pdf_failed"] + stats["image_failed"]
        total_skipped = stats["pdf_skipped"] + stats["image_skipped"]
        
        self.logger.info(f"Procesamiento completo en {elapsed_time:.2f} segundos")
        self.logger.info(f"Resultados totales: {total_processed} procesados, {total_failed} fallidos, {total_skipped} omitidos")
        self.logger.info(f"Desglose - PDFs: {stats['pdf_processed']} procesados, {stats['pdf_failed']} fallidos, {stats['pdf_skipped']} omitidos")
        self.logger.info(f"Desglose - Imágenes: {stats['image_processed']} procesadas, {stats['image_failed']} fallidas, {stats['image_skipped']} omitidas")
        
        return stats


if __name__ == "__main__":
    import argparse
    
    # Verificar si se está ejecutando como proceso principal
    # (necesario para multiprocessing en Windows)
    if multiprocessing.current_process().name == 'MainProcess':
        multiprocessing.freeze_support()
    
    parser = argparse.ArgumentParser(description='Procesa archivos PDF e imágenes y los convierte a Markdown')
    parser.add_argument('--input', '-i', required=True, help='Directorio de entrada que contiene archivos')
    parser.add_argument('--output', '-o', required=True, help='Directorio de salida para archivos Markdown')
    parser.add_argument('--logs', '-l', help='Directorio para archivos de log (opcional)')
    parser.add_argument('--timeout', '-t', type=int, default=300, help='Límite de tiempo en segundos para procesar un archivo (default: 300)')
    parser.add_argument('--extraction-timeout', '-e', type=int, default=10, help='Límite de tiempo para extracción directa antes de usar VLM (default: 10)')
    parser.add_argument('--ollama-endpoint', help='URL del endpoint de Ollama API (ej: http://localhost:11434/api/chat)')
    parser.add_argument('--ollama-model', default='llava:latest', help='Modelo de Ollama a utilizar (default: llava:latest)')
    
    args = parser.parse_args()
    
    processor = PDFImageProcessor(
        input_dir=args.input,
        output_dir=args.output,
        log_dir=args.logs,
        ollama_endpoint=args.ollama_endpoint,
        ollama_model=args.ollama_model,
        extraction_timeout=args.extraction_timeout
    )
    
    # Establecer límite de tiempo personalizado si se proporciona
    if args.timeout:
        processor.PDF_PROCESSING_TIMEOUT = args.timeout
    
    processor.process_all()