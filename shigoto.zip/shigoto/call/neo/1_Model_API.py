# pages/1_Model_API.py
import streamlit as st
import pandas as pd
import numpy as np
import mlflow
from mlflow.tracking import MlflowClient
import json
import logging
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

MLFLOW_TRACKING_URI = "http://127.0.0.1:8080"

def initialize_mlflow():
    """Inicializar conexión con MLflow"""
    try:
        mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
        client = MlflowClient()
        return client
    except Exception as e:
        logger.error(f"Error iniciando MLflow: {e}")
        st.error(f"Error conectando con MLflow: {str(e)}")
        return None

def get_registered_models(client):
    """Obtener lista de modelos registrados"""
    try:
        models = client.search_registered_models()
        # Agrupar modelos por tipo (optimal/historical)
        model_groups = {
            'optimal': [],
            'historical': []
        }
        for model in models:
            if model.name.endswith('_optimal'):
                model_groups['optimal'].append((model.name, model.latest_versions[-1]))
            elif model.name.endswith('_historical'):
                model_groups['historical'].append((model.name, model.latest_versions[-1]))
        return model_groups
    except Exception as e:
        logger.error(f"Error obteniendo modelos registrados: {e}")
        return {'optimal': [], 'historical': []}

def get_model_metrics(run_id):
    """Obtener métricas del modelo"""
    try:
        run = mlflow.get_run(run_id)
        metrics = run.data.metrics
        params = run.data.params
        return metrics, params
    except Exception as e:
        logger.error(f"Error obteniendo métricas: {e}")
        return {}, {}

def make_prediction(model, features, mae):
    """Realizar predicción con intervalo de confianza"""
    try:
        prediction = model.predict(features)[0]
        lower_bound = max(1, prediction - mae)
        upper_bound = prediction + mae
        return prediction, lower_bound, upper_bound
    except Exception as e:
        logger.error(f"Error en predicción: {e}")
        raise

def get_available_hours(day_of_week):
    """Obtener horas disponibles según el día"""
    if day_of_week <= 4:  # Lunes a viernes
        return list(range(7, 20))  # 7:00 - 19:00
    else:  # Sábado
        return list(range(8, 16))  # 8:00 - 15:00

def main():
    st.set_page_config(page_title="Model API", layout="wide")
    st.title("API de Predicción de Ratio de Marcación")
    
    # Inicializar MLflow
    client = initialize_mlflow()
    if not client:
        st.error("No se pudo conectar con MLflow")
        return
    
    # Obtener modelos registrados
    model_groups = get_registered_models(client)
    if not model_groups['optimal'] and not model_groups['historical']:
        st.error("No hay modelos registrados disponibles")
        return
    
    # Selector de tipo de modelo
    st.write("### Modo de Predicción")
    prediction_mode = st.radio(
        "Seleccione el modo de predicción:",
        ["Optimización con scoring", "Basado en histórico"],
        help="Optimización: Recomienda ratios óptimos según objetivos.\n"
             "Histórico: Predice basado solo en patrones históricos."
    )
    
    mode_key = 'optimal' if prediction_mode == "Optimización con scoring" else 'historical'
    available_models = model_groups[mode_key]
    
    if not available_models:
        st.error(f"No hay modelos disponibles para el modo {prediction_mode}")
        return
    
    # Selector de modelo
    st.write("### Selección de Modelo")
    model_options = {model[0]: model for model in available_models}
    selected_model_name = st.selectbox(
        "Seleccione un modelo registrado",
        options=list(model_options.keys()),
        format_func=lambda x: x.replace(f"dialer_ratio_predictor_", "").replace(f"_{mode_key}", "")
    )
    
    selected_model = model_options[selected_model_name]
    version = selected_model[1]
    
    # Mostrar información del modelo
    st.write("### Métricas de Desempeño del Modelo")
    
    metrics, params = get_model_metrics(version.run_id)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric(
            "Error Absoluto Medio (MAE)", 
            f"{metrics.get('mae', 0):.3f}",
            help="Error promedio en la predicción del ratio"
        )
    with col2:
        st.metric(
            "Coeficiente de Determinación (R²)", 
            f"{metrics.get('r2', 0):.3f}",
            help="Calidad del ajuste del modelo"
        )
    with col3:
        st.metric(
            "Error Cuadrático Medio (RMSE)", 
            f"{metrics.get('mse', 0)**0.5:.3f}",
            help="Error cuadrático medio de las predicciones"
        )
    
    # Formulario de predicción
    st.write("### Variables de Entrada")
    
    with st.form("prediction_form"):
        # Sección Agentes
        st.subheader("Datos de Agentes")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            agents_connected = st.number_input(
                "Agentes Conectados",
                min_value=0,
                value=1000,
                help="Número total de agentes conectados"
            )
        
        with col2:
            agents_available = st.number_input(
                "Agentes Disponibles",
                min_value=0,
                max_value=agents_connected,
                value=min(500, agents_connected),
                help="Número de agentes disponibles para llamadas"
            )
        
        with col3:
            avg_call_duration = st.number_input(
                "Duración Promedio de Llamada (seg)",
                min_value=0,
                value=180,
                help="Duración promedio de las llamadas en segundos"
            )
        
        # Sección Horario
        st.markdown("---")
        st.subheader("Horario")
        col1, col2 = st.columns(2)
        
        with col1:
            day_of_week = st.selectbox(
                "Día de la Semana",
                options=[(0, "Lunes"), (1, "Martes"), (2, "Miércoles"),
                        (3, "Jueves"), (4, "Viernes"), (5, "Sábado")],
                format_func=lambda x: x[1]
            )[0]
        
        with col2:
            available_hours = get_available_hours(day_of_week)
            default_hour = 9 if day_of_week <= 4 else 10
            
            hour = st.selectbox(
                "Hora del Día",
                options=available_hours,
                index=available_hours.index(default_hour) if default_hour in available_hours else 0,
                format_func=lambda x: f"{x:02d}:00"
            )
        
        submit = st.form_submit_button("Calcular Predicción", use_container_width=True)
    
    if submit:
        try:
            # Determinar parte del día
            part_of_day = -1
            if day_of_week <= 4:  # Lunes a viernes
                if 7 <= hour < 11:
                    part_of_day = 0
                elif 11 <= hour < 14:
                    part_of_day = 1
                elif 14 <= hour < 19:
                    part_of_day = 2
            elif day_of_week == 5:  # Sábado
                if 8 <= hour < 11:
                    part_of_day = 0
                elif 11 <= hour < 15:
                    part_of_day = 1
            
            # Crear DataFrame con features
            features = pd.DataFrame({
                'agents_connected': [agents_connected],
                'agents_available': [agents_available],
                'hour': [hour],
                'day_of_week': [day_of_week],
                'part_of_day': [part_of_day],
                'avg_call_duration': [avg_call_duration]
            })
            
            # Cargar modelo
            model = mlflow.xgboost.load_model(f"runs:/{version.run_id}/model")
            
            # Realizar predicción
            prediction, lower_bound, upper_bound = make_prediction(
                model,
                features,
                metrics.get('mae', 0)
            )
            
            # Mostrar resultados
            st.write("### Resultados de la Predicción")
            
            ratio_label = "Ratio Predicho" if mode_key == 'historical' else "Ratio Óptimo"
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric(
                    ratio_label,
                    f"{prediction:.2f}",
                    help=f"{'Número predicho' if mode_key == 'historical' else 'Número recomendado'} de llamadas por agente disponible"
                )
            
            with col2:
                st.metric(
                    "Límite Inferior",
                    f"{lower_bound:.2f}",
                    help="Límite inferior del intervalo de confianza"
                )
            
            with col3:
                st.metric(
                    "Límite Superior",
                    f"{upper_bound:.2f}",
                    help="Límite superior del intervalo de confianza"
                )
            
            msg_prefix = "ratio óptimo" if mode_key == 'optimal' else "ratio predicho"
            st.info(
                f"Con un Error Absoluto Medio de {metrics.get('mae', 0):.3f}, " 
                f"el {msg_prefix} debería estar entre {lower_bound:.2f} "
                f"y {upper_bound:.2f} llamadas por agente disponible."
            )
            
        except Exception as e:
            st.error(f"Error al realizar la predicción: {str(e)}")

if __name__ == "__main__":
    main()