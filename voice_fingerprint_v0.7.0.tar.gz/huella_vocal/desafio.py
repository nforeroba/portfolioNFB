"""Desafío de la prueba de vida: una secuencia corta de dígitos al azar.

La persona dice su nombre y luego repite los dígitos, uno por uno. El nombre
aporta voz para la huella; los dígitos demuestran que habla en vivo, porque
una grabación previa no tendrá justo esa secuencia en ese orden.
"""

import secrets

from .config import DIGITOS_DESAFIO

PALABRAS_DIGITO = ["cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve"]

_aleatorio = secrets.SystemRandom()   # impredecible: no se puede anticipar el desafío


def generar_desafio(n=DIGITOS_DESAFIO):
    """
    Dígitos al azar sin repetir el mismo dígito dos veces seguidas (más fácil
    de decir y de contar). Devuelve el desafío listo para mostrar o para leer.
    """
    digitos = [_aleatorio.randrange(10)]
    while len(digitos) < n:
        d = _aleatorio.randrange(10)
        if d != digitos[-1]:
            digitos.append(d)
    pantalla = " ".join(str(d) for d in digitos)
    return {
        "digitos": "".join(str(d) for d in digitos),
        "texto_pantalla": pantalla,
        "texto_voz": ", ".join(PALABRAS_DIGITO[d] for d in digitos),
        "instruccion": f"Diga su nombre completo y luego repita estos números, uno por uno: {pantalla}",
    }


def combinaciones_posibles(n=DIGITOS_DESAFIO):
    return 10 * 9 ** (n - 1)
