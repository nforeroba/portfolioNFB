"""
Servicio gRPC TTS — Fish Audio S2-Pro
Arquitectura: gRPC (grpc.aio) → TTSInferenceEngine directo (sin HTTP interno, sin SGLang)
Protocolo: tts_service.proto (TTS unary) — idéntico al de tts_s1_mini
Modelo: fishaudio/s2-pro (Dual-AR, 4B Slow AR + 400M Fast AR)

Diferencias respecto a tts_s1_mini/server.py:
  - Checkpoint por defecto: checkpoints/s2-pro (antes: checkpoints/openaudio-s1-mini)
  - Precisión configurable vía TTS_PRECISION=bf16|fp16 (antes: bf16 fijo).
    La doc oficial de fish-speech indica usar --half (fp16) en GPUs que no
    soportan bf16 nativamente o que no tienen suficiente VRAM para el
    checkpoint completo en bf16 (S2-Pro recomienda >=24GB VRAM en bf16).
"""

import argparse
import asyncio
import io
import json
import logging
import os
import time
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
from pydub import AudioSegment

import grpc
import grpc.aio

# Imports del repo fish-speech (disponibles porque PYTHONPATH=/app)
from fish_speech.inference_engine import TTSInferenceEngine
from fish_speech.models.dac.inference import load_model as load_decoder_model
from fish_speech.models.text2semantic.inference import launch_thread_safe_queue
from fish_speech.utils.schema import ServeTTSRequest as EngineRequest
from fish_speech.utils.schema import ServeReferenceAudio

# Deshabilitar validación de versión de protobuf si aplica
try:
    import google.protobuf.runtime_version as _pb_rv
    _pb_rv.ValidateProtobufRuntimeVersion = lambda *a, **kw: None
except Exception:
    pass

import tts_service_pb2
import tts_service_pb2_grpc

# =============================================================================
# Logging
# =============================================================================

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s|%(name)s|%(levelname)s|%(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("tts_service")

# =============================================================================
# Precisión — configurable vía TTS_PRECISION (bf16 | fp16)
# =============================================================================

def resolve_precision() -> torch.dtype:
    """
    Resuelve el dtype de inferencia desde la variable de entorno TTS_PRECISION.
    - bf16 (default): recomendado en H200 NVL / GPUs con suficiente VRAM.
    - fp16: para GPUs con VRAM limitada (ej. RTX 5070 Ti, 16GB) donde el
      checkpoint completo de S2-Pro en bf16 puede no caber. Equivalente al
      flag --half de la documentación oficial de fish-speech.
    """
    raw = os.environ.get("TTS_PRECISION", "bf16").strip().lower()
    mapping = {
        "bf16": torch.bfloat16,
        "bfloat16": torch.bfloat16,
        "fp16": torch.float16,
        "float16": torch.float16,
        "half": torch.float16,
    }
    if raw not in mapping:
        logger.warning(
            "TTS_PRECISION='%s' no reconocido — usando bf16 por defecto", raw
        )
        return torch.bfloat16
    return mapping[raw]


def resolve_device() -> str:
    """
    Resuelve el dispositivo de inferencia. Por defecto usa CUDA si está
    disponible; TTS_DEVICE=cpu fuerza CPU incluso con GPU presente.

    Uso: validar que el pipeline completo de carga/inferencia funciona
    sin errores de código, en un escenario donde el checkpoint no cabe en
    la VRAM disponible (ej. S2-Pro en una GPU de 16GB). Será lento
    (minutos por frase) pero no depende de VRAM — usa la RAM del sistema.
    """
    raw = os.environ.get("TTS_DEVICE", "").strip().lower()
    if raw == "cpu":
        logger.warning(
            "TTS_DEVICE=cpu forzado explícitamente — la inferencia será "
            "considerablemente más lenta (minutos por frase). Uso previsto "
            "solo para validar el pipeline cuando el modelo no cabe en VRAM."
        )
        return "cpu"
    if raw not in ("", "cuda", "auto"):
        logger.warning("TTS_DEVICE='%s' no reconocido — usando auto-detección", raw)
    return "cuda" if torch.cuda.is_available() else "cpu"


# =============================================================================
# Configuración
# =============================================================================

def load_config(path: str) -> dict:
    defaults = {
        "listen": "0.0.0.0:50051",
        "temperature": 0.7,
        "top_p": 0.7,
        "repetition_penalty": 1.2,
        "default_reference_id": "vanessa",
        "warmup_text": "Hola, esta es una prueba de síntesis de voz.",
        "warmup_reference_id": "vanessa",
        "warmup_runs": 3,
        "compile": False,
    }
    try:
        with open(path) as f:
            cfg = json.load(f)
        defaults.update(cfg)
        logger.info("Configuración cargada desde %s", path)
    except FileNotFoundError:
        logger.warning("Config no encontrada en %s — usando defaults", path)
    logger.debug("Config: %s", json.dumps(defaults))
    return defaults


# =============================================================================
# Resolución de voces de referencia
# =============================================================================

VOICES_DIR = Path(os.environ.get("VOICES_DIR", "/voices"))
SAMPLES_DIR = Path("/app/samples")


def resolve_voice(reference_id: str) -> tuple[bytes, str]:
    """
    Devuelve (audio_bytes, transcripción) para un reference_id dado.
    Busca primero en /voices/, luego en /app/samples/.
    """
    for base in [VOICES_DIR, SAMPLES_DIR]:
        wav = base / f"{reference_id}.wav"
        txt = base / f"{reference_id}.txt"
        if wav.exists() and txt.exists():
            audio_bytes = wav.read_bytes()
            transcript = txt.read_text(encoding="utf-8").strip()
            logger.debug("Voz '%s' resuelta desde %s", reference_id, base)
            return audio_bytes, transcript
    raise FileNotFoundError(
        f"Voz '{reference_id}' no encontrada en {VOICES_DIR} ni en {SAMPLES_DIR}"
    )


# =============================================================================
# Conversión WAV → Opus
# =============================================================================

def wav_to_opus(wav_bytes: bytes) -> tuple[bytes, float]:
    """
    Convierte bytes WAV a bytes Opus.
    Devuelve (opus_bytes, duration_seconds).
    """
    t0 = time.perf_counter()
    audio = AudioSegment.from_wav(io.BytesIO(wav_bytes))
    duration = len(audio) / 1000.0

    buf = io.BytesIO()
    audio.export(buf, format="opus", codec="libopus")
    opus_bytes = buf.getvalue()

    elapsed = time.perf_counter() - t0
    logger.debug(
        "WAV→Opus | dur=%.3fs | opus_size=%d bytes | conv_time=%.3fs",
        duration, len(opus_bytes), elapsed,
    )
    return opus_bytes, duration


# =============================================================================
# Servicer gRPC
# =============================================================================

class TTSServicer(tts_service_pb2_grpc.TTSServiceServicer):

    def __init__(self, engine: TTSInferenceEngine, config: dict):
        self.engine = engine
        self.config = config

    async def TTS(
        self,
        request: tts_service_pb2.ServeTTSRequest,
        context: grpc.aio.ServicerContext,
    ) -> tts_service_pb2.ServeAudioResponse:

        t_total = time.perf_counter()
        text = request.text
        reference_id = request.reference_id or self.config["default_reference_id"]
        temperature = request.temperature or self.config["temperature"]
        top_p = request.top_p or self.config["top_p"]
        repetition_penalty = request.repetition_penalty or self.config["repetition_penalty"]

        logger.info(
            "REQUEST | text_len=%d | voz=%s | temp=%.2f | top_p=%.2f | rep_penalty=%.2f",
            len(text), reference_id, temperature, top_p, repetition_penalty,
        )

        # ── Resolver voz de referencia ────────────────────────────────────────
        t0 = time.perf_counter()
        try:
            audio_bytes, transcript = resolve_voice(reference_id)
        except FileNotFoundError as e:
            logger.error("Voz no encontrada: %s", e)
            await context.abort(grpc.StatusCode.NOT_FOUND, str(e))
            return

        logger.debug("Voz resuelta | voz=%s | elapsed=%.3fs", reference_id, time.perf_counter() - t0)

        # ── Construir request para el engine ─────────────────────────────────
        engine_request = EngineRequest(
            text=text,
            references=[ServeReferenceAudio(audio=audio_bytes, text=transcript)],
            max_new_tokens=1024,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            streaming=False,
        )

        # ── Inferencia (bloqueante — correr en executor para no bloquear el loop) ──
        t0 = time.perf_counter()
        logger.info("INFERENCIA | inicio | voz=%s | text_len=%d", reference_id, len(text))

        loop = asyncio.get_event_loop()
        wav_bytes = await loop.run_in_executor(None, self._run_inference, engine_request)

        if wav_bytes is None:
            logger.error("INFERENCIA | falló — no se obtuvo audio")
            await context.abort(grpc.StatusCode.INTERNAL, "Error en síntesis de voz")
            return

        logger.info("INFERENCIA | fin | elapsed=%.3fs", time.perf_counter() - t0)

        # ── Conversión WAV → Opus ─────────────────────────────────────────────
        t0 = time.perf_counter()
        logger.debug("CONVERSIÓN | WAV→Opus | inicio")
        opus_bytes, audio_duration = wav_to_opus(wav_bytes)
        logger.debug("CONVERSIÓN | WAV→Opus | fin | elapsed=%.3fs", time.perf_counter() - t0)

        # ── Respuesta ─────────────────────────────────────────────────────────
        total_elapsed = time.perf_counter() - t_total
        rtf = total_elapsed / audio_duration if audio_duration > 0 else 0.0

        logger.info(
            "RESPONSE | voz=%s | audio_dur=%.3fs | total_time=%.3fs | RTF=%.4f | opus_size=%d bytes",
            reference_id, audio_duration, total_elapsed, rtf, len(opus_bytes),
        )

        return tts_service_pb2.ServeAudioResponse(
            audio_bytes=opus_bytes,
            audio_duration=audio_duration,
        )

    def _run_inference(self, engine_request: EngineRequest) -> bytes | None:
        """
        Ejecuta la inferencia en el TTSInferenceEngine y devuelve bytes WAV.
        Se corre en un executor para no bloquear el event loop de asyncio.
        """
        import io as _io
        wav_buf = _io.BytesIO()

        try:
            t_llama = time.perf_counter()
            audio_chunks = []

            for result in self.engine.inference(engine_request):
                if result.code == "error":
                    logger.error("ENGINE | error: %s", result.error)
                    return None
                if result.code in ("segment", "final"):
                    sample_rate, audio_data = result.audio
                    audio_chunks.append((sample_rate, audio_data))
                    if result.code == "segment":
                        logger.debug(
                            "ENGINE | segmento recibido | sr=%d | samples=%d",
                            sample_rate, len(audio_data),
                        )

            if not audio_chunks:
                return None

            t_llama_end = time.perf_counter()
            logger.info(
                "ENGINE | generación completa | chunks=%d | elapsed=%.3fs",
                len(audio_chunks), t_llama_end - t_llama,
            )

            # Concatenar chunks y escribir WAV
            t_wav = time.perf_counter()
            import soundfile as _sf
            all_audio = np.concatenate([chunk for _, chunk in audio_chunks])
            sample_rate = audio_chunks[0][0]
            _sf.write(wav_buf, all_audio, sample_rate, format="WAV", subtype="PCM_16")
            logger.debug(
                "ENGINE | WAV escrito | samples=%d | sr=%d | elapsed=%.3fs",
                len(all_audio), sample_rate, time.perf_counter() - t_wav,
            )
            return wav_buf.getvalue()

        except Exception as e:
            logger.exception("ENGINE | excepción durante inferencia: %s", e)
            return None


# =============================================================================
# Carga del modelo
# =============================================================================

def load_engine(config: dict) -> TTSInferenceEngine:
    llama_ckpt = Path(os.environ.get(
        "LLAMA_CHECKPOINT_PATH", "checkpoints/s2-pro"
    ))
    decoder_ckpt = Path(os.environ.get(
        "DECODER_CHECKPOINT_PATH", "checkpoints/s2-pro/codec.pth"
    ))
    decoder_cfg = os.environ.get("DECODER_CONFIG_NAME", "modded_dac_vq")
    compile_model = config.get("compile", False)
    device = resolve_device()
    if compile_model and device == "cpu":
        logger.warning(
            "COMPILE | torch.compile (Triton) no aplica en CPU — "
            "deshabilitando automáticamente para este arranque"
        )
        compile_model = False
    precision = resolve_precision()
    if device == "cpu" and precision != torch.float32:
        logger.warning(
            "PRECISIÓN | %s no es totalmente soportado/estable en CPU — "
            "forzando float32 para este arranque (TTS_PRECISION se ignora en CPU)",
            precision,
        )
        precision = torch.float32

    logger.info("════════════════════════════════════════════════")
    logger.info("  Fish Audio S2-Pro TTS gRPC Service — cargando modelo")
    logger.info("════════════════════════════════════════════════")
    logger.info("Dispositivo : %s", device)
    logger.info("Precisión   : %s (TTS_PRECISION=%s)", precision, os.environ.get("TTS_PRECISION", "bf16"))
    logger.info("LLaMA ckpt  : %s", llama_ckpt)
    logger.info("Decoder ckpt: %s", decoder_ckpt)
    logger.info("Decoder cfg : %s", decoder_cfg)
    logger.info("Compile     : %s", compile_model)

    if precision == torch.float16 and device == "cuda":
        logger.info(
            "NOTA: usando fp16 (--half equivalente) — recomendado para GPUs "
            "con VRAM limitada (ej. RTX 5070 Ti). En H200 NVL usar bf16 (default)."
        )

    # Cargar LLaMA (Slow AR + Fast AR — Dual-AR)
    t0 = time.perf_counter()
    logger.info("CARGA | LLaMA Dual-AR (Slow 4B + Fast 400M) | inicio")
    llama_queue = launch_thread_safe_queue(
        checkpoint_path=llama_ckpt,
        device=device,
        precision=precision,
        compile=compile_model,
    )
    logger.info("CARGA | LLaMA Dual-AR | fin | elapsed=%.2fs", time.perf_counter() - t0)

    # Cargar codec DAC
    t0 = time.perf_counter()
    logger.info("CARGA | Codec DAC (%s) | inicio", decoder_cfg)
    decoder_model = load_decoder_model(
        config_name=decoder_cfg,
        checkpoint_path=decoder_ckpt,
        device=device,
    )
    logger.info("CARGA | Codec DAC | fin | elapsed=%.2fs", time.perf_counter() - t0)

    # Crear engine
    engine = TTSInferenceEngine(
        llama_queue=llama_queue,
        decoder_model=decoder_model,
        precision=precision,
        compile=compile_model,
    )
    logger.info("CARGA | TTSInferenceEngine creado")

    return engine


# =============================================================================
# Warmup
# =============================================================================

def run_warmup(engine: TTSInferenceEngine, config: dict):
    warmup_text = config.get("warmup_text", "Hola.")
    warmup_ref = config.get("warmup_reference_id", config.get("default_reference_id", "vanessa"))
    warmup_runs = config.get("warmup_runs", 3)

    logger.info("WARMUP | inicio | corridas=%d | voz=%s", warmup_runs, warmup_ref)

    try:
        audio_bytes, transcript = resolve_voice(warmup_ref)
    except FileNotFoundError:
        logger.warning("WARMUP | voz '%s' no encontrada — saltando warmup", warmup_ref)
        return

    engine_request = EngineRequest(
        text=warmup_text,
        references=[ServeReferenceAudio(audio=audio_bytes, text=transcript)],
        max_new_tokens=1024,
        temperature=config["temperature"],
        top_p=config["top_p"],
        repetition_penalty=config["repetition_penalty"],
        streaming=False,
    )

    for i in range(warmup_runs):
        t0 = time.perf_counter()
        logger.info("WARMUP | corrida %d/%d | inicio", i + 1, warmup_runs)

        audio_chunks = []
        for result in engine.inference(engine_request):
            if result.code in ("segment", "final"):
                audio_chunks.append(result.audio)

        elapsed = time.perf_counter() - t0
        if audio_chunks:
            sr, data = audio_chunks[0]
            total_samples = sum(len(d) for _, d in audio_chunks)
            duration = total_samples / sr
            rtf = elapsed / duration if duration > 0 else 0.0
            logger.info(
                "WARMUP | corrida %d/%d | OK | dur=%.3fs | elapsed=%.3fs | RTF=%.4f",
                i + 1, warmup_runs, duration, elapsed, rtf,
            )
        else:
            logger.warning("WARMUP | corrida %d/%d | sin audio", i + 1, warmup_runs)

    logger.info("WARMUP | completado")


# =============================================================================
# Servidor gRPC
# =============================================================================

async def serve(engine: TTSInferenceEngine, config: dict, port: int):
    listen_addr = f"0.0.0.0:{port}"
    server = grpc.aio.server()
    tts_service_pb2_grpc.add_TTSServiceServicer_to_server(
        TTSServicer(engine, config), server
    )
    server.add_insecure_port(listen_addr)

    await server.start()
    logger.info("════════════════════════════════════════════════")
    logger.info("  gRPC escuchando en %s", listen_addr)
    logger.info("  Servicio listo para recibir requests")
    logger.info("════════════════════════════════════════════════")

    await server.wait_for_termination()


# =============================================================================
# Main
# =============================================================================

def parse_args():
    parser = argparse.ArgumentParser(description="Fish Audio S2-Pro TTS gRPC Service")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 50051)))
    parser.add_argument("--config", default="/app/config_tts.json")
    return parser.parse_args()


def main():
    t_start = time.perf_counter()
    args = parse_args()
    config = load_config(args.config)

    # Cargar modelo
    engine = load_engine(config)

    # Warmup
    run_warmup(engine, config)

    logger.info(
        "ARRANQUE | completo | elapsed_total=%.2fs",
        time.perf_counter() - t_start,
    )

    # Iniciar servidor gRPC
    asyncio.run(serve(engine, config, args.port))


if __name__ == "__main__":
    main()
