"""Decisión de identidad 1:N de conjunto abierto, con zona gris."""

from .config import MARGEN_MINIMO, UMBRAL_ALTO, UMBRAL_BAJO


def decidir(candidatos):
    """
    candidatos: lista de (score, payload) de mayor a menor (top-k de Qdrant).

    - "identificado":    el mejor supera UMBRAL_ALTO y le saca MARGEN_MINIMO al segundo.
    - "no_concluyente":  zona gris, o dos candidatos demasiado cercanos: pedir que repita.
    - "no_identificado": ni el mejor llega a UMBRAL_BAJO.
    """
    if not candidatos:
        return {"resultado": "no_identificado", "motivo": "No hay personas registradas.", "persona": None}
    mejor_score, mejor = candidatos[0]
    segundo_score = candidatos[1][0] if len(candidatos) > 1 else None
    margen = mejor_score - segundo_score if segundo_score is not None else None

    if mejor_score < UMBRAL_BAJO:
        resultado, motivo, persona = "no_identificado", "La voz no se parece lo suficiente a nadie del pool.", None
    elif mejor_score >= UMBRAL_ALTO and (margen is None or margen >= MARGEN_MINIMO):
        resultado, motivo, persona = "identificado", "Coincidencia clara con una persona del pool.", mejor
    elif mejor_score >= UMBRAL_ALTO:
        resultado, motivo, persona = "no_concluyente", "Dos personas del pool se parecen demasiado a la muestra.", None
    else:
        resultado, motivo, persona = "no_concluyente", "La similitud está en la zona gris.", None

    return {
        "resultado": resultado,
        "motivo": motivo,
        "persona": persona,
        "score": round(mejor_score, 4),
        "margen": round(margen, 4) if margen is not None else None,
        "umbrales": {"alto": UMBRAL_ALTO, "bajo": UMBRAL_BAJO, "margen_minimo": MARGEN_MINIMO},
    }
