"""
Cliente de Ollama para rag-api.

Habla con el endpoint /api/embed para generar embeddings con el modelo
qwen3-embedding:8b. Es el motor de embeddings del camino preciso
(copilotos), donde el vector de mayor dimension busca capturar mas
matiz semantico que el camino rapido.
"""

import logging
import random
import time

import httpx

from rag_api.config import settings

logger = logging.getLogger(__name__)


class OllamaClientError(Exception):
    """Error de comunicacion o respuesta invalida del servicio Ollama."""


class OllamaClient:
    def __init__(self) -> None:
        cfg = settings.ollama
        self._base_url = f"http://{cfg.host}:{cfg.port}"
        self._nombre_modelo_embedding = cfg.nombre_modelo_embedding
        self._timeout = cfg.timeout_segundos
        self._reintentos = cfg.reintentos
        self._dimensiones = settings.qdrant.dim_coleccion_precisa

        self._client = httpx.Client(base_url=self._base_url, timeout=self._timeout)

    def embed(self, texto: str) -> list[float]:
        return self.embed_lote([texto])[0]

    def embed_lote(self, textos: list[str]) -> list[list[float]]:
        """
        Genera embeddings para varios textos usando /api/embed. Pide
        explicitamente la dimension configurada (QDRANT_DIM_COLECCION_PRECISA)
        para mantener siempre sincronizado el tamano del vector con lo
        que espera la coleccion de Qdrant, incluso si se trunca por
        debajo de la dimension nativa del modelo (4096).

        Reintenta con backoff exponencial + jitter, igual que el
        cliente de vLLM.
        """
        payload = {
            "model": self._nombre_modelo_embedding,
            "input": textos,
            "dimensions": self._dimensiones,
        }

        espera_base_segundos = 0.5
        ultimo_error: Exception | None = None

        for intento in range(1, self._reintentos + 2):
            try:
                respuesta = self._client.post("/api/embed", json=payload)
                respuesta.raise_for_status()
                datos = respuesta.json()
                return datos["embeddings"]
            except (httpx.HTTPError, KeyError, ValueError) as error:
                ultimo_error = error
                es_ultimo_intento = intento == self._reintentos + 1
                logger.warning(
                    "Fallo al pedir embeddings a Ollama (intento %d/%d): %s",
                    intento, self._reintentos + 1, error,
                )
                if not es_ultimo_intento:
                    espera = espera_base_segundos * (2 ** (intento - 1))
                    espera_con_jitter = espera + random.uniform(0, espera * 0.1)
                    time.sleep(espera_con_jitter)

        raise OllamaClientError(
            f"No se pudo obtener embeddings de Ollama tras {self._reintentos + 1} intentos"
        ) from ultimo_error

    def cerrar(self) -> None:
        self._client.close()
