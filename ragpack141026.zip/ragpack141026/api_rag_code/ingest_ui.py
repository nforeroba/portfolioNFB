"""
Interfaz grafica de pruebas para rag-api: INGEST y DELETE.

Cubre TODOS los campos del contrato gRPC (proto/rag.proto) para estos
dos RPCs, incluyendo ambos modos de Ingest (documento completo /
chunks pre-cortados) y ambos criterios de Delete (id / filtro).

Retrieve queda deliberadamente fuera, se aborda despues.

Requisitos (dentro del venv rag-env):
    pip install streamlit

Uso (desde el directorio api_rag_code, con el servidor rag-api ya
corriendo en otra terminal):
    streamlit run ingest_ui.py
"""

import uuid

import grpc
import streamlit as st

from rag_api.generated import rag_pb2, rag_pb2_grpc

st.set_page_config(page_title="rag-api - Pruebas Ingest / Delete", layout="wide")

# -----------------------------------------------------------------
# Conexion gRPC (una sola vez, cacheada en la sesion de Streamlit)
# -----------------------------------------------------------------

@st.cache_resource
def obtener_stub(host: str, puerto: int):
    canal = grpc.insecure_channel(f"{host}:{puerto}")
    return rag_pb2_grpc.RagServiceStub(canal)


with st.sidebar:
    st.header("Conexion")
    host = st.text_input("Host", value="localhost")
    puerto = st.number_input("Puerto", value=50051, step=1)
    timeout = st.number_input("Timeout (segundos)", value=30, step=5)
    st.caption("El servidor rag-api debe estar corriendo (python -m rag_api.server) en otra terminal.")

stub = obtener_stub(host, int(puerto))

PERFILES = {
    "PERFIL_RAPIDO (vLLM 0.6b, denso simple)": rag_pb2.PERFIL_RAPIDO,
    "PERFIL_PRECISO (Ollama 8b, hybrid + RRF)": rag_pb2.PERFIL_PRECISO,
}

ESTRATEGIAS = {
    "CHUNKING_RECURSIVO": rag_pb2.CHUNKING_RECURSIVO,
    "CHUNKING_FIJO": rag_pb2.CHUNKING_FIJO,
    "CHUNKING_SEMANTIC": rag_pb2.CHUNKING_SEMANTIC,
    "CHUNKING_AST_CODIGO": rag_pb2.CHUNKING_AST_CODIGO,
    "CHUNKING_CLAUSULA_LEGAL_JERARQUICA": rag_pb2.CHUNKING_CLAUSULA_LEGAL_JERARQUICA,
}

LENGUAJES_CODIGO = ("python", "javascript", "html", "sql", "cpp")

# Extension de archivo -> lenguaje_codigo (para preseleccionar al cargar un archivo)
EXTENSION_A_LENGUAJE = {
    ".py": "python",
    ".js": "javascript",
    ".mjs": "javascript",
    ".html": "html",
    ".htm": "html",
    ".sql": "sql",
    ".c": "cpp",
    ".h": "cpp",
    ".cc": "cpp",
    ".cpp": "cpp",
    ".hpp": "cpp",
}

EXTENSIONES_ACEPTADAS = ["txt", "md", "markdown", "py", "js", "mjs", "html", "htm", "sql", "c", "h", "cc", "cpp", "hpp"]


def cargar_archivo_en_formulario():
    """Callback del file_uploader: vuelca el contenido del archivo en el campo 'texto'
    y preselecciona fuente y (si es codigo) estrategia AST y lenguaje."""
    archivo = st.session_state.get("ingest_archivo")
    if archivo is None:
        return

    datos = archivo.getvalue()
    try:
        contenido = datos.decode("utf-8-sig")
    except UnicodeDecodeError:
        contenido = datos.decode("latin-1")

    st.session_state["ingest_texto"] = contenido
    st.session_state["ingest_fuente"] = archivo.name

    extension = ""
    if "." in archivo.name:
        extension = "." + archivo.name.rsplit(".", 1)[1].lower()
    lenguaje = EXTENSION_A_LENGUAJE.get(extension)
    if lenguaje is not None:
        st.session_state["ingest_estrategia"] = "CHUNKING_AST_CODIGO"
        st.session_state["ingest_lenguaje_codigo"] = lenguaje

tab_ingest, tab_delete = st.tabs(["INGEST", "DELETE"])

# ===================================================================
# TAB INGEST
# ===================================================================

with tab_ingest:
    st.subheader("IngestRequest")

    col1, col2, col3 = st.columns(3)
    with col1:
        categoria = st.text_input("categoria", value="", key="ingest_categoria")
    with col2:
        fuente = st.text_input("fuente", value="", key="ingest_fuente")
    with col3:
        perfil_label = st.radio("perfil", list(PERFILES.keys()), key="ingest_perfil")
        perfil = PERFILES[perfil_label]

    st.divider()

    modo = st.radio(
        "Modo de contenido (oneof 'contenido')",
        ["Modo A: DocumentoCompleto (la API chunkea)", "Modo B: ChunksPreCortados (cliente ya chunkeo)"],
        key="ingest_modo",
    )

    request_kwargs = {"categoria": categoria, "fuente": fuente, "perfil": perfil}

    # ---------------------------------------------------------------
    # MODO A: DocumentoCompleto
    # ---------------------------------------------------------------
    if modo.startswith("Modo A"):
        st.file_uploader(
            "Cargar archivo (opcional): llena 'texto' y 'fuente'. Si es codigo, preselecciona AST y el lenguaje.",
            type=EXTENSIONES_ACEPTADAS,
            key="ingest_archivo",
            on_change=cargar_archivo_en_formulario,
        )

        texto = st.text_area(
            "texto (DocumentoCompleto.texto)",
            height=200,
            key="ingest_texto",
            placeholder="Pega aqui el texto completo a ingestar, o carga un archivo arriba...",
        )

        estrategia_label = st.radio(
            "estrategia (EstrategiaChunking, obligatorio)",
            list(ESTRATEGIAS.keys()),
            key="ingest_estrategia",
        )
        estrategia = ESTRATEGIAS[estrategia_label]

        st.caption(
            {
                "CHUNKING_RECURSIVO": "Corta por parrafos > lineas > oraciones, corte ciego por tokens como ultimo recurso. Usa tamano_tokens y overlap_tokens.",
                "CHUNKING_FIJO": "Corte ciego cada N tokens, sin mirar estructura. Usa tamano_tokens y overlap_tokens.",
                "CHUNKING_SEMANTIC": "Agrupa oraciones por similitud coseno de embeddings (mismo motor del perfil activo). Usa tamano_tokens como tope de grupo y overlap_tokens.",
                "CHUNKING_AST_CODIGO": "Respeta limites de funcion/clase via Tree-sitter. Requiere lenguaje_codigo. Usa tamano_tokens, ignora overlap_tokens.",
                "CHUNKING_CLAUSULA_LEGAL_JERARQUICA": "Respeta articulos/clausulas, el padre es el articulo completo. Usa tamano_tokens, ignora overlap_tokens.",
            }[estrategia_label]
        )

        documento_kwargs = {"estrategia": estrategia}

        usa_overlap = estrategia_label in ("CHUNKING_RECURSIVO", "CHUNKING_FIJO", "CHUNKING_SEMANTIC")
        colp1, colp2, colp3 = st.columns(3)
        with colp1:
            especificar_parametros = st.checkbox(
                "Especificar parametros de tamano/overlap (si no, usa defaults del servidor)",
                value=False,
                key="ingest_especificar_parametros",
            )
        if especificar_parametros:
            with colp2:
                tamano_tokens = st.number_input("tamano_tokens", value=500, min_value=1, key="ingest_tamano_tokens")
            with colp3:
                if usa_overlap:
                    overlap_tokens = st.number_input("overlap_tokens", value=100, min_value=0, key="ingest_overlap_tokens")
                else:
                    overlap_tokens = 0
                    st.caption("overlap_tokens: no aplica a esta estrategia (se envia 0).")
            documento_kwargs["parametros"] = rag_pb2.ParametrosChunkingConTamano(
                tamano_tokens=int(tamano_tokens),
                overlap_tokens=int(overlap_tokens),
            )

        if estrategia_label == "CHUNKING_AST_CODIGO":
            lenguaje_codigo = st.selectbox("lenguaje_codigo (obligatorio para AST)", LENGUAJES_CODIGO, key="ingest_lenguaje_codigo")
            documento_kwargs["lenguaje_codigo"] = lenguaje_codigo

        if st.button("Enviar Ingest (Modo A)", type="primary", key="ingest_enviar_a"):
            if not texto.strip():
                st.error("El campo 'texto' no puede estar vacio.")
            else:
                documento_kwargs["texto"] = texto
                request_kwargs["documento"] = rag_pb2.DocumentoCompleto(**documento_kwargs)
                request = rag_pb2.IngestRequest(**request_kwargs)

                st.text("Solicitud enviada al servidor (protobuf, tal como se construyo antes de serializar):")
                st.code(str(request), language="text")

                try:
                    response = stub.Ingest(request, timeout=int(timeout))
                except grpc.RpcError as error:
                    st.error(f"Error gRPC: codigo={error.code()} detalle={error.details()}")
                else:
                    st.success("IngestResponse recibido")
                    st.table(
                        {
                            "chunks_insertados": [response.chunks_insertados],
                            "chunks_actualizados": [response.chunks_actualizados],
                            "cantidad_ids": [len(response.ids_generados)],
                        }
                    )
                    st.write("ids_generados:", list(response.ids_generados))
                    st.text("Respuesta cruda recibida del servidor (protobuf, tal como llega deserializado):")
                    st.code(str(response), language="text")

    # ---------------------------------------------------------------
    # MODO B: ChunksPreCortados
    # ---------------------------------------------------------------
    else:
        st.caption("Cada fila es un ChunkEntrante. 'id' se autogenera (uuid4) si lo dejas vacio.")

        if "filas_chunks" not in st.session_state:
            st.session_state.filas_chunks = [{"id": "", "texto": "", "metadata": "", "fecha_ingesta": ""}]

        colb1, colb2 = st.columns(2)
        with colb1:
            if st.button("+ Agregar fila", key="agregar_fila"):
                st.session_state.filas_chunks.append({"id": "", "texto": "", "metadata": "", "fecha_ingesta": ""})
        with colb2:
            if st.button("- Quitar ultima fila", key="quitar_fila") and len(st.session_state.filas_chunks) > 1:
                st.session_state.filas_chunks.pop()

        for i, fila in enumerate(st.session_state.filas_chunks):
            st.markdown(f"**Chunk {i + 1}**")
            colf1, colf2 = st.columns([1, 2])
            with colf1:
                fila["id"] = st.text_input(f"id (opcional, autogenera si vacio)", value=fila["id"], key=f"chunk_id_{i}")
                fila["fecha_ingesta"] = st.text_input(
                    "fecha_ingesta (ISO 8601, opcional, autogenera si vacio)",
                    value=fila["fecha_ingesta"],
                    key=f"chunk_fecha_{i}",
                )
                fila["metadata"] = st.text_input(
                    "metadata_adicional (formato clave=valor,clave2=valor2)",
                    value=fila["metadata"],
                    key=f"chunk_meta_{i}",
                    placeholder="alcance=transversal,idioma=es",
                )
            with colf2:
                fila["texto"] = st.text_area("texto", value=fila["texto"], key=f"chunk_texto_{i}", height=100)
            st.divider()

        if st.button("Enviar Ingest (Modo B)", type="primary", key="ingest_enviar_b"):
            chunks_entrantes = []
            error_filas = False
            for i, fila in enumerate(st.session_state.filas_chunks):
                if not fila["texto"].strip():
                    st.error(f"Chunk {i + 1}: el campo 'texto' no puede estar vacio.")
                    error_filas = True
                    continue

                metadata_dict = {}
                if fila["metadata"].strip():
                    try:
                        for par in fila["metadata"].split(","):
                            clave, valor = par.split("=", 1)
                            metadata_dict[clave.strip()] = valor.strip()
                    except ValueError:
                        st.error(f"Chunk {i + 1}: metadata_adicional mal formada, usa clave=valor,clave2=valor2")
                        error_filas = True
                        continue

                chunk_id = fila["id"].strip() or str(uuid.uuid4())

                kwargs_chunk = {"id": chunk_id, "texto": fila["texto"], "metadata_adicional": metadata_dict}
                if fila["fecha_ingesta"].strip():
                    kwargs_chunk["fecha_ingesta"] = fila["fecha_ingesta"].strip()

                chunks_entrantes.append(rag_pb2.ChunkEntrante(**kwargs_chunk))

            if not error_filas and chunks_entrantes:
                request_kwargs["chunks"] = rag_pb2.ChunksPreCortados(chunks=chunks_entrantes)
                request = rag_pb2.IngestRequest(**request_kwargs)

                st.text("Solicitud enviada al servidor (protobuf, tal como se construyo antes de serializar):")
                st.code(str(request), language="text")

                try:
                    response = stub.Ingest(request, timeout=int(timeout))
                except grpc.RpcError as error:
                    st.error(f"Error gRPC: codigo={error.code()} detalle={error.details()}")
                else:
                    st.success("IngestResponse recibido")
                    st.table(
                        {
                            "chunks_insertados": [response.chunks_insertados],
                            "chunks_actualizados": [response.chunks_actualizados],
                            "cantidad_ids": [len(response.ids_generados)],
                        }
                    )
                    st.write("ids_generados:", list(response.ids_generados))
                    st.text("Respuesta cruda recibida del servidor (protobuf, tal como llega deserializado):")
                    st.code(str(response), language="text")

# ===================================================================
# TAB DELETE
# ===================================================================

with tab_delete:
    st.subheader("DeleteRequest")
    st.caption("Se aplica siempre sobre AMBAS colecciones (rapida y precisa), el proto no distingue perfil en Delete.")

    criterio = st.radio(
        "criterio (oneof 'criterio')",
        ["Por id puntual", "Por filtro (categoria / fuente / fecha_antes_de)"],
        key="delete_criterio",
    )

    dry_run = st.checkbox("dry_run (solo contar, no borrar)", value=True, key="delete_dry_run")

    request_kwargs = {"dry_run": dry_run}

    if criterio == "Por id puntual":
        punto_id = st.text_input("id del chunk a borrar", key="delete_id")

        if st.button("Enviar Delete (por id)", type="primary", key="delete_enviar_id"):
            if not punto_id.strip():
                st.error("Debes especificar un id.")
            else:
                request_kwargs["id"] = punto_id.strip()
                request = rag_pb2.DeleteRequest(**request_kwargs)

                st.text("Solicitud enviada al servidor (protobuf, tal como se construyo antes de serializar):")
                st.code(str(request), language="text")

                try:
                    response = stub.Delete(request, timeout=int(timeout))
                except grpc.RpcError as error:
                    st.error(f"Error gRPC: codigo={error.code()} detalle={error.details()}")
                else:
                    etiqueta = "contados (dry_run)" if response.fue_dry_run else "borrados"
                    st.success(f"DeleteResponse recibido - {etiqueta}")
                    st.table(
                        {
                            "chunks_afectados": [response.chunks_afectados],
                            "fue_dry_run": [response.fue_dry_run],
                        }
                    )
                    st.text("Respuesta cruda recibida del servidor (protobuf, tal como llega deserializado):")
                    st.code(str(response), language="text")

    else:
        st.caption("Al menos uno de los tres campos es obligatorio (FiltroDelete no puede estar vacio).")
        colf1, colf2, colf3 = st.columns(3)
        with colf1:
            usar_categoria = st.checkbox("Filtrar por categoria", key="delete_usar_categoria")
            filtro_categoria = st.text_input("categoria", key="delete_filtro_categoria", disabled=not usar_categoria)
        with colf2:
            usar_fuente = st.checkbox("Filtrar por fuente", key="delete_usar_fuente")
            filtro_fuente = st.text_input("fuente", key="delete_filtro_fuente", disabled=not usar_fuente)
        with colf3:
            usar_fecha = st.checkbox("Filtrar por fecha_antes_de", key="delete_usar_fecha")
            filtro_fecha = st.text_input(
                "fecha_antes_de (ISO 8601)",
                key="delete_filtro_fecha",
                placeholder="2026-09-01T00:00:00Z",
                disabled=not usar_fecha,
            )

        if st.button("Enviar Delete (por filtro)", type="primary", key="delete_enviar_filtro"):
            if not (usar_categoria or usar_fuente or usar_fecha):
                st.error("FiltroDelete no puede estar vacio: activa al menos un campo.")
            else:
                filtro_kwargs = {}
                if usar_categoria:
                    if not filtro_categoria.strip():
                        st.error("Activaste el filtro de categoria pero no diste un valor.")
                        st.stop()
                    filtro_kwargs["categoria"] = filtro_categoria.strip()
                if usar_fuente:
                    if not filtro_fuente.strip():
                        st.error("Activaste el filtro de fuente pero no diste un valor.")
                        st.stop()
                    filtro_kwargs["fuente"] = filtro_fuente.strip()
                if usar_fecha:
                    if not filtro_fecha.strip():
                        st.error("Activaste el filtro de fecha pero no diste un valor.")
                        st.stop()
                    filtro_kwargs["fecha_antes_de"] = filtro_fecha.strip()

                request_kwargs["filtro"] = rag_pb2.FiltroDelete(**filtro_kwargs)
                request = rag_pb2.DeleteRequest(**request_kwargs)

                st.text("Solicitud enviada al servidor (protobuf, tal como se construyo antes de serializar):")
                st.code(str(request), language="text")

                try:
                    response = stub.Delete(request, timeout=int(timeout))
                except grpc.RpcError as error:
                    st.error(f"Error gRPC: codigo={error.code()} detalle={error.details()}")
                else:
                    etiqueta = "contados (dry_run)" if response.fue_dry_run else "borrados"
                    st.success(f"DeleteResponse recibido - {etiqueta}")
                    st.table(
                        {
                            "chunks_afectados": [response.chunks_afectados],
                            "fue_dry_run": [response.fue_dry_run],
                        }
                    )
                    st.text("Respuesta cruda recibida del servidor (protobuf, tal como llega deserializado):")
                    st.code(str(response), language="text")
