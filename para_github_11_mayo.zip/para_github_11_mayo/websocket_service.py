#!/usr/bin/env python3
import fastapi
import uvicorn
import json
import base64
import time
import os
import sys
import gc
import re
import asyncio
import queue
import torch
import torchaudio
import numpy as np
from pathlib import Path
from fastapi import WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Generator

# Agregar Fish Speech al path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root / "fish-speech"))

# Configurar para mensajes grandes
app = fastapi.FastAPI()

# Agregar CORS para permitir que HTML local acceda al servidor
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Definir clases para la API
class VoiceRequest(BaseModel):
    text: str
    voz: str
    velocidad: float = 1.0
    chunk_length: int = 150

class VoiceResponse(BaseModel):
    audio: Dict[str, Any]
    metricas: Dict[str, Any]

class ErrorResponse(BaseModel):
    error: str
    tipo: str

# Cargar configuración
with open(project_root / "config" / "config.json", 'r') as f:
    config_data = json.load(f)

# Importar módulos después de la configuración inicial
from fish_speech.models.text2semantic.inference import load_model, launch_thread_safe_queue, GenerateRequest, GenerateResponse, WrappedGenerateResponse
from fish_speech.models.vqgan.inference import load_model as load_decoder_model
from fish_speech.inference_engine import TTSInferenceEngine, InferenceResult
from fish_speech.utils.schema import ServeTTSRequest, ServeReferenceAudio
from fish_speech.conversation import Conversation, Message, TextPart, VQPart
from fish_speech.utils import autocast_exclude_mps, set_seed
from fish_speech.text.clean import clean_text
from fish_speech.text.spliter import split_text

# Variables globales para los modelos y colas
llama_queue = None
decoder_model = None
inference_engine = None
# Caché para referencias de audio
REFERENCE_CACHE = {}

def configurar_optimizaciones():
    """Configura optimizaciones de rendimiento para la inferencia"""
    print("Configurando optimizaciones de GPU...")
    
    # Verificar disponibilidad de CUDA
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name()
        capabilities = torch.cuda.get_device_capability()
        print(f"GPU detectada: {gpu_name} (CUDA {capabilities[0]}.{capabilities[1]})")
        
        # Configurar la arquitectura correcta basada en las capacidades detectadas
        cuda_arch = f"sm_{capabilities[0]}{capabilities[1]}"
        # Solo establecemos la variable de entorno si no está ya configurada
        if "TORCH_CUDA_ARCH_LIST" not in os.environ:
            os.environ["TORCH_CUDA_ARCH_LIST"] = cuda_arch
        
        # Habilitar optimizaciones de CUDA
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True
        
        # Permitir TF32 para matrices grandes
        torch.set_float32_matmul_precision('high')
    else:
        print("ADVERTENCIA: No se detectó GPU con CUDA. El rendimiento será limitado.")
    
    # Configurar procesamiento determinístico para mayor estabilidad
    torch.use_deterministic_algorithms(False)

def inicializar_modelos(compile=True):
    """Inicializa los modelos para inferencia de voz"""
    global llama_queue, decoder_model, inference_engine
    
    print("Inicializando modelos de síntesis de voz...")
    start_time = time.time()
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    precision = torch.float16 if torch.cuda.is_available() else torch.float32
    
    # Inicializar la cola LLAMA con el compilador JIT habilitado
    try:
        print("Inicializando modelo text2semantic...")
        llama_queue = launch_thread_safe_queue(
            checkpoint_path=config_data["model_path"],
            device=device,
            precision=precision,
            compile=compile
        )
    except Exception as e:
        print(f"Error al inicializar con compilación: {e}")
        print("Reintentando sin compilación JIT...")
        compile = False
        llama_queue = launch_thread_safe_queue(
            checkpoint_path=config_data["model_path"],
            device=device,
            precision=precision,
            compile=False
        )
    
    # Cargar el modelo VQGAN
    print("Cargando modelo VQGAN...")
    decoder_model = load_decoder_model(
        config_name="firefly_gan_vq",
        checkpoint_path=os.path.join(config_data["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth"),
        device=device
    )
    
    # Inicializar el motor de inferencia
    inference_engine = TTSInferenceEngine(
        llama_queue=llama_queue,
        decoder_model=decoder_model,
        precision=precision,
        compile=compile
    )
    
    # Realizar un calentamiento inicial para optimizar el rendimiento
    print("Realizando calentamiento inicial...")
    warmup_request = ServeTTSRequest(
        text="Hola, esto es una prueba de calentamiento.",
        chunk_length=150,
        references=[],
        reference_id=None,
        max_new_tokens=1024,
        top_p=0.7,
        repetition_penalty=1.2,
        temperature=0.7,
        streaming=False,
        format="wav",
        use_memory_cache="off"
    )
    
    try:
        list(inference_engine.inference(warmup_request))
    except Exception as e:
        print(f"Advertencia durante el calentamiento: {e}")
        print("El sistema continuará funcionando, pero el primer uso puede ser más lento")
    
    print(f"✅ Modelos inicializados en {time.time() - start_time:.2f} segundos")
    
    # Limpiar caché de memoria después del calentamiento
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        gc.collect()

def get_available_voices():
    """Escanea la carpeta samples para encontrar todas las voces disponibles"""
    samples_dir = os.path.join(project_root, "samples")
    
    # Asegurarse de que la carpeta samples existe
    if not os.path.exists(samples_dir):
        os.makedirs(samples_dir)
        print(f"Carpeta samples creada en: {samples_dir}")
        return []
    
    voices = []
    wav_files = []
    
    # Buscar todos los archivos WAV en la carpeta samples
    for file in os.listdir(samples_dir):
        if file.endswith('.wav'):
            wav_files.append(file)
    
    # Para cada archivo WAV, verificar si tiene su transcripción correspondiente
    for wav_file in wav_files:
        # Obtener el nombre base sin extensión
        voice_name = os.path.splitext(wav_file)[0]
        txt_file = f"{voice_name}.txt"
        txt_path = os.path.join(samples_dir, txt_file)
        
        # Leer transcripción si existe
        transcription = ""
        if os.path.exists(txt_path):
            try:
                with open(txt_path, 'r', encoding='utf-8') as f:
                    transcription = f.read().strip()
            except Exception as e:
                print(f"Error leyendo transcripción para {voice_name}: {e}")
        
        # Crear información de la voz
        voice_info = {
            "name": voice_name,
            "display_name": voice_name.replace('_', ' ').title(),
            "wav_file": wav_file,
            "txt_file": txt_file if os.path.exists(txt_path) else None,
            "transcription": transcription,
            "created_at": time.ctime(os.path.getmtime(os.path.join(samples_dir, wav_file)))
        }
        
        voices.append(voice_info)
    
    print(f"Encontradas {len(voices)} voces en {samples_dir}")
    return voices

def load_reference_text(voice_name):
    """Carga el texto de referencia para una voz específica"""
    samples_dir = os.path.join(project_root, "samples")
    
    try:
        # Buscar el archivo TXT correspondiente
        txt_path = os.path.join(samples_dir, f"{voice_name}.txt")
        
        if os.path.exists(txt_path):
            with open(txt_path, 'r', encoding='utf-8') as f:
                text = f.read().strip()
                print(f"Texto de referencia cargado desde {txt_path}")
                return text
        else:
            print(f"No se encontró archivo de transcripción para {voice_name}")
            # Devolver un texto por defecto si no hay transcripción
            return f"Audio de referencia para {voice_name}"
            
    except Exception as e:
        print(f"Error cargando texto de referencia para {voice_name}: {e}")
        return f"Audio de referencia para {voice_name}"

def load_reference_audio(voice_name):
    """Carga el audio de referencia para una voz específica"""
    global REFERENCE_CACHE
    
    # Si ya está en caché, devolverlo
    if voice_name in REFERENCE_CACHE:
        return REFERENCE_CACHE[voice_name]
    
    # Ruta al archivo de audio específico
    samples_dir = os.path.join(project_root, "samples")
    sample_path = os.path.join(samples_dir, f"{voice_name}.wav")
    
    if not os.path.exists(sample_path):
        raise FileNotFoundError(f"Archivo de audio no encontrado: {sample_path}")
    
    try:
        # Leer el archivo de audio
        with open(sample_path, "rb") as audio_file:
            audio_bytes = audio_file.read()
        
        # Almacenar en caché
        REFERENCE_CACHE[voice_name] = audio_bytes
        
        print(f"Audio de referencia cargado desde {sample_path}")
        return audio_bytes
    except Exception as e:
        print(f"Error cargando audio de referencia para {voice_name}: {e}")
        raise e

async def sintetizar_voz(req: VoiceRequest):
    """Sintetiza voz utilizando el motor de inferencia optimizado"""
    global inference_engine
    
    if inference_engine is None:
        raise Exception("Los modelos no están inicializados")
    
    # Segmentar el texto para procesamiento por lotes
    chunk_length = req.chunk_length if hasattr(req, 'chunk_length') else 150
    text_segments = split_text(req.text, chunk_length)
    
    # Cargar texto de referencia
    prompt_text = load_reference_text(req.voz)
    
    # Cargar audio de referencia
    try:
        audio_bytes = load_reference_audio(req.voz)
    except Exception as e:
        raise Exception(f"Error cargando audio de referencia: {str(e)}")
    
    # Crear referencia para el motor de inferencia
    references = [
        ServeReferenceAudio(
            audio=audio_bytes,
            text=prompt_text
        )
    ]
    
    # Configurar la solicitud
    tts_request = ServeTTSRequest(
        text=" ".join(text_segments),
        references=references,
        reference_id=None,
        max_new_tokens=1024,
        chunk_length=chunk_length,
        top_p=0.7,
        repetition_penalty=1.2,
        temperature=0.7,
        streaming=False,
        format="wav",
        use_memory_cache="on",  # Mantener caché para velocidad
        seed=None
    )
    
    # Establecer semilla para resultados deterministas si se proporciona velocidad como semilla
    if req.velocidad != 1.0:
        tts_request.seed = int(abs(hash(str(req.velocidad))) % 2**31)
    
    # Realizar la inferencia con reintentos
    start_time = time.time()
    
    audio_segments = []
    sample_rate = None
    max_retries = 3
    
    for attempt in range(max_retries):
        try:
            # Obtener resultados de la síntesis
            results = list(inference_engine.inference(tts_request))
            
            audio_segments = []
            for result in results:
                if result.code == "error":
                    if attempt < max_retries - 1:
                        print(f"Error en intento {attempt + 1}, reintentando...")
                        break
                    else:
                        raise Exception(str(result.error))
                elif result.code == "final":
                    sample_rate, audio_data = result.audio
                    audio_segments.append(audio_data)
                elif result.code == "segment":
                    sample_rate, segment_data = result.audio
            
            # Si llegamos aquí sin errores con audio, salir del bucle
            if audio_segments:
                break
            elif attempt < max_retries - 1:
                print(f"No se generó audio en intento {attempt + 1}, reintentando...")
        
        except Exception as e:
            if attempt == max_retries - 1:
                print(f"Error final en síntesis: {e}")
                raise e
            else:
                print(f"Error en intento {attempt + 1}: {e}, reintentando...")
    
    # Combinar segmentos de audio
    if audio_segments:
        # Convertir a numpy array si es necesario
        audio_combined = None
        
        if len(audio_segments) == 1:
            audio_combined = audio_segments[0]
        else:
            audio_combined = np.concatenate(audio_segments, axis=0)
        
        # Verificar que el audio no esté vacío
        if audio_combined.size == 0:
            raise Exception("Audio generado está vacío")
        
        # Asegurarse de que el audio tenga el formato correcto
        if audio_combined.dtype != np.float32:
            audio_combined = audio_combined.astype(np.float32)
        
        # Normalizar audio si es necesario
        if audio_combined.max() != 0:
            audio_combined = audio_combined / np.max(np.abs(audio_combined)) * 0.9
        
        # Ajustar velocidad si es necesario
        if req.velocidad != 1.0:
            import librosa
            audio_combined = librosa.effects.time_stretch(audio_combined, rate=1.0/req.velocidad)
        
        # Calcular métricas
        synthesis_time = time.time() - start_time
        audio_duration = len(audio_combined) / sample_rate
        
        # Convertir a base64 con formato WAV correcto
        import io
        import soundfile as sf
        
        # Crear buffer para el audio
        buffer = io.BytesIO()
        
        # Asegurarse de que el sample_rate sea entero
        sample_rate_int = int(sample_rate) if sample_rate is not None else 24000
        
        # Escribir audio en formato WAV al buffer
        sf.write(buffer, audio_combined, sample_rate_int, format='WAV', subtype='PCM_16')
        
        # Obtener bytes del audio
        buffer.seek(0)
        audio_bytes = buffer.getvalue()
        
        # Codificar a base64
        audio_base64 = base64.b64encode(audio_bytes).decode('utf-8')
        
        # Verificar que la codificación fue exitosa
        if not audio_base64:
            raise Exception("Fallo al codificar audio a base64")
        
        # Debug: verificar el formato del base64
        print(f"Debug - Base64 generado: length={len(audio_base64)}, start='{audio_base64[:20]}', end='{audio_base64[-20:]}'")
        
        # Validar que el base64 solo contiene caracteres válidos
        import re
        if not re.match(r'^[A-Za-z0-9+/=]*$', audio_base64):
            print("⚠️ ADVERTENCIA: Base64 contiene caracteres inválidos!")
            # Limpiar caracteres inválidos
            audio_base64 = re.sub(r'[^A-Za-z0-9+/=]', '', audio_base64)
            print(f"Base64 limpiado: length={len(audio_base64)}")
        
        # Construir respuesta
        audio_info = {
            "base64": audio_base64,
            "formato": "wav",
            "sample_rate": sample_rate_int,
            "channels": 1,
            "duration": audio_duration,
            "size_bytes": len(audio_bytes)
        }
        
        metrics = {
            "synthesis_time": synthesis_time,
            "text_length": len(req.text),
            "audio_duration": audio_duration,
            "real_time_factor": audio_duration / synthesis_time,
            "voice_used": req.voz,
            "velocidad": req.velocidad,
            "audio_size_bytes": len(audio_bytes),
            "attempts": attempt + 1
        }
        
        print(f"✅ Audio generado exitosamente: {audio_duration:.2f}s, {len(audio_bytes)} bytes")
        
        return audio_info, metrics
    else:
        raise Exception("No se generó audio después de todos los intentos")

@app.get("/voices")
async def get_voices():
    """Devuelve la lista de voces disponibles"""
    try:
        voices = get_available_voices()
        
        if not voices:
            # Si no hay voces, crear una instrucción para el usuario
            return {
                "voices": [],
                "instructions": "Para agregar voces, coloca archivos .wav y sus transcripciones .txt correspondientes en la carpeta samples/. Por ejemplo: mi_voz.wav y mi_voz.txt"
            }
        
        return {"voices": voices}
    except Exception as e:
        print(f"Error al cargar voces: {e}")
        raise HTTPException(status_code=500, detail=f"Error al cargar voces: {str(e)}")

@app.websocket("/synthesize")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    try:
        while True:
            # Recibir mensaje JSON
            try:
                data = await websocket.receive_json()
                request = VoiceRequest(**data)
                
                # Verificar valores
                if not request.text.strip():
                    raise ValueError("El texto no puede estar vacío")
                
                if request.velocidad < 0.5 or request.velocidad > 2.0:
                    print(f"Advertencia: velocidad {request.velocidad} fuera del rango recomendado (0.5-2.0)")
                
                # Sintetizar voz
                try:
                    audio_info, metrics = await sintetizar_voz(request)
                    
                    # Log info de audio antes de enviar
                    print(f"📤 Enviando audio: {metrics['audio_size_bytes']} bytes, {metrics['audio_duration']:.2f}s")
                    
                    # Enviar respuesta con información de éxito
                    response = {
                        "audio": audio_info,
                        "metricas": metrics,
                        "status": "success"
                    }
                    
                    await websocket.send_json(response)
                    
                except Exception as e:
                    import traceback
                    print(f"Error en síntesis: {str(e)}")
                    print(traceback.format_exc())
                    
                    await websocket.send_json({
                        "error": str(e),
                        "tipo": type(e).__name__,
                        "status": "error"
                    })
                    
            except json.JSONDecodeError:
                await websocket.send_json({
                    "error": "El mensaje recibido no es un JSON válido",
                    "tipo": "JSONDecodeError",
                    "status": "error"
                })
            except Exception as e:
                await websocket.send_json({
                    "error": str(e),
                    "tipo": type(e).__name__,
                    "status": "error"
                })
                
    except WebSocketDisconnect:
        print("Cliente desconectado")

@app.on_event("startup")
async def startup_event():
    """Evento de inicio del servidor"""
    try:
        # Configurar optimizaciones de GPU
        configurar_optimizaciones()
        
        # Inicializar modelos con compilación
        inicializar_modelos(compile=True)
        
        # Cargar y mostrar voces disponibles al inicio
        voices = get_available_voices()
        if voices:
            print(f"\n🎤 Voces disponibles ({len(voices)}):")
            for voice in voices:
                print(f"  - {voice['display_name']} ({voice['name']})")
        else:
            print("\n⚠️ No hay voces disponibles. Coloque archivos .wav y .txt en la carpeta samples/")
        
    except Exception as e:
        print(f"Error durante la inicialización: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Configurar servidor Uvicorn
    uvicorn_config = uvicorn.Config(
        app, 
        host="0.0.0.0", 
        port=8000,
        ws_max_size=16777216,  # 16MB límite para mensajes WebSocket
        log_level="info"
    )
    server = uvicorn.Server(uvicorn_config)
    server.run()
