#!/bin/bash
set -e

PORT="${PORT:-50051}"
TTS_PRECISION="${TTS_PRECISION:-bf16}"

if [ -n "$CUDA_VISIBLE_DEVICES" ]; then
    echo "[entrypoint] Using GPU device(s): $CUDA_VISIBLE_DEVICES"
else
    echo "[entrypoint] CUDA_VISIBLE_DEVICES not set — using all available GPUs"
fi

echo "[entrypoint] Precision: ${TTS_PRECISION} (set TTS_PRECISION=fp16 for lower-VRAM GPUs, bf16 for H200 NVL)"
echo "[entrypoint] Starting S2-Pro TTS gRPC service on port ${PORT}..."

export PYTHONPATH="/app"

exec /app/.venv/bin/python /app/server.py \
    --port "${PORT}" \
    --config /app/config_tts.json
