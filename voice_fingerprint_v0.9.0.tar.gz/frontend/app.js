import { Grabadora, crearMedidor } from "./grabadora.js";
import {
  ESTADOS_UMBRAL, crearHuellas, dibujarEspectrograma, dibujarLineaTiempo, dibujarMapa, dibujarRecursos, dibujarUmbral,
  fmtDuracion, fmtMs,
} from "./graficos.js";

const $ = (id) => document.getElementById(id);
const fmt = (n, d = 2) => (n === null || n === undefined || Number.isNaN(n)) ? "—"
  : Number(n).toLocaleString("es-CO", { minimumFractionDigits: d, maximumFractionDigits: d });
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// El medidor del navegador es una estimación; se deja margen sobre el mínimo del servidor (3 s).
const MINIMO_VOZ_VALIDACION = 3.5;
const MAX_SEGUNDOS_VALIDACION = 12;
const MINIMO_VOZ_REGISTRO = 4;
const MAX_SEGUNDOS_REGISTRO = 15;
const MINIMO_VOZ_UMBRAL = 1;          // "Detener" se activa con 1 s de voz (estimación del navegador)
const MAX_SEGUNDOS_UMBRAL = 30;

const ICONOS = {
  ok: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m7.5 12.5 3 3 6-6.5"/></svg>`,
  alerta: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 7v6"/><circle cx="12" cy="16.8" r=".6" fill="currentColor"/></svg>`,
  error: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="m8.5 8.5 7 7m0-7-7 7"/></svg>`,
};

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------

async function pedir(ruta, opciones = {}) {
  const r = await fetch(ruta, opciones);
  let datos = null;
  try { datos = await r.json(); } catch { /* respuesta sin cuerpo */ }
  if (!r.ok) throw new Error((datos && (datos.detalle || datos.detail)) || `Error ${r.status} del servicio.`);
  return datos;
}

// ---------------------------------------------------------------------------
// Pestañas y estado del servicio
// ---------------------------------------------------------------------------

const pestanas = [...document.querySelectorAll('[role="tab"]')];
pestanas.forEach((tab) => tab.addEventListener("click", () => mostrar(tab.id.replace("tab-", ""))));

function mostrar(nombre) {
  if (grabacionActiva) grabacionActiva.cancelarControlada();
  pestanas.forEach((t) => t.setAttribute("aria-selected", String(t.id === `tab-${nombre}`)));
  document.querySelectorAll(".vista").forEach((v) => { v.hidden = v.id !== `vista-${nombre}`; });
  if (nombre === "personas") cargarPersonas();
  if (nombre === "umbral") cargarHistorialUmbral();
  if (nombre === "recursos") abrirRecursos(); else cerrarRecursos();
}

let eliminacionHabilitada = false;

async function estadoServicio() {
  try {
    const s = await pedir("/api/salud");
    eliminacionHabilitada = s.eliminacion_habilitada;
    const sync = s.sincronizacion;
    $("estado-servicio").textContent = sync.en_curso
      ? `Sincronizando referencias${sync.total ? ` (${sync.hechos} de ${sync.total})` : ""}…`
      : `${s.personas} personas registradas · ${s.vad_nombre} · ${Object.values(s.dispositivos || {}).includes("cuda") ? "GPU" : "CPU"}`;
    $("estado-servicio").title = (s.avisos_dispositivo || []).join("\n");
  } catch {
    $("estado-servicio").textContent = "Sin conexión con el servicio";
  }
}
estadoServicio();
setInterval(estadoServicio, 5000);

// Grabación con el botón Detener inactivo hasta alcanzar el mínimo de voz.
// Junto a él aparece "Cancelar", disponible en todo momento (también con Esc):
// descarta el audio sin enviarlo y llama a alCancelar para restaurar la pantalla.
let grabacionActiva = null;   // la grabación en curso, para cancelarla al cambiar de pestaña

function iniciarGrabacionControlada({ boton, medidor, minimoVoz, maxSegundos, textoDetener, alTerminar, alCancelar }) {
  medidor.hidden = false;
  const pintar = crearMedidor(medidor, { minimoVoz, maxSegundos });
  let listo = false;
  const grabadora = new Grabadora({
    maxSegundos,
    alActualizar: (estado) => {
      pintar(estado);
      if (!listo && estado.segundosVoz >= minimoVoz) {
        listo = true;
        boton.disabled = false;
        boton.textContent = textoDetener;
      }
    },
  });
  grabadora.alLimite = () => { if (grabadora.grabando) alTerminar(grabadora); };

  const botonCancelar = document.createElement("button");
  botonCancelar.type = "button";
  botonCancelar.className = "boton boton-secundario";
  botonCancelar.textContent = "Cancelar";
  botonCancelar.title = "Descarta esta grabación (Esc)";
  boton.after(botonCancelar);

  const cancelar = () => {
    if (!grabadora.activa) return;
    grabadora.cancelar();
    medidor.hidden = true;
    alCancelar();
  };
  const alTecla = (e) => { if (e.key === "Escape") { e.preventDefault(); cancelar(); } };
  botonCancelar.addEventListener("click", cancelar);
  document.addEventListener("keydown", alTecla);
  grabadora.cancelarControlada = cancelar;
  grabadora.alFinalizar = () => {          // al detener o al cancelar
    botonCancelar.remove();
    document.removeEventListener("keydown", alTecla);
    boton.classList.remove("grabando");
    if (grabacionActiva === grabadora) grabacionActiva = null;
  };
  grabacionActiva = grabadora;

  boton.disabled = true;
  boton.textContent = "Siga hablando…";
  boton.classList.add("grabando");
  return grabadora;
}

// ---------------------------------------------------------------------------
// Validar identidad
// ---------------------------------------------------------------------------

let desafio = null;
let relojDesafio = null;
let grabadoraValidacion = null;
let ultimoMapaValidacion = null;
const actualizarHuellas = crearHuellas($("huellas"));

$("btn-desafio").addEventListener("click", pedirDesafio);
$("btn-grabar-validacion").addEventListener("click", alternarGrabacionValidacion);
$("btn-nueva").addEventListener("click", () => { reiniciarValidacion(); pedirDesafio(); });
$("nombres-validar").addEventListener("change", () => { if (ultimoMapaValidacion) pintarMapaValidacion(); });

function reiniciarValidacion() {
  $("resultado").hidden = true;
  $("digitos").innerHTML = "";
  $("digitos").classList.remove("vencido");
  $("desafio-vigencia").textContent = "";
  $("desafio-guia").textContent = "Para validar una identidad, pida unos números al azar. La persona dirá su nombre completo y luego esos números, uno por uno.";
  $("medidor-validacion").hidden = true;
  const grabar = $("btn-grabar-validacion");
  grabar.disabled = true;
  grabar.textContent = "Grabar respuesta";
  grabar.classList.remove("grabando");
  $("btn-desafio").disabled = false;
  $("btn-desafio").textContent = "Pedir números";
  $("btn-desafio").className = "boton boton-principal";
  clearInterval(relojDesafio);
  desafio = null;
}

async function pedirDesafio() {
  try {
    reiniciarValidacion();
    desafio = await pedir("/api/desafio", { method: "POST" });
    desafio.expira = Date.now() + desafio.vigencia_s * 1000;
    $("digitos").innerHTML = [...desafio.digitos]
      .map((d) => `<li><span class="digito-pedido">${d}</span><span class="digito-oido"></span></li>`).join("");
    $("desafio-guia").textContent = "Diga su nombre completo y luego estos números, uno por uno:";
    $("btn-grabar-validacion").disabled = false;
    $("btn-desafio").textContent = "Pedir otros números";
    $("btn-desafio").className = "boton boton-secundario";
    $("btn-grabar-validacion").focus();
    actualizarVigencia();
    relojDesafio = setInterval(actualizarVigencia, 1000);
  } catch (e) {
    $("desafio-guia").textContent = e.message;
  }
}

function actualizarVigencia() {
  if (!desafio) return;
  const restante = Math.max(0, Math.round((desafio.expira - Date.now()) / 1000));
  if (restante === 0 && !grabadoraValidacion) {
    clearInterval(relojDesafio);
    $("digitos").classList.add("vencido");
    $("desafio-vigencia").textContent = "Estos números vencieron. Pida otros.";
    $("btn-grabar-validacion").disabled = true;
    return;
  }
  const m = Math.floor(restante / 60), s = String(restante % 60).padStart(2, "0");
  $("desafio-vigencia").textContent = `Vigentes por ${m}:${s}`;
}

async function alternarGrabacionValidacion() {
  const boton = $("btn-grabar-validacion");
  if (!grabadoraValidacion) {
    grabadoraValidacion = iniciarGrabacionControlada({
      boton, medidor: $("medidor-validacion"), minimoVoz: MINIMO_VOZ_VALIDACION, maxSegundos: MAX_SEGUNDOS_VALIDACION,
      textoDetener: "Detener y validar", alTerminar: () => alternarGrabacionValidacion(),
      alCancelar: cancelarGrabacionValidacion,
    });
    try {
      await grabadoraValidacion.iniciar();
    } catch (e) {
      if (e.name === "GrabacionCancelada") return;
      grabadoraValidacion = null;
      reiniciarBotonGrabar(boton);
      $("medidor-validacion").hidden = true;
      $("desafio-guia").textContent = "No se pudo usar el micrófono. Revise que el navegador tenga permiso para usarlo.";
      return;
    }
    $("btn-desafio").disabled = true;
    return;
  }
  const grabadora = grabadoraValidacion;
  if (!grabadora.grabando) return;
  boton.disabled = true;
  boton.textContent = "Analizando la voz…";
  boton.classList.remove("grabando");
  const { blob } = await grabadora.detener();
  grabadoraValidacion = null;
  clearInterval(relojDesafio);
  $("desafio-vigencia").textContent = "";
  try {
    const datos = new FormData();
    datos.append("audio", blob, "respuesta.wav");
    datos.append("desafio_id", desafio.id);
    const r = await pedir("/api/validar", { method: "POST", body: datos });
    await mostrarResultado(r);
  } catch (e) {
    $("desafio-guia").textContent = e.message;
    $("btn-desafio").disabled = false;
  } finally {
    boton.textContent = "Grabar respuesta";
    boton.disabled = true;
  }
}

// Vuelve al estado previo a grabar. El desafío sigue vigente: solo se gasta al validar.
function cancelarGrabacionValidacion() {
  grabadoraValidacion = null;
  reiniciarBotonGrabar($("btn-grabar-validacion"));
  $("btn-desafio").disabled = false;
  $("desafio-guia").textContent = "Grabación cancelada. Puede grabar de nuevo con los mismos números o pedir otros.";
  actualizarVigencia();
  $("btn-grabar-validacion").focus();
}

function reiniciarBotonGrabar(boton, texto = "Grabar respuesta") {
  boton.disabled = false;
  boton.textContent = texto;
  boton.classList.remove("grabando");
}

const VEREDICTOS = {
  validado: { tono: "ok", titulo: (r) => `Identidad validada: ${r.identificacion.candidatos[0].nombre}` },
  rechazado_prueba_de_vida: { tono: "error", titulo: () => "Rechazado: los números no coinciden" },
  no_concluyente: { tono: "alerta", titulo: () => "No concluyente" },
  no_identificado: { tono: "error", titulo: () => "Voz no registrada" },
  muestra_insuficiente: { tono: "alerta", titulo: () => "Muestra insuficiente" },
};

async function mostrarResultado(r) {
  const v = VEREDICTOS[r.veredicto];
  $("veredicto").className = `veredicto ${v.tono}`;
  $("veredicto-icono").innerHTML = ICONOS[v.tono];
  $("veredicto-titulo").textContent = v.titulo(r);
  $("veredicto-mensaje").textContent = r.mensaje;
  $("resultado").hidden = false;
  $("desafio-guia").textContent = "Números pedidos y, debajo, lo que se oyó:";
  $("btn-desafio").disabled = false;

  const completo = r.veredicto !== "muestra_insuficiente";
  ["capas", "tiempos", "panel-espectro", "panel-huellas", "panel-perfil"].forEach((id) => { $(id).hidden = !completo; });
  $("mapa-validar").closest(".panel").hidden = !completo;
  if (!completo) { $("veredicto").scrollIntoView({ behavior: "smooth", block: "start" }); return; }

  marcarDigitos(r.prueba_de_vida);
  pintarCapaVida(r.prueba_de_vida);
  pintarCapaIdentidad(r.identificacion);
  dibujarEspectrograma($("espectrograma"), r.muestra.espectrograma,
    { pedidos: r.prueba_de_vida.pedidos, oidos: r.prueba_de_vida.digitos_oidos });
  pintarHuellas(r);
  pintarPerfil(r);
  $("tiempos").textContent = `Validación completa en ${fmt(r.tiempos.total_s)} s, con ${fmt(r.voz_neta_s, 1)} s de voz.`;
  $("veredicto").scrollIntoView({ behavior: "smooth", block: "start" });

  try {
    ultimoMapaValidacion = { mapa: await pedir("/api/mapa"), r };
    pintarMapaValidacion();
  } catch { $("mapa-validar").innerHTML = `<p class="vacio">No se pudo cargar el mapa.</p>`; }
}

function pintarMapaValidacion() {
  const { mapa, r } = ultimoMapaValidacion;
  dibujarMapa($("mapa-validar"), mapa, {
    muestra: r.muestra.posicion_mapa,
    similitudes: r.muestra.similitudes,
    destacados: r.identificacion.candidatos.map((c) => c.persona_id),
    todosLosNombres: $("nombres-validar").checked,
  });
}

function marcarDigitos(vida) {
  const items = [...$("digitos").children];
  const oidos = vida.digitos_oidos || "";
  const alineados = oidos.length === vida.pedidos.length;
  items.forEach((li, i) => {
    const oido = alineados ? oidos[i] : "";
    li.querySelector(".digito-oido").textContent = alineados ? oido : "";
    li.classList.toggle("acierto", alineados ? oido === vida.pedidos[i] : vida.aprobada);
    li.classList.toggle("fallo", alineados ? oido !== vida.pedidos[i] : !vida.aprobada);
  });
  if (!alineados) {
    $("desafio-vigencia").textContent = `Se oyó: ${oidos ? [...oidos].join(" ") : "ningún número"}`;
  }
}

function estadoCapa(tono, texto) {
  return `<p class="estado-capa ${tono}">${ICONOS[tono]}<span>${esc(texto)}</span></p>`;
}

function pintarCapaVida(vida) {
  $("capa-vida").innerHTML = `
    ${estadoCapa(vida.aprobada ? "ok" : "error", vida.aprobada ? "Aprobada" : "No aprobada")}
    <p class="dato"><span>Números pedidos</span><span>${[...vida.pedidos].join(" ")}</span></p>
    <p class="dato"><span>Números oídos</span><span>${vida.digitos_oidos ? [...vida.digitos_oidos].join(" ") : "ninguno"}</span></p>
    <p class="dato"><span>Diferencias</span><span>${vida.errores} (se admite ${vida.errores_permitidos})</span></p>
    <p class="dato"><span>Transcripción</span><span>«${esc(vida.transcripcion)}»</span></p>`;
}

function pintarCapaIdentidad(id) {
  const u = id.umbrales;
  const tono = { identificado: "ok", no_concluyente: "alerta", no_identificado: "error" }[id.resultado];
  const texto = {
    identificado: `Coincide con ${id.candidatos[0].nombre}`,
    no_concluyente: "No es posible confirmarla",
    no_identificado: "No coincide con nadie registrado",
  }[id.resultado];
  const pct = (x) => `${Math.max(0, Math.min(1, x)) * 100}%`;
  const filas = id.candidatos.map((c, i) => `
    <div class="candidato${i === 0 ? " primero" : ""}">
      <span class="candidato-nombre" title="${esc(c.nombre)}">${esc(c.nombre)}</span>
      <span class="pista" aria-hidden="true">
        <span class="zona-gris" style="left:${pct(u.bajo)};width:${pct(u.alto - u.bajo)}"></span>
        <span class="zona-ok" style="width:${pct(1 - u.alto)}"></span>
        <span class="relleno" style="width:${pct(c.score)}"></span>
      </span>
      <span class="candidato-score">${fmt(c.score, 2)}</span>
    </div>`).join("");
  $("capa-identidad").innerHTML = `
    ${estadoCapa(tono, texto)}
    <div class="candidatos" aria-label="Las tres personas más parecidas">${filas}
      <div class="escala" aria-hidden="true"><span></span>
        <span class="escala-marcas"><span style="left:0">0</span><span style="left:${pct(u.bajo)}">${fmt(u.bajo, 2)}</span>
          <span style="left:${pct(u.alto)}">${fmt(u.alto, 2)}</span><span style="left:100%">1</span></span><span></span>
      </div>
    </div>
    <p class="nota">Por encima de ${fmt(u.alto, 2)} la coincidencia es clara; entre ${fmt(u.bajo, 2)} y ${fmt(u.alto, 2)} se pide repetir.</p>
    <p class="dato"><span>Ventaja sobre el segundo</span><span>${fmt(id.margen, 2)} (mínimo ${fmt(u.margen_minimo, 2)})</span></p>`;
}

function pintarHuellas(r) {
  const cand = r.mejor_candidato;
  $("huella-etiqueta-candidato").textContent = cand ? cand.nombre : "Candidato";
  $("huella-etiqueta-candidato").title = cand ? cand.nombre : "";
  const similitud = actualizarHuellas(r.muestra.huella, cand && cand.plantilla, cand && cand.nombre);
  $("huella-similitud").textContent = cand
    ? `En la franja de aporte, cada barra hacia arriba es una posición donde las dos huellas van en la misma dirección y suman parecido; hacia abajo, restan. La suma de todos los aportes es la similitud entre las dos huellas: ${fmt(similitud, 2)} (1 sería idénticas).`
    : "";
}

// ---------------------------------------------------------------------------
// Perfil acústico con ayudas y escalas de referencia
// ---------------------------------------------------------------------------

const CAMPOS_PERFIL = [
  ["Tono mediano (Hz)", "La frecuencia típica a la que vibran las cuerdas vocales al hablar. Depende sobre todo de su tamaño y tensión: cuerdas más largas y gruesas dan voces más graves.",
    (p) => fmt(p.f0_mediana_hz, 0)],
  ["Rango de tono (Hz)", "Entre qué tonos se mueve la voz al hablar, del 5 % más grave al 5 % más agudo. Refleja la entonación.",
    (p) => p.f0_p5_hz != null ? `${fmt(p.f0_p5_hz, 0)} a ${fmt(p.f0_p95_hz, 0)}` : "—"],
  ["Formante 1 (Hz)", "Primera resonancia de la garganta y la boca. Sube cuando la boca se abre más, como en la a.",
    (p) => fmt(p.f1_hz, 0)],
  ["Formante 2 (Hz)", "Segunda resonancia. Depende de la posición de la lengua: es más alta en vocales como la i y más baja en la u.",
    (p) => fmt(p.f2_hz, 0)],
  ["Formante 3 (Hz)", "Tercera resonancia. Varía poco entre vocales y se relaciona con el tamaño del tracto vocal, por eso es bastante personal.",
    (p) => fmt(p.f3_hz, 0)],
  ["Longitud del tracto vocal (cm)", "Distancia estimada desde las cuerdas vocales hasta los labios, calculada a partir de la separación entre los formantes. Es aproximada.",
    (p) => fmt(p.tracto_vocal_cm, 1)],
  ["Armonicidad (dB)", "Qué tan limpia es la voz: cuánto sonido armónico hay frente al ruido de aire. Más alta, voz más clara; más baja, voz más ronca o soplada.",
    (p) => fmt(p.hnr_db, 1)],
  ["Variación de periodo, jitter (%)", "Cuánto cambia la duración de cada ciclo de vibración respecto al siguiente. En habla continua sale más alto que en una vocal sostenida; aquí se compara entre muestras.",
    (p) => fmt(p.jitter_pct, 2)],
  ["Variación de amplitud, shimmer (%)", "Cuánto cambia la intensidad de cada ciclo respecto al siguiente. Igual que el jitter, sirve para comparar muestras entre sí, no contra normas clínicas.",
    (p) => fmt(p.shimmer_pct, 2)],
];

function pintarPerfil(r) {
  const pm = r.muestra.perfil || {};
  const cand = r.mejor_candidato;
  const pc = (cand && cand.perfil) || {};
  $("tabla-perfil").innerHTML = `
    <thead><tr><th>Medida</th><th>Muestra</th><th>${esc(cand ? cand.nombre : "Candidato")}</th></tr></thead>
    <tbody>${CAMPOS_PERFIL.map(([nombre, ayuda, f], i) => `<tr>
      <td><span class="medida">${nombre}
        <span class="ayuda"><button class="ayuda-boton" type="button" aria-label="Qué es: ${esc(nombre)}" aria-describedby="ayuda-${i}">i</button>
          <span class="ayuda-texto" role="tooltip" id="ayuda-${i}">${esc(ayuda)}</span></span></span></td>
      <td>${f(pm)}</td><td>${f(pc)}</td></tr>`).join("")}</tbody>`;

  const nombre = cand ? cand.nombre : null;
  escalaReferencia($("escala-tono"), {
    titulo: "Tono mediano", unidad: "Hz", min: 60, max: 300, decimales: 0, ticks: [100, 150, 200, 250],
    bandas: [{ clase: "hombres", desde: 85, hasta: 155, etiqueta: "Hombres: 85 a 155 Hz" },
             { clase: "mujeres", desde: 165, hasta: 255, etiqueta: "Mujeres: 165 a 255 Hz" }],
    muestra: pm.f0_mediana_hz, candidato: pc.f0_mediana_hz, nombre,
  });
  escalaReferencia($("escala-tracto"), {
    titulo: "Longitud del tracto vocal", unidad: "cm", min: 11, max: 21, decimales: 1, ticks: [12, 14, 16, 18, 20],
    bandas: [{ clase: "mujeres", desde: 13.5, hasta: 15.5, etiqueta: "Mujeres: ≈ 14 a 15 cm" },
             { clase: "hombres", desde: 16, hasta: 18.5, etiqueta: "Hombres: ≈ 16 a 18 cm" }],
    muestra: pm.tracto_vocal_cm, candidato: pc.tracto_vocal_cm, nombre,
  });
}

function escalaReferencia(cont, o) {
  const pos = (v) => `${(Math.max(o.min, Math.min(o.max, v)) - o.min) / (o.max - o.min) * 100}%`;
  const marca = (clase, valor, etiqueta) => valor == null ? "" :
    `<span class="escala-ref-marca ${clase}" style="left:${pos(valor)}">${esc(etiqueta)}: ${fmt(valor, o.decimales)} ${o.unidad}</span>`;
  cont.innerHTML = `
    <div class="escala-ref">
      <span class="escala-ref-titulo">${o.titulo}</span>
      <div class="escala-ref-pista" role="img" aria-label="${esc(o.titulo)}: muestra ${o.muestra != null ? fmt(o.muestra, o.decimales) : "sin dato"} ${o.unidad}">
        <div class="escala-ref-eje"></div>
        ${o.bandas.map((b) => `<div class="escala-ref-banda ${b.clase}" style="left:${pos(b.desde)};width:calc(${pos(b.hasta)} - ${pos(b.desde)})">${b.etiqueta}</div>`).join("")}
        <div class="escala-ref-ticks">${o.ticks.map((t) => `<span style="left:${pos(t)}">${fmt(t, 0)}</span>`).join("")}</div>
        ${marca("candidato", o.candidato, o.nombre || "Candidato")}
        ${marca("muestra", o.muestra, "Muestra")}
      </div>
    </div>`;
}

// ---------------------------------------------------------------------------
// Registrar voz
// ---------------------------------------------------------------------------

const TEMAS = [
  "Cuente qué hizo el fin de semana pasado.",
  "Describa el camino de su casa al trabajo.",
  "Hable de su comida favorita y de cómo se prepara.",
  "Cuente cómo fue su primer día en un trabajo.",
  "Describa el lugar donde creció.",
  "Hable de un viaje que recuerde con gusto.",
];

const grabaciones = [];

function prepararRegistro() {
  const temas = [...TEMAS].sort(() => Math.random() - 0.5);
  const pasos = [
    { titulo: "Hable libremente", indicacion: `${temas[0]} Hable con naturalidad unos 10 segundos.` },
    { titulo: "Otro tema", indicacion: `${temas[1]} De nuevo, unos 10 segundos.` },
    { titulo: "Nombre y números", indicacion: "Diga su nombre completo y luego cuente del uno al diez, a su ritmo normal." },
  ];
  grabaciones.length = 0;
  $("grabaciones").innerHTML = pasos.map((p, i) => `
    <li class="grabacion" id="grabacion-${i}">
      <h3>${p.titulo}</h3>
      <p class="grabacion-indicacion">${p.indicacion}</p>
      <div class="grabacion-botones"><button class="boton boton-grabar" data-indice="${i}">Grabar</button></div>
      <div class="medidor" hidden></div>
      <audio controls hidden></audio>
      <p class="grabacion-estado" aria-live="polite"></p>
    </li>`).join("");
  $("grabaciones").querySelectorAll(".boton-grabar").forEach((b) => b.addEventListener("click", () => alternarGrabacionRegistro(Number(b.dataset.indice))));
  actualizarBotonRegistro();
}

let grabadoraRegistro = null;
let indiceGrabando = null;

async function alternarGrabacionRegistro(i) {
  const item = $(`grabacion-${i}`);
  const boton = item.querySelector(".boton-grabar");
  const estado = item.querySelector(".grabacion-estado");
  if (grabadoraRegistro === null) {
    grabadoraRegistro = iniciarGrabacionControlada({
      boton, medidor: item.querySelector(".medidor"), minimoVoz: MINIMO_VOZ_REGISTRO, maxSegundos: MAX_SEGUNDOS_REGISTRO,
      textoDetener: "Detener", alTerminar: () => alternarGrabacionRegistro(i),
      alCancelar: () => cancelarGrabacionRegistro(i),
    });
    try {
      await grabadoraRegistro.iniciar();
    } catch (e) {
      if (e.name === "GrabacionCancelada") return;
      grabadoraRegistro = null;
      reiniciarBotonGrabar(boton, "Grabar");
      estado.textContent = "No se pudo usar el micrófono. Revise el permiso del navegador.";
      estado.classList.add("error");
      return;
    }
    indiceGrabando = i;
    $("grabaciones").querySelectorAll(".boton-grabar").forEach((b) => { if (b !== boton) b.disabled = true; });
    estado.textContent = "";
    return;
  }
  if (indiceGrabando !== i || !grabadoraRegistro.grabando) return;
  const { blob, segundosVoz } = await grabadoraRegistro.detener();
  grabadoraRegistro = null;
  indiceGrabando = null;
  reiniciarBotonGrabar(boton, "Grabar de nuevo");
  $("grabaciones").querySelectorAll(".boton-grabar").forEach((b) => { b.disabled = false; });
  const audio = item.querySelector("audio");
  audio.src = URL.createObjectURL(blob);
  audio.hidden = false;
  if (segundosVoz < MINIMO_VOZ_REGISTRO) {
    grabaciones[i] = null;
    item.classList.remove("lista");
    estado.textContent = `Se captaron ${fmt(segundosVoz, 1)} s de voz; hacen falta al menos ${MINIMO_VOZ_REGISTRO}. Grábela de nuevo.`;
    estado.classList.add("error");
  } else {
    grabaciones[i] = blob;
    item.classList.add("lista");
    estado.textContent = `Lista: ${fmt(segundosVoz, 1)} s de voz.`;
    estado.classList.remove("error");
  }
  actualizarBotonRegistro();
}

// Descarta la grabación en curso; si el paso ya tenía una grabación válida, se conserva.
function cancelarGrabacionRegistro(i) {
  const item = $(`grabacion-${i}`);
  const estado = item.querySelector(".grabacion-estado");
  grabadoraRegistro = null;
  indiceGrabando = null;
  reiniciarBotonGrabar(item.querySelector(".boton-grabar"), grabaciones[i] ? "Grabar de nuevo" : "Grabar");
  $("grabaciones").querySelectorAll(".boton-grabar").forEach((b) => { b.disabled = false; });
  estado.classList.remove("error");
  estado.textContent = grabaciones[i] ? "Grabación cancelada; se conserva la anterior." : "Grabación cancelada.";
  item.querySelector(".boton-grabar").focus();
}

function actualizarBotonRegistro() {
  const completo = $("reg-nombre").value.trim() && $("reg-consentimiento").checked
    && grabaciones.filter(Boolean).length === 3;
  $("btn-registrar").disabled = !completo;
}
["reg-nombre", "reg-consentimiento"].forEach((id) => $(id).addEventListener("input", actualizarBotonRegistro));

$("btn-registrar").addEventListener("click", async () => {
  const estado = $("registro-estado");
  const boton = $("btn-registrar");
  boton.disabled = true;
  estado.className = "registro-estado";
  estado.textContent = "Registrando la voz y calculando su huella…";
  try {
    const datos = new FormData();
    datos.append("nombre", $("reg-nombre").value.trim());
    datos.append("origen", $("reg-origen").value.trim());
    datos.append("consentimiento", "true");
    grabaciones.forEach((g, i) => datos.append("grabaciones", g, `grabacion_${i + 1}.wav`));
    const r = await pedir("/api/registro", { method: "POST", body: datos });
    estado.className = "registro-estado ok";
    estado.textContent = `Registro completo para ${r.persona.nombre}: ${r.persona.tramos} tramos, ${fmt(r.persona.voz_neta_s, 1)} s de voz. Ya puede validar su identidad.`
      + (r.advertencias && r.advertencias.length ? ` Algunas grabaciones no se usaron: ${r.advertencias.join("; ")}` : "");
    $("reg-nombre").value = "";
    $("reg-origen").value = "";
    $("reg-consentimiento").checked = false;
    prepararRegistro();
    estadoServicio();
  } catch (e) {
    estado.className = "registro-estado error";
    estado.textContent = e.message;
    actualizarBotonRegistro();
  }
});

prepararRegistro();

// ---------------------------------------------------------------------------
// Personas registradas
// ---------------------------------------------------------------------------

let sondeoSync = null;
let datosPersonas = null;

$("nombres-personas").addEventListener("change", pintarMapaPersonas);

function pintarMapaPersonas() {
  if (datosPersonas) dibujarMapa($("mapa-personas"), datosPersonas.mapa, { todosLosNombres: $("nombres-personas").checked, alto: 620 });
}

async function cargarPersonas() {
  try {
    await estadoServicio();
    const [personas, mapa, sync] = await Promise.all([pedir("/api/personas"), pedir("/api/mapa"), pedir("/api/sincronizacion")]);
    datosPersonas = { personas, mapa };
    pintarSync(sync);
    pintarMapaPersonas();
    pintarTablaPersonas();
  } catch (e) {
    $("sync-estado").textContent = e.message;
  }
}

function pintarTablaPersonas() {
  const { personas } = datosPersonas;
  $("aviso-eliminar").hidden = eliminacionHabilitada;
  $("tabla-personas").innerHTML = `
    <thead><tr><th>Nombre</th><th>Origen</th><th>Fuente</th><th>Tramos</th><th>Voz (s)</th><th>Tono mediano (Hz)</th>${eliminacionHabilitada ? "<th><span class=\"sr-only\">Acciones</span></th>" : ""}</tr></thead>
    <tbody>${personas.map((p) => `<tr data-persona="${esc(p.persona_id)}">
      <td>${esc(p.nombre)}</td><td>${esc(p.origen || "—")}</td><td>${p.fuente === "web" ? "Registro web" : "Archivo"}</td>
      <td>${p.tramos}</td><td>${fmt(p.voz_neta_s, 1)}</td><td>${fmt(p.perfil && p.perfil.f0_mediana_hz, 0)}</td>
      ${eliminacionHabilitada ? `<td><button class="boton boton-secundario boton-chico" data-eliminar="${esc(p.persona_id)}">Eliminar</button></td>` : ""}
    </tr>`).join("")}</tbody>`;
  $("tabla-personas").querySelectorAll("[data-eliminar]").forEach((b) =>
    b.addEventListener("click", () => abrirConfirmacion(b.dataset.eliminar)));
}

function abrirConfirmacion(personaId) {
  document.querySelectorAll(".fila-confirmar").forEach((f) => f.remove());
  const persona = datosPersonas.personas.find((p) => p.persona_id === personaId);
  const fila = document.querySelector(`tr[data-persona="${CSS.escape(personaId)}"]`);
  const n = (persona.archivos || []).length;
  const confirmar = document.createElement("tr");
  confirmar.className = "fila-confirmar";
  confirmar.innerHTML = `<td colspan="7"><form class="confirmar">
      <p>Se eliminarán definitivamente ${n === 1 ? "el archivo de audio" : `los ${n} archivos de audio`} de <strong>${esc(persona.nombre)}</strong>${persona.fuente === "web" ? " y su consentimiento" : ""}, junto con su huella vocal. No se puede deshacer.</p>
      <label>Clave <input type="password" inputmode="numeric" autocomplete="off" maxlength="4" pattern="\\d{4}" required aria-label="Clave de 4 dígitos"></label>
      <button class="boton boton-peligro boton-chico" type="submit">Eliminar definitivamente</button>
      <button class="boton boton-secundario boton-chico" type="button" data-cancelar>Cancelar</button>
      <p class="confirmar-error" aria-live="polite"></p>
    </form></td>`;
  fila.after(confirmar);
  const formulario = confirmar.querySelector("form");
  const entrada = formulario.querySelector("input");
  const error = formulario.querySelector(".confirmar-error");
  entrada.focus();
  formulario.querySelector("[data-cancelar]").addEventListener("click", () => confirmar.remove());
  formulario.addEventListener("submit", async (e) => {
    e.preventDefault();
    const enviar = formulario.querySelector("[type=submit]");
    enviar.disabled = true;
    error.textContent = "";
    try {
      const r = await pedir(`/api/personas/${encodeURIComponent(personaId)}/eliminar`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clave: entrada.value }),
      });
      await cargarPersonas();
      $("sync-estado").textContent = `Se eliminó a ${r.nombre}: se borraron ${r.archivos_eliminados.length} archivos y su huella.`;
    } catch (err) {
      error.textContent = err.message;
      entrada.value = "";
      entrada.focus();
      enviar.disabled = false;
    }
  });
}

function pintarSync(sync) {
  const boton = $("btn-resincronizar");
  if (sync.en_curso) {
    boton.disabled = true;
    $("sync-estado").textContent = sync.total
      ? `Sincronizando: ${sync.hechos} de ${sync.total} archivos${sync.archivo ? ` (${sync.archivo})` : ""}…`
      : "Sincronizando: revisando la carpeta de referencias…";
    return;
  }
  boton.disabled = false;
  const r = sync.ultimo_resumen;
  if (sync.error) { $("sync-estado").textContent = `La última sincronización falló: ${sync.error}`; return; }
  if (!r) { $("sync-estado").textContent = "Aún no se ha sincronizado la carpeta de referencias."; return; }
  const partes = [`${r.nuevos.length} nuevos`, `${r.actualizados.length} actualizados`, `${r.eliminados.length} eliminados`, `${r.sin_cambios} sin cambios`];
  if (r.errores.length) partes.push(`${r.errores.length} con error (${r.errores.map((e) => e.archivo).join(", ")})`);
  $("sync-estado").textContent = `Última sincronización: ${partes.join(", ")}.`;
}

$("btn-resincronizar").addEventListener("click", async () => {
  try {
    await pedir("/api/sincronizacion", { method: "POST" });
  } catch (e) {
    $("sync-estado").textContent = e.message;
  }
  clearInterval(sondeoSync);
  sondeoSync = setInterval(async () => {
    const sync = await pedir("/api/sincronizacion");
    pintarSync(sync);
    if (!sync.en_curso) { clearInterval(sondeoSync); cargarPersonas(); }
  }, 1000);
});

// ---------------------------------------------------------------------------
// Tiempos y recursos
// ---------------------------------------------------------------------------

const VEREDICTOS_CORTOS = {
  validado: "identidad validada", no_concluyente: "no concluyente", no_identificado: "no identificado",
  rechazado_prueba_de_vida: "rechazado en la prueba de vida", muestra_insuficiente: "muestra insuficiente",
};
let sondeoRecursos = null;

function cifra(titulo, valor, detalle = "") {
  return `<div><dt>${esc(titulo)}</dt><dd>${valor}${detalle ? `<small>${detalle}</small>` : ""}</dd></div>`;
}

function abrirRecursos() {
  cargarTiempos();
  cargarFicha();
  actualizarRecursos();
  clearInterval(sondeoRecursos);
  sondeoRecursos = setInterval(actualizarRecursos, 2000);
}

function cerrarRecursos() {
  clearInterval(sondeoRecursos);
  sondeoRecursos = null;
}

async function cargarTiempos() {
  let datos;
  try {
    datos = await pedir("/api/tiempos");
  } catch (e) {
    $("ultima-meta").textContent = e.message;
    return;
  }
  const u = datos.ultima;
  dibujarLineaTiempo($("linea-tiempo"), u, datos.nombres);
  if (u) {
    const fecha = new Date(u.fecha_utc).toLocaleString("es-CO", { dateStyle: "medium", timeStyle: "medium" });
    $("ultima-meta").textContent = `${fecha}: ${VEREDICTOS_CORTOS[u.veredicto] || u.veredicto}, con ${fmt(u.voz_neta_s, 1)} s de voz.`;
    const c = u.consumo || {};
    $("consumo-validacion").innerHTML = [
      cifra("Tiempo total en el servidor", fmtDuracion(u.total_s)),
      cifra("CPU usado", c.cpu_s != null ? `${fmt(c.cpu_s, 2)} s` : "—",
        c.nucleos_promedio != null ? `≈ ${fmt(c.nucleos_promedio, 1)} núcleos en promedio` : ""),
      cifra("RAM del servicio (pico)", c.ram_pico_mb != null ? `${fmt(c.ram_pico_mb, 0)} MB` : "—",
        c.ram_inicio_mb != null ? `${c.ram_pico_mb - c.ram_inicio_mb >= 0 ? "+" : ""}${fmt(c.ram_pico_mb - c.ram_inicio_mb, 0)} MB durante la validación` : ""),
    ].join("");
  } else {
    $("ultima-meta").textContent = "";
    $("consumo-validacion").innerHTML = "";
  }
  pintarHistorial(datos.historial);
}

function pintarHistorial(h) {
  if (!h || !h.n) {
    $("historial-meta").textContent = "Todavía no hay validaciones con tiempos medidos.";
    $("tabla-historial").innerHTML = "";
    return;
  }
  $("historial-meta").textContent = `Mediana y percentil 95 de las últimas ${h.n} ${h.n === 1 ? "validación" : "validaciones"} `
    + "con el VAD y los dispositivos actuales (CPU y GPU no se mezclan): "
    + "la mediana es el tiempo típico; el p95, el tiempo que solo se supera en 1 de cada 20.";
  const maximo = Math.max(...h.pasos.map((p) => p.mediana || 0), 1e-6);
  const filas = h.pasos.map((p) => `<tr>
      <td>${esc(p.nombre)}</td>
      <td class="barra-celda"><span class="barra-mediana${p.paso === "stt" ? " paralelo" : ""}" style="width:${(100 * (p.mediana || 0) / maximo).toFixed(1)}%"></span></td>
      <td>${fmtDuracion(p.mediana)}</td><td>${fmtDuracion(p.p95)}</td><td>${p.n}</td></tr>`).join("");
  const resumen = (nombre, r, f) => `<tr class="fila-resumen"><td>${nombre}</td><td></td><td>${f(r.mediana)}</td><td>${f(r.p95)}</td><td>${r.n}</td></tr>`;
  $("tabla-historial").innerHTML = `
    <thead><tr><th>Paso</th><th class="barra-celda"><span class="sr-only">Mediana relativa</span></th><th>Mediana</th><th>p95</th><th>Veces</th></tr></thead>
    <tbody>${filas}
      ${resumen("Total en el servidor", h.total_s, fmtDuracion)}
      ${resumen("CPU usado por validación", h.cpu_s, (v) => (v == null ? "—" : `${fmt(v, 2)} s`))}
      ${resumen("RAM del servicio (pico)", h.ram_pico_mb, (v) => (v == null ? "—" : `${fmt(v, 0)} MB`))}
    </tbody>`;
}

async function actualizarRecursos() {
  let r;
  try {
    r = await pedir("/api/recursos");
  } catch (e) {
    $("vivo-estado").textContent = e.message;
    return;
  }
  const a = r.actual;
  if (!a) { $("vivo-estado").textContent = "Reuniendo las primeras muestras…"; return; }
  $("vivo-estado").textContent = `Actualizado ${new Date(a.t * 1000).toLocaleTimeString("es-CO")}`;
  $("recursos-actuales").innerHTML = [
    cifra("CPU del servicio", `${fmt(a.cpu_servicio_pct, 1)} %`),
    cifra("CPU de la máquina", `${fmt(a.cpu_maquina_pct, 1)} %`, `${r.nucleos} núcleos`),
    cifra("RAM del servicio", `${fmt(a.ram_servicio_mb / 1024, 2)} GB`),
    cifra("RAM de la máquina", `${fmt(a.ram_maquina_usada_mb / 1024, 1)} GB`, `de ${fmt(a.ram_maquina_total_mb / 1024, 0)} GB`),
    cifra("Hilos del servicio", fmt(a.hilos, 0)),
  ].join("");
  dibujarRecursos($("grafico-cpu"), $("grafico-ram"), r.historia);
}

async function cargarFicha() {
  let f;
  try {
    f = await pedir("/api/sistema");
  } catch (e) {
    $("ficha-sistema").innerHTML = `<dt>Error</dt><dd>${esc(e.message)}</dd>`;
    return;
  }
  const nucleos = f.nucleos_fisicos && f.nucleos_fisicos !== f.nucleos ? `${f.nucleos} (${f.nucleos_fisicos} físicos)` : `${f.nucleos}`;
  const sync = f.ultima_sincronizacion;
  const filas = [
    ["Versión", f.version || "—"],
    ["Imagen del entorno", f.imagen || "— (sin Docker)"],
    ["Detección de voz", f.vad || "—"],
    ["Colecciones en Qdrant", (f.colecciones || []).join(", ") || "—"],
    ["Modelos", `${f.dir_modelos || "—"}${f.modo_offline ? ", en modo offline" : ""}`],
    ["Arquitectura", f.arquitectura],
    ["Procesador", f.procesador || "—"],
    ["Núcleos", nucleos],
    ["RAM total", `${fmt(f.ram_total_mb / 1024, 1)} GB`],
    ["Sistema", `${f.sistema}${f.en_docker ? ", dentro de Docker" : ""}`],
    ["Dispositivo pedido", f.dispositivo_pedido === "gpu" ? "GPU (VF_DISPOSITIVO=gpu)" : "CPU (VF_DISPOSITIVO=cpu)"],
    ["GPU", f.gpu + (f.gpu_memoria_mb ? ` · ${fmt(f.gpu_memoria_mb / 1024, 1)} GB` : "")
      + (f.gpu_memoria_pytorch_mb != null ? ` · ${fmt(f.gpu_memoria_pytorch_mb, 0)} MB en uso por PyTorch` : "")],
    ...(f.avisos_dispositivo || []).map((a) => ["Advertencia", a]),
    ["Python / PyTorch", `${f.python} / ${f.torch} (${f.hilos_torch} ${f.hilos_torch === 1 ? "hilo" : "hilos"})`],
    ["CTranslate2 (Whisper)", f.ctranslate2 || "—"],
    ["Carga de modelos al arrancar", `${fmt(f.carga_modelos_s, 1)} s`],
    ["Última sincronización", sync && sync.duracion_s != null ? `${fmt(sync.duracion_s, 1)} s, ${sync.personas} personas` : "—"],
  ];
  $("ficha-sistema").innerHTML = filas.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join("");
  $("tabla-modelos").innerHTML = `
    <thead><tr><th>Función</th><th>Modelo</th><th>Dispositivo</th><th>Carga</th></tr></thead>
    <tbody>${f.modelos.map((m) => `<tr><td>${esc(m.rol)}</td><td>${esc(m.modelo)}</td>
      <td>${m.dispositivo === "cuda" ? "GPU" : m.dispositivo === "cpu" ? "CPU" : "—"}</td>
      <td>${m.carga_s != null ? `${fmt(m.carga_s, 2)} s` : "—"}</td></tr>`).join("")}</tbody>`;
}

// ---------------------------------------------------------------------------
// Umbral: cuánta voz neta hace falta para identificar
// ---------------------------------------------------------------------------

let umbral = null;          // sesión en curso: { grabadora, sesion, pendientes, puntos, enVuelo, ... }
let ultimoUmbral = null;    // { puntos, umbrales, resultado } para volver a dibujar

$("btn-umbral").addEventListener("click", () => (umbral ? detenerUmbral() : empezarUmbral()));

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

function aPcm16(bloques) {
  const total = bloques.reduce((n, b) => n + b.length, 0);
  const pcm = new Int16Array(total);
  let k = 0;
  for (const b of bloques) {
    for (let i = 0; i < b.length; i++) {
      const v = Math.max(-1, Math.min(1, b[i]));
      pcm[k++] = v < 0 ? v * 0x8000 : v * 0x7fff;
    }
  }
  return pcm;
}

function estadoUmbral(texto, tono = "") {
  const p = $("umbral-estado");
  p.className = `umbral-estado ${tono}`;
  p.textContent = texto;
}

function reiniciarControlUmbral() {
  const boton = $("btn-umbral");
  boton.disabled = false;
  boton.textContent = "Empezar";
  boton.classList.remove("grabando");
  $("medidor-umbral").hidden = true;
}

async function empezarUmbral() {
  $("panel-umbral-resultado").hidden = true;
  $("umbral-vivo").innerHTML = "";
  const estado = { sesion: null, pendientes: [], puntos: [], enVuelo: false, cerrando: false, temporizador: null };
  const grabadora = iniciarGrabacionControlada({
    boton: $("btn-umbral"), medidor: $("medidor-umbral"), minimoVoz: MINIMO_VOZ_UMBRAL, maxSegundos: MAX_SEGUNDOS_UMBRAL,
    textoDetener: "Detener", alTerminar: () => detenerUmbral(), alCancelar: () => cancelarUmbral(),
  });
  grabadora.alBloque = (bloque) => estado.pendientes.push(bloque);
  umbral = { ...estado, grabadora };
  const actual = umbral;
  pintarUmbralVivo();
  estadoUmbral("Hable con naturalidad. La gráfica se actualiza mientras habla.");
  try {
    await grabadora.iniciar();
  } catch (e) {
    if (e.name === "GrabacionCancelada") return;
    umbral = null;
    reiniciarControlUmbral();
    estadoUmbral("No se pudo usar el micrófono. Revise el permiso del navegador.", "error");
    return;
  }
  try {
    actual.sesion = await pedir("/api/umbral/sesion", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tasa: grabadora.tasa }),
    });
  } catch (e) {
    if (umbral === actual) { grabadora.cancelar(); }
    estadoUmbral(e.message, "error");
    return;
  }
  if (umbral !== actual) {                 // se canceló mientras se abría la sesión
    pedir(`/api/umbral/sesion/${actual.sesion.id}/cancelar`, { method: "POST" }).catch(() => {});
    return;
  }
  actual.temporizador = setInterval(() => enviarUmbral(actual), actual.sesion.intervalo_s * 1000);
}

// Envía todo lo grabado desde el envío anterior. Si el servidor tardó, el envío lleva más audio
// (en trozos de máximo 4 s; solo el último se procesa), así la página nunca se atrasa.
async function enviarUmbral(u) {
  if (!u.sesion || u.enVuelo || !u.pendientes.length) return;
  u.enVuelo = true;
  try {
    const pcm = aPcm16(u.pendientes.splice(0));
    const porEnvio = Math.round(u.grabadora.tasa * 4);
    let ultimo = null;
    for (let i = 0; i < pcm.length; i += porEnvio) {
      const procesar = i + porEnvio >= pcm.length ? 1 : 0;
      ultimo = await pedir(`/api/umbral/sesion/${u.sesion.id}/audio?procesar=${procesar}`, {
        method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: pcm.subarray(i, i + porEnvio),
      });
      if (umbral !== u) return;
    }
    if (ultimo && ultimo.estado) {
      u.puntos.push(ultimo);
      pintarUmbralVivo();
    }
  } catch (e) {
    if (umbral === u) estadoUmbral(e.message, "error");
  } finally {
    u.enVuelo = false;
  }
}

function pintarUmbralVivo() {
  const u = umbral;
  const puntos = u ? u.puntos : [];
  const umbrales = u && u.sesion ? u.sesion.umbrales : (ultimoUmbral && ultimoUmbral.umbrales);
  const vozMin = u && u.sesion ? u.sesion.voz_min_ms : undefined;
  dibujarUmbral($("grafico-umbral"), puntos, { umbrales, vozMin });
  const p = puntos[puntos.length - 1];
  if (!p) { $("umbral-vivo").innerHTML = ""; return; }
  const mejor = p.candidatos && p.candidatos[0];
  $("umbral-vivo").innerHTML = [
    cifra("Voz neta analizada", fmtMs(p.voz_ms), `de ${fmt(p.audio_ms / 1000, 1)} s grabados`),
    cifra("Estado", esc(ESTADOS_UMBRAL[p.estado] || p.estado)),
    cifra("Más parecida", mejor ? esc(mejor.nombre) : "—", mejor ? `similitud ${fmt(mejor.score, 2)}` : ""),
    cifra("Ventaja sobre la segunda", p.margen != null ? fmt(p.margen, 2) : "—"),
    cifra("Último cálculo", fmtMs(p.proceso_ms)),
  ].join("");
}

async function detenerUmbral() {
  const u = umbral;
  if (!u || u.cerrando || !u.grabadora.grabando) return;
  u.cerrando = true;
  clearInterval(u.temporizador);
  const boton = $("btn-umbral");
  boton.disabled = true;
  boton.textContent = "Calculando…";
  boton.classList.remove("grabando");
  await u.grabadora.detener();
  estadoUmbral("Calculando con precisión los cruces…");
  try {
    if (!u.sesion) throw new Error("La sesión no llegó a abrirse.");
    while (u.enVuelo) await esperar(40);
    await enviarUmbral(u);
    const r = await pedir(`/api/umbral/sesion/${u.sesion.id}/finalizar`, { method: "POST" });
    ultimoUmbral = { puntos: u.puntos, umbrales: u.sesion.umbrales, resultado: r };
    mostrarResultadoUmbral(r, u.sesion.umbrales);
    estadoUmbral("");
    cargarHistorialUmbral();
  } catch (e) {
    estadoUmbral(e.message, "error");
  } finally {
    if (umbral === u) umbral = null;
    reiniciarControlUmbral();
  }
}

function cancelarUmbral() {
  const u = umbral;
  umbral = null;
  if (u) {
    clearInterval(u.temporizador);
    if (u.sesion) pedir(`/api/umbral/sesion/${u.sesion.id}/cancelar`, { method: "POST" }).catch(() => {});
  }
  reiniciarControlUmbral();
  estadoUmbral("Sesión cancelada. No se guardó nada.");
}

// Un cruce en el mínimo medible (500 ms) se muestra como "≤ 500 ms".
const msCruce = (ms, enMinimo) => (ms != null && enMinimo ? `≤ ${fmtMs(ms)}` : fmtMs(ms));

function mostrarResultadoUmbral(r, umbrales) {
  dibujarUmbral($("grafico-umbral"), r.puntos, {
    umbrales, destacada: r.persona_id, primer: r.primer_cruce_ms, estable: r.cruce_estable_ms, refinamiento: r.refinamiento,
    vozMin: r.voz_min_ms,
  });
  const estadoTexto = {
    confirmado: "Confirmado",
    sin_confirmar: "Sin confirmar",
    sin_identificar: "Sin identificar",
  }[r.estado] || r.estado;
  $("umbral-resultado").innerHTML = [
    cifra("Primer cruce", msCruce(r.primer_cruce_ms, r.primer_cruce_en_minimo), r.primer_cruce_nombre ? esc(r.primer_cruce_nombre) : ""),
    cifra("Cruce estable", msCruce(r.cruce_estable_ms, r.cruce_estable_en_minimo), esc(estadoTexto)),
    cifra("Identificada al final", r.nombre ? esc(r.nombre) : "Nadie",
      r.score_final != null ? `similitud ${fmt(r.score_final, 2)}, ventaja ${fmt(r.margen_final, 2)}` : ""),
    cifra("Voz neta total", fmtMs(r.voz_total_ms), `de ${fmt(r.audio_total_ms / 1000, 1)} s grabados`),
    cifra("Barrido preciso", `${fmt(r.duracion_barrido_s, 1)} s`, `${r.evaluaciones} cálculos · ${esc(r.vad_nombre)}`),
  ].join("");
  const notas = [];
  if (r.estado === "sin_identificar") notas.push(r.motivo || "Al final de la sesión el sistema no identificó a nadie con confianza.");
  if (r.estado === "sin_confirmar") notas.push(`Después del cruce estable hubo menos de ${fmt(2, 0)} s de voz neta: la próxima vez siga hablando unos segundos más para confirmarlo.`);
  if (r.primer_cruce_en_minimo || r.cruce_estable_en_minimo) {
    notas.push(`«≤ ${fmtMs(r.voz_min_ms)}» significa que con el mínimo medible ya alcanzaba: con menos voz no se calcula una huella, así que el valor real puede ser menor. En la práctica, el VAD entrega el primer segmento de voz a partir de unos 250 ms.`);
  }
  if (r.primer_cruce_persona_id && r.persona_id && r.primer_cruce_persona_id !== r.persona_id) {
    notas.push(`Ojo: el primer cruce fue con ${r.primer_cruce_nombre}; con más voz la identificación cambió a ${r.nombre}.`);
  }
  notas.push("Primer cruce: los primeros milisegundos de voz neta con los que el sistema identificó a alguien. Cruce estable: desde dónde identificó a la misma persona sin interrupción hasta el final.");
  $("umbral-resultado-nota").textContent = notas.join(" ");
  $("panel-umbral-resultado").hidden = false;
}

async function cargarHistorialUmbral() {
  let h;
  try {
    h = await pedir("/api/umbral/historial");
  } catch (e) {
    $("umbral-historial-meta").textContent = e.message;
    return;
  }
  if (!umbral && !ultimoUmbral) dibujarUmbral($("grafico-umbral"), [], {});
  if (!h.sesiones) {
    $("umbral-historial-meta").textContent = "Todavía no hay sesiones guardadas.";
    ["tabla-umbral-vad", "tabla-umbral-personas", "tabla-umbral-recientes"].forEach((id) => { $(id).innerHTML = ""; });
    return;
  }
  $("umbral-historial-meta").textContent = `${h.sesiones} ${h.sesiones === 1 ? "sesión guardada" : "sesiones guardadas"}. `
    + "El primer cruce cuenta todas las sesiones que lo tuvieron; el cruce estable, solo las confirmadas. "
    + "Con pocas sesiones, el p90 y el p95 quedan cerca del máximo. Las sesiones se agrupan por la voz mínima con que se hicieron "
    + `(hoy ${fmtMs(h.voz_min_ms)}), porque sus cruces no son comparables. El VAD actual es `
    + `${h.vad_actual === "ten" ? "TEN VAD" : "Silero VAD"}.`;
  const nombreVad = (v) => (v === "ten" ? "TEN VAD" : "Silero VAD");
  // Cada grupo ocupa dos filas: primer cruce (todas las sesiones con cruce) y cruce estable (solo confirmadas).
  const columnasCifras = "<th>Cifra</th><th>n</th><th>Media</th><th>Mediana</th><th>p90</th><th>p95</th><th>Mín.</th><th>Máx.</th>";
  const celdasCifras = (e) => `<td>${e.n}</td><td>${fmtMs(e.media)}</td><td>${fmtMs(e.mediana)}</td><td>${fmtMs(e.p90)}</td>`
    + `<td>${fmtMs(e.p95)}</td><td>${fmtMs(e.min)}</td><td>${fmtMs(e.max)}</td>`;
  const dosFilas = (inicio, g) => `<tr class="grupo-inicio">${inicio}<td class="cifra">Primer cruce</td>${celdasCifras(g.primer_cruce)}</tr>`
    + `<tr><td class="cifra">Cruce estable</td>${celdasCifras(g.cruce_estable)}</tr>`;
  const r2 = (contenido) => `<td rowspan="2">${contenido}</td>`;
  $("tabla-umbral-vad").innerHTML = `
    <thead><tr><th>VAD</th><th>Voz mínima</th><th>Sesiones</th><th>Identificadas</th><th>Confirmadas</th>${columnasCifras}</tr></thead>
    <tbody>${h.por_vad.map((v) => dosFilas(
      r2(nombreVad(v.vad)) + r2(fmtMs(v.voz_min_ms)) + r2(v.sesiones) + r2(v.identificadas) + r2(v.confirmadas), v)).join("")}</tbody>`;
  $("tabla-umbral-personas").innerHTML = `
    <thead><tr><th>VAD</th><th>Persona</th><th>Voz mínima</th><th>Sesiones</th><th>Confirmadas</th>${columnasCifras}</tr></thead>
    <tbody>${h.por_persona.map((p) => dosFilas(
      r2(nombreVad(p.vad)) + r2(p.persona_id ? esc(p.nombre) : "<em>Sin identificar</em>") + r2(fmtMs(p.voz_min_ms))
      + r2(p.sesiones) + r2(p.confirmadas), p)).join("")}</tbody>`;
  const estados = { confirmado: "Confirmado", sin_confirmar: "Sin confirmar", sin_identificar: "Sin identificar" };
  $("tabla-umbral-recientes").innerHTML = `
    <thead><tr><th>Fecha</th><th>VAD</th><th>Persona</th><th>Primer cruce</th><th>Cruce estable</th><th>Voz neta</th><th>Estado</th></tr></thead>
    <tbody>${h.recientes.map((r) => `<tr><td>${new Date(r.fecha_utc).toLocaleString("es-CO", { dateStyle: "short", timeStyle: "short" })}</td>
      <td>${nombreVad(r.vad)}</td><td>${r.nombre ? esc(r.nombre) : "—"}</td><td>${msCruce(r.primer_cruce_ms, r.primer_cruce_en_minimo)}</td>
      <td>${msCruce(r.cruce_estable_ms, r.cruce_estable_en_minimo)}</td><td>${fmtMs(r.voz_total_ms)}</td><td>${estados[r.estado] || esc(r.estado)}</td></tr>`).join("")}</tbody>`;
}
