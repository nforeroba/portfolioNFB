"""Material para visualizar: espectrograma mel (como datos) y proyección 2D (PCA) de huellas."""

import numpy as np

from .config import SR


def _banco_mel(n_fft, n_mels, fmin=50.0, fmax=None):
    """
    Filtros triangulares en escala mel evaluados sobre la frecuencia exacta de
    cada bin de la FFT. Cada fila se normaliza para dar la potencia media de su
    banda, así las bandas graves (más angostas) no salen artificialmente oscuras.
    """
    fmax = fmax or SR / 2
    a_mel = lambda f: 2595 * np.log10(1 + f / 700)  # noqa: E731
    de_mel = lambda m: 700 * (10 ** (m / 2595) - 1)  # noqa: E731
    puntos = de_mel(np.linspace(a_mel(fmin), a_mel(fmax), n_mels + 2))
    f_bins = np.linspace(0, SR / 2, n_fft // 2 + 1)
    izq, centro, der = puntos[:-2, None], puntos[1:-1, None], puntos[2:, None]
    subida = (f_bins - izq) / (centro - izq)
    bajada = (der - f_bins) / (der - centro)
    banco = np.maximum(0.0, np.minimum(subida, bajada))
    banco /= np.maximum(banco.sum(axis=1, keepdims=True), 1e-12)
    return banco, puntos[1:-1]


def espectrograma_datos(voz, segundos=10.0, n_mels=80, max_columnas=500, rango_db=80):
    """
    Espectrograma mel en dB listo para dibujar con Plotly:
    {"tiempos_s": [...], "frecuencias_hz": [...], "db": [[fila por banda mel]], "duracion_s"}.
    """
    from scipy.signal import stft

    voz = np.asarray(voz, dtype=np.float32)[: int(segundos * SR)]
    if len(voz) < SR // 4:
        return None
    _, tiempos, z = stft(voz, fs=SR, nperseg=400, noverlap=240, nfft=2048, boundary=None)
    banco, centros = _banco_mel(2048, n_mels)
    mel = banco @ (np.abs(z) ** 2)
    db = 10 * np.log10(np.maximum(mel, 1e-10))
    db = np.maximum(db, db.max() - rango_db)
    db = db - db.max()                                     # 0 dB = lo más fuerte de la muestra

    paso = int(np.ceil(db.shape[1] / max_columnas))        # promedia columnas para aligerar
    if paso > 1:
        columnas = db.shape[1] // paso
        db = db[:, : columnas * paso].reshape(n_mels, columnas, paso).mean(axis=2)
        tiempos = tiempos[: columnas * paso].reshape(columnas, paso).mean(axis=1)
    return {
        "tiempos_s": [round(float(t), 3) for t in tiempos],
        "frecuencias_hz": [round(float(f), 1) for f in centros],
        "db": np.round(db).astype(int).tolist(),
        "duracion_s": round(len(voz) / SR, 3),
    }


def ajustar_pca(vectores):
    """PCA de 2 componentes sobre huellas normalizadas. Devuelve lo necesario para proyectar."""
    x = np.asarray(vectores, dtype=np.float64)
    x = x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), 1e-12)
    media = x.mean(axis=0)
    _, valores, componentes = np.linalg.svd(x - media, full_matrices=False)
    varianza = valores ** 2 / np.sum(valores ** 2)
    return {"media": media, "componentes": componentes[:2], "varianza": varianza[:2]}


def proyectar(pca, vectores):
    x = np.atleast_2d(np.asarray(vectores, dtype=np.float64))
    x = x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), 1e-12)
    return (x - pca["media"]) @ pca["componentes"].T
