"""
Cliente de prueba manual para el RPC Ingest.

Caso: PERFIL_RAPIDO, modo A (documento completo), estrategia
CHUNKING_RECURSIVO, texto corto.

Ejecutar desde /home/user_ia/api_rag_prototipo/api_rag_code, con el
mismo venv (rag-env) activado, mientras el servidor corre en otra
terminal:

    python /ruta/a/test_ingest_rapido.py
"""

import grpc

from rag_api.generated import rag_pb2, rag_pb2_grpc

TEXTO_PRUEBA = (
    "Este es un texto corto de prueba para el prototipo de API RAG.\n\n"
    "Sirve para validar el camino de ingesta mas simple: perfil rapido, "
    "estrategia de chunking recursiva, sin parametros especiales.\n\n"
    "Si esto funciona, el siguiente paso es probar Retrieve contra lo "
    "que se acaba de ingestar."
)


def main() -> None:
    canal = grpc.insecure_channel("localhost:50051")
    stub = rag_pb2_grpc.RagServiceStub(canal)

    request = rag_pb2.IngestRequest(
        categoria="prueba_smoke",
        fuente="test_ingest_rapido_manual",
        perfil=rag_pb2.PERFIL_RAPIDO,
        documento=rag_pb2.DocumentoCompleto(
            texto=TEXTO_PRUEBA,
            estrategia=rag_pb2.CHUNKING_RECURSIVO,
        ),
    )

    print("Enviando IngestRequest...")
    print(request)

    try:
        response = stub.Ingest(request, timeout=30)
    except grpc.RpcError as error:
        print(f"ERROR gRPC: codigo={error.code()} detalle={error.details()}")
        return

    print("\nIngestResponse recibido:")
    print(f"  chunks_insertados: {response.chunks_insertados}")
    print(f"  chunks_actualizados: {response.chunks_actualizados}")
    print(f"  ids_generados: {list(response.ids_generados)}")


if __name__ == "__main__":
    main()
