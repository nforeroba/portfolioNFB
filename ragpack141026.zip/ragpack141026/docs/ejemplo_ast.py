"""Modulo de ejemplo para probar el chunking AST: gestion de inventario de una tienda."""

import logging
from dataclasses import dataclass, field

LOG = logging.getLogger(__name__)

IVA_GENERAL = 0.19
IVA_REDUCIDO = 0.05
MAX_ITEMS_POR_PEDIDO = 50


@dataclass
class Producto:
    """Un producto del catalogo."""

    sku: str
    nombre: str
    precio: float
    stock: int = 0
    categorias: list[str] = field(default_factory=list)


class ErrorInventario(Exception):
    """Se lanza cuando una operacion de inventario no es valida."""


class Inventario:
    """Controla existencias y reservas de productos."""

    def __init__(self) -> None:
        self._productos: dict[str, Producto] = {}
        self._reservas: dict[str, int] = {}

    def agregar(self, producto: Producto) -> None:
        if producto.sku in self._productos:
            raise ErrorInventario(f"El SKU {producto.sku} ya existe")
        self._productos[producto.sku] = producto
        LOG.info("Producto agregado: %s", producto.sku)

    def disponible(self, sku: str) -> int:
        producto = self._productos.get(sku)
        if producto is None:
            raise ErrorInventario(f"SKU desconocido: {sku}")
        return producto.stock - self._reservas.get(sku, 0)

    def reservar(self, sku: str, cantidad: int) -> None:
        if cantidad <= 0:
            raise ErrorInventario("La cantidad debe ser positiva")
        if self.disponible(sku) < cantidad:
            raise ErrorInventario(f"Stock insuficiente para {sku}")
        self._reservas[sku] = self._reservas.get(sku, 0) + cantidad

    def confirmar_reserva(self, sku: str) -> None:
        cantidad = self._reservas.pop(sku, 0)
        self._productos[sku].stock -= cantidad
        LOG.info("Reserva confirmada: %s x%d", sku, cantidad)


def calcular_total(items: list[tuple[Producto, int]], aplicar_descuento: bool = False) -> dict:
    """Calcula subtotal, impuestos y total de un pedido, con descuentos por volumen."""
    if len(items) > MAX_ITEMS_POR_PEDIDO:
        raise ErrorInventario("El pedido supera el maximo de items permitido")

    subtotal = 0.0
    impuestos = 0.0
    detalle = []
    for producto, cantidad in items:
        linea = producto.precio * cantidad
        if aplicar_descuento and cantidad >= 10:
            linea *= 0.90
        tasa = IVA_REDUCIDO if "alimentos" in producto.categorias else IVA_GENERAL
        impuesto_linea = linea * tasa
        subtotal += linea
        impuestos += impuesto_linea
        detalle.append(
            {
                "sku": producto.sku,
                "cantidad": cantidad,
                "linea": round(linea, 2),
                "impuesto": round(impuesto_linea, 2),
            }
        )

    return {
        "subtotal": round(subtotal, 2),
        "impuestos": round(impuestos, 2),
        "total": round(subtotal + impuestos, 2),
        "detalle": detalle,
    }


def formatear_factura(pedido_id: str, resumen: dict) -> str:
    lineas = [f"Factura {pedido_id}", "-" * 30]
    for fila in resumen["detalle"]:
        lineas.append(f"{fila['sku']:<12} x{fila['cantidad']:<4} {fila['linea']:>10.2f}")
    lineas.append("-" * 30)
    lineas.append(f"Total: {resumen['total']:.2f}")
    return "\n".join(lineas)


if __name__ == "__main__":
    inv = Inventario()
    inv.agregar(Producto("A-1", "Cafe", 12.5, stock=100, categorias=["alimentos"]))
    print(formatear_factura("P-001", calcular_total([(Producto("A-1", "Cafe", 12.5), 3)])))
