#!/bin/bash

set -e

# === CONFIGURACIÓN ===
PROJECT_NAME="fish_tts_service"
PYTHON_VERSION="3.10"
MODEL_REPO="fishaudio/fish-speech-1.5"
EMBEDDING_NAME="voz_clonada.pth"

# === INICIO ===
echo "[+] Iniciando instalación de $PROJECT_NAME..."

# 1. Crear estructura de proyecto
mkdir -p $PROJECT_NAME/{logs,checkpoints}
cd $PROJECT_NAME

# 2. Instalar Python 3.10 y herramientas
sudo apt update
sudo apt install -y software-properties-common curl git sox libsndfile1 ffmpeg
sudo add-apt-repository -y ppa:deadsnakes/ppa
sudo apt update
sudo apt install -y python$PYTHON_VERSION python$PYTHON_VERSION-venv python$PYTHON_VERSION-dev

# 3. Crear entorno virtual
python$PYTHON_VERSION -m venv venv
source venv/bin/activate

# 4. Instalar pip y PyTorch nightly con CUDA 12.8
pip install --upgrade pip
pip install --pre torch --pre torchaudio   --index-url https://download.pytorch.org/whl/nightly/cu128

# 5. Clonar Fish-Speech e instalar
git clone https://github.com/fishaudio/fish-speech.git
cd fish-speech
pip install -U "huggingface_hub[cli]"
pip install -e .
cd ..

# 6. Login a Hugging Face
echo "[?] Ingresa tu token de Hugging Face para descargar el modelo:"
huggingface-cli login

# 7. Descargar modelo base
huggingface-cli download $MODEL_REPO --local-dir checkpoints/fish-speech-1.5

# 8. Crear archivo de configuración
cat > config.env <<EOF
# Configuración del servidor Fish TTS
PORT=8000
VOICE_EMBEDDING=$EMBEDDING_NAME
EOF

# 9. Copiar scripts principales
cat > clone_voice.py <<'EOF'
<OMITIDO POR LONGITUD>
EOF

cat > synthesize.py <<'EOF'
<OMITIDO POR LONGITUD>
EOF

cat > tts_server.py <<'EOF'
<OMITIDO POR LONGITUD>
EOF

# 10. Crear README.md
cat > README.md <<'EOF'
<OMITIDO POR LONGITUD>
EOF

# 11. Final
echo "[✔] Instalación completada."
echo "[i] Activa el entorno con: source venv/bin/activate"
echo "[i] Clona tu voz con: python clone_voice.py --audio sample.wav --text "Tu transcripción aquí""
echo "[i] Lanza el servidor con: uvicorn tts_server:app --host 0.0.0.0 --port \$PORT"
