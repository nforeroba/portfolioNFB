"""Huella vocal con ECAPA-TDNN (SpeechBrain) y operaciones sobre huellas."""

from pathlib import Path

import numpy as np

from .config import MODELO_HUELLA, SR


def normalizar(vector):
    """Lleva una huella (o un lote, por filas) a norma 1."""
    vector = np.asarray(vector, dtype=np.float32)
    norma = np.linalg.norm(vector, axis=-1, keepdims=True)
    return vector / np.maximum(norma, 1e-12)


def plantilla(huellas):
    """Plantilla de una persona: promedio de sus huellas normalizadas, renormalizado."""
    return normalizar(normalizar(huellas).mean(axis=0))


def similitud(a, b):
    """Coseno entre huellas; acepta vectores o matrices (por filas)."""
    return normalizar(a) @ normalizar(b).T


class ExtractorHuella:
    def __init__(self, dir_modelos):
        import torch
        from speechbrain.inference.speaker import EncoderClassifier

        self._torch = torch
        self.modelo = EncoderClassifier.from_hparams(
            source=MODELO_HUELLA,
            savedir=str(Path(dir_modelos) / "speechbrain" / "spkrec-ecapa-voxceleb"),
            run_opts={"device": "cpu"},
        )

    def extraer(self, voz):
        """Huella normalizada (192 valores) de un fragmento de voz a 16 kHz."""
        if len(voz) < SR // 2:
            raise ValueError("Se necesita al menos medio segundo de voz para extraer una huella.")
        with self._torch.inference_mode():
            emb = self.modelo.encode_batch(self._torch.from_numpy(np.asarray(voz, dtype=np.float32)).unsqueeze(0))
        return normalizar(emb.squeeze().cpu().numpy())
