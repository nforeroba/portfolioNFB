"""Tiempos por paso de la validación y recursos del sistema (CPU, RAM, hilos).

  - Cronometro: registra cada paso con su inicio y duración relativos al comienzo
    de la petición, y el carril (hilo) donde corrió, para dibujar lo que va en paralelo.
  - Monitor: muestrea el proceso y la máquina cada segundo en segundo plano y
    mide el consumo de cada validación (segundos de CPU y pico de RAM).
  - ficha_sistema: arquitectura, procesador, memoria, versiones y modelos.

Dentro de Docker, "máquina" es lo que reporta el kernel del anfitrión (CPU y RAM
totales); "servicio" es el proceso de esta aplicación.
"""

import os
import platform
import statistics
import threading
import time
from collections import deque
from contextlib import contextmanager

import psutil

# Pasos del servidor, en orden, con el nombre que ve la persona.
PASOS = {
    "recepcion": "Recepción del audio",
    "desafio": "Verificación del desafío",
    "lectura_audio": "Lectura y conversión a 16 kHz",
    "espera_turno": "Espera de turno de inferencia",
    "vad": "Detección de voz (Silero VAD)",
    "huella": "Huella vocal (ECAPA-TDNN)",
    "stt": "Transcripción (Whisper)",
    "busqueda": "Búsqueda 1:N en Qdrant",
    "decision": "Decisión y prueba de vida",
    "perfil": "Perfil acústico (Praat)",
    "espectrograma": "Espectrograma mel",
    "tono": "Trayectoria del tono (F0)",
    "candidato": "Huella del mejor candidato",
    "mapa": "Proyección en el mapa 2D",
    "bitacora": "Registro en la bitácora",
}

MB = 1024 * 1024


class Cronometro:
    def __init__(self, inicio=None):
        self.t0 = inicio if inicio is not None else time.perf_counter()
        self.pasos = []
        self._lock = threading.Lock()

    @contextmanager
    def paso(self, clave, carril="principal"):
        t = time.perf_counter()
        try:
            yield
        finally:
            self.anotar(clave, t, time.perf_counter(), carril)

    def anotar(self, clave, desde, hasta, carril="principal"):
        with self._lock:
            self.pasos.append({"paso": clave, "carril": carril,
                               "inicio_s": round(desde - self.t0, 4), "duracion_s": round(hasta - desde, 4)})

    def total(self):
        return round(time.perf_counter() - self.t0, 4)


class Monitor:
    def __init__(self, intervalo_s=1.0, muestras=300):
        self.intervalo_s = intervalo_s
        self.proceso = psutil.Process()
        self.nucleos = psutil.cpu_count() or 1
        self.historia = deque(maxlen=muestras)
        self._lock = threading.Lock()
        self.proceso.cpu_percent(None)       # la primera lectura siempre da 0: se descarta
        psutil.cpu_percent(None)
        threading.Thread(target=self._bucle, daemon=True, name="monitor-recursos").start()

    def _bucle(self):
        while True:
            time.sleep(self.intervalo_s)
            try:
                muestra = self._muestra()
            except Exception:  # noqa: BLE001  (el monitor nunca debe tumbar el servicio)
                continue
            with self._lock:
                self.historia.append(muestra)

    def _muestra(self):
        memoria = psutil.virtual_memory()
        return {
            "t": round(time.time(), 1),
            # % de la máquina completa (100 % = todos los núcleos ocupados)
            "cpu_servicio_pct": round(self.proceso.cpu_percent(None) / self.nucleos, 1),
            "cpu_maquina_pct": round(psutil.cpu_percent(None), 1),
            "ram_servicio_mb": round(self.proceso.memory_info().rss / MB),
            "ram_maquina_usada_mb": round((memoria.total - memoria.available) / MB),
            "ram_maquina_total_mb": round(memoria.total / MB),
            "hilos": self.proceso.num_threads(),
        }

    def estado(self):
        with self._lock:
            historia = list(self.historia)
        return {"intervalo_s": self.intervalo_s, "nucleos": self.nucleos,
                "actual": historia[-1] if historia else None, "historia": historia}

    @contextmanager
    def consumo(self, destino):
        """
        Mide una validación: segundos de CPU del proceso (todos sus hilos) y pico
        de RAM, muestreando la memoria cada 50 ms. Si hay otras peticiones a la
        vez, su consumo se suma.
        """
        cpu_antes = self.proceso.cpu_times()
        pico = {"rss": self.proceso.memory_info().rss}
        inicio_rss = pico["rss"]
        parar = threading.Event()

        def vigilar():
            while not parar.wait(0.05):
                try:
                    pico["rss"] = max(pico["rss"], self.proceso.memory_info().rss)
                except Exception:  # noqa: BLE001
                    return

        hilo = threading.Thread(target=vigilar, daemon=True)
        hilo.start()
        t = time.perf_counter()
        try:
            yield
        finally:
            parar.set()
            hilo.join(timeout=0.2)
            cpu_despues = self.proceso.cpu_times()
            pared = time.perf_counter() - t
            cpu = (cpu_despues.user - cpu_antes.user) + (cpu_despues.system - cpu_antes.system)
            destino.update({
                "cpu_s": round(cpu, 3),
                "nucleos_promedio": round(cpu / pared, 2) if pared > 0 else None,
                "ram_inicio_mb": round(inicio_rss / MB),
                "ram_pico_mb": round(pico["rss"] / MB),
            })


def _procesador():
    modelo = platform.processor() or None
    try:
        with open("/proc/cpuinfo", encoding="utf-8") as f:
            for linea in f:
                if linea.lower().startswith(("model name", "hardware")):
                    modelo = linea.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    return modelo


def ficha_sistema(modelos, segundos_carga, estado_sync):
    import torch

    memoria = psutil.virtual_memory()
    try:
        import ctranslate2
        version_ct2 = ctranslate2.__version__
    except Exception:  # noqa: BLE001
        version_ct2 = None
    gpu = "Disponible pero no se usa: los modelos corren en CPU" if torch.cuda.is_available() \
        else "No se usa: los modelos corren en CPU"
    resumen = (estado_sync or {}).get("ultimo_resumen") or {}
    return {
        "arquitectura": platform.machine(),
        "procesador": _procesador(),
        "nucleos": psutil.cpu_count(),
        "nucleos_fisicos": psutil.cpu_count(logical=False),
        "ram_total_mb": round(memoria.total / MB),
        "sistema": f"{platform.system()} {platform.release()}",
        "en_docker": os.path.exists("/.dockerenv"),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "hilos_torch": torch.get_num_threads(),
        "ctranslate2": version_ct2,
        "gpu": gpu,
        "modelos": modelos,
        "carga_modelos_s": segundos_carga,
        "ultima_sincronizacion": {
            "duracion_s": resumen.get("duracion_s"),
            "fin_utc": resumen.get("fin_utc"),
            "personas": resumen.get("personas_total"),
        } if resumen else None,
    }


def _percentil(valores, p):
    if not valores:
        return None
    ordenados = sorted(valores)
    k = (len(ordenados) - 1) * p
    i = int(k)
    j = min(i + 1, len(ordenados) - 1)
    return ordenados[i] + (ordenados[j] - ordenados[i]) * (k - i)


def estadisticas(registros):
    """Mediana y p95 por paso, por total y por consumo, sobre registros de la bitácora."""
    por_paso = {clave: [] for clave in PASOS}
    totales, cpus, picos = [], [], []
    for r in registros:
        duraciones = {}
        for p in r.get("pasos", []):
            duraciones[p["paso"]] = duraciones.get(p["paso"], 0) + p["duracion_s"]
        for clave, d in duraciones.items():
            if clave in por_paso:
                por_paso[clave].append(d)
        if r.get("tiempo_total_s") is not None:
            totales.append(r["tiempo_total_s"])
        consumo = r.get("consumo") or {}
        if consumo.get("cpu_s") is not None:
            cpus.append(consumo["cpu_s"])
        if consumo.get("ram_pico_mb") is not None:
            picos.append(consumo["ram_pico_mb"])

    def resumir(valores, decimales=3):
        if not valores:
            return {"n": 0, "mediana": None, "p95": None}
        return {"n": len(valores), "mediana": round(statistics.median(valores), decimales),
                "p95": round(_percentil(valores, 0.95), decimales)}

    return {
        "n": len(registros),
        "pasos": [{"paso": c, "nombre": PASOS[c], **resumir(v)} for c, v in por_paso.items() if v],
        "total_s": resumir(totales),
        "cpu_s": resumir(cpus),
        "ram_pico_mb": resumir(picos, 0),
    }
