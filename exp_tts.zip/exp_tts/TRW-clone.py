import torch
from TTS.api import TTS
from TTS.tts.configs.xtts_config import XttsConfig  # Importar la configuración del modelo
from TTS.tts.models.xtts import XttsAudioConfig, XttsArgs  # Importar la configuración de audio del modelo y argumentos
from TTS.config.shared_configs import BaseDatasetConfig  # Importar configuración del dataset

# Permitir la carga segura del modelo en PyTorch 2.6+
torch.serialization.add_safe_globals([XttsConfig, XttsAudioConfig, BaseDatasetConfig, XttsArgs])

# Obtener el dispositivo disponible ('cuda' o 'cpu')
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

# Definir el texto a sintetizar
txt = "hola hola hola. esta es la voz clonada de cristina hernandez utilizando coqui en linux. hablo en representacion de nicolas forero. los numeros son uno dos tres cuatro cinco."

# Definir el audio de referencia
sample = "/home/nfb/Documents/cristina_sample.wav"

# Cargar el modelo y moverlo al dispositivo
tts1 = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(device)

# Generar el audio clonando la voz del sample
tts1.tts_to_file(txt, speaker_wav=sample, language="es", file_path="/home/nfb/Documents/cristina_clon.wav")

print("Síntesis de voz completada. Archivo guardado en /home/nfb/Documents/cristina_clon.wav")
