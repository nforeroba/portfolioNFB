"""
Servicio gRPC TTS, Fish Audio S2-Pro con motor SGLang-Omni.
Traduce el contrato gRPC (tts_service.proto) hacia la API HTTP de
sgl-omni serve, que corre como proceso separado dentro del mismo
contenedor (localhost:SGLANG_OMNI_PORT).

Las voces en /voices y /app/samples se precargan en memoria al
arrancar (voice_cache.py): cada request usa vq_codes ya calculados,
sin volver a leer el disco.
"""

import argparse
import asyncio
import base64
import io
import json
import logging
import os
import time
from pathlib import Path

import grpc
import grpc.aio
import httpx
from pydub import AudioSegment

import tts_service_pb2
import tts_service_pb2_grpc
import voice_cache

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s|%(name)s|%(levelname)s|%(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("tts_service")

logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)


def load_config(path: str) -> dict:
    defaults = {
        "listen": "0.0.0.0:8009",
        "temperature": 0.8,
        "top_p": 0.8,
        "top_k": 20,
        "default_reference_id": "vanessa",
        "sglang_omni_base_url": "http://127.0.0.1:8000",
        "sglang_omni_model": "fishaudio/s2-pro",
        "request_timeout_s": 120.0,
        "initial_codec_chunk_frames": None,
        "max_audio_duration_sanity_s": 60.0,
        "unary_response_format": "wav",
    }
    try:
        with open(path) as f:
            cfg = json.load(f)
        defaults.update(cfg)
        logger.info("Configuración cargada desde %s", path)
    except FileNotFoundError:
        logger.warning("Config no encontrada en %s, usando defaults", path)
    logger.debug("Config: %s", json.dumps(defaults))
    return defaults


VOICES_DIR = Path(os.environ.get("VOICES_DIR", "/voices"))
SAMPLES_DIR = Path("/app/samples")


def wav_bytes_to_opus(wav_bytes: bytes) -> tuple[bytes, float]:
    t0 = time.perf_counter()
    audio = AudioSegment.from_wav(io.BytesIO(wav_bytes))
    duration = len(audio) / 1000.0

    buf = io.BytesIO()
    audio.export(buf, format="opus", codec="libopus")
    opus_bytes = buf.getvalue()

    elapsed = time.perf_counter() - t0
    logger.debug(
        "WAV->Opus | dur=%.3fs | opus_size=%d bytes | conv_time=%.3fs",
        duration, len(opus_bytes), elapsed,
    )
    return opus_bytes, duration


def pcm_chunk_to_opus(pcm_bytes: bytes, sample_rate: int = 44100,
                       channels: int = 1, sample_width: int = 2) -> tuple[bytes, float]:
    audio = AudioSegment(
        data=pcm_bytes,
        sample_width=sample_width,
        frame_rate=sample_rate,
        channels=channels,
    )
    duration = len(audio) / 1000.0

    buf = io.BytesIO()
    audio.export(buf, format="opus", codec="libopus")
    opus_bytes = buf.getvalue()

    return opus_bytes, duration


class SGLangOmniClient:
    def __init__(self, base_url: str, model: str, timeout_s: float):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout_s = timeout_s
        self._client: httpx.AsyncClient | None = None

    async def start(self):
        self._client = httpx.AsyncClient(timeout=self.timeout_s)

    async def stop(self):
        if self._client:
            await self._client.aclose()

    def _build_payload(
        self,
        text: str,
        vq_codes: list,
        transcript: str,
        temperature: float,
        top_p: float,
        top_k: int,
        stream: bool,
        initial_codec_chunk_frames: int | None,
        response_format: str | None = None,
    ) -> dict:
        payload = {
            "model": self.model,
            "input": text,
            "temperature": temperature,
            "top_p": top_p,
            "top_k": top_k,
            "stream": stream,
            "references": [
                {"vq_codes": vq_codes, "text": transcript}
            ],
        }
        if stream:
            payload["response_format"] = response_format or "pcm"
            if initial_codec_chunk_frames is not None:
                payload["initial_codec_chunk_frames"] = initial_codec_chunk_frames
        elif response_format:
            payload["response_format"] = response_format
        return payload

    async def synthesize_unary(
        self, text: str, vq_codes: list, transcript: str,
        temperature: float, top_p: float, top_k: int,
        response_format: str | None = None,
    ) -> bytes:
        payload = self._build_payload(
            text, vq_codes, transcript, temperature, top_p, top_k,
            stream=False, initial_codec_chunk_frames=None,
            response_format=response_format,
        )
        logger.debug(
            "HTTP -> sgl-omni | POST /v1/audio/speech | vq_codes_len=%d | response_format=%s",
            len(vq_codes[0]) if vq_codes else 0, response_format or "wav",
        )

        resp = await self._client.post(
            f"{self.base_url}/v1/audio/speech", json=payload,
        )
        if resp.status_code != 200:
            raise RuntimeError(
                f"sgl-omni serve devolvió {resp.status_code}: {resp.text}"
            )
        return resp.content

    async def synthesize_stream(
        self, text: str, vq_codes: list, transcript: str,
        temperature: float, top_p: float, top_k: int,
        initial_codec_chunk_frames: int | None,
    ):
        payload = self._build_payload(
            text, vq_codes, transcript, temperature, top_p, top_k,
            stream=True, initial_codec_chunk_frames=initial_codec_chunk_frames,
        )
        logger.debug(
            "HTTP -> sgl-omni (stream) | POST /v1/audio/speech | vq_codes_len=%d",
            len(vq_codes[0]) if vq_codes else 0,
        )

        async with self._client.stream(
            "POST", f"{self.base_url}/v1/audio/speech", json=payload,
        ) as resp:
            if resp.status_code != 200:
                body = await resp.aread()
                raise RuntimeError(
                    f"sgl-omni serve devolvió {resp.status_code}: {body!r}"
                )

            async for line in resp.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data_str = line[len("data:"):].strip()
                if data_str == "[DONE]":
                    break
                try:
                    event = json.loads(data_str)
                except json.JSONDecodeError:
                    logger.warning("SSE | línea no-JSON ignorada: %r", data_str)
                    continue

                audio_b64 = (
                    event.get("audio")
                    or event.get("chunk", {}).get("audio")
                    or event.get("data")
                )
                if audio_b64 is None:
                    logger.warning("SSE | evento sin campo de audio reconocible: %s", event)
                    continue

                pcm_bytes = base64.b64decode(audio_b64)
                yield pcm_bytes


class TTSServicer(tts_service_pb2_grpc.TTSServiceServicer):

    def __init__(self, omni_client: SGLangOmniClient, config: dict, voices: voice_cache.VoiceCache):
        self.omni = omni_client
        self.config = config
        self.voices = voices

    def _resolve_params(self, request: tts_service_pb2.ServeTTSRequest):
        reference_id = request.reference_id or self.config["default_reference_id"]
        temperature = request.temperature or self.config["temperature"]
        top_p = request.top_p or self.config["top_p"]
        top_k = request.top_k or self.config["top_k"]
        return reference_id, temperature, top_p, top_k

    async def TTS(
        self,
        request: tts_service_pb2.ServeTTSRequest,
        context: grpc.aio.ServicerContext,
    ) -> tts_service_pb2.ServeAudioResponse:

        t_total = time.perf_counter()
        text = request.text
        reference_id, temperature, top_p, top_k = self._resolve_params(request)

        logger.info(
            "REQUEST (unary) | text_len=%d | voz=%s | temp=%.2f | top_p=%.2f | top_k=%d",
            len(text), reference_id, temperature, top_p, top_k,
        )

        vq_codes, transcript = self.voices.get(reference_id)

        unary_format = self.config.get("unary_response_format", "wav")
        request_format = "pcm" if unary_format == "pcm" else None

        t0 = time.perf_counter()
        try:
            audio_bytes = await self.omni.synthesize_unary(
                text, vq_codes, transcript, temperature, top_p, top_k,
                response_format=request_format,
            )
        except Exception as e:
            logger.exception("INFERENCIA | falló: %s", e)
            await context.abort(grpc.StatusCode.INTERNAL, f"Error en síntesis: {e}")
            return
        logger.info("INFERENCIA | fin | elapsed=%.3fs", time.perf_counter() - t0)

        t0 = time.perf_counter()
        if unary_format == "pcm":
            opus_bytes, audio_duration = pcm_chunk_to_opus(audio_bytes)
            logger.debug("CONVERSIÓN | PCM->Opus | elapsed=%.3fs", time.perf_counter() - t0)
        else:
            opus_bytes, audio_duration = wav_bytes_to_opus(audio_bytes)
            logger.debug("CONVERSIÓN | WAV->Opus | elapsed=%.3fs", time.perf_counter() - t0)

        total_elapsed = time.perf_counter() - t_total
        rtf = total_elapsed / audio_duration if audio_duration > 0 else 0.0
        logger.info(
            "RESPONSE (unary) | voz=%s | formato=%s | audio_dur=%.3fs | total_time=%.3fs | RTF=%.4f",
            reference_id, unary_format, audio_duration, total_elapsed, rtf,
        )

        return tts_service_pb2.ServeAudioResponse(
            audio_bytes=opus_bytes,
            audio_duration=audio_duration,
        )

    async def TTSStream(
        self,
        request: tts_service_pb2.ServeTTSRequest,
        context: grpc.aio.ServicerContext,
    ):
        t_total = time.perf_counter()
        text = request.text
        reference_id, temperature, top_p, top_k = self._resolve_params(request)
        chunk_frames = self.config.get("initial_codec_chunk_frames")

        logger.info(
            "REQUEST (stream) | text_len=%d | voz=%s | temp=%.2f | top_p=%.2f | top_k=%d",
            len(text), reference_id, temperature, top_p, top_k,
        )

        vq_codes, transcript = self.voices.get(reference_id)

        max_sane_duration = self.config.get("max_audio_duration_sanity_s", 60.0)
        accumulated_duration = 0.0
        chunk_count = 0

        try:
            async for pcm_bytes in self.omni.synthesize_stream(
                text, vq_codes, transcript, temperature, top_p, top_k,
                initial_codec_chunk_frames=chunk_frames,
            ):
                opus_bytes, chunk_duration = pcm_chunk_to_opus(pcm_bytes)
                accumulated_duration += chunk_duration
                chunk_count += 1

                if accumulated_duration > max_sane_duration:
                    logger.error(
                        "SANITY CHECK | duración acumulada %.1fs excede el umbral %.1fs",
                        accumulated_duration, max_sane_duration,
                    )
                    await context.abort(
                        grpc.StatusCode.INTERNAL,
                        "Duración de audio generada excede el límite de sanidad",
                    )
                    return

                logger.debug(
                    "STREAM | chunk #%d | dur=%.3fs | acumulado=%.3fs",
                    chunk_count, chunk_duration, accumulated_duration,
                )

                yield tts_service_pb2.ServeAudioResponse(
                    audio_bytes=opus_bytes,
                    audio_duration=chunk_duration,
                )
        except Exception as e:
            logger.exception("INFERENCIA (stream) | falló: %s", e)
            await context.abort(grpc.StatusCode.INTERNAL, f"Error en síntesis: {e}")
            return

        total_elapsed = time.perf_counter() - t_total
        rtf = total_elapsed / accumulated_duration if accumulated_duration > 0 else 0.0
        logger.info(
            "RESPONSE (stream) | voz=%s | chunks=%d | audio_dur=%.3fs | total_time=%.3fs | RTF=%.4f",
            reference_id, chunk_count, accumulated_duration, total_elapsed, rtf,
        )


async def serve(omni_client: SGLangOmniClient, config: dict, voices: voice_cache.VoiceCache, port: int):
    listen_addr = f"0.0.0.0:{port}"
    server = grpc.aio.server()
    tts_service_pb2_grpc.add_TTSServiceServicer_to_server(
        TTSServicer(omni_client, config, voices), server
    )
    server.add_insecure_port(listen_addr)

    await server.start()
    logger.info("gRPC escuchando en %s", listen_addr)
    logger.info("Motor interno (sgl-omni serve): %s", config["sglang_omni_base_url"])
    logger.info("Servicio listo para recibir requests")

    await server.wait_for_termination()


async def wait_for_sglang_omni(base_url: str, timeout_s: float = 900.0):
    logger.info("Esperando a que sgl-omni serve esté listo en %s", base_url)
    t0 = time.perf_counter()
    poll_interval_s = 5.0
    progress_every_s = 30.0
    last_progress = t0

    async with httpx.AsyncClient(timeout=5.0) as client:
        while time.perf_counter() - t0 < timeout_s:
            try:
                resp = await client.get(f"{base_url}/health")
                if resp.status_code == 200:
                    logger.info(
                        "sgl-omni serve listo | elapsed=%.1fs",
                        time.perf_counter() - t0,
                    )
                    return
            except Exception:
                pass

            now = time.perf_counter()
            if now - last_progress >= progress_every_s:
                logger.info(
                    "Sigue esperando a sgl-omni serve... (%.0fs transcurridos)",
                    now - t0,
                )
                last_progress = now

            await asyncio.sleep(poll_interval_s)
    raise TimeoutError(
        f"sgl-omni serve no respondió en {timeout_s}s"
    )


def parse_args():
    parser = argparse.ArgumentParser(description="Fish Audio S2-Pro TTS gRPC Service (SGLang-Omni)")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8009)))
    parser.add_argument("--config", default="/app/config_tts.json")
    return parser.parse_args()


async def main_async():
    t_start = time.perf_counter()
    args = parse_args()
    config = load_config(args.config)

    await wait_for_sglang_omni(config["sglang_omni_base_url"])

    voices = voice_cache.VoiceCache(checkpoint_dir=config["sglang_omni_model"])
    voices.load_all(
        voices_dirs=[VOICES_DIR, SAMPLES_DIR],
        default_reference_id=config["default_reference_id"],
    )
    logger.info("Voces disponibles: %s", voices.known_ids())

    omni_client = SGLangOmniClient(
        base_url=config["sglang_omni_base_url"],
        model=config["sglang_omni_model"],
        timeout_s=config["request_timeout_s"],
    )
    await omni_client.start()

    logger.info(
        "ARRANQUE | wrapper gRPC listo | elapsed_total=%.2fs",
        time.perf_counter() - t_start,
    )

    try:
        await serve(omni_client, config, voices, args.port)
    finally:
        await omni_client.stop()


def main():
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
