#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Servicio de procesamiento de PDFs e imágenes a Markdown.
Este script implementa un servicio que monitorea continuamente
una carpeta de entrada y procesa los archivos encontrados.
Incorpora procesamiento VLM como fallback para PDFs problemáticos
y para extraer texto de imágenes en diversos formatos.
"""

import time
import signal
import logging
import sys
import multiprocessing
from pathlib import Path

# Importar módulos del proyecto
from pdf_image_processor import PDFImageProcessor
import config

# Configuración de logging
log_file = Path(config.LOG_DIR) / "service.log"
log_file.parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("ProcessorService")

# Variable para controlar la ejecución del servicio
running = True

def signal_handler(sig, frame):
    """
    Manejador de señales para detener el servicio correctamente.
    """
    global running
    logger.info("Señal de terminación recibida. Deteniendo servicio...")
    running = False

def run_service():
    """
    Función principal del servicio.
    Monitorea la carpeta de entrada y procesa los archivos encontrados.
    """
    logger.info("Iniciando servicio de procesamiento de PDFs e imágenes a Markdown")
    logger.info(f"Carpeta de entrada: {config.INPUT_DIR}")
    logger.info(f"Carpeta de salida: {config.OUTPUT_DIR}")
    logger.info(f"Tiempo límite para procesar archivos: {config.PDF_PROCESSING_TIMEOUT} segundos")
    logger.info(f"Tiempo límite para extracción directa PDF: {config.PDF_EXTRACTION_TIMEOUT} segundos")
    
    # Mostrar información de formatos soportados
    logger.info("Formatos soportados: PDF y diversos formatos de imagen (TIFF, JPG, PNG, etc.)")
    
    # Mostrar información de Ollama si está configurado
    if config.OLLAMA_ENABLED:
        logger.info(f"Endpoint Ollama: {config.OLLAMA_ENDPOINT}")
        logger.info(f"Modelo Ollama: {config.OLLAMA_MODEL}")
    else:
        logger.warning("Procesamiento con Ollama desactivado. Los PDFs problemáticos y las imágenes no se procesarán correctamente.")
    
    # Registrar manejadores de señales para detener el servicio correctamente
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Crear instancia del procesador
    processor = PDFImageProcessor(
        input_dir=config.INPUT_DIR,
        output_dir=config.OUTPUT_DIR,
        log_dir=config.LOG_DIR,
        ollama_endpoint=config.OLLAMA_ENDPOINT if config.OLLAMA_ENABLED else None,
        ollama_model=config.OLLAMA_MODEL,
        extraction_timeout=config.PDF_EXTRACTION_TIMEOUT
    )
    
    # Configurar tiempo límite para procesamiento completo
    processor.PDF_PROCESSING_TIMEOUT = config.PDF_PROCESSING_TIMEOUT
    
    try:
        # Bucle principal del servicio
        while running:
            logger.info("Buscando archivos para procesar...")
            
            try:
                stats = processor.process_all()
                
                total_processed = stats["pdf_processed"] + stats["image_processed"]
                total_failed = stats["pdf_failed"] + stats["image_failed"]
                total_skipped = stats["pdf_skipped"] + stats["image_skipped"]
                
                if total_processed + total_failed + total_skipped > 0:
                    logger.info(f"Ciclo completado: {total_processed} archivos procesados, {total_failed} fallidos, {total_skipped} omitidos")
                    logger.info(f"Desglose - PDFs: {stats['pdf_processed']} procesados, {stats['pdf_failed']} fallidos")
                    logger.info(f"Desglose - Imágenes: {stats['image_processed']} procesadas, {stats['image_failed']} fallidas")
                else:
                    logger.info("No se encontraron nuevos archivos para procesar que cumplan con los criterios")
                    
            except Exception as e:
                logger.error(f"Error durante el procesamiento: {str(e)}")
            
            # Esperar antes del próximo ciclo
            logger.info(f"Esperando {config.SCAN_INTERVAL} segundos para el próximo ciclo...")
            
            # Implementar espera que puede ser interrumpida por señales
            for _ in range(config.SCAN_INTERVAL):
                if not running:
                    break
                time.sleep(1)
    
    except Exception as e:
        logger.error(f"Error crítico en el servicio: {str(e)}")
    
    finally:
        logger.info("Servicio detenido")

if __name__ == "__main__":
    # Verificar si se está ejecutando como proceso principal
    # (necesario para multiprocessing en Windows)
    if multiprocessing.current_process().name == 'MainProcess':
        multiprocessing.freeze_support()
        
    run_service()
