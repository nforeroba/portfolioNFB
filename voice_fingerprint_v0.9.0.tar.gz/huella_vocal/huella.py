"""Huella vocal con ECAPA-TDNN (SpeechBrain) y operaciones sobre huellas."""

import re
from pathlib import Path

import numpy as np

from .config import SR

# Voz mínima para calcular una huella. ECAPA funciona desde unos 50 ms (con menos, sus
# capas convolucionales no tienen cuadros suficientes). La validación y el registro
# exigen mucho más (3 s); este mínimo solo importa en el experimento Umbral.
MINIMO_HUELLA_S = 0.1


def normalizar(vector):
    """Lleva una huella (o un lote, por filas) a norma 1."""
    vector = np.asarray(vector, dtype=np.float32)
    norma = np.linalg.norm(vector, axis=-1, keepdims=True)
    return vector / np.maximum(norma, 1e-12)


def plantilla(huellas):
    """Plantilla de una persona: promedio de sus huellas normalizadas, renormalizado."""
    return normalizar(normalizar(huellas).mean(axis=0))


def similitud(a, b):
    """Coseno entre huellas; acepta vectores o matrices (por filas)."""
    return normalizar(a) @ normalizar(b).T


class ExtractorHuella:
    """
    Carga ECAPA-TDNN desde una carpeta local (los archivos del repositorio
    speechbrain/spkrec-ecapa-voxceleb). No descarga ni escribe nada:
      - savedir=None: SpeechBrain usa los archivos donde están (sin enlaces ni copias).
      - pretrained_path apunta a la carpeta local: los pesos no se buscan en Hugging Face.
    """

    def __init__(self, ruta_ecapa, dispositivo="cpu"):
        """
        dispositivo: "cpu" o "gpu". Con "gpu" se carga en CUDA y se prueba con un audio corto;
        si no hay GPU o falla, queda en CPU y `aviso` explica por qué.
        """
        import torch

        self._torch = torch
        self.ruta = Path(ruta_ecapa).resolve()
        self.dispositivo = "cpu"            # el que quedó en uso: "cpu" o "cuda"
        self.aviso = None
        if dispositivo == "gpu":
            if not torch.cuda.is_available():
                self.aviso = ("ECAPA: se pidió GPU pero PyTorch no ve ninguna (¿el contenedor no tiene acceso "
                              "a la GPU o el controlador es muy antiguo?). Sigue en CPU.")
            else:
                try:
                    self.modelo = self._cargar("cuda:0")
                    self.extraer(np.random.default_rng(0).standard_normal(SR).astype(np.float32) * 0.01)
                    self.dispositivo = "cuda"
                    return
                except Exception as exc:  # noqa: BLE001 — cualquier fallo de la GPU deja el modelo en CPU
                    self.aviso = f"ECAPA: la GPU falló al probarla ({type(exc).__name__}: {exc}). Sigue en CPU."
        self.modelo = self._cargar("cpu")

    def _cargar(self, dispositivo):
        from speechbrain.inference.speaker import EncoderClassifier

        hiperparametros = (self.ruta / "hyperparams.yaml").read_text(encoding="utf-8")
        overrides = {}
        if re.search(r"^pretrained_path\s*:", hiperparametros, flags=re.MULTILINE):
            overrides["pretrained_path"] = str(self.ruta)
        return EncoderClassifier.from_hparams(
            source=str(self.ruta), savedir=None, overrides=overrides, run_opts={"device": dispositivo},
        )

    def extraer(self, voz):
        """Huella normalizada (192 valores) de un fragmento de voz a 16 kHz."""
        if len(voz) < int(MINIMO_HUELLA_S * SR):
            raise ValueError(f"Se necesitan al menos {MINIMO_HUELLA_S * 1000:.0f} ms de voz para extraer una huella.")
        with self._torch.inference_mode():
            emb = self.modelo.encode_batch(self._torch.from_numpy(np.asarray(voz, dtype=np.float32)).unsqueeze(0))
        return normalizar(emb.squeeze().cpu().numpy())
