"""Prueba de vida anti-reproducción: ¿la persona repitió los dígitos pedidos?

Se transcribe la voz con faster-whisper (base, int8, CPU), se extraen los
dígitos de la transcripción (vengan escritos como "4, 7", "47" o "cuatro siete")
y se comparan con la secuencia pedida.
"""

import os
import unicodedata
from pathlib import Path

from .config import ERRORES_DIGITOS_PERMITIDOS, MODELO_STT, SR

_UNIDADES = {
    "cero": 0, "uno": 1, "una": 1, "un": 1, "dos": 2, "tres": 3, "cuatro": 4,
    "cinco": 5, "seis": 6, "siete": 7, "ocho": 8, "nueve": 9,
}
_ESPECIALES = {
    "diez": 10, "once": 11, "doce": 12, "trece": 13, "catorce": 14, "quince": 15,
    "dieciseis": 16, "diecisiete": 17, "dieciocho": 18, "diecinueve": 19, "veinte": 20,
    "veintiuno": 21, "veintiun": 21, "veintidos": 22, "veintitres": 23, "veinticuatro": 24,
    "veinticinco": 25, "veintiseis": 26, "veintisiete": 27, "veintiocho": 28, "veintinueve": 29,
}
_DECENAS = {"treinta": 30, "cuarenta": 40, "cincuenta": 50, "sesenta": 60, "setenta": 70, "ochenta": 80, "noventa": 90}


def normalizar_texto(texto):
    """Minúsculas, sin tildes ni signos, espacios simples."""
    texto = unicodedata.normalize("NFKD", texto.lower())
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return " ".join("".join(c if c.isalnum() else " " for c in texto).split())


def _fichas_digitos(trozos):
    """
    trozos: lista de (palabra_normalizada, inicio, fin). Devuelve (digitos, inicio, fin)
    por cada número dicho, en orden. Si se agruparon ("cuarenta y siete"), se toman sus cifras.
    """
    fichas = []
    i = 0
    while i < len(trozos):
        p, ini, fin = trozos[i]
        if p.isdigit():
            fichas.append((p, ini, fin))
        elif p in _UNIDADES:
            fichas.append((str(_UNIDADES[p]), ini, fin))
        elif p in _ESPECIALES:
            fichas.append((str(_ESPECIALES[p]), ini, fin))
        elif p in _DECENAS:
            valor = _DECENAS[p]
            if i + 2 < len(trozos) and trozos[i + 1][0] == "y" and trozos[i + 2][0] in _UNIDADES:
                valor += _UNIDADES[trozos[i + 2][0]]
                fin = trozos[i + 2][2]
                i += 2
            fichas.append((str(valor), ini, fin))
        i += 1
    return fichas


def extraer_digitos(texto):
    """Secuencia de dígitos dicha en el texto, en orden ("4, 7", "47", "cuatro siete", "cuarenta y siete")."""
    return "".join(d for d, _, _ in _fichas_digitos([(p, None, None) for p in normalizar_texto(texto).split()]))


def marcas_digitos(palabras):
    """
    Momento en que se dijo cada dígito, a partir de las palabras con tiempo del STT.
    Una palabra con varias cifras ("472951", "5-3-1") reparte su duración entre ellas.
    """
    trozos = []
    for palabra in palabras:
        for p in normalizar_texto(palabra["texto"]).split():
            trozos.append((p, palabra["inicio"], palabra["fin"]))
    marcas = []
    for digitos, ini, fin in _fichas_digitos(trozos):
        paso = (fin - ini) / len(digitos)
        for k, d in enumerate(digitos):
            marcas.append({"digito": d, "inicio": round(ini + k * paso, 3), "fin": round(ini + (k + 1) * paso, 3)})
    return marcas


def _levenshtein(a, b):
    if len(a) < len(b):
        a, b = b, a
    anterior = list(range(len(b) + 1))
    for i, x in enumerate(a, start=1):
        actual = [i]
        for j, y in enumerate(b, start=1):
            actual.append(min(anterior[j] + 1, actual[j - 1] + 1, anterior[j - 1] + (x != y)))
        anterior = actual
    return anterior[-1]


def errores_digitos(oidos, pedidos):
    """
    Menor número de errores entre la secuencia pedida y cualquier tramo seguido
    de los dígitos oídos (así no estorban números sueltos dichos antes o después).
    """
    if not oidos:
        return len(pedidos)
    mejor = len(pedidos)
    for largo in range(max(1, len(pedidos) - 1), len(pedidos) + 2):
        for inicio in range(0, max(1, len(oidos) - largo + 1)):
            mejor = min(mejor, _levenshtein(oidos[inicio:inicio + largo], pedidos))
    return mejor


def verificar_digitos(transcripcion, pedidos, permitidos=ERRORES_DIGITOS_PERMITIDOS):
    oidos = extraer_digitos(transcripcion)
    errores = errores_digitos(oidos, pedidos)
    return {"aprobada": errores <= permitidos, "digitos_oidos": oidos, "errores": errores}


class Transcriptor:
    def __init__(self, dir_modelos, modelo=MODELO_STT, hilos=None):
        from faster_whisper import WhisperModel

        self.modelo = WhisperModel(
            modelo,
            device="cpu",
            compute_type="int8",
            cpu_threads=hilos or min(8, os.cpu_count() or 1),
            download_root=str(Path(dir_modelos) / "faster_whisper"),
        )

    def transcribir(self, voz):
        """Transcribe voz ya recortada por el VAD (evita alucinaciones en silencios)."""
        return self.transcribir_detallado(voz, con_tiempos=False)[0]

    def transcribir_detallado(self, voz, con_tiempos=True):
        """(texto, palabras) con el inicio y fin de cada palabra en segundos."""
        if len(voz) < SR // 2:
            return "", []
        segmentos, _ = self.modelo.transcribe(
            voz,
            language="es",
            task="transcribe",
            beam_size=1,
            condition_on_previous_text=False,
            vad_filter=False,
            word_timestamps=con_tiempos,
        )
        textos, palabras = [], []
        for segmento in segmentos:
            textos.append(segmento.text.strip())
            for w in (segmento.words or []) if con_tiempos else []:
                palabras.append({"texto": w.word, "inicio": float(w.start), "fin": float(w.end)})
        return " ".join(textos).strip(), palabras
