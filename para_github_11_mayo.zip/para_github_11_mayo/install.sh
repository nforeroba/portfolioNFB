#!/bin/bash

# Script de instalación para el módulo de síntesis de voz con Fish Speech
# Este script configura todo el entorno necesario para ejecutar el servicio de síntesis

# Colores para mejor legibilidad
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Función para imprimir mensajes con formato
print_message() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar si se está ejecutando como root
if [ "$EUID" -ne 0 ]; then
    print_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

# Crear directorio principal del proyecto
PROJECT_DIR="$(pwd)/modulo_sintesis_voz"
print_message "Creando directorio del proyecto en $PROJECT_DIR"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

# Crear directorios adicionales
mkdir -p scripts samples config

# Verificar la instalación de Python 3.10
print_message "Verificando la instalación de Python 3.10..."
if command -v python3.10 >/dev/null 2>&1; then
    print_success "Python 3.10 ya está instalado"
else
    print_message "Instalando Python 3.10..."
    apt update
    apt install -y software-properties-common
    add-apt-repository ppa:deadsnakes/ppa -y
    apt update
    apt install -y python3.10 python3.10-dev python3.10-venv python3.10-distutils
    print_success "Python 3.10 instalado correctamente"
fi

# Verificar si los drivers NVIDIA están instalados
print_message "Verificando drivers NVIDIA..."
if command -v nvidia-smi >/dev/null 2>&1; then
    print_success "Los drivers NVIDIA ya están instalados"
    nvidia-smi
else
    print_message "Instalando drivers NVIDIA Open 570..."
    apt update
    apt install -y software-properties-common
    add-apt-repository ppa:graphics-drivers/ppa -y
    apt update
    
    # Instalar drivers Open
    apt install -y nvidia-driver-570-open
    
    print_success "Drivers NVIDIA instalados correctamente"
    print_warning "Es posible que sea necesario reiniciar el sistema para activar los drivers"
fi

# Verificar si CUDA está instalado
print_message "Verificando instalación de CUDA..."
if [ -d "/usr/local/cuda" ]; then
    print_success "CUDA ya está instalado"
else
    print_message "Instalando CUDA 12.8..."
    
    # Agregar repositorio de CUDA
    wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
    dpkg -i cuda-keyring_1.0-1_all.deb
    rm cuda-keyring_1.0-1_all.deb
    apt update
    
    # Instalar CUDA Toolkit
    apt install -y cuda-toolkit-12-8
    
    print_success "CUDA 12.8 instalado correctamente"
    
    # Configurar variables de entorno para CUDA
    echo 'export PATH=/usr/local/cuda-12.8/bin${PATH:+:${PATH}}' >> /etc/profile.d/cuda.sh
    echo 'export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}' >> /etc/profile.d/cuda.sh
    chmod +x /etc/profile.d/cuda.sh
    source /etc/profile.d/cuda.sh
    
    print_message "Variables de entorno para CUDA configuradas"
fi

# Instalar otras dependencias importantes
print_message "Instalando dependencias del sistema..."
apt install -y build-essential cmake \
               libsox-dev ffmpeg \
               portaudio19-dev libportaudio2 libportaudiocpp0 \
               pkg-config
print_success "Dependencias del sistema instaladas correctamente"

# Clonar el repositorio de Fish Speech
print_message "Clonando el repositorio de Fish Speech..."
cd "$PROJECT_DIR"
if [ -d "fish-speech" ]; then
    print_warning "El directorio fish-speech ya existe. Omitiendo clonación."
else
    git clone https://github.com/fishaudio/fish-speech.git
    print_success "Repositorio de Fish Speech clonado correctamente"
fi

# Crear y activar el entorno virtual
print_message "Configurando el entorno virtual Python..."
cd "$PROJECT_DIR"
python3.10 -m venv modulo_tts
source modulo_tts/bin/activate

# Instalar dependencias de Python
print_message "Instalando dependencias de Python..."
python -m pip install --upgrade pip setuptools wheel

# Opcional: guardar entorno actual de pip
pip freeze > pip_backup.txt

# Instalar dependencias de fish-speech
cd "$PROJECT_DIR/fish-speech"
pip install -e .[stable]

# Instalar versiones específicas de PyTorch
print_message "Instalando PyTorch con soporte CUDA..."
pip uninstall -y torch torchaudio
pip install --pre torch --index-url https://download.pytorch.org/whl/nightly/cu128
pip install --pre torchaudio --index-url https://download.pytorch.org/whl/nightly/cu128

# Descargar los modelos preentrenados
print_message "Descargando modelos preentrenados (esto puede tardar varios minutos)..."
huggingface-cli download fishaudio/fish-speech-1.5 --local-dir checkpoints/fish-speech-1.5

# Crear scripts necesarios
print_message "Configurando los scripts de servicio..."

# Crear el archivo de configuración
mkdir -p "$PROJECT_DIR/config"
cat > "$PROJECT_DIR/config/config.json" << EOF
{
    "model_path": "${PROJECT_DIR}/fish-speech/checkpoints/fish-speech-1.5",
    "samples_dir": "${PROJECT_DIR}/samples",
    "host": "0.0.0.0",
    "port": 8000
}
EOF

# Copiar scripts a la carpeta correspondiente
print_message "Copiando scripts a la carpeta correspondiente..."

# Crear el script websocket_service.py
cat > "$PROJECT_DIR/scripts/websocket_service.py" << 'EOF'
#!/usr/bin/env python3
import fastapi
import uvicorn
import json
import base64
import time
import os
import sys
import gc
import re
import asyncio
import queue
import torch
import torchaudio
import numpy as np
from pathlib import Path
from fastapi import WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Generator

# Agregar Fish Speech al path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root / "fish-speech"))

# Configurar para mensajes grandes
app = fastapi.FastAPI()

# Agregar CORS para permitir que HTML local acceda al servidor
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Definir clases para la API
class VoiceRequest(BaseModel):
    text: str
    voz: str
    velocidad: float = 1.0
    chunk_length: int = 150

class VoiceResponse(BaseModel):
    audio: Dict[str, Any]
    metricas: Dict[str, Any]

class ErrorResponse(BaseModel):
    error: str
    tipo: str

# Cargar configuración
with open(project_root / "config" / "config.json", 'r') as f:
    config_data = json.load(f)

# Importar módulos después de la configuración inicial
from fish_speech.models.text2semantic.inference import load_model, launch_thread_safe_queue, GenerateRequest, GenerateResponse, WrappedGenerateResponse
from fish_speech.models.vqgan.inference import load_model as load_decoder_model
from fish_speech.inference_engine import TTSInferenceEngine, InferenceResult
from fish_speech.utils.schema import ServeTTSRequest, ServeReferenceAudio
from fish_speech.conversation import Conversation, Message, TextPart, VQPart
from fish_speech.utils import autocast_exclude_mps, set_seed
from fish_speech.text.clean import clean_text
from fish_speech.text.spliter import split_text

# Variables globales para los modelos y colas
llama_queue = None
decoder_model = None
inference_engine = None
# Caché para referencias de audio
REFERENCE_CACHE = {}

def configurar_optimizaciones():
    """Configura optimizaciones de rendimiento para la inferencia"""
    print("Configurando optimizaciones de GPU...")
    
    # Verificar disponibilidad de CUDA
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name()
        capabilities = torch.cuda.get_device_capability()
        print(f"GPU detectada: {gpu_name} (CUDA {capabilities[0]}.{capabilities[1]})")
        
        # Configurar la arquitectura correcta basada en las capacidades detectadas
        cuda_arch = f"sm_{capabilities[0]}{capabilities[1]}"
        # Solo establecemos la variable de entorno si no está ya configurada
        if "TORCH_CUDA_ARCH_LIST" not in os.environ:
            os.environ["TORCH_CUDA_ARCH_LIST"] = cuda_arch
        
        # Habilitar optimizaciones de CUDA
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True
        
        # Permitir TF32 para matrices grandes
        torch.set_float32_matmul_precision('high')
    else:
        print("ADVERTENCIA: No se detectó GPU con CUDA. El rendimiento será limitado.")
    
    # Configurar procesamiento determinístico para mayor estabilidad
    torch.use_deterministic_algorithms(False)

def inicializar_modelos(compile=True):
    """Inicializa los modelos para inferencia de voz"""
    global llama_queue, decoder_model, inference_engine
    
    print("Inicializando modelos de síntesis de voz...")
    start_time = time.time()
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    precision = torch.float16 if torch.cuda.is_available() else torch.float32
    
    # Inicializar la cola LLAMA con el compilador JIT habilitado
    try:
        print("Inicializando modelo text2semantic...")
        llama_queue = launch_thread_safe_queue(
            checkpoint_path=config_data["model_path"],
            device=device,
            precision=precision,
            compile=compile
        )
    except Exception as e:
        print(f"Error al inicializar con compilación: {e}")
        print("Reintentando sin compilación JIT...")
        compile = False
        llama_queue = launch_thread_safe_queue(
            checkpoint_path=config_data["model_path"],
            device=device,
            precision=precision,
            compile=False
        )
    
    # Cargar el modelo VQGAN
    print("Cargando modelo VQGAN...")
    decoder_model = load_decoder_model(
        config_name="firefly_gan_vq",
        checkpoint_path=os.path.join(config_data["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth"),
        device=device
    )
    
    # Inicializar el motor de inferencia
    inference_engine = TTSInferenceEngine(
        llama_queue=llama_queue,
        decoder_model=decoder_model,
        precision=precision,
        compile=compile
    )
    
    # Realizar un calentamiento inicial para optimizar el rendimiento
    print("Realizando calentamiento inicial...")
    warmup_request = ServeTTSRequest(
        text="Hola, esto es una prueba de calentamiento.",
        chunk_length=150,
        references=[],
        reference_id=None,
        max_new_tokens=1024,
        top_p=0.7,
        repetition_penalty=1.2,
        temperature=0.7,
        streaming=False,
        format="wav",
        use_memory_cache="off"
    )
    
    try:
        list(inference_engine.inference(warmup_request))
    except Exception as e:
        print(f"Advertencia durante el calentamiento: {e}")
        print("El sistema continuará funcionando, pero el primer uso puede ser más lento")
    
    print(f"✅ Modelos inicializados en {time.time() - start_time:.2f} segundos")
    
    # Limpiar caché de memoria después del calentamiento
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        gc.collect()

def get_available_voices():
    """Escanea la carpeta samples para encontrar todas las voces disponibles"""
    samples_dir = os.path.join(project_root, "samples")
    
    # Asegurarse de que la carpeta samples existe
    if not os.path.exists(samples_dir):
        os.makedirs(samples_dir)
        print(f"Carpeta samples creada en: {samples_dir}")
        return []
    
    voices = []
    wav_files = []
    
    # Buscar todos los archivos WAV en la carpeta samples
    for file in os.listdir(samples_dir):
        if file.endswith('.wav'):
            wav_files.append(file)
    
    # Para cada archivo WAV, verificar si tiene su transcripción correspondiente
    for wav_file in wav_files:
        # Obtener el nombre base sin extensión
        voice_name = os.path.splitext(wav_file)[0]
        txt_file = f"{voice_name}.txt"
        txt_path = os.path.join(samples_dir, txt_file)
        
        # Leer transcripción si existe
        transcription = ""
        if os.path.exists(txt_path):
            try:
                with open(txt_path, 'r', encoding='utf-8') as f:
                    transcription = f.read().strip()
            except Exception as e:
                print(f"Error leyendo transcripción para {voice_name}: {e}")
        
        # Crear información de la voz
        voice_info = {
            "name": voice_name,
            "display_name": voice_name.replace('_', ' ').title(),
            "wav_file": wav_file,
            "txt_file": txt_file if os.path.exists(txt_path) else None,
            "transcription": transcription,
            "created_at": time.ctime(os.path.getmtime(os.path.join(samples_dir, wav_file)))
        }
        
        voices.append(voice_info)
    
    print(f"Encontradas {len(voices)} voces en {samples_dir}")
    return voices

def load_reference_text(voice_name):
    """Carga el texto de referencia para una voz específica"""
    samples_dir = os.path.join(project_root, "samples")
    
    try:
        # Buscar el archivo TXT correspondiente
        txt_path = os.path.join(samples_dir, f"{voice_name}.txt")
        
        if os.path.exists(txt_path):
            with open(txt_path, 'r', encoding='utf-8') as f:
                text = f.read().strip()
                print(f"Texto de referencia cargado desde {txt_path}")
                return text
        else:
            print(f"No se encontró archivo de transcripción para {voice_name}")
            # Devolver un texto por defecto si no hay transcripción
            return f"Audio de referencia para {voice_name}"
            
    except Exception as e:
        print(f"Error cargando texto de referencia para {voice_name}: {e}")
        return f"Audio de referencia para {voice_name}"

def load_reference_audio(voice_name):
    """Carga el audio de referencia para una voz específica"""
    global REFERENCE_CACHE
    
    # Si ya está en caché, devolverlo
    if voice_name in REFERENCE_CACHE:
        return REFERENCE_CACHE[voice_name]
    
    # Ruta al archivo de audio específico
    samples_dir = os.path.join(project_root, "samples")
    sample_path = os.path.join(samples_dir, f"{voice_name}.wav")
    
    if not os.path.exists(sample_path):
        raise FileNotFoundError(f"Archivo de audio no encontrado: {sample_path}")
    
    try:
        # Leer el archivo de audio
        with open(sample_path, "rb") as audio_file:
            audio_bytes = audio_file.read()
        
        # Almacenar en caché
        REFERENCE_CACHE[voice_name] = audio_bytes
        
        print(f"Audio de referencia cargado desde {sample_path}")
        return audio_bytes
    except Exception as e:
        print(f"Error cargando audio de referencia para {voice_name}: {e}")
        raise e

async def sintetizar_voz(req: VoiceRequest):
    """Sintetiza voz utilizando el motor de inferencia optimizado"""
    global inference_engine
    
    if inference_engine is None:
        raise Exception("Los modelos no están inicializados")
    
    # Segmentar el texto para procesamiento por lotes
    chunk_length = req.chunk_length if hasattr(req, 'chunk_length') else 150
    text_segments = split_text(req.text, chunk_length)
    
    # Cargar texto de referencia
    prompt_text = load_reference_text(req.voz)
    
    # Cargar audio de referencia
    try:
        audio_bytes = load_reference_audio(req.voz)
    except Exception as e:
        raise Exception(f"Error cargando audio de referencia: {str(e)}")
    
    # Crear referencia para el motor de inferencia
    references = [
        ServeReferenceAudio(
            audio=audio_bytes,
            text=prompt_text
        )
    ]
    
    # Configurar la solicitud
    tts_request = ServeTTSRequest(
        text=" ".join(text_segments),
        references=references,
        reference_id=None,
        max_new_tokens=1024,
        chunk_length=chunk_length,
        top_p=0.7,
        repetition_penalty=1.2,
        temperature=0.7,
        streaming=False,
        format="wav",
        use_memory_cache="on",  # Mantener caché para velocidad
        seed=None
    )
    
    # Establecer semilla para resultados deterministas si se proporciona velocidad como semilla
    if req.velocidad != 1.0:
        tts_request.seed = int(abs(hash(str(req.velocidad))) % 2**31)
    
    # Realizar la inferencia con reintentos
    start_time = time.time()
    
    audio_segments = []
    sample_rate = None
    max_retries = 3
    
    for attempt in range(max_retries):
        try:
            # Obtener resultados de la síntesis
            results = list(inference_engine.inference(tts_request))
            
            audio_segments = []
            for result in results:
                if result.code == "error":
                    if attempt < max_retries - 1:
                        print(f"Error en intento {attempt + 1}, reintentando...")
                        break
                    else:
                        raise Exception(str(result.error))
                elif result.code == "final":
                    sample_rate, audio_data = result.audio
                    audio_segments.append(audio_data)
                elif result.code == "segment":
                    sample_rate, segment_data = result.audio
            
            # Si llegamos aquí sin errores con audio, salir del bucle
            if audio_segments:
                break
            elif attempt < max_retries - 1:
                print(f"No se generó audio en intento {attempt + 1}, reintentando...")
        
        except Exception as e:
            if attempt == max_retries - 1:
                print(f"Error final en síntesis: {e}")
                raise e
            else:
                print(f"Error en intento {attempt + 1}: {e}, reintentando...")
    
    # Combinar segmentos de audio
    if audio_segments:
        # Convertir a numpy array si es necesario
        audio_combined = None
        
        if len(audio_segments) == 1:
            audio_combined = audio_segments[0]
        else:
            audio_combined = np.concatenate(audio_segments, axis=0)
        
        # Verificar que el audio no esté vacío
        if audio_combined.size == 0:
            raise Exception("Audio generado está vacío")
        
        # Asegurarse de que el audio tenga el formato correcto
        if audio_combined.dtype != np.float32:
            audio_combined = audio_combined.astype(np.float32)
        
        # Normalizar audio si es necesario
        if audio_combined.max() != 0:
            audio_combined = audio_combined / np.max(np.abs(audio_combined)) * 0.9
        
        # Ajustar velocidad si es necesario
        if req.velocidad != 1.0:
            import librosa
            audio_combined = librosa.effects.time_stretch(audio_combined, rate=1.0/req.velocidad)
        
        # Calcular métricas
        synthesis_time = time.time() - start_time
        audio_duration = len(audio_combined) / sample_rate
        
        # Convertir a base64 con formato WAV correcto
        import io
        import soundfile as sf
        
        # Crear buffer para el audio
        buffer = io.BytesIO()
        
        # Asegurarse de que el sample_rate sea entero
        sample_rate_int = int(sample_rate) if sample_rate is not None else 24000
        
        # Escribir audio en formato WAV al buffer
        sf.write(buffer, audio_combined, sample_rate_int, format='WAV', subtype='PCM_16')
        
        # Obtener bytes del audio
        buffer.seek(0)
        audio_bytes = buffer.getvalue()
        
        # Codificar a base64
        audio_base64 = base64.b64encode(audio_bytes).decode('utf-8')
        
        # Verificar que la codificación fue exitosa
        if not audio_base64:
            raise Exception("Fallo al codificar audio a base64")
        
        # Debug: verificar el formato del base64
        print(f"Debug - Base64 generado: length={len(audio_base64)}, start='{audio_base64[:20]}', end='{audio_base64[-20:]}'")
        
        # Validar que el base64 solo contiene caracteres válidos
        import re
        if not re.match(r'^[A-Za-z0-9+/=]*$', audio_base64):
            print("⚠️ ADVERTENCIA: Base64 contiene caracteres inválidos!")
            # Limpiar caracteres inválidos
            audio_base64 = re.sub(r'[^A-Za-z0-9+/=]', '', audio_base64)
            print(f"Base64 limpiado: length={len(audio_base64)}")
        
        # Construir respuesta
        audio_info = {
            "base64": audio_base64,
            "formato": "wav",
            "sample_rate": sample_rate_int,
            "channels": 1,
            "duration": audio_duration,
            "size_bytes": len(audio_bytes)
        }
        
        metrics = {
            "synthesis_time": synthesis_time,
            "text_length": len(req.text),
            "audio_duration": audio_duration,
            "real_time_factor": audio_duration / synthesis_time,
            "voice_used": req.voz,
            "velocidad": req.velocidad,
            "audio_size_bytes": len(audio_bytes),
            "attempts": attempt + 1
        }
        
        print(f"✅ Audio generado exitosamente: {audio_duration:.2f}s, {len(audio_bytes)} bytes")
        
        return audio_info, metrics
    else:
        raise Exception("No se generó audio después de todos los intentos")

@app.get("/voices")
async def get_voices():
    """Devuelve la lista de voces disponibles"""
    try:
        voices = get_available_voices()
        
        if not voices:
            # Si no hay voces, crear una instrucción para el usuario
            return {
                "voices": [],
                "instructions": "Para agregar voces, coloca archivos .wav y sus transcripciones .txt correspondientes en la carpeta samples/. Por ejemplo: mi_voz.wav y mi_voz.txt"
            }
        
        return {"voices": voices}
    except Exception as e:
        print(f"Error al cargar voces: {e}")
        raise HTTPException(status_code=500, detail=f"Error al cargar voces: {str(e)}")

@app.websocket("/synthesize")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    try:
        while True:
            # Recibir mensaje JSON
            try:
                data = await websocket.receive_json()
                request = VoiceRequest(**data)
                
                # Verificar valores
                if not request.text.strip():
                    raise ValueError("El texto no puede estar vacío")
                
                if request.velocidad < 0.5 or request.velocidad > 2.0:
                    print(f"Advertencia: velocidad {request.velocidad} fuera del rango recomendado (0.5-2.0)")
                
                # Sintetizar voz
                try:
                    audio_info, metrics = await sintetizar_voz(request)
                    
                    # Log info de audio antes de enviar
                    print(f"📤 Enviando audio: {metrics['audio_size_bytes']} bytes, {metrics['audio_duration']:.2f}s")
                    
                    # Enviar respuesta con información de éxito
                    response = {
                        "audio": audio_info,
                        "metricas": metrics,
                        "status": "success"
                    }
                    
                    await websocket.send_json(response)
                    
                except Exception as e:
                    import traceback
                    print(f"Error en síntesis: {str(e)}")
                    print(traceback.format_exc())
                    
                    await websocket.send_json({
                        "error": str(e),
                        "tipo": type(e).__name__,
                        "status": "error"
                    })
                    
            except json.JSONDecodeError:
                await websocket.send_json({
                    "error": "El mensaje recibido no es un JSON válido",
                    "tipo": "JSONDecodeError",
                    "status": "error"
                })
            except Exception as e:
                await websocket.send_json({
                    "error": str(e),
                    "tipo": type(e).__name__,
                    "status": "error"
                })
                
    except WebSocketDisconnect:
        print("Cliente desconectado")

@app.on_event("startup")
async def startup_event():
    """Evento de inicio del servidor"""
    try:
        # Configurar optimizaciones de GPU
        configurar_optimizaciones()
        
        # Inicializar modelos con compilación
        inicializar_modelos(compile=True)
        
        # Cargar y mostrar voces disponibles al inicio
        voices = get_available_voices()
        if voices:
            print(f"\n🎤 Voces disponibles ({len(voices)}):")
            for voice in voices:
                print(f"  - {voice['display_name']} ({voice['name']})")
        else:
            print("\n⚠️ No hay voces disponibles. Coloque archivos .wav y .txt en la carpeta samples/")
        
    except Exception as e:
        print(f"Error durante la inicialización: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Configurar servidor Uvicorn
    uvicorn_config = uvicorn.Config(
        app, 
        host="0.0.0.0", 
        port=8000,
        ws_max_size=16777216,  # 16MB límite para mensajes WebSocket
        log_level="info"
    )
    server = uvicorn.Server(uvicorn_config)
    server.run()
EOF

# Crear el archivo voice_client.html
cat > "$PROJECT_DIR/scripts/voice_client.html" << 'EOF'
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Síntesis de Voz con Fish Speech</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --primary-dark: #388E3C;
            --light-bg: #f5f5f5;
            --dark-bg: #343a40;
            --light-text: #f8f9fa;
            --dark-text: #212529;
            --shadow: 0 2px 4px rgba(0,0,0,0.1);
            --border-radius: 8px;
            --font-main: Arial, sans-serif;
        }

        body {
            font-family: var(--font-main);
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: var(--light-bg);
            line-height: 1.6;
        }

        .container {
            background-color: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }

        h1 {
            color: var(--dark-text);
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: var(--dark-text);
        }

        textarea, select {
            width: 100%;
            padding: 12px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: var(--font-main);
            font-size: 16px;
        }

        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            width: 100%;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: var(--primary-dark);
        }

        button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        .audio-player {
            margin-top: 20px;
            width: 100%;
            border-radius: var(--border-radius);
        }

        .status {
            margin-top: 15px;
            padding: 12px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .status.success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }

        .status.error {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        .status.processing {
            background-color: #cce5ff;
            border: 1px solid #b8daff;
            color: #004085;
        }

        .status.warning {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
        }

        .metrics {
            margin-top: 20px;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            font-family: monospace;
            white-space: pre-wrap;
        }

        .debug {
            margin-top: 20px;
            background-color: var(--dark-bg);
            color: var(--light-text);
            padding: 15px;
            border-radius: 4px;
            font-family: monospace;
            white-space: pre-wrap;
            max-height: 200px;
            overflow-y: auto;
        }

        .json-display {
            margin-top: 20px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            font-family: monospace;
            white-space: pre-wrap;
            max-height: 400px;
            overflow-y: auto;
        }

        .section-title {
            font-weight: bold;
            margin-top: 25px;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #dee2e6;
            color: var(--dark-text);
        }

        .voice-info {
            font-size: 0.9em;
            color: #666;
            margin-top: 5px;
            font-style: italic;
        }

        /* Control deslizante para velocidad */
        .slider-container {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }

        .slider {
            flex-grow: 1;
            height: 8px;
            border-radius: 4px;
            background: #ddd;
            outline: none;
            -webkit-appearance: none;
        }

        .slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: var(--primary-color);
            cursor: pointer;
        }

        .slider::-moz-range-thumb {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: var(--primary-color);
            cursor: pointer;
        }

        .slider-value {
            width: 60px;
            text-align: center;
            font-weight: bold;
            margin-left: 15px;
        }

        .speed-labels {
            display: flex;
            justify-content: space-between;
            margin-top: 5px;
            font-size: 0.8em;
            color: #666;
        }

        /* Accordion para métricas y debug */
        .accordion {
            background-color: #f1f1f1;
            color: #444;
            cursor: pointer;
            padding: 12px;
            width: 100%;
            text-align: left;
            border: none;
            outline: none;
            transition: 0.4s;
            margin-top: 15px;
            border-radius: 4px 4px 0 0;
            font-weight: bold;
        }

        .accordion.active, .accordion:hover {
            background-color: #ddd;
        }

        .panel {
            padding: 0 12px;
            background-color: white;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
            border-radius: 0 0 4px 4px;
            border: 1px solid #ddd;
            border-top: none;
        }

        .panel.active {
            max-height: 500px;
            padding: 12px;
        }

        /* Estilos para métricas visuales */
        .metrics-visual {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-top: 20px;
        }

        .metric-card {
            background-color: white;
            border-radius: var(--border-radius);
            padding: 15px;
            box-shadow: var(--shadow);
            width: calc(50% - 10px);
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        .metric-title {
            font-size: 0.9em;
            color: #555;
            margin-bottom: 5px;
        }

        .metric-value {
            font-size: 1.8em;
            font-weight: bold;
            color: var(--dark-text);
        }

        .metric-unit {
            font-size: 0.8em;
            color: #777;
        }

        /* Loader animation */
        .loader {
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top: 4px solid var(--primary-color);
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
            display: none;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Advanced settings panel */
        .advanced-settings {
            margin-top: 15px;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 4px;
            background-color: #f9f9f9;
            display: none;
        }

        .advanced-toggle {
            color: #007bff;
            cursor: pointer;
            margin-top: 10px;
            display: inline-block;
            font-size: 0.9em;
        }

        .advanced-toggle:hover {
            text-decoration: underline;
        }

        /* Botón de descarga */
        .download-btn {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 8px 15px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 14px;
            display: none;
        }

        .download-btn:hover {
            background-color: #0056b3;
        }

        /* Diseño responsive */
        @media (max-width: 600px) {
            .metric-card {
                width: 100%;
            }

            .container {
                padding: 15px;
            }

            button {
                padding: 10px;
            }
        }

        /* Estilos para instrucciones de voces */
        .voice-instructions {
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 15px;
            font-size: 0.9em;
            color: #6c757d;
        }

        .voice-instructions code {
            background-color: #e9ecef;
            padding: 2px 4px;
            border-radius: 3px;
            font-family: monospace;
        }

        /* Información detallada de voz */
        .voice-details {
            margin-top: 10px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 4px;
            border: 1px solid #e9ecef;
            display: none;
        }

        .voice-detail-item {
            margin-bottom: 5px;
            font-size: 0.9em;
        }

        .voice-detail-label {
            font-weight: bold;
            color: #495057;
        }

        .transcription-preview {
            font-style: italic;
            color: #6c757d;
            max-height: 60px;
            overflow-y: auto;
            margin-top: 5px;
            padding: 5px;
            background-color: #ffffff;
            border: 1px solid #dee2e6;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Síntesis de Voz con Fish Speech</h1>
        
        <div class="input-group">
            <label for="text">Texto a sintetizar:</label>
            <textarea id="text" placeholder="Ingresa el texto que quieres sintetizar..." rows="5">Hola, esta es una prueba de síntesis de voz en español usando una voz clonada. Soy un agente de inteligencia artificial a tu disposición para ayudarte con lo que necesites. Encontraremos una solución a tus problemas.</textarea>
        </div>
        
        <div class="input-group">
            <label for="voice">Seleccionar voz:</label>
            <select id="voice">
                <option value="">Cargando voces...</option>
            </select>
            <div id="voiceInfo" class="voice-info"></div>
            <div id="voiceDetails" class="voice-details"></div>
        </div>
        
        <div class="input-group">
            <label for="speed">Velocidad de voz:</label>
            <div class="slider-container">
                <input type="range" id="speed" class="slider" min="0.7" max="1.5" step="0.1" value="1.0">
                <span id="speedValue" class="slider-value">1.0x</span>
            </div>
            <div class="speed-labels">
                <span>Lento</span>
                <span>Normal</span>
                <span>Rápido</span>
            </div>
        </div>
        
        <div class="advanced-toggle" onclick="toggleAdvancedSettings()">Configuración avanzada ▼</div>
        
        <div id="advancedSettings" class="advanced-settings">
            <div class="input-group">
                <label for="chunkLength">Longitud de segmento:</label>
                <input type="number" id="chunkLength" min="50" max="500" value="150" style="width: 100px;">
                <div class="voice-info">Valores más pequeños pueden mejorar la calidad en textos largos pero aumentan el tiempo de procesamiento.</div>
            </div>
        </div>
        
        <button id="synthesizeBtn" onclick="synthesizeSpeech()">🎤 Sintetizar Voz</button>
        
        <div id="status" class="status">Inicializando...</div>
        <div id="loader" class="loader"></div>
        
        <audio id="audioPlayer" class="audio-player" controls style="display: none;"></audio>
        <button id="downloadBtn" class="download-btn" onclick="downloadAudio()">⬇️ Descargar Audio</button>
        
        <!-- Sección de Métricas Visuales -->
        <div id="metricsVisual" class="metrics-visual" style="display: none;"></div>
        
        <!-- Secciones expandibles -->
        <button class="accordion">Métricas Detalladas</button>
        <div class="panel">
            <div id="metrics" class="metrics">No hay métricas disponibles</div>
        </div>
        
        <button class="accordion">JSON de Respuesta Completo</button>
        <div class="panel">
            <div id="jsonDisplay" class="json-display">No hay datos JSON disponibles</div>
        </div>
        
        <button class="accordion">Consola de Desarrollo</button>
        <div class="panel">
            <div id="debug" class="debug"></div>
        </div>
    </div>

    <script>
    let ws = null;
    let isConnected = false;
    let voices = [];
    let lastRequestTime = 0;
    let reconnectAttempts = 0;
    const MAX_RECONNECT_ATTEMPTS = 5;
    let lastAudioDataUrl = null;
    let lastAudioBlob = null;
    
    function setupAccordions() {
        const accordions = document.getElementsByClassName("accordion");
        
        for (let i = 0; i < accordions.length; i++) {
            accordions[i].addEventListener("click", function() {
                this.classList.toggle("active");
                const panel = this.nextElementSibling;
                panel.classList.toggle("active");
            });
        }
    }
    
    function toggleAdvancedSettings() {
        const advancedSettings = document.getElementById('advancedSettings');
        const toggle = document.querySelector('.advanced-toggle');
        
        if (advancedSettings.style.display === 'none' || !advancedSettings.style.display) {
            advancedSettings.style.display = 'block';
            toggle.innerHTML = 'Configuración avanzada ▲';
        } else {
            advancedSettings.style.display = 'none';
            toggle.innerHTML = 'Configuración avanzada ▼';
        }
    }
    
    function log(message) {
        const debugDiv = document.getElementById('debug');
        const timestamp = new Date().toLocaleTimeString();
        debugDiv.innerHTML += `[${timestamp}] ${message}\n`;
        debugDiv.scrollTop = debugDiv.scrollHeight;
    }
    
    function displayMetricsVisual(metrics) {
        const container = document.getElementById('metricsVisual');
        container.innerHTML = '';
        container.style.display = 'flex';
        
        const createMetricCard = (title, value, unit) => {
            const card = document.createElement('div');
            card.className = 'metric-card';
            
            const titleEl = document.createElement('div');
            titleEl.className = 'metric-title';
            titleEl.textContent = title;
            
            const valueEl = document.createElement('div');
            valueEl.className = 'metric-value';
            valueEl.textContent = value;
            
            const unitEl = document.createElement('span');
            unitEl.className = 'metric-unit';
            unitEl.textContent = unit;
            
            valueEl.appendChild(unitEl);
            card.appendChild(titleEl);
            card.appendChild(valueEl);
            
            return card;
        };
        
        // Métricas a mostrar
        container.appendChild(createMetricCard('Tiempo de Síntesis', metrics.synthesis_time.toFixed(2), ' seg'));
        container.appendChild(createMetricCard('Duración de Audio', metrics.audio_duration.toFixed(2), ' seg'));
        container.appendChild(createMetricCard('Factor Tiempo Real', metrics.real_time_factor.toFixed(2), 'x'));
        container.appendChild(createMetricCard('Velocidad', metrics.velocidad.toFixed(1), 'x'));
        
        // Agregar nuevas métricas
        if (metrics.audio_size_bytes) {
            container.appendChild(createMetricCard('Tamaño de Audio', (metrics.audio_size_bytes / 1024).toFixed(1), ' KB'));
        }
        
        if (metrics.attempts) {
            container.appendChild(createMetricCard('Intentos', metrics.attempts, ''));
        }
        
        if (metrics.voice_used) {
            container.appendChild(createMetricCard('Voz Usada', metrics.voice_used, ''));
        }
    }
    
    function displayMetricsRaw(metrics) {
        const metricsDiv = document.getElementById('metrics');
        metricsDiv.textContent = JSON.stringify(metrics, null, 2);
    }
    
    function displayJson(jsonData) {
        const jsonDiv = document.getElementById('jsonDisplay');
        
        // Crear una copia para manipular
        const displayData = { ...jsonData };
        
        // Agregar opción para mostrar/ocultar base64 completo
        if (displayData.audio && displayData.audio.base64) {
            const base64Length = displayData.audio.base64.length;
            const fullBase64 = displayData.audio.base64;
            
            // Por defecto, mostrar solo información del base64
            displayData.audio.base64_summary = `[base64 data: ${base64Length} caracteres total] - Click para ver completo`;
            displayData.audio.base64_truncated = true;
            
            // Agregar botón para ver base64 completo
            const container = document.createElement('div');
            
            const buttonContainer = document.createElement('div');
            buttonContainer.style.marginBottom = '10px';
            
            const toggleButton = document.createElement('button');
            toggleButton.textContent = 'Mostrar Base64 Completo';
            toggleButton.style.backgroundColor = '#007bff';
            toggleButton.style.color = 'white';
            toggleButton.style.border = 'none';
            toggleButton.style.padding = '5px 10px';
            toggleButton.style.borderRadius = '4px';
            toggleButton.style.cursor = 'pointer';
            toggleButton.style.marginRight = '10px';
            
            const copyButton = document.createElement('button');
            copyButton.textContent = 'Copiar Base64';
            copyButton.style.backgroundColor = '#28a745';
            copyButton.style.color = 'white';
            copyButton.style.border = 'none';
            copyButton.style.padding = '5px 10px';
            copyButton.style.borderRadius = '4px';
            copyButton.style.cursor = 'pointer';
            
            copyButton.onclick = async function() {
                try {
                    await navigator.clipboard.writeText(fullBase64);
                    const originalText = copyButton.textContent;
                    copyButton.textContent = '✓ Copiado!';
                    copyButton.style.backgroundColor = '#17a2b8';
                    setTimeout(() => {
                        copyButton.textContent = originalText;
                        copyButton.style.backgroundColor = '#28a745';
                    }, 2000);
                } catch (err) {
                    console.error('Error al copiar:', err);
                    alert('Error al copiar al portapapeles');
                }
            };
            
            toggleButton.onclick = function() {
                const currentJson = jsonDiv.querySelector('pre').textContent;
                try {
                    const currentData = JSON.parse(currentJson);
                    
                    if (currentData.audio && currentData.audio.base64_truncated) {
                        // Mostrar completo
                        currentData.audio.base64 = fullBase64;
                        currentData.audio.base64_summary = undefined;
                        currentData.audio.base64_truncated = false;
                        jsonDiv.querySelector('pre').textContent = JSON.stringify(currentData, null, 2);
                        toggleButton.textContent = 'Ocultar Base64 Completo';
                    } else {
                        // Mostrar truncado
                        currentData.audio.base64_summary = `[base64 data: ${base64Length} caracteres total] - Click para ver completo`;
                        currentData.audio.base64 = undefined;
                        currentData.audio.base64_truncated = true;
                        jsonDiv.querySelector('pre').textContent = JSON.stringify(currentData, null, 2);
                        toggleButton.textContent = 'Mostrar Base64 Completo';
                    }
                } catch (e) {
                    console.error('Error toggling base64:', e);
                }
            };
            
            buttonContainer.appendChild(toggleButton);
            buttonContainer.appendChild(copyButton);
            container.appendChild(buttonContainer);
            
            const pre = document.createElement('pre');
            pre.style.whiteSpace = 'pre-wrap';
            pre.style.margin = '0';
            pre.style.padding = '15px';
            pre.style.backgroundColor = '#f8f9fa';
            pre.style.border = '1px solid #dee2e6';
            pre.style.borderRadius = '4px';
            pre.style.maxHeight = '400px';
            pre.style.overflowY = 'auto';
            pre.style.fontFamily = 'monospace';
            pre.textContent = JSON.stringify(displayData, null, 2);
            
            container.appendChild(pre);
            
            jsonDiv.innerHTML = '';
            jsonDiv.appendChild(container);
            
            // Guardar referencia al base64 completo para uso futuro
            jsonDiv._fullBase64 = fullBase64;
        } else {
            // Si no hay audio, mostrar JSON normalmente
            jsonDiv.textContent = JSON.stringify(displayData, null, 2);
        }
    }
    
    function showVoiceInstructions() {
        const voiceSelect = document.getElementById('voice');
        
        // Crear elemento de instrucciones si no existe
        let instructionsDiv = document.getElementById('voiceInstructions');
        if (!instructionsDiv) {
            instructionsDiv = document.createElement('div');
            instructionsDiv.id = 'voiceInstructions';
            instructionsDiv.className = 'voice-instructions';
            voiceSelect.parentNode.insertBefore(instructionsDiv, voiceSelect.nextSibling);
        }
        
        instructionsDiv.innerHTML = `
            <strong>📁 Para agregar voces:</strong><br>
            1. Coloca archivos WAV en la carpeta <code>samples/</code><br>
            2. Crea archivos TXT con la transcripción (mismo nombre que el WAV)<br>
            <br>
            <strong>Ejemplo:</strong> <code>mi_voz.wav</code> y <code>mi_voz.txt</code>
        `;
        
        instructionsDiv.style.display = 'block';
    }
    
    async function loadAvailableVoices() {
        try {
            log('Obteniendo lista de voces disponibles...');
            const response = await fetch('http://localhost:8000/voices');
            
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            voices = data.voices || [];
            
            const voiceSelect = document.getElementById('voice');
            voiceSelect.innerHTML = '';
            
            if (voices.length === 0) {
                voiceSelect.innerHTML = '<option value="">No hay voces disponibles</option>';
                log('⚠️ No se encontraron voces disponibles');
                showVoiceInstructions();
                
                if (data.instructions) {
                    log(`ℹ️ ${data.instructions}`);
                }
            } else {
                // Agregar opción por defecto
                voiceSelect.innerHTML = '<option value="">Selecciona una voz...</option>';
                
                // Agregar todas las voces
                voices.forEach(voice => {
                    const option = document.createElement('option');
                    option.value = voice.name;
                    option.textContent = voice.display_name || voice.name;
                    voiceSelect.appendChild(option);
                });
                
                log(`✅ Cargadas ${voices.length} voces disponibles`);
                
                // Ocultar instrucciones si hay voces
                const instructionsDiv = document.getElementById('voiceInstructions');
                if (instructionsDiv) {
                    instructionsDiv.style.display = 'none';
                }
            }
            
            // Actualizar información de voz
            updateVoiceInfo();
            
        } catch (error) {
            log(`❌ Error al cargar voces: ${error}`);
            const voiceSelect = document.getElementById('voice');
            voiceSelect.innerHTML = '<option value="">Error al cargar voces</option>';
            showVoiceInstructions();
        }
    }
    
    function updateVoiceInfo() {
        const voiceSelect = document.getElementById('voice');
        const voiceInfo = document.getElementById('voiceInfo');
        const voiceDetails = document.getElementById('voiceDetails');
        const selectedVoice = voices.find(v => v.name === voiceSelect.value);
        
        if (selectedVoice) {
            let info = selectedVoice.created_at ? `Creada: ${selectedVoice.created_at}` : '';
            
            voiceInfo.innerHTML = info || 'Voz seleccionada';
            
            // Mostrar detalles expandidos
            voiceDetails.innerHTML = `
                <div class="voice-detail-item">
                    <span class="voice-detail-label">Archivo WAV:</span> ${selectedVoice.wav_file}
                </div>
                <div class="voice-detail-item">
                    <span class="voice-detail-label">Archivo TXT:</span> ${selectedVoice.txt_file || 'No disponible'}
                </div>
                ${selectedVoice.transcription ? `
                <div class="voice-detail-item">
                    <span class="voice-detail-label">Transcripción:</span>
                    <div class="transcription-preview">${selectedVoice.transcription}</div>
                </div>
                ` : ''}
            `;
            voiceDetails.style.display = 'block';
        } else {
            voiceInfo.innerHTML = '';
            voiceDetails.style.display = 'none';
        }
    }
    
    function connectWebSocket() {
        try {
            log('Intentando conectar al servidor WebSocket...');
            ws = new WebSocket('ws://localhost:8000/synthesize');
            
            ws.onopen = function(event) {
                isConnected = true;
                reconnectAttempts = 0;
                showStatus('Conectado al servidor', 'success');
                log('✅ WebSocket conectado exitosamente');
                document.getElementById('synthesizeBtn').disabled = false;
            };
            
            ws.onclose = function(event) {
                isConnected = false;
                showStatus('Desconectado del servidor', 'error');
                log(`❌ WebSocket cerrado: Código=${event.code}, Razón=${event.reason}`);
                document.getElementById('synthesizeBtn').disabled = true;
                document.getElementById('loader').style.display = 'none';
                
                // Reintentar conexión con backoff exponencial
                if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                    reconnectAttempts++;
                    const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
                    log(`Reintentando conexión en ${delay/1000} segundos (intento ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`);
                    setTimeout(connectWebSocket, delay);
                } else {
                    log('⚠️ Número máximo de intentos de reconexión alcanzado. Por favor, recarga la página.');
                }
            };
            
            ws.onerror = function(error) {
                log(`❌ Error WebSocket: ${error}`);
                showStatus('Error de conexión', 'error');
                document.getElementById('loader').style.display = 'none';
            };
            
            ws.onmessage = function(event) {
                const processingTime = Date.now() - lastRequestTime;
                log(`✅ Respuesta recibida (${processingTime/1000} segundos)`);
                document.getElementById('loader').style.display = 'none';
                
                try {
                    const data = JSON.parse(event.data);
                    
                    // ¡IMPORTANTE! Crear una copia para mostrar el JSON sin modificar el original
                    const displayData = JSON.parse(JSON.stringify(data));
                    
                    // Mostrar JSON completo (versión para visualización)
                    displayJson(displayData);
                    log('📄 JSON de respuesta completo mostrado');
                    
                    if (data.error) {
                        log(`❌ Error del servidor: ${data.error}`);
                        showStatus(`Error: ${data.error}`, 'error');
                        return;
                    }
                    
                    // Mostrar métricas (usando data original)
                    if (data.metricas) {
                        log('📊 Métricas recibidas');
                        displayMetricsRaw(data.metricas);
                        displayMetricsVisual(data.metricas);
                        document.getElementById('metricsVisual').style.display = 'flex';
                    }
                    
                    // Reproducir audio (usando data original, no displayData)
                    if (data.audio && data.audio.base64) {
                        log('🔊 Audio recibido, preparando para reproducir');
                        log(`Audio info: ${data.audio.sample_rate} Hz, ${data.audio.formato}, ${data.audio.size_bytes || 0} bytes`);
                        
                        const audioPlayer = document.getElementById('audioPlayer');
                        
                        try {
                            // Validar y limpiar el string base64
                            let base64String = data.audio.base64;
                            
                            // Log para debug: primeros y últimos caracteres del base64
                            log(`Base64 info: length=${base64String.length}, start="${base64String.substring(0, 20)}", end="${base64String.substring(base64String.length - 20)}"`);
                            
                            // Remover cualquier espacio en blanco o caracteres de salto de línea
                            base64String = base64String.replace(/\s/g, '');
                            
                            // Verificar que el string sea base64 válido (solo contiene caracteres base64)
                            const base64Regex = /^[A-Za-z0-9+/=]*$/;
                            if (!base64Regex.test(base64String)) {
                                throw new Error('El string base64 contiene caracteres inválidos');
                            }
                            
                            // Convertir base64 a blob usando fetch API (más robusto que atob)
                            log('Decodificando audio...');
                            const dataURL = `data:audio/wav;base64,${base64String}`;
                            
                            fetch(dataURL)
                                .then(res => res.blob())
                                .then(blob => {
                                    lastAudioBlob = blob;
                                    
                                    // Crear URL del objeto
                                    lastAudioDataUrl = URL.createObjectURL(lastAudioBlob);
                                    
                                    // Configurar reproductor
                                    audioPlayer.src = lastAudioDataUrl;
                                    audioPlayer.style.display = 'block';
                                    
                                    // Mostrar botón de descarga
                                    document.getElementById('downloadBtn').style.display = 'block';
                                    
                                    // Intentar reproducir
                                    audioPlayer.play().then(() => {
                                        log('▶️ Audio reproducido exitosamente');
                                        showStatus('Audio generado y reproducido correctamente', 'success');
                                    }).catch((playError) => {
                                        log(`⚠️ No se pudo reproducir automáticamente: ${playError}`);
                                        showStatus('Audio generado. Haz clic en play para reproducir', 'success');
                                    });
                                })
                                .catch(decodeError => {
                                    throw new Error(`Error al decodificar: ${decodeError}`);
                                });
                            
                        } catch (audioError) {
                            log(`❌ Error al procesar audio: ${audioError}`);
                            log(`Error detail: ${audioError.message}`);
                            showStatus('Error al procesar audio', 'error');
                            
                            // Intentar método alternativo con atob como fallback
                            try {
                                log('Intentando método alternativo de decodificación...');
                                const base64String = data.audio.base64.replace(/\s/g, '');
                                
                                // Usar atob como fallback
                                const binaryStr = atob(base64String);
                                const len = binaryStr.length;
                                const bytes = new Uint8Array(len);
                                
                                for (let i = 0; i < len; i++) {
                                    bytes[i] = binaryStr.charCodeAt(i);
                                }
                                
                                lastAudioBlob = new Blob([bytes], { type: 'audio/wav' });
                                lastAudioDataUrl = URL.createObjectURL(lastAudioBlob);
                                
                                audioPlayer.src = lastAudioDataUrl;
                                audioPlayer.style.display = 'block';
                                document.getElementById('downloadBtn').style.display = 'block';
                                
                                log('✓ Método alternativo exitoso');
                                showStatus('Audio procesado con método alternativo', 'success');
                            } catch (fallbackError) {
                                log(`❌ Método alternativo también falló: ${fallbackError}`);
                                showStatus('Error crítico al procesar audio', 'error');
                            }
                        }
                    } else {
                        log('⚠️ No se recibieron datos de audio');
                        showStatus('No se recibieron datos de audio', 'error');
                    }
                } catch (parseError) {
                    log(`❌ Error al procesar respuesta JSON: ${parseError}`);
                    showStatus('Error al procesar respuesta', 'error');
                }
            };
        } catch (error) {
            log(`❌ Error al crear WebSocket: ${error}`);
            showStatus('Error al conectar', 'error');
            document.getElementById('loader').style.display = 'none';
        }
    }
    
    function downloadAudio() {
        if (!lastAudioBlob) {
            log('❌ No hay audio disponible para descargar');
            return;
        }
        
        try {
            const downloadLink = document.createElement('a');
            downloadLink.href = URL.createObjectURL(lastAudioBlob);
            
            // Crear nombre de archivo con fecha y hora
            const now = new Date();
            const timestamp = now.toISOString().replace(/[:.]/g, '-').substring(0, 19);
            const voiceName = document.getElementById('voice').value;
            downloadLink.download = `voz_${voiceName}_${timestamp}.wav`;
            
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            
            log(`✅ Audio descargado como ${downloadLink.download}`);
        } catch (downloadError) {
            log(`❌ Error al descargar audio: ${downloadError}`);
        }
    }
    
    function synthesizeSpeech() {
        log('Iniciando síntesis de voz...');
        lastRequestTime = Date.now();
        
        if (!isConnected) {
            log('❌ No conectado al servidor');
            showStatus('No conectado al servidor', 'error');
            return;
        }
        
        const text = document.getElementById('text').value;
        const voice = document.getElementById('voice').value;
        const velocidad = parseFloat(document.getElementById('speed').value);
        const chunkLength = parseInt(document.getElementById('chunkLength').value, 10);
        
        if (!text.trim()) {
            log('⚠️ Texto vacío');
            showStatus('Por favor ingresa un texto', 'error');
            return;
        }
        
        if (!voice) {
            log('⚠️ Ninguna voz seleccionada');
            showStatus('Por favor selecciona una voz', 'error');
            return;
        }
        
        // Validar chunk length
        if (isNaN(chunkLength) || chunkLength < 50 || chunkLength > 500) {
            log('⚠️ Longitud de segmento inválida, usando valor predeterminado (150)');
        }
        
        // Limpiar audio anterior
        const audioPlayer = document.getElementById('audioPlayer');
        audioPlayer.style.display = 'none';
        audioPlayer.src = '';
        document.getElementById('downloadBtn').style.display = 'none';
        document.getElementById('metricsVisual').style.display = 'none';
        
        // Limpiar blobs anteriores
        if (lastAudioDataUrl) {
            URL.revokeObjectURL(lastAudioDataUrl);
            lastAudioDataUrl = null;
        }
        lastAudioBlob = null;
        
        // Limpiar JSON anterior
        document.getElementById('jsonDisplay').textContent = 'Esperando respuesta...';
        
        // Mostrar loader
        document.getElementById('loader').style.display = 'block';
        
        showStatus(`Procesando texto (${text.length} caracteres)...`, 'processing');
        document.getElementById('synthesizeBtn').disabled = true;
        
        const request = {
            "text": text,
            "voz": voice,
            "velocidad": velocidad,
            "chunk_length": isNaN(chunkLength) ? 150 : chunkLength
        };
        
        log(`📤 Enviando solicitud: texto de ${text.length} caracteres, voz "${voice}", velocidad ${velocidad}x, chunk_length ${request.chunk_length}`);
        ws.send(JSON.stringify(request));
    }
    
    function showStatus(message, type) {
        const statusDiv = document.getElementById('status');
        statusDiv.textContent = message;
        statusDiv.className = 'status ' + type;
        statusDiv.style.display = 'block';
        
        if (type === 'success' || type === 'error') {
            document.getElementById('synthesizeBtn').disabled = false;
        }
    }
    
    // Actualizar valor del deslizador de velocidad cuando cambia
    document.addEventListener('DOMContentLoaded', function() {
        const speedSlider = document.getElementById('speed');
        const speedValue = document.getElementById('speedValue');
        
        speedSlider.addEventListener('input', function() {
            speedValue.textContent = parseFloat(this.value).toFixed(1) + 'x';
        });
        
        // Configurar los acordeones
        setupAccordions();
        
        // Manejar cambio de voz
        document.getElementById('voice').addEventListener('change', updateVoiceInfo);
    });
    
    // Permitir enviar con Enter (solo si no está presionada la tecla Shift)
    document.getElementById('text').addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            synthesizeSpeech();
        }
    });
    
    // Inicializar al cargar la página
    window.onload = function() {
        connectWebSocket();
        loadAvailableVoices();
        log('✅ Página cargada');
        
        // Mostrar información sobre procesamiento por lotes
        log('ℹ️ Sistema configurado con procesamiento por lotes');
        log('ℹ️ Los textos largos se dividirán automáticamente en segmentos');
        log('ℹ️ Si el primer intento falla, el sistema reintentará automáticamente');
        
        // Recargar voces cada 300 segundos para detectar nuevas voces
        setInterval(loadAvailableVoices, 300000);
    }
    </script>
</body>
</html>
EOF

# Añadir script de lanzamiento
cat > "$PROJECT_DIR/run_service.sh" << 'EOF'
#!/bin/bash

# Script para ejecutar el servicio de síntesis de voz
PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PYTHON_ENV="$PROJECT_DIR/modulo_tts/bin/activate"

# Activar entorno virtual
source "$PYTHON_ENV"

# Iniciar el servicio
cd "$PROJECT_DIR"
python3 "$PROJECT_DIR/scripts/websocket_service.py"
EOF

# Añadir script para abrir el cliente
cat > "$PROJECT_DIR/open_client.sh" << 'EOF'
#!/bin/bash

# Obtener directorio del proyecto
PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CLIENT_PATH="$PROJECT_DIR/scripts/voice_client.html"

# Detectar navegador disponible
if command -v xdg-open > /dev/null; then
    xdg-open "$CLIENT_PATH"
elif command -v open > /dev/null; then
    open "$CLIENT_PATH"
elif command -v firefox > /dev/null; then
    firefox "$CLIENT_PATH"
elif command -v google-chrome > /dev/null; then
    google-chrome "$CLIENT_PATH"
elif command -v chromium-browser > /dev/null; then
    chromium-browser "$CLIENT_PATH"
else
    echo "No se pudo encontrar un navegador para abrir el cliente."
    echo "Por favor, abre manualmente el archivo: $CLIENT_PATH"
fi
EOF

# Hacer ejecutables los scripts de lanzamiento
chmod +x "$PROJECT_DIR/run_service.sh"
chmod +x "$PROJECT_DIR/open_client.sh"

# Crear un README con instrucciones
cat > "$PROJECT_DIR/README.md" << 'EOF'
# Módulo de Síntesis de Voz con Fish Speech

Este sistema permite generar voz sintética a partir de texto utilizando Fish Speech y clonación de voz.

## Requisitos del sistema

- NVIDIA GPU con CUDA
- Python 3.10
- Navegador web moderno (Chrome, Firefox, etc.)

## Cómo usar

1. **Iniciar el servicio**:
   ```bash
   ./run_service.sh
   ```
   Este comando iniciará el servidor de síntesis de voz en http://localhost:8000

2. **Abrir el cliente web**:
   ```bash
   ./open_client.sh
   ```
   O abra manualmente el archivo `scripts/voice_client.html` en su navegador.

3. **Agregar voces para clonar**:
   - Coloque archivos de audio WAV en la carpeta `samples/`
   - Cree archivos TXT con el mismo nombre que contienen la transcripción del audio
   - Ejemplo: `mi_voz.wav` y `mi_voz.txt`

4. **Usar el sistema**:
   - Seleccione una voz
   - Escriba o pegue el texto que desea sintetizar
   - Ajuste la velocidad si lo desea
   - Haga clic en "Sintetizar Voz"

## Estructura de directorios

- `fish-speech/`: Código fuente del modelo Fish Speech
- `modulo_tts/`: Entorno virtual de Python
- `samples/`: Muestras de voz para clonación
- `scripts/`: Scripts de servicio y cliente
- `config/`: Archivos de configuración

## Solución de problemas

Si encuentra problemas con el servicio:

1. Verifique que el servidor esté en ejecución (`./run_service.sh`)
2. Asegúrese de tener archivos de voz en la carpeta `samples/`
3. Revise los logs en la consola del servidor
4. Consulte la sección "Consola de desarrollo" en la interfaz web

## Créditos

Este sistema utiliza [Fish Speech](https://github.com/fishaudio/fish-speech) para la síntesis de voz.
EOF

print_success "Instalación completada correctamente"
print_message "Directorio del proyecto: $PROJECT_DIR"
print_message ""
print_message "Para usar el sistema:"
print_message "1. Agregue archivos WAV y TXT de muestras en la carpeta '$PROJECT_DIR/samples/'"
print_message "2. Ejecute './run_service.sh' para iniciar el servidor"
print_message "3. Ejecute './open_client.sh' para abrir la interfaz web"
print_message ""
print_message "Consulte el archivo README.md para más detalles."

# Si se necesita reiniciar debido a la instalación de drivers
if [ -n "$(dpkg -l | grep -i nvidia | grep -i 'ii' | grep '570')" ] && ! command -v nvidia-smi >/dev/null 2>&1; then
    print_warning "Se han instalado nuevos drivers NVIDIA. Es recomendable reiniciar el sistema."
    echo ""
    read -p "¿Desea reiniciar ahora? (s/n): " choice
    if [[ "$choice" == "s" || "$choice" == "S" ]]; then
        print_message "Reiniciando el sistema..."
        reboot
    else
        print_warning "Recuerde reiniciar el sistema para activar los drivers NVIDIA antes de usar el servicio."
    fi
fi