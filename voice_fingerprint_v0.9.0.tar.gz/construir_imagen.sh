#!/usr/bin/env bash
# voice_fingerprint — construye la imagen del ENTORNO (una sola vez, con internet),
# la verifica SIN red y deja un respaldo en ../imagenes/ para recuperarla sin internet.
#
# Uso (desde codigo/):
#   ./construir_imagen.sh                 construir + verificar sin red + respaldar
#   ./construir_imagen.sh --verificar     solo verificar sin red una imagen ya presente (no usa internet)
#   ./construir_imagen.sh --respaldar     solo respaldar una imagen ya presente (no usa internet)
#
# Recuperar la imagen sin internet (por ejemplo, tras un "docker system prune -a"):
#   docker load -i ../imagenes/<archivo>.tar.gz
set -euo pipefail
cd "$(dirname "$0")"

if [[ -f .env ]]; then set -a; . ./.env; set +a; fi
IMAGEN="${VF_IMAGEN:-voice_fingerprint-entorno:0.9.0}"
case "$(uname -m)" in
  x86_64|amd64)  ARQ=amd64 ;;
  aarch64|arm64) ARQ=arm64 ;;
  *)             ARQ="$(uname -m)" ;;
esac
DIR_IMAGENES="../imagenes"
RESPALDO="${DIR_IMAGENES}/$(echo "$IMAGEN" | tr ':/' '__')_${ARQ}.tar.gz"
USUARIO="${VF_UID:-$(id -u)}:${VF_GID:-$(id -g)}"

paso() { printf '\n==> %s\n' "$*"; }

docker info >/dev/null 2>&1 || { echo "ERROR: no hay acceso a Docker (¿el usuario está en el grupo docker?)."; exit 1; }

construir() {
  paso "Construyendo ${IMAGEN} para ${ARQ} (necesita internet; descarga varios GB; en arm64 tarda 15-25 min)"
  docker build --pull --build-arg VF_ENTORNO="${IMAGEN}" -t "${IMAGEN}" .
}

verificar() {
  docker image inspect "${IMAGEN}" >/dev/null 2>&1 || { echo "ERROR: no existe la imagen ${IMAGEN}."; exit 1; }
  paso "Verificando ${IMAGEN} con el contenedor SIN red, en CPU"
  docker run --rm --network none --user "${USUARIO}" -e VF_DISPOSITIVO=cpu \
    -v "${PWD}/huella_vocal:/app/huella_vocal:ro" \
    -v "${PWD}/servicio:/app/servicio:ro" \
    "${IMAGEN}" python -m servicio.verificar
  if docker info --format '{{json .Runtimes}}' 2>/dev/null | grep -q nvidia; then
    paso "Verificando ${IMAGEN} con el contenedor SIN red, en GPU (NVIDIA Container Toolkit presente)"
    docker run --rm --network none --user "${USUARIO}" --gpus all -e VF_DISPOSITIVO=gpu \
      -v "${PWD}/huella_vocal:/app/huella_vocal:ro" \
      -v "${PWD}/servicio:/app/servicio:ro" \
      "${IMAGEN}" python -m servicio.verificar
  else
    paso "Sin NVIDIA Container Toolkit en este equipo: se omite la verificación en GPU"
  fi
}

respaldar() {
  paso "Respaldando la imagen en ${RESPALDO}"
  mkdir -p "${DIR_IMAGENES}"
  docker save "${IMAGEN}" | gzip -1 > "${RESPALDO}.parcial"
  mv "${RESPALDO}.parcial" "${RESPALDO}"
  (cd "${DIR_IMAGENES}" && sha256sum "$(basename "${RESPALDO}")" > "$(basename "${RESPALDO}").sha256")
  ls -lh "${RESPALDO}"
}

case "${1:-}" in
  --verificar) verificar ;;
  --respaldar) respaldar ;;
  "")          construir; verificar; respaldar
               paso "Listo. Desde ahora no hace falta internet: docker compose up -d" ;;
  *)           echo "Opción desconocida: $1"; exit 2 ;;
esac
