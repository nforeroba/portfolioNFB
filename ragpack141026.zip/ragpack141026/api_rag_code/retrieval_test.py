"""
Chatbot de pruebas para el RPC Retrieve de rag-api, con RAG on/off.

Usa LangGraph para orquestar dos pasos (retrieve condicional ->
generate con Ollama via LangChain), y Streamlit como interfaz. La
idea es poder ver, turno a turno, si el modelo esta usando contexto
recuperado de Qdrant o no, comparando respuestas con RAG prendido y
apagado.

Requisitos (dentro del venv rag-env):
    pip install streamlit langchain langchain-ollama langgraph httpx grpcio

Uso (con rag-api ya corriendo en otra terminal, y Ollama sirviendo
tanto el modelo de embeddings como el/los modelos conversacionales
que quieras usar en el chat):
    streamlit run retrieval_test.py
"""

from __future__ import annotations

import operator
from typing import Annotated, TypedDict

import grpc
import httpx
import streamlit as st
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph

from rag_api.generated import rag_pb2, rag_pb2_grpc

st.set_page_config(page_title="rag-api - Chatbot Retrieve (RAG on/off)", layout="wide")

PERFILES = {
    "PERFIL_RAPIDO (vLLM 0.6b, denso simple)": rag_pb2.PERFIL_RAPIDO,
    "PERFIL_PRECISO (Ollama 8b, hybrid + RRF)": rag_pb2.PERFIL_PRECISO,
}


# ===================================================================
# Utilidades de conexion
# ===================================================================

@st.cache_resource
def obtener_stub_rag(host: str, puerto: int):
    canal = grpc.insecure_channel(f"{host}:{puerto}")
    return rag_pb2_grpc.RagServiceStub(canal)


def listar_modelos_ollama(ollama_host: str, ollama_puerto: int) -> list[str]:
    """
    Consulta GET /api/tags de Ollama para listar los modelos disponibles
    localmente (equivalente a 'ollama list'), sin depender de una
    libreria adicional solo para esto.
    """
    try:
        respuesta = httpx.get(f"http://{ollama_host}:{ollama_puerto}/api/tags", timeout=5.0)
        respuesta.raise_for_status()
        datos = respuesta.json()
        return sorted(modelo["name"] for modelo in datos.get("models", []))
    except (httpx.HTTPError, KeyError, ValueError) as error:
        st.sidebar.error(f"No se pudo listar modelos de Ollama: {error}")
        return []


# ===================================================================
# Estado y grafo de LangGraph
# ===================================================================

class EstadoChat(TypedDict):
    messages: Annotated[list, operator.add]
    rag_habilitado: bool
    chunks_recuperados: list[dict]
    retrieve_request_crudo: str | None
    retrieve_response_crudo: str | None
    perfil: int
    categoria_principal: str
    categorias_adicionales: list[str]
    top_k: int
    ef_search: int | None
    modelo_chat: str
    ollama_host: str
    ollama_puerto: int


def nodo_retrieve(estado: EstadoChat, stub) -> dict:
    """
    Si el RAG esta apagado, no llama a rag-api y deja los chunks
    vacios. Si esta prendido, ejecuta el RPC Retrieve con la ultima
    pregunta del usuario como query.
    """
    if not estado["rag_habilitado"]:
        return {
            "chunks_recuperados": [],
            "retrieve_request_crudo": None,
            "retrieve_response_crudo": None,
        }

    ultima_pregunta = estado["messages"][-1].content

    kwargs = {
        "query": ultima_pregunta,
        "categoria_principal": estado["categoria_principal"],
        "categorias_adicionales": estado["categorias_adicionales"],
        "top_k": estado["top_k"],
        "perfil": estado["perfil"],
    }
    if estado["ef_search"] is not None:
        kwargs["ef_search"] = estado["ef_search"]

    request = rag_pb2.RetrieveRequest(**kwargs)
    request_crudo = str(request)

    try:
        response = stub.Retrieve(request, timeout=30)
    except grpc.RpcError as error:
        return {
            "chunks_recuperados": [
                {"error": f"Error gRPC en Retrieve: codigo={error.code()} detalle={error.details()}"}
            ],
            "retrieve_request_crudo": request_crudo,
            "retrieve_response_crudo": None,
        }

    chunks = [
        {
            "id": chunk.id,
            "texto": chunk.texto,
            "fuente": chunk.fuente,
            "categoria": chunk.categoria,
            "score": chunk.score,
            "texto_padre": chunk.texto_padre if chunk.HasField("texto_padre") else None,
        }
        for chunk in response.resultados
    ]
    return {
        "chunks_recuperados": chunks,
        "retrieve_request_crudo": request_crudo,
        "retrieve_response_crudo": str(response),
    }


def nodo_generate(estado: EstadoChat) -> dict:
    llm = ChatOllama(
        model=estado["modelo_chat"],
        base_url=f"http://{estado['ollama_host']}:{estado['ollama_puerto']}",
    )

    chunks_validos = [c for c in estado["chunks_recuperados"] if "error" not in c]

    if chunks_validos:
        contexto = "\n\n".join(
            f"[Fuente: {c['fuente']} | categoria: {c['categoria']} | score: {c['score']:.4f}]\n{c['texto']}"
            for c in chunks_validos
        )
        mensaje_sistema = SystemMessage(
            content=(
                "Eres un asistente que responde SOLO con base en el siguiente contexto recuperado. "
                "Si el contexto no contiene la respuesta, dilo explicitamente en vez de inventar.\n\n"
                f"--- CONTEXTO RECUPERADO ---\n{contexto}\n--- FIN DEL CONTEXTO ---"
            )
        )
        mensajes_para_llm = [mensaje_sistema, *estado["messages"]]
    else:
        mensajes_para_llm = list(estado["messages"])

    respuesta = llm.invoke(mensajes_para_llm)
    return {"messages": [AIMessage(content=respuesta.content)]}


def construir_grafo(stub):
    grafo = StateGraph(EstadoChat)
    grafo.add_node("retrieve", lambda estado: nodo_retrieve(estado, stub))
    grafo.add_node("generate", nodo_generate)
    grafo.set_entry_point("retrieve")
    grafo.add_edge("retrieve", "generate")
    grafo.add_edge("generate", END)
    return grafo.compile()


# ===================================================================
# Sidebar: configuracion de conexiones y parametros de Retrieve
# ===================================================================

with st.sidebar:
    st.header("Conexiones")

    st.subheader("rag-api (gRPC)")
    rag_host = st.text_input("Host rag-api", value="localhost", key="rag_host")
    rag_puerto = st.number_input("Puerto rag-api", value=50051, step=1, key="rag_puerto")

    st.subheader("Ollama")
    ollama_host = st.text_input("Host Ollama", value="localhost", key="ollama_host")
    ollama_puerto = st.number_input("Puerto Ollama", value=11434, step=1, key="ollama_puerto")

    if st.button("Refrescar lista de modelos"):
        st.cache_data.clear()

    @st.cache_data(ttl=30)
    def _modelos_cacheados(host, puerto):
        return listar_modelos_ollama(host, puerto)

    modelos_disponibles = _modelos_cacheados(ollama_host, int(ollama_puerto))

    if not modelos_disponibles:
        st.warning("No se encontraron modelos en Ollama (o no se pudo conectar).")
        modelo_chat = st.text_input("Nombre del modelo (manual)", value="qwen3:14b")
    else:
        modelo_chat = st.selectbox("Modelo de chat (ollama list)", modelos_disponibles)

    st.divider()
    st.header("RAG")
    rag_habilitado = st.toggle("RAG activo (usar Retrieve antes de responder)", value=True)

    perfil_label = st.radio("Perfil de retrieval", list(PERFILES.keys()))
    perfil = PERFILES[perfil_label]

    categoria_principal = st.text_input("categoria_principal (obligatorio)", value="")
    categorias_adicionales_raw = st.text_input(
        "categorias_adicionales (separadas por coma, opcional)", value=""
    )
    categorias_adicionales = [c.strip() for c in categorias_adicionales_raw.split(",") if c.strip()]

    top_k = st.slider("top_k", min_value=1, max_value=20, value=5)

    usar_ef_search = st.checkbox("Override ef_search (avanzado)", value=False)
    ef_search = None
    if usar_ef_search:
        ef_search = st.number_input("ef_search", value=64, min_value=1, step=1)

    if st.button("Limpiar conversacion"):
        st.session_state.historial_mensajes = []
        st.rerun()

# ===================================================================
# Cuerpo principal: chat
# ===================================================================

st.title("RAG - Chatbot de pruebas - RETRIEVAL información")
st.caption(
    "Compara respuestas con RAG prendido y apagado para confirmar si el modelo "
    "esta usando contexto recuperado de Qdrant."
)

if "historial_mensajes" not in st.session_state:
    st.session_state.historial_mensajes = []

stub_rag = obtener_stub_rag(rag_host, int(rag_puerto))
grafo = construir_grafo(stub_rag)

for mensaje in st.session_state.historial_mensajes:
    rol = "user" if isinstance(mensaje, HumanMessage) else "assistant"
    with st.chat_message(rol):
        st.markdown(mensaje.content)

pregunta = st.chat_input("Escribe tu pregunta...")

if pregunta:
    st.session_state.historial_mensajes.append(HumanMessage(content=pregunta))
    with st.chat_message("user"):
        st.markdown(pregunta)

    estado_entrada: EstadoChat = {
        "messages": st.session_state.historial_mensajes,
        "rag_habilitado": rag_habilitado,
        "chunks_recuperados": [],
        "retrieve_request_crudo": None,
        "retrieve_response_crudo": None,
        "perfil": perfil,
        "categoria_principal": categoria_principal,
        "categorias_adicionales": categorias_adicionales,
        "top_k": int(top_k),
        "ef_search": int(ef_search) if ef_search is not None else None,
        "modelo_chat": modelo_chat,
        "ollama_host": ollama_host,
        "ollama_puerto": int(ollama_puerto),
    }

    with st.chat_message("assistant"):
        with st.spinner("Pensando..." if not rag_habilitado else "Recuperando contexto y pensando..."):
            try:
                resultado = grafo.invoke(estado_entrada)
            except Exception as error:  # noqa: BLE001 - mostrar cualquier fallo en la UI, es una herramienta de pruebas
                st.error(f"Error ejecutando el grafo: {error}")
                resultado = None

        if resultado is not None:
            respuesta_ai = resultado["messages"][-1]
            st.markdown(respuesta_ai.content)
            st.session_state.historial_mensajes.append(respuesta_ai)

            chunks = resultado["chunks_recuperados"]
            with st.expander(
                f"Contexto usado ({'RAG activo' if rag_habilitado else 'RAG apagado'} - {len(chunks)} chunk(s))"
            ):
                if not rag_habilitado:
                    st.caption("RAG apagado: no se llamo a Retrieve, el modelo respondio solo con su conocimiento.")
                elif not chunks:
                    st.caption("RAG activo, pero Retrieve no devolvio chunks (revisa categoria_principal/perfil).")
                elif "error" in chunks[0]:
                    st.error(chunks[0]["error"])
                else:
                    for i, chunk in enumerate(chunks, start=1):
                        st.markdown(
                            f"**{i}. score={chunk['score']:.4f} | categoria={chunk['categoria']} | fuente={chunk['fuente']}**"
                        )
                        st.text(chunk["texto"])
                        if chunk["texto_padre"]:
                            st.caption(f"texto_padre: {chunk['texto_padre']}")
                        st.divider()

            if resultado["retrieve_request_crudo"] is None:
                st.caption("RAG apagado: no se construyo ni se envio ningun RetrieveRequest en este turno.")
            else:
                st.text("Solicitud enviada al servidor (protobuf, tal como se construyo antes de serializar):")
                st.code(resultado["retrieve_request_crudo"], language="text")
                st.text("Respuesta cruda recibida del servidor (protobuf, tal como llega deserializado):")
                if resultado["retrieve_response_crudo"] is None:
                    st.caption("Sin respuesta (fallo el RPC, ver el error arriba).")
                else:
                    st.code(resultado["retrieve_response_crudo"], language="text")
