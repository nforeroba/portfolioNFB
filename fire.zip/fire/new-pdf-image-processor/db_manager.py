#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo para interactuar con la base de datos PostgreSQL.
Este módulo se utilizará en el futuro cuando la base de datos esté disponible.
"""

import logging
import psycopg2
from psycopg2 import sql
from psycopg2.extras import DictCursor
from pathlib import Path

# Importar configuración
import config
from security_module import SecurityManager

logger = logging.getLogger("DatabaseManager")

class DatabaseManager:
    """
    Clase para gestionar la interacción con la base de datos PostgreSQL.
    """
    
    def __init__(self, db_config=None):
        """
        Inicializa el gestor de base de datos.
        
        Args:
            db_config (dict, optional): Configuración de la base de datos.
                Si es None, se utilizará la configuración del módulo config.
        """
        self.original_db_config = db_config or config.DB_CONFIG
        self.security = SecurityManager()
        # Aplicar seguridad a la configuración de BD
        self.db_config = self.security.secure_db_config(self.original_db_config)
        self.conn = None
        self.is_connected = False
    
    def connect(self):
        """
        Establece conexión con la base de datos.
        
        Returns:
            bool: True si la conexión se estableció correctamente, False en caso contrario.
        """
        try:
            self.conn = psycopg2.connect(**self.db_config)
            self.is_connected = True
            logger.info("Conexión establecida con la base de datos")
            return True
        except Exception as e:
            logger.error(f"Error al conectar con la base de datos: {str(e)}")
            self.is_connected = False
            return False
    
    def disconnect(self):
        """Cierra la conexión con la base de datos."""
        if self.conn and self.is_connected:
            self.conn.close()
            self.is_connected = False
            logger.info("Conexión cerrada con la base de datos")
    
    def ensure_connection(self):
        """
        Asegura que haya una conexión activa con la base de datos.
        
        Returns:
            bool: True si hay una conexión activa, False en caso contrario.
        """
        if not self.is_connected:
            return self.connect()
        
        # Verificar si la conexión está viva
        try:
            with self.conn.cursor() as cursor:
                cursor.execute("SELECT 1")
                return True
        except Exception:
            logger.warning("Conexión caída, reconectando...")
            self.disconnect()
            return self.connect()
    
    def get_pending_files(self):
        """
        Obtiene la lista de archivos pendientes por procesar según la base de datos.
        
        Returns:
            list: Lista de rutas relativas a archivos pendientes.
        """
        if not self.ensure_connection():
            logger.error("No se puede obtener archivos pendientes: sin conexión a BD")
            return []
        
        try:
            with self.conn.cursor(cursor_factory=DictCursor) as cursor:
                # Consulta de ejemplo, ajustar según el esquema real de la tabla
                cursor.execute("""
                    SELECT file_path FROM files 
                    WHERE status = 'pending' 
                    ORDER BY created_at ASC
                """)
                
                results = cursor.fetchall()
                return [row['file_path'] for row in results]
                
        except Exception as e:
            logger.error(f"Error al obtener archivos pendientes: {str(e)}")
            return []
    
    def update_file_status(self, file_path, status, method=None, error_msg=None):
        """
        Actualiza el estado de un archivo en la base de datos.
        
        Args:
            file_path (str): Ruta relativa al archivo.
            status (str): Nuevo estado ('processed', 'failed').
            method (str, optional): Método utilizado para procesar el archivo.
            error_msg (str, optional): Mensaje de error si el estado es 'failed'.
            
        Returns:
            bool: True si la actualización fue exitosa, False en caso contrario.
        """
        if not self.ensure_connection():
            logger.error(f"No se puede actualizar estado de {file_path}: sin conexión a BD")
            return False
        
        try:
            with self.conn.cursor() as cursor:
                # Consulta con todos los campos
                cursor.execute("""
                    UPDATE files 
                    SET status = %s, 
                        method = %s,
                        error_message = %s, 
                        updated_at = NOW() 
                    WHERE file_path = %s
                """, (status, method, error_msg, file_path))
                
                self.conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"Error al actualizar estado de {file_path}: {str(e)}")
            if self.conn:
                self.conn.rollback()
            return False
    
    def register_new_file(self, file_path, file_type):
        """
        Registra un nuevo archivo en la base de datos.
        
        Args:
            file_path (str): Ruta relativa al archivo.
            file_type (str): Tipo de archivo ('pdf', 'image').
            
        Returns:
            bool: True si el registro fue exitoso, False en caso contrario.
        """
        if not self.ensure_connection():
            logger.error(f"No se puede registrar {file_path}: sin conexión a BD")
            return False
        
        try:
            with self.conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO files (file_path, file_type, status, created_at, updated_at)
                    VALUES (%s, %s, 'pending', NOW(), NOW())
                    ON CONFLICT (file_path) DO NOTHING
                """, (file_path, file_type))
                
                self.conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"Error al registrar archivo {file_path}: {str(e)}")
            if self.conn:
                self.conn.rollback()
            return False
    
    def create_tables_if_not_exist(self):
        """
        Crea las tablas necesarias en la base de datos si no existen.
        
        Returns:
            bool: True si la operación fue exitosa, False en caso contrario
        """
        if not self.ensure_connection():
            logger.error("No se pueden crear tablas: sin conexión a BD")
            return False
            
        try:
            with self.conn.cursor() as cursor:
                # Crear tabla principal para el seguimiento de archivos
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS files (
                        id SERIAL PRIMARY KEY,
                        file_path VARCHAR(512) UNIQUE NOT NULL,
                        file_type VARCHAR(20) NOT NULL, -- 'pdf' o 'image'
                        status VARCHAR(20) NOT NULL,
                        method VARCHAR(50), -- método usado para procesar
                        error_message TEXT,
                        created_at TIMESTAMP NOT NULL,
                        updated_at TIMESTAMP NOT NULL,
                        processed_at TIMESTAMP
                    );
                    
                    CREATE INDEX IF NOT EXISTS idx_files_status ON files(status);
                    CREATE INDEX IF NOT EXISTS idx_files_filepath ON files(file_path);
                    CREATE INDEX IF NOT EXISTS idx_files_filetype ON files(file_type);
                """)
                
                self.conn.commit()
                logger.info("Tablas creadas o verificadas correctamente")
                return True
                
        except Exception as e:
            logger.error(f"Error al crear tablas: {str(e)}")
            if self.conn:
                self.conn.rollback()
            return False
    
    def sync_with_json_records(self, processed_records):
        """
        Sincroniza los registros de la base de datos con los registros JSON locales.
        Útil para la migración inicial a PostgreSQL.
        
        Args:
            processed_records (dict): Diccionario con registros de archivos procesados y fallidos.
            
        Returns:
            bool: True si la sincronización fue exitosa, False en caso contrario.
        """
        if not self.ensure_connection():
            logger.error("No se puede sincronizar: sin conexión a BD")
            return False
            
        try:
            # Procesar archivos procesados correctamente
            for file_path in processed_records.get("processed", []):
                # Determinar tipo de archivo por extensión
                file_type = 'image' if any(file_path.lower().endswith(f'.{ext}') 
                                           for ext in config.SUPPORTED_IMAGE_FORMATS) else 'pdf'
                
                # Obtener método usado si está disponible
                method = processed_records.get("methods", {}).get(file_path, "unknown")
                
                with self.conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO files (file_path, file_type, status, method, created_at, updated_at, processed_at)
                        VALUES (%s, %s, 'processed', %s, NOW(), NOW(), NOW())
                        ON CONFLICT (file_path) 
                        DO UPDATE SET 
                            status = 'processed',
                            method = EXCLUDED.method,
                            updated_at = NOW(),
                            processed_at = NOW()
                    """, (file_path, file_type, method))
            
            # Procesar archivos fallidos
            for file_path in processed_records.get("failed", []):
                # Determinar tipo de archivo por extensión
                file_type = 'image' if any(file_path.lower().endswith(f'.{ext}') 
                                           for ext in config.SUPPORTED_IMAGE_FORMATS) else 'pdf'
                
                # Obtener error si está disponible
                error_msg = processed_records.get("errors", {}).get(file_path, "Error desconocido")
                
                with self.conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO files (file_path, file_type, status, error_message, created_at, updated_at)
                        VALUES (%s, %s, 'failed', %s, NOW(), NOW())
                        ON CONFLICT (file_path) 
                        DO UPDATE SET 
                            status = 'failed',
                            error_message = EXCLUDED.error_message,
                            updated_at = NOW()
                    """, (file_path, file_type, error_msg))
                    
            self.conn.commit()
            logger.info("Sincronización con registros JSON completada")
            return True
            
        except Exception as e:
            logger.error(f"Error al sincronizar registros: {str(e)}")
            if self.conn:
                self.conn.rollback()
            return False
