"""Carga de audio: cualquier WAV a mono, 16 kHz, float32."""

from math import gcd

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

from .config import SR


def _decodificar_con_av(ruta):
    """Decodifica con PyAV (FFmpeg) directo a mono, 16 kHz, float32. Devuelve (n, 1)."""
    import av

    piezas = []
    with av.open(str(ruta)) as contenedor:
        remuestreador = av.AudioResampler(format="flt", layout="mono", rate=SR)
        for cuadro in contenedor.decode(audio=0):
            for salida in remuestreador.resample(cuadro):
                piezas.append(salida.to_ndarray().reshape(-1))
        for salida in remuestreador.resample(None):   # vacía lo que quede en el remuestreador
            piezas.append(salida.to_ndarray().reshape(-1))
    if not piezas:
        raise ValueError(f"No se encontró audio en {ruta}")
    return np.concatenate(piezas).astype(np.float32)[:, None]


def cargar_audio(ruta, canal=None):
    """
    Devuelve (senal, info).

    canal=None promedia los canales; un entero toma solo ese canal (útil a futuro
    para grabaciones estéreo de contact center con cliente y asesor separados).
    """
    try:
        datos, sr_original = sf.read(ruta, dtype="float32", always_2d=True)
    except sf.LibsndfileError:
        # Formatos que libsndfile no lee (m4a, aac del celular, webm del navegador...).
        datos, sr_original = _decodificar_con_av(ruta), SR
    canales = datos.shape[1]
    if canal is None:
        senal = datos.mean(axis=1)
    else:
        if not 0 <= canal < canales:
            raise ValueError(f"El archivo tiene {canales} canal(es); se pidió el canal {canal}.")
        senal = datos[:, canal]

    if sr_original != SR:
        divisor = gcd(sr_original, SR)
        senal = resample_poly(senal, SR // divisor, sr_original // divisor)
    senal = np.ascontiguousarray(senal, dtype=np.float32)

    pico = float(np.max(np.abs(senal))) if senal.size else 0.0
    rms = float(np.sqrt(np.mean(senal ** 2))) if senal.size else 0.0
    info = {
        "sr_original": int(sr_original),
        "canales_originales": int(canales),
        "duracion_s": round(len(senal) / SR, 3),
        "pico": round(pico, 4),
        "rms_dbfs": round(20 * np.log10(rms + 1e-12), 2),
        "fraccion_saturada": round(float(np.mean(np.abs(senal) >= 0.999)), 6),
    }
    return senal, info
