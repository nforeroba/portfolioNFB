#!/bin/bash

# Script de instalación completo para sistema de clonación y síntesis de voz
# Instala automáticamente drivers NVIDIA y CUDA si no están disponibles

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Instalación de Sistema de Clonación y Síntesis de Voz ===${NC}"
echo "Usando Fish Speech con soporte para GPUs RTX 5000"

# Verificar ejecución como root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Este script debe ejecutarse como root${NC}"
    echo "Usa: sudo ./install.sh"
    exit 1
fi

# Función para verificar comandos
check_command() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}$1 no está instalado${NC}"
        return 1
    fi
    return 0
}

# Verificar e instalar drivers NVIDIA si es necesario
echo -e "${YELLOW}Verificando drivers NVIDIA...${NC}"
if ! check_command nvidia-smi; then
    echo -e "${YELLOW}Instalando drivers NVIDIA Open (570)...${NC}"
    
    # Agregar repositorio de NVIDIA
    apt update
    apt install -y software-properties-common
    add-apt-repository ppa:graphics-drivers/ppa -y
    apt update
    
    # Instalar drivers Open
    apt install -y nvidia-driver-570-open
    
    echo -e "${YELLOW}Se requiere reiniciar el sistema para cargar los drivers NVIDIA${NC}"
    echo -e "${RED}Por favor reinicia el sistema y vuelve a ejecutar este script${NC}"
    exit 0
else
    echo -e "${GREEN}Drivers NVIDIA detectados${NC}"
    nvidia-smi
fi

# Verificar e instalar CUDA si es necesario
echo -e "${YELLOW}Verificando CUDA...${NC}"
if ! check_command nvcc; then
    echo -e "${YELLOW}Instalando CUDA Toolkit 12.8...${NC}"
    
    # Agregar repositorio de CUDA
    wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
    dpkg -i cuda-keyring_1.0-1_all.deb
    rm cuda-keyring_1.0-1_all.deb
    apt update
    
    # Instalar CUDA Toolkit
    apt install -y cuda-toolkit-12-8
    
    # Configurar variables de entorno
    echo 'export PATH=/usr/local/cuda-12.8/bin:$PATH' >> /etc/profile.d/cuda.sh
    echo 'export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:$LD_LIBRARY_PATH' >> /etc/profile.d/cuda.sh
    
    echo -e "${YELLOW}CUDA instalado. Cargando variables de entorno...${NC}"
    source /etc/profile.d/cuda.sh
    
    if ! command -v nvcc &> /dev/null; then
        echo -e "${RED}Es necesario reiniciar el sistema para cargar CUDA correctamente${NC}"
        echo -e "${YELLOW}Por favor reinicia el sistema y vuelve a ejecutar este script${NC}"
        exit 0
    fi
else
    echo -e "${GREEN}CUDA detectado${NC}"
    nvcc --version
fi

# Verificar versión de CUDA
CUDA_VERSION=$(nvcc --version | grep "Cuda compilation tools" | cut -d " " -f 6)
echo "CUDA version: $CUDA_VERSION"

# Verificar comandos necesarios e instalar si faltan
echo -e "${YELLOW}Verificando dependencias del sistema...${NC}"
PACKAGES_TO_INSTALL=""

if ! check_command git; then
    PACKAGES_TO_INSTALL="$PACKAGES_TO_INSTALL git"
fi

if ! check_command wget; then
    PACKAGES_TO_INSTALL="$PACKAGES_TO_INSTALL wget"
fi

if ! check_command ffmpeg; then
    PACKAGES_TO_INSTALL="$PACKAGES_TO_INSTALL ffmpeg"
fi

if [ -n "$PACKAGES_TO_INSTALL" ]; then
    echo -e "${YELLOW}Instalando: $PACKAGES_TO_INSTALL${NC}"
    apt update
    apt install -y $PACKAGES_TO_INSTALL
fi

# Instalar Python 3.10 desde deadsnakes si no está instalado
echo -e "${YELLOW}Verificando Python 3.10...${NC}"
if ! command -v python3.10 &> /dev/null; then
    echo -e "${YELLOW}Instalando Python 3.10 desde deadsnakes...${NC}"
    add-apt-repository ppa:deadsnakes/ppa -y
    apt update
    apt install -y python3.10 python3.10-dev python3.10-venv python3.10-distutils
else
    echo -e "${GREEN}Python 3.10 detectado${NC}"
fi

# Instalar dependencias de desarrollo
echo -e "${YELLOW}Instalando dependencias de desarrollo...${NC}"
apt install -y build-essential cmake \
               libsox-dev ffmpeg \
               portaudio19-dev libportaudio2 libportaudiocpp0 \
               pkg-config

# Crear estructura de directorios
echo -e "${YELLOW}Creando estructura de directorios...${NC}"
mkdir -p voice-cloning-project/{embeddings,samples,outputs,logs,scripts,config}
cd voice-cloning-project

# Crear entorno virtual con Python 3.10
echo -e "${YELLOW}Creando entorno virtual con Python 3.10...${NC}"
python3.10 -m venv venv
source venv/bin/activate

# Actualizar pip
echo -e "${YELLOW}Actualizando pip...${NC}"
pip install --upgrade pip

# Instalar dependencias preliminares
echo -e "${YELLOW}Instalando dependencias preliminares...${NC}"
pip install wheel setuptools

# Clonar Fish Speech
echo -e "${YELLOW}Clonando Fish Speech...${NC}"
git clone https://github.com/fishaudio/fish-speech.git
cd fish-speech

# Instalar Fish Speech
echo -e "${YELLOW}Instalando Fish Speech...${NC}"
pip install -e .

# Instalar FastAPI y dependencias WebSocket
echo -e "${YELLOW}Instalando FastAPI y dependencias WebSocket...${NC}"
pip install fastapi uvicorn websockets python-multipart pydantic aiofiles librosa

# Eliminar torch y torchaudio para instalar versiones nightly
echo -e "${YELLOW}Actualizando PyTorch para RTX 5000...${NC}"
pip uninstall -y torch torchaudio

# Instalar versiones nightly compatibles con CUDA 12.8
echo -e "${YELLOW}Instalando PyTorch nightly para CUDA 12.8...${NC}"
pip install --pre torch --index-url https://download.pytorch.org/whl/nightly/cu128
pip install --pre torchaudio --index-url https://download.pytorch.org/whl/nightly/cu128

# Verificar que PyTorch detecta la GPU
echo -e "${YELLOW}Verificando detección de GPU...${NC}"
python -c "import torch; print(f'PyTorch version: {torch.__version__}'); print(f'CUDA available: {torch.cuda.is_available()}'); print(f'GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"No GPU\"}')"

# Descargar modelos preentrenados
echo -e "${YELLOW}Descargando modelos preentrenados...${NC}"
mkdir -p checkpoints
huggingface-cli download fishaudio/fish-speech-1.5 --local-dir checkpoints/fish-speech-1.5

# Crear archivo de configuración
echo -e "${YELLOW}Creando archivo de configuración...${NC}"
cd ../config
cat > config.json << EOF
{
  "model_path": "../fish-speech/checkpoints/fish-speech-1.5",
  "embeddings_dir": "../embeddings",
  "samples_dir": "../samples",
  "outputs_dir": "../outputs",
  "logs_dir": "../logs",
  "sample_rate": 44100,
  "device": "cuda"
}
EOF

# Crear script de activación de entorno
echo -e "${YELLOW}Creando script de activación...${NC}"
cd ..
cat > activate_env.sh << EOF
#!/bin/bash
source venv/bin/activate
cd fish-speech
export GRADIO_SERVER_NAME="0.0.0.0"
export PYTHONPATH="\$PYTHONPATH:$(pwd)"
cd ..
echo "Entorno activado. Ubicación actual: $(pwd)"
echo "Python version: $(python --version)"
echo "PyTorch version: $(python -c 'import torch; print(torch.__version__)')"
echo "CUDA available: $(python -c 'import torch; print(torch.cuda.is_available())')"
EOF
chmod +x activate_env.sh

# Crear todos los scripts necesarios
echo -e "${YELLOW}Creando scripts del proyecto...${NC}"
cd scripts

# Crear script voice_cloning.py
cat > voice_cloning.py << 'ENDOFFILE'
#!/usr/bin/env python3
import torch
import torchaudio
import argparse
import os
import json
import sys
import subprocess
from pathlib import Path
from datetime import datetime

project_root = Path(__file__).parent.parent

def save_embedding_metadata(voice_name, prompt_text, config_path):
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    metadata_path = os.path.join(config["embeddings_dir"], f"{voice_name}_metadata.json")
    metadata = {
        "name": voice_name,
        "prompt_text": prompt_text,
        "created_at": str(datetime.now()),
        "audio_sample": None
    }
    
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    print(f"Metadata guardado en: {metadata_path}")

def clone_voice(sample_path, output_name, config_path, transcription=None, transcription_file=None):
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    print(f"Clonando voz desde: {sample_path}")
    
    if not os.path.exists(sample_path):
        raise FileNotFoundError(f"Archivo de muestra no encontrado: {sample_path}")
    
    if transcription_file and os.path.exists(transcription_file):
        print(f"Leyendo transcripción desde archivo: {transcription_file}")
        with open(transcription_file, 'r', encoding='utf-8') as f:
            transcription = f.read().strip()
            print(f"Texto de transcripción completo: {transcription}")
    
    checkpoint_path = os.path.join(config["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth")
    
    try:
        os.chdir(str(project_root / "fish-speech"))
        
        cmd = [sys.executable, "-m", "fish_speech.models.vqgan.inference",
               "-i", sample_path, "--checkpoint-path", checkpoint_path]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        os.chdir(str(project_root / "scripts"))
        
        output_path = str(project_root / "fish-speech" / "fake.npy")
        
        if os.path.exists(output_path):
            embedding_path = os.path.join(config["embeddings_dir"], f"{output_name}.npy")
            os.rename(output_path, embedding_path)
            print(f"Embedding guardado en: {embedding_path}")
            
            if transcription:
                save_embedding_metadata(output_name, transcription, config_path)
                print(f"\n✅ Se ha creado un perfil completo de voz con transcripción")
            else:
                print("\n⚠️ No se proporcionó transcripción")
            
            return True
        else:
            print(f"Error: No se generó el archivo {output_path}")
            return False
            
    except Exception as e:
        print(f"Error en clonación de voz: {e}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Clone voice from audio sample using Fish Speech")
    parser.add_argument("--sample", required=True, help="Path to audio sample")
    parser.add_argument("--name", required=True, help="Name for the voice embedding")
    parser.add_argument("--config", default="../config/config.json", help="Config file path")
    parser.add_argument("--transcription", help="Transcription text (for few-shot mode)")
    parser.add_argument("--transcription-file", help="Path to transcription file (plain text)")
    
    args = parser.parse_args()
    
    success = clone_voice(args.sample, args.name, args.config, args.transcription, args.transcription_file)
    if success:
        print(f"\n✅ Voice cloned successfully: {args.name}")
    else:
        print("❌ Failed to clone voice")
ENDOFFILE

# Crear script voice_synthesis.py
cat > voice_synthesis.py << 'ENDOFFILE'
#!/usr/bin/env python3
import torch
import torchaudio
import argparse
import time
import os
import json
from pathlib import Path
import sys
import subprocess

project_root = Path(__file__).parent.parent

def load_embedding_metadata(voice_name, config_path):
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        metadata_path = os.path.join(config["embeddings_dir"], f"{voice_name}_metadata.json")
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                full_text = metadata.get("prompt_text", None)
                if full_text:
                    print(f"Texto de referencia completo cargado")
                    return full_text
    except Exception as e:
        print(f"No se pudo cargar metadata: {e}")
    return None

def synthesize_speech(text, voice_embedding_path, output_path, config_path, prompt_text=None, zero_shot=False):
    start_time = time.time()
    
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    print(f"Sintetizando texto: {text}")
    
    try:
        fish_speech_dir = str(project_root / "fish-speech")
        os.chdir(fish_speech_dir)
        os.makedirs("temp", exist_ok=True)
        
        cmd = [sys.executable, "-m", "fish_speech.models.text2semantic.inference",
               "--text", text, "--checkpoint-path", config["model_path"], "--num-samples", "1"]
        
        if not zero_shot and os.path.exists(voice_embedding_path):
            if not prompt_text:
                print("Error: Se necesita --prompt-text cuando se usa un embedding de voz")
                return False, {}
            
            print(f"Modo Few-shot: usando embedding de voz -> {voice_embedding_path}")
            cmd.extend(["--prompt-tokens", voice_embedding_path])
            cmd.extend(["--prompt-text", prompt_text])
        else:
            print("Modo Zero-shot: síntesis sin referencia de voz")
        
        subprocess.run(cmd, check=True)
        
        cmd = [sys.executable, "-m", "fish_speech.models.vqgan.inference",
               "-i", "temp/codes_0.npy", "--checkpoint-path", 
               os.path.join(config["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth")]
        
        subprocess.run(cmd, check=True)
        
        output_audio = "fake.wav"
        if os.path.exists(output_audio):
            os.rename(output_audio, str(project_root / "scripts" / output_path))
            os.chdir(str(project_root / "scripts"))
            
            waveform, _ = torchaudio.load(output_path)
            audio_duration = waveform.shape[1] / config["sample_rate"]
            synthesis_time = time.time() - start_time
            
            metrics = {
                "synthesis_time": synthesis_time,
                "text_length": len(text),
                "audio_duration": audio_duration,
                "real_time_factor": audio_duration / synthesis_time if synthesis_time > 0 else 0,
                "mode": "zero-shot" if zero_shot else "few-shot"
            }
            
            return True, metrics
        else:
            return False, {}
            
    except Exception as e:
        print(f"Error en síntesis: {e}")
        os.chdir(str(project_root / "scripts"))
        return False, {}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Synthesize speech with Fish Speech")
    parser.add_argument("--text", required=True, help="Text to synthesize")
    parser.add_argument("--voice", help="Voice embedding name (for few-shot)")
    parser.add_argument("--output", required=True, help="Output audio file path")
    parser.add_argument("--config", default="../config/config.json", help="Config file path")
    parser.add_argument("--prompt-text", help="Text prompt corresponding to the voice embedding")
    parser.add_argument("--zero-shot", action="store_true", help="Use zero-shot synthesis without voice reference")
    parser.add_argument("--auto-metadata", action="store_true", help="Try to load metadata automatically")
    
    args = parser.parse_args()
    
    if args.zero_shot:
        embedding_path = None
        prompt_text = None
    else:
        embedding_path = f"../embeddings/{args.voice}.npy"
        prompt_text = args.prompt_text
        
        if args.auto_metadata and not prompt_text:
            prompt_text = load_embedding_metadata(args.voice, args.config)
    
    success, metrics = synthesize_speech(args.text, embedding_path, args.output, args.config, prompt_text, args.zero_shot)
    
    if success:
        print(f"Speech synthesized successfully: {args.output}")
        print(f"Metrics: {json.dumps(metrics, indent=2)}")
    else:
        print("Failed to synthesize speech")
ENDOFFILE

# Crear script websocket_service.py
cat > websocket_service.py << 'ENDOFFILE'
#!/usr/bin/env python3
import fastapi
import uvicorn
import json
import base64
import time
import os
import sys
import subprocess
import asyncio
from pathlib import Path
from fastapi import WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import torchaudio

project_root = Path(__file__).parent.parent
sys.path.append(str(project_root / "fish-speech"))

app = fastapi.FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class VoiceRequest(BaseModel):
    text: str
    voz: str

class VoiceResponse(BaseModel):
    base64: str
    metricas: dict

with open(project_root / "config" / "config.json", 'r') as f:
    config_data = json.load(f)

@app.get("/voices")
async def get_voices():
    voices = []
    embeddings_dir = config_data["embeddings_dir"]
    
    if os.path.exists(embeddings_dir):
        for file in os.listdir(embeddings_dir):
            if file.endswith('.npy'):
                voice_name = file[:-4]
                metadata_path = os.path.join(embeddings_dir, f"{voice_name}_metadata.json")
                metadata = {}
                if os.path.exists(metadata_path):
                    try:
                        with open(metadata_path, 'r') as f:
                            metadata = json.load(f)
                    except:
                        pass
                
                voice_info = {
                    "name": voice_name,
                    "display_name": voice_name.replace('_', ' ').title(),
                    "created_at": metadata.get("created_at", "Desconocido"),
                    "prompt_text": metadata.get("prompt_text", "").split('.')[0] + "..." if metadata.get("prompt_text") else ""
                }
                voices.append(voice_info)
    
    return {"voices": voices}

async def synthesize_with_voice(text: str, voice: str):
    start_time = time.time()
    
    embedding_path = os.path.join(config_data["embeddings_dir"], f"{voice}.npy")
    if not os.path.exists(embedding_path):
        raise FileNotFoundError(f"Voice embedding not found: {voice}")
    
    metadata_path = os.path.join(config_data["embeddings_dir"], f"{voice}_metadata.json")
    prompt_text = "Audio de referencia en español"
    
    if os.path.exists(metadata_path):
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
            full_text = metadata.get("prompt_text", None)
            if full_text:
                words = full_text.split()
                prompt_text = ' '.join(words[:7]) + '.'
    
    try:
        os.chdir(str(project_root / "fish-speech"))
        
        cmd = [sys.executable, "-m", "fish_speech.models.text2semantic.inference",
               "--text", text, "--prompt-tokens", embedding_path, "--prompt-text", prompt_text,
               "--checkpoint-path", config_data["model_path"], "--num-samples", "1"]
        
        process = await asyncio.create_subprocess_exec(*cmd)
        await process.wait()
        
        cmd = [sys.executable, "-m", "fish_speech.models.vqgan.inference",
               "-i", "temp/codes_0.npy", "--checkpoint-path", 
               os.path.join(config_data["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth")]
        
        process = await asyncio.create_subprocess_exec(*cmd)
        await process.wait()
        
        audio_path = "fake.wav"
        if os.path.exists(audio_path):
            with open(audio_path, "rb") as f:
                audio_data = f.read()
            
            audio_base64 = base64.b64encode(audio_data).decode('utf-8')
            
            waveform, sample_rate = torchaudio.load(audio_path)
            audio_duration = waveform.shape[1] / sample_rate
            
            synthesis_time = time.time() - start_time
            
            metrics = {
                "synthesis_time": synthesis_time,
                "text_length": len(text),
                "audio_duration": audio_duration,
                "real_time_factor": audio_duration / synthesis_time,
                "voice_used": voice
            }
            
            return audio_base64, metrics
        else:
            raise FileNotFoundError("Generated audio file not found")
            
    except Exception as e:
        raise Exception(f"Synthesis error: {str(e)}")
    finally:
        os.chdir(str(project_root / "scripts"))

@app.websocket("/synthesize")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    try:
        while True:
            data = await websocket.receive_json()
            request = VoiceRequest(**data)
            
            try:
                audio_base64, metrics = await synthesize_with_voice(request.text, request.voz)
                
                response = VoiceResponse(
                    base64=f"data:audio/wav;base64,{audio_base64}",
                    metricas=metrics
                )
                
                await websocket.send_json(response.dict())
                
            except Exception as e:
                error_response = {
                    "error": str(e),
                    "type": type(e).__name__
                }
                await websocket.send_json(error_response)
                
    except WebSocketDisconnect:
        pass

if __name__ == "__main__":
    uvicorn_config = uvicorn.Config(
        app, 
        host="0.0.0.0", 
        port=8000,
        ws_max_size=16777216,
        ws_ping_interval=20,   
        ws_ping_timeout=20    
    )
    server = uvicorn.Server(uvicorn_config)
    server.run()
ENDOFFILE

# Crear script test_client.py
cat > test_client.py << 'ENDOFFILE'
#!/usr/bin/env python3
import websockets
import json
import base64
import wave
import io
import asyncio
import argparse

async def test_voice_synthesis(text, voice):
    uri = "ws://localhost:8000/synthesize"
    
    async with websockets.connect(uri, max_size=16777216) as websocket:
        message = {
            "text": text,
            "voz": voice
        }
        
        print("=== Enviando solicitud ===")
        print(json.dumps(message, indent=2))
        print()
        
        await websocket.send(json.dumps(message))
        
        response = await websocket.recv()
        result = json.loads(response)
        
        if "error" in result:
            print(f"Error: {result['error']}")
            return
        
        print("=== Respuesta JSON del servidor ===")
        print(f"Llaves presentes: {list(result.keys())}")
        print()
        
        display_result = result.copy()
        if "base64" in display_result:
            base64_length = len(display_result["base64"])
            display_result["base64"] = f"{display_result['base64'][:100]}... [total: {base64_length} caracteres]"
        
        print("JSON truncado:")
        print(json.dumps(display_result, indent=2))
        print()
        
        print("=== Métricas ===")
        if "metricas" in result:
            print(json.dumps(result["metricas"], indent=2))
        print()
        
        audio_data = result["base64"].split(",")[1]
        audio_bytes = base64.b64decode(audio_data)
        
        output_path = "../outputs/test_output.wav"
        with open(output_path, "wb") as f:
            f.write(audio_bytes)
        
        print(f"=== Audio guardado ===")
        print(f"Ruta: {output_path}")
        print(f"Tamaño: {len(audio_bytes)} bytes")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test WebSocket voice synthesis")
    parser.add_argument("--text", required=True, help="Text to synthesize")
    parser.add_argument("--voice", required=True, help="Voice to use")
    
    args = parser.parse_args()
    asyncio.run(test_voice_synthesis(args.text, args.voice))
ENDOFFILE

# Crear voice_client.html
cat > voice_client.html << 'ENDOFFILE'
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Síntesis de Voz en Tiempo Real</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 { color: #333; text-align: center; }
        .input-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        textarea, select, button { width: 100%; padding: 10px; margin-bottom: 10px; box-sizing: border-box; }
        textarea { height: 100px; resize: vertical; }
        button { background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .audio-player { margin-top: 20px; width: 100%; }
        .status { margin-top: 10px; padding: 10px; border-radius: 4px; text-align: center; }
        .metrics { margin-top: 20px; background-color: #f8f9fa; padding: 15px; border-radius: 4px; font-family: monospace; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Síntesis de Voz con Voz Clonada</h1>
        <div class="input-group">
            <label for="text">Texto a sintetizar:</label>
            <textarea id="text" placeholder="Ingresa el texto que quieres sintetizar...">Hola, esta es una prueba de síntesis de voz en español usando una voz clonada colombiana.</textarea>
        </div>
        <div class="input-group">
            <label for="voice">Seleccionar voz:</label>
            <select id="voice"><option value="">Cargando voces...</option></select>
        </div>
        <button onclick="synthesizeSpeech()">🎤 Sintetizar Voz</button>
        <div id="status" class="status">Inicializando...</div>
        <audio id="audioPlayer" class="audio-player" controls style="display: none;"></audio>
        <div id="metrics" class="metrics" style="display: none;"></div>
    </div>

    <script>
    let ws = null;
    let isConnected = false;
    
    function connectWebSocket() {
        ws = new WebSocket('ws://localhost:8000/synthesize');
        
        ws.onopen = function() {
            isConnected = true;
            document.getElementById('status').textContent = 'Conectado al servidor';
        };
        
        ws.onmessage = function(event) {
            const data = JSON.parse(event.data);
            if (data.error) {
                document.getElementById('status').textContent = 'Error: ' + data.error;
            } else {
                if (data.metricas) {
                    document.getElementById('metrics').textContent = JSON.stringify(data.metricas, null, 2);
                    document.getElementById('metrics').style.display = 'block';
                }
                if (data.base64) {
                    const audioPlayer = document.getElementById('audioPlayer');
                    audioPlayer.src = data.base64;
                    audioPlayer.style.display = 'block';
                    audioPlayer.play();
                    document.getElementById('status').textContent = 'Audio generado correctamente';
                }
            }
        };
    }
    
    async function loadAvailableVoices() {
        try {
            const response = await fetch('http://localhost:8000/voices');
            const data = await response.json();
            const voiceSelect = document.getElementById('voice');
            voiceSelect.innerHTML = '';
            
            data.voices.forEach(voice => {
                const option = document.createElement('option');
                option.value = voice.name;
                option.textContent = voice.display_name;
                voiceSelect.appendChild(option);
            });
        } catch (error) {
            document.getElementById('voice').innerHTML = '<option value="">Error al cargar voces</option>';
        }
    }
    
    function synthesizeSpeech() {
        const text = document.getElementById('text').value;
        const voice = document.getElementById('voice').value;
        
        if (!text.trim() || !voice) {
            document.getElementById('status').textContent = 'Por favor ingresa un texto y selecciona una voz';
            return;
        }
        
        document.getElementById('status').textContent = 'Procesando...';
        
        ws.send(JSON.stringify({
            "text": text,
            "voz": voice
        }));
    }
    
    window.onload = function() {
        connectWebSocket();
        loadAvailableVoices();
    }
    </script>
</body>
</html>
ENDOFFILE

# Hacer los scripts ejecutables
chmod +x voice_cloning.py voice_synthesis.py websocket_service.py test_client.py

# Crear requirements.txt
echo -e "${YELLOW}Creando requirements.txt...${NC}"
cat > requirements.txt << EOF
torch
torchaudio
fastapi
uvicorn
websockets
python-multipart
pydantic
aiofiles
numpy
librosa
huggingface-hub
gradio
matplotlib
scipy
EOF

# Crear README.md
echo -e "${YELLOW}Creando README.md...${NC}"
cat > README.md << 'ENDOFREADME'
# Sistema de Clonación y Síntesis de Voz

Sistema para clonar voces usando Fish Speech y sintetizar en tiempo real.

## Activación del entorno
```bash
source activate_env.sh
```

## Comandos básicos

### 1. Clonar una voz
```bash
cd scripts
python voice_cloning.py --sample ../samples/voice_sample.wav --name voz_colombiana --transcription-file ../samples/transcripcion.txt
```

### 2. Sintetizar con voz clonada
```bash
python voice_synthesis.py --text "Hola mundo" --voice voz_colombiana --output ../outputs/output.wav --auto-metadata
```

### 3. Ejecutar servidor WebSocket
```bash
python websocket_service.py
```

### 4. Usar cliente HTML
1. Ejecutar el servidor (pasos 3)
2. Abrir `scripts/voice_client.html` en el navegador
3. Seleccionar una voz y escribir texto
4. Click en "Sintetizar Voz"

### 5. Cliente de línea de comando
```bash
python test_client.py --text "Texto de prueba" --voice voz_colombiana
```

## Estructura del proyecto
```
voice-cloning-project/
├── embeddings/         # Embeddings de voces
├── samples/           # Audios originales
├── outputs/           # Audios sintetizados
├── scripts/           # Scripts Python
├── config/            # Configuración
└── venv/              # Entorno virtual
```

## Troubleshooting

### Error de GPU no detectada
```bash
source activate_env.sh
python -c "import torch; print(torch.cuda.is_available())"
```

### Reinstalar PyTorch para RTX 5000
```bash
source activate_env.sh
pip uninstall -y torch torchaudio
pip install --pre torch --index-url https://download.pytorch.org/whl/nightly/cu128
pip install --pre torchaudio --index-url https://download.pytorch.org/whl/nightly/cu128
```

### Drivers NVIDIA
Los drivers NVIDIA Open y CUDA se instalan automáticamente si no están presentes.
Si persisten problemas:
```bash
# Verificar drivers
nvidia-smi

# Reinstalar drivers si es necesario
sudo apt reinstall nvidia-driver-570-open
sudo reboot
```

### CUDA 12.8
```bash
# Verificar CUDA
nvcc --version

# Verificar detección en PyTorch
python -c "import torch; print(torch.cuda.is_available())"
```
ENDOFREADME

# Crear archivo .gitignore
echo -e "${YELLOW}Creando .gitignore...${NC}"
cat > .gitignore << EOF
venv/
__pycache__/
*.pyc
embeddings/*.npy
embeddings/*.json
outputs/*.wav
samples/*.wav
.env
temp/
*.log
fish-speech/temp/
fish-speech/fake.wav
fish-speech/*.npy
fish-speech/codes_0.npy
.DS_Store
.idea/
.vscode/
EOF

# Mensaje final
echo -e "\n${GREEN}=== Instalación completada exitosamente ===${NC}"
echo -e "\n${YELLOW}Próximos pasos:${NC}"
echo "1. Si se instalaron drivers, reinicia el sistema antes de continuar"
echo "2. Coloca un archivo de audio y su transcripción en samples/"
echo "3. Activa el entorno: source activate_env.sh"
echo "4. Clona una voz: cd scripts && python voice_cloning.py --sample ../samples/sample.wav --name mi_voz --transcription-file ../samples/transcripcion.txt"
echo "5. Sintetiza audio: python voice_synthesis.py --text \"Tu texto\" --voice mi_voz --output ../outputs/output.wav --auto-metadata"
echo "6. Ejecuta el servidor WebSocket: python websocket_service.py"
echo "7. Abre el cliente HTML: firefox voice_client.html"
echo -e "\n${GREEN}¡Sistema listo para usar!${NC}"

# Verificación final del sistema
echo -e "\n${YELLOW}Verificación del sistema:${NC}"
source venv/bin/activate
echo "Python version: $(python --version)"
python -c "import torch; print(f'PyTorch version: {torch.__version__}')"
python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')"
if python -c "import torch; print(torch.cuda.is_available())" | grep -q "True"; then
    python -c "import torch; print(f'GPU device: {torch.cuda.get_device_name(0)}')"
fi

# Crear script de prueba rápida
echo -e "\n${YELLOW}Creando script de prueba rápida...${NC}"
cat > quick_test.sh << 'EOF'
#!/bin/bash
echo "=== Prueba rápida del sistema ==="
echo "1. Activando entorno..."
source activate_env.sh

echo -e "\n2. Verificando PyTorch..."
python -c "import torch; print(f'CUDA disponible: {torch.cuda.is_available()}')"

echo -e "\n3. Verificando estructura de archivos..."
ls -la
cd scripts && ls -la && cd ..

echo -e "\n4. Para comenzar:"
echo "   source activate_env.sh"
echo "   cd scripts"
echo "   python websocket_service.py &"
echo "   firefox voice_client.html"
echo -e "\n¡Listo para clonar voces!"
EOF
chmod +x quick_test.sh

echo -e "\n${GREEN}=== Instalación finalizada ===${NC}"
echo -e "Ejecuta './quick_test.sh' para una prueba rápida del sistema"