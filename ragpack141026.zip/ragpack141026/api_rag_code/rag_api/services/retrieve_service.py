"""
Logica de negocio del RPC Retrieve.

Bifurca segun el perfil declarado explicitamente en el request:
  - PERFIL_RAPIDO: embedding con vLLM (0.6b), busqueda densa simple
    en la coleccion rapida.
  - PERFIL_PRECISO: embedding denso con Ollama (8b) + embedding
    disperso BM25 (fastembed, local) para hybrid search con fusion
    RRF en la coleccion precisa.

No conoce nada de gRPC (no maneja el objeto `context` del servidor ni
serializa/deserializa mensajes): recibe y devuelve los mensajes
generados por protoc directamente, y es la capa de servidor
(server.py) la que lo conecta al servicio gRPC real.
"""

import logging

from fastembed.sparse.bm25 import Bm25
from qdrant_client import models

from rag_api.clients.ollama_client import OllamaClient
from rag_api.clients.qdrant_client import QdrantWrapper
from rag_api.clients.vllm_client import VllmClient
from rag_api.config import settings
from rag_api.generated import rag_pb2

logger = logging.getLogger(__name__)

# Modelo BM25 disperso para el camino preciso. Corre localmente (CPU,
# sin red) tras descargar el archivo de stopwords del idioma la
# primera vez. Se instancia una sola vez a nivel de modulo -- cargarlo
# por request seria un costo innecesario.
_MODELO_BM25 = Bm25(model_name="Qdrant/bm25", language="spanish")


class RetrieveService:
    def __init__(
        self,
        qdrant: QdrantWrapper,
        vllm_client: VllmClient,
        ollama_client: OllamaClient,
    ) -> None:
        self._qdrant = qdrant
        self._vllm_client = vllm_client
        self._ollama_client = ollama_client

    @staticmethod
    def _validar_request(request: rag_pb2.RetrieveRequest) -> None:
        """
        El perfil es obligatorio: como PERFIL_RAPIDO vale 0 en el enum, sin
        HasField un cliente que olvide enviarlo consultaria silenciosamente
        la coleccion rapida.
        """
        if not request.HasField("perfil"):
            raise ValueError("RetrieveRequest.perfil es obligatorio (PERFIL_RAPIDO o PERFIL_PRECISO)")
        if request.perfil not in (rag_pb2.PERFIL_RAPIDO, rag_pb2.PERFIL_PRECISO):
            raise ValueError(f"Perfil de retrieval desconocido: {request.perfil}")
        if not request.query.strip():
            raise ValueError("RetrieveRequest.query no puede estar vacia")
        if not request.categoria_principal.strip():
            raise ValueError("RetrieveRequest.categoria_principal es obligatoria")
        if any(not categoria.strip() for categoria in request.categorias_adicionales):
            raise ValueError("RetrieveRequest.categorias_adicionales no puede contener valores vacios")
        if request.top_k < 1:
            raise ValueError("RetrieveRequest.top_k debe ser mayor o igual a 1")
        if request.HasField("ef_search") and request.ef_search < 1:
            raise ValueError("RetrieveRequest.ef_search debe ser mayor o igual a 1 cuando se envia")

    def retrieve(self, request: rag_pb2.RetrieveRequest) -> rag_pb2.RetrieveResponse:
        self._validar_request(request)
        categorias = [request.categoria_principal, *request.categorias_adicionales]

        if request.perfil == rag_pb2.PERFIL_RAPIDO:
            resultados = self._retrieve_rapido(request, categorias)
        elif request.perfil == rag_pb2.PERFIL_PRECISO:
            resultados = self._retrieve_preciso(request, categorias)
        else:
            raise ValueError(f"Perfil de retrieval desconocido: {request.perfil}")

        return rag_pb2.RetrieveResponse(
            resultados=resultados,
            categoria_usada=request.categoria_principal,
            perfil_usado=request.perfil,
        )

    def _retrieve_rapido(
        self,
        request: rag_pb2.RetrieveRequest,
        categorias: list[str],
    ) -> list[rag_pb2.Chunk]:
        vector_consulta = self._vllm_client.embed(request.query)
        ef_search = request.ef_search if request.HasField("ef_search") else settings.qdrant.ef_search_rapida_default

        puntos = self._qdrant.buscar_rapida(
            vector_consulta=vector_consulta,
            categorias=categorias,
            top_k=request.top_k,
            ef_search=ef_search,
        )

        return [self._punto_a_chunk(punto) for punto in puntos]

    def _retrieve_preciso(
        self,
        request: rag_pb2.RetrieveRequest,
        categorias: list[str],
    ) -> list[rag_pb2.Chunk]:
        vector_denso = self._ollama_client.embed(request.query)
        vector_disperso = self._vectorizar_disperso_consulta(request.query)
        ef_search = request.ef_search if request.HasField("ef_search") else settings.qdrant.ef_search_precisa_default

        puntos = self._qdrant.buscar_precisa(
            vector_denso=vector_denso,
            vector_disperso=vector_disperso,
            categorias=categorias,
            top_k=request.top_k,
            ef_search=ef_search,
        )

        return [self._punto_a_chunk(punto) for punto in puntos]

    @staticmethod
    def _vectorizar_disperso_consulta(query: str) -> models.SparseVector:
        """
        Vectoriza una consulta de busqueda con BM25 (query_embed, no
        embed): a diferencia de indexar un documento, una consulta no
        usa pesos diferenciados por termino -- cada token unico
        presente en la consulta vale 1.0. Este es el comportamiento
        esperado de BM25 y lo maneja fastembed internamente.
        """
        (embedding_disperso,) = _MODELO_BM25.query_embed(query)
        return models.SparseVector(
            indices=embedding_disperso.indices.tolist(),
            values=embedding_disperso.values.tolist(),
        )

    @staticmethod
    def _punto_a_chunk(punto: models.ScoredPoint) -> rag_pb2.Chunk:
        payload = punto.payload or {}
        chunk_kwargs = {
            "id": str(punto.id),
            "texto": payload.get("texto", ""),
            "fuente": payload.get("fuente", ""),
            "categoria": payload.get("categoria", ""),
            "score": punto.score,
        }
        if payload.get("texto_padre"):
            chunk_kwargs["texto_padre"] = payload["texto_padre"]

        return rag_pb2.Chunk(**chunk_kwargs)
