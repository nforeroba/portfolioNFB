#!/usr/bin/env python3
import fastapi
import uvicorn
import json
import base64
import time
import os
import sys
import subprocess
import asyncio
from pathlib import Path
from fastapi import WebSocket, WebSocketDisconnect
from fastapi import HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import torchaudio

# Agregar Fish Speech al path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root / "fish-speech"))

# Configurar para mensajes grandes
app = fastapi.FastAPI()

# Agregar CORS para permitir que HTML local acceda al servidor
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class VoiceRequest(BaseModel):
    text: str
    voz: str  # Cambiado de "voice" a "voz"

class VoiceResponse(BaseModel):
    base64: str
    metricas: dict  # Cambiado de "metrics" a "metricas"

# Cargar configuración global - RENOMBRADO a config_data para evitar conflicto
with open(project_root / "config" / "config.json", 'r') as f:
    config_data = json.load(f)

@app.get("/voices")
async def get_voices():
    """Endpoint para obtener lista de voces disponibles"""
    voices = []
    embeddings_dir = config_data["embeddings_dir"]
    
    if os.path.exists(embeddings_dir):
        for file in os.listdir(embeddings_dir):
            if file.endswith('.npy'):
                voice_name = file[:-4]  # Remover extensión .npy
                # Verificar si existe metadata
                metadata_path = os.path.join(embeddings_dir, f"{voice_name}_metadata.json")
                metadata = {}
                if os.path.exists(metadata_path):
                    try:
                        with open(metadata_path, 'r') as f:
                            metadata = json.load(f)
                    except:
                        pass
                
                voice_info = {
                    "name": voice_name,
                    "display_name": voice_name.replace('_', ' ').title(),
                    "created_at": metadata.get("created_at", "Desconocido"),
                    "prompt_text": metadata.get("prompt_text", "").split('.')[0] + "..." if metadata.get("prompt_text") else ""
                }
                voices.append(voice_info)
    
    return {"voices": voices}

def load_embedding_metadata(voice_name):
    """Load metadata for voice embedding if exists"""
    try:
        metadata_path = os.path.join(config_data["embeddings_dir"], f"{voice_name}_metadata.json")
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                full_text = metadata.get("prompt_text", None)
                # Devolver el texto completo tal como está en metadata
                return full_text
    except Exception as e:
        print(f"No se pudo cargar metadata: {e}")
    return None

async def synthesize_with_voice(text: str, voice: str):
    """Synthesize speech with voice embedding using Fish Speech"""
    start_time = time.time()
    
    # Cargar embedding
    embedding_path = os.path.join(config_data["embeddings_dir"], f"{voice}.npy")
    if not os.path.exists(embedding_path):
        raise FileNotFoundError(f"Voice embedding not found: {voice}")
    
    # Cargar texto de referencia automáticamente
    prompt_text = load_embedding_metadata(voice)
    if not prompt_text:
        prompt_text = "Audio de referencia en español"  # Fallback
    
    try:
        # Procesar texto a tokens semánticos
        text_processing_start = time.time()
        
        os.chdir(str(project_root / "fish-speech"))
        
        # Ejecutar text2semantic
        cmd = [
            sys.executable,
            "-m", "fish_speech.models.text2semantic.inference",
            "--text", text,
            "--prompt-tokens", embedding_path,
            "--prompt-text", prompt_text,
            "--checkpoint-path", config_data["model_path"],
            "--num-samples", "1"
        ]
        
        process = await asyncio.create_subprocess_exec(*cmd)
        await process.wait()
        
        text_processing_time = time.time() - text_processing_start
        
        # Generar audio desde tokens
        audio_generation_start = time.time()
        
        # Ejecutar VQGAN para síntesis
        cmd = [
            sys.executable,
            "-m", "fish_speech.models.vqgan.inference",
            "-i", "temp/codes_0.npy",
            "--checkpoint-path", os.path.join(config_data["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth")
        ]
        
        process = await asyncio.create_subprocess_exec(*cmd)
        await process.wait()
        
        audio_generation_time = time.time() - audio_generation_start
        
        # Leer el archivo de audio
        audio_path = "fake.wav"
        if os.path.exists(audio_path):
            with open(audio_path, "rb") as f:
                audio_data = f.read()
            
            # Convertir a base64
            audio_base64 = base64.b64encode(audio_data).decode('utf-8')
            
            # Obtener duración del audio
            waveform, sample_rate = torchaudio.load(audio_path)
            audio_duration = waveform.shape[1] / sample_rate
            
            synthesis_time = time.time() - start_time
            
            metrics = {
                "synthesis_time": synthesis_time,
                "text_length": len(text),
                "audio_duration": audio_duration,
                "real_time_factor": audio_duration / synthesis_time if synthesis_time > 0 else 0,
                "text_processing_time": text_processing_time,
                "audio_generation_time": audio_generation_time,
                "voice_used": voice
            }
            
            return audio_base64, metrics
        else:
            raise FileNotFoundError("Generated audio file not found")
            
    except Exception as e:
        raise Exception(f"Synthesis error: {str(e)}")
    finally:
        # Volver al directorio scripts
        os.chdir(str(project_root / "scripts"))

@app.websocket("/synthesize")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    
    try:
        while True:
            data = await websocket.receive_json()
            request = VoiceRequest(**data)
            
            try:
                audio_base64, metrics = await synthesize_with_voice(request.text, request.voz)
                
                response = VoiceResponse(
                    base64=f"data:audio/wav;base64,{audio_base64}",
                    metricas=metrics
                )
                
                await websocket.send_json(response.dict())
                
            except Exception as e:
                error_response = {
                    "error": str(e),
                    "type": type(e).__name__
                }
                await websocket.send_json(error_response)
                
    except WebSocketDisconnect:
        pass

if __name__ == "__main__":
    # Configurar para mensajes grandes
    uvicorn_config = uvicorn.Config(
        app, 
        host="0.0.0.0", 
        port=8000,
        ws_max_size=16777216,  # 16MB límite para mensajes WebSocket
        ws_ping_interval=20,   
        ws_ping_timeout=20    
    )
    server = uvicorn.Server(uvicorn_config)
    server.run()
