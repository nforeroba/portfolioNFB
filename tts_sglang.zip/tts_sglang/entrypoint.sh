#!/bin/bash
set -e

PORT="${PORT:-50051}"
SGLANG_OMNI_PORT="${SGLANG_OMNI_PORT:-8000}"
SGLANG_OMNI_MODEL="${SGLANG_OMNI_MODEL:-/app/checkpoints/s2-pro}"
SGLANG_OMNI_CONFIG="${SGLANG_OMNI_CONFIG:-/app/configs/s2pro_tts.yaml}"

echo "[entrypoint] ════════════════════════════════════════════════"
echo "[entrypoint]  Fish Audio S2-Pro TTS gRPC Service (SGLang-Omni)"
echo "[entrypoint] ════════════════════════════════════════════════"

if [ -n "$CUDA_VISIBLE_DEVICES" ]; then
    echo "[entrypoint] GPU device(s) visibles: $CUDA_VISIBLE_DEVICES"
else
    echo "[entrypoint] CUDA_VISIBLE_DEVICES no definido — usando todas las GPU visibles"
fi
echo "[entrypoint] ⚠️  Recordatorio: NUNCA combinar --gpus device=N con"
echo "[entrypoint]     CUDA_VISIBLE_DEVICES=N a la vez (causa fallback"
echo "[entrypoint]     silencioso a CPU — ver incidente documentado en"
echo "[entrypoint]     tts_s2_pro/README_s2_pro.md, sección 6.2)"

# Diagnóstico de GPU antes de arrancar — usa el propio comando de sgl-omni
# para confirmar visibilidad de GPU con el mismo detalle que usa el motor.
echo "[entrypoint] Ejecutando diagnóstico de GPU (sgl-omni check-gpu)..."
/opt/venv-omni/bin/sgl-omni check-gpu || echo "[entrypoint] ⚠️ check-gpu falló — revisar antes de continuar"

# ── Arrancar sgl-omni serve en background ──────────────────────────────────
echo "[entrypoint] Iniciando sgl-omni serve en puerto interno ${SGLANG_OMNI_PORT}..."
echo "[entrypoint] Modelo: ${SGLANG_OMNI_MODEL} (checkpoint local, horneado en la imagen — sin acceso a internet requerido)"
echo "[entrypoint] Config: ${SGLANG_OMNI_CONFIG}"
echo "[entrypoint] HF_HUB_OFFLINE=${HF_HUB_OFFLINE:-no definido} — modo offline forzado"
echo "[entrypoint] NOTA: sin restricciones de mem_fraction_static — H200 no las necesita."

/opt/venv-omni/bin/sgl-omni serve \
    --model-path "${SGLANG_OMNI_MODEL}" \
    --config "${SGLANG_OMNI_CONFIG}" \
    --port "${SGLANG_OMNI_PORT}" \
    > /tmp/sglang_omni.log 2>&1 &

SGLANG_OMNI_PID=$!
echo "[entrypoint] sgl-omni serve arrancado con PID ${SGLANG_OMNI_PID}"
echo "[entrypoint] Log completo en /tmp/sglang_omni.log (docker exec + tail para ver en vivo)"

# ── Manejo de señales: propagar SIGTERM/SIGINT a ambos procesos ────────────
cleanup() {
    echo "[entrypoint] Señal de cierre recibida — deteniendo sgl-omni serve (PID ${SGLANG_OMNI_PID})..."
    kill -TERM "$SGLANG_OMNI_PID" 2>/dev/null || true
    wait "$SGLANG_OMNI_PID" 2>/dev/null || true
    echo "[entrypoint] sgl-omni serve detenido"
    exit 0
}
trap cleanup SIGTERM SIGINT

# ── Verificar que sgl-omni serve sigue vivo antes de lanzar el wrapper ────
# (el wrapper gRPC también espera activamente por /health en su propio
# main() — este chequeo aquí es solo para fallar rápido y con claridad si
# el proceso muere inmediatamente, en vez de esperar el timeout completo
# del wrapper para descubrirlo)
sleep 5
if ! kill -0 "$SGLANG_OMNI_PID" 2>/dev/null; then
    echo "[entrypoint] ❌ sgl-omni serve murió inmediatamente tras arrancar."
    echo "[entrypoint] ❌ Últimas líneas de su log:"
    tail -50 /tmp/sglang_omni.log
    exit 1
fi

# ── Arrancar el wrapper gRPC en foreground (PID 1 efectivo del contenedor) ──
echo "[entrypoint] Iniciando wrapper gRPC en puerto ${PORT}..."
export PYTHONPATH="/app"

/opt/venv-omni/bin/python /app/server.py \
    --port "${PORT}" \
    --config /app/config_tts.json &

SERVER_PID=$!

# Esperar a que cualquiera de los dos procesos termine (normal o por error)
wait -n "$SGLANG_OMNI_PID" "$SERVER_PID"
EXIT_CODE=$?

echo "[entrypoint] Uno de los procesos terminó (exit code $EXIT_CODE) — deteniendo el otro..."
kill -TERM "$SGLANG_OMNI_PID" "$SERVER_PID" 2>/dev/null || true
wait 2>/dev/null || true

exit $EXIT_CODE
