#!/bin/bash
source venv/bin/activate
cd fish-speech
export GRADIO_SERVER_NAME="0.0.0.0"
export PYTHONPATH="$PYTHONPATH:/home/nfb/Documents/ubuntu_tts/voice-cloning-project"
cd ..
