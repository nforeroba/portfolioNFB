#!/usr/bin/env python3
import torch
import torchaudio
import argparse
import os
import json
import sys
import subprocess
from pathlib import Path
from datetime import datetime

# Usar subprocess en lugar de importar directamente
project_root = Path(__file__).parent.parent

def save_embedding_metadata(voice_name, prompt_text, config_path):
    """Save metadata (prompt text) for a voice embedding"""
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    # Crear archivo de metadata
    metadata_path = os.path.join(config["embeddings_dir"], f"{voice_name}_metadata.json")
    
    metadata = {
        "name": voice_name,
        "prompt_text": prompt_text,
        "created_at": str(datetime.now()),
        "audio_sample": None
    }
    
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    print(f"Metadata guardado en: {metadata_path}")

def clone_voice(sample_path, output_name, config_path, transcription=None, transcription_file=None):
    """Clone a voice from audio sample using Fish Speech"""
    # Cargar configuración
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    print(f"Clonando voz desde: {sample_path}")
    
    # Verificar que el archivo existe
    if not os.path.exists(sample_path):
        raise FileNotFoundError(f"Archivo de muestra no encontrado: {sample_path}")
    
    # Procesar texto de referencia (leer archivo si está disponible)
    if transcription_file and os.path.exists(transcription_file):
        print(f"Leyendo transcripción desde archivo: {transcription_file}")
        with open(transcription_file, 'r', encoding='utf-8') as f:
            transcription = f.read().strip()
            print(f"Texto de transcripción completo: {transcription}")
    
    # Ejecutar inferencia VQGAN para clonar la voz
    checkpoint_path = os.path.join(
        config["model_path"], 
        "firefly-gan-vq-fsq-8x1024-21hz-generator.pth"
    )
    
    try:
        # Cambiar al directorio de Fish Speech
        os.chdir(str(project_root / "fish-speech"))
        
        # Ejecutar inferencia VQGAN
        cmd = [
            sys.executable,
            "-m", "fish_speech.models.vqgan.inference",
            "-i", sample_path,
            "--checkpoint-path", checkpoint_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        # Volver al directorio original
        os.chdir(str(project_root / "scripts"))
        
        # El archivo generado estará en el directorio de Fish Speech
        output_path = str(project_root / "fish-speech" / "fake.npy")
        
        if os.path.exists(output_path):
            # Mover el embedding a la carpeta de embeddings
            embedding_path = os.path.join(config["embeddings_dir"], f"{output_name}.npy")
            os.rename(output_path, embedding_path)
            print(f"Embedding guardado en: {embedding_path}")
            
            # Si hay transcripción, guardar metadata
            if transcription:
                save_embedding_metadata(output_name, transcription, config_path)
                print(f"\n✅ Se ha creado un perfil completo de voz con transcripción")
                print(f"✅ Texto de referencia guardado para modo few-shot")
            else:
                print("\n⚠️ No se proporcionó transcripción. El modo few-shot requerirá --prompt-text manualmente")
            
            return True
        else:
            print(f"Error: No se generó el archivo {output_path}")
            print(f"STDOUT: {result.stdout}")
            print(f"STDERR: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"Error en clonación de voz: {e}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Clone voice from audio sample using Fish Speech")
    parser.add_argument("--sample", required=True, help="Path to audio sample")
    parser.add_argument("--name", required=True, help="Name for the voice embedding")
    parser.add_argument("--config", default="../config/config.json", help="Config file path")
    parser.add_argument("--transcription", help="Transcription text (for few-shot mode)")
    parser.add_argument("--transcription-file", help="Path to transcription file (plain text)")
    
    args = parser.parse_args()
    
    # Verificar que no se usen ambas opciones al mismo tiempo
    if args.transcription and args.transcription_file:
        print("Error: Solo puedes usar --transcription O --transcription-file, no ambos")
        exit(1)
    
    success = clone_voice(args.sample, args.name, args.config, args.transcription, args.transcription_file)
    if success:
        print(f"\n✅ Voice cloned successfully: {args.name}")
        if args.transcription or args.transcription_file:
            print("✅ Metadata guardado. Puedes usar modo few-shot con --auto-metadata")
        else:
            print("⚠️ Sin transcripción. Para usar few-shot necesitarás --prompt-text")
    else:
        print("❌ Failed to clone voice")
