"""Detección de voz (Silero VAD o TEN VAD) y partición de la voz neta en tramos.

Los dos detectores exponen la misma interfaz:
  segmentos(senal) -> [(inicio, fin), ...] en muestras a 16 kHz
  voz_neta(senal)  -> (voz sin silencios, segmentos)

Se configuran con los mismos parámetros (umbral, silencio y voz mínimos, relleno)
para que la voz neta de uno y otro sea comparable.
"""

import numpy as np

from .config import (
    SEGUNDOS_MIN_REFERENCIA, SEGUNDOS_MIN_TRAMO, SEGUNDOS_TRAMO, SR, VAD_RELLENO_S,
    VAD_SILENCIO_MIN_S, VAD_UMBRAL, VAD_VOZ_MIN_S, VADS,
)


class _Detector:
    nombre = ""

    @property
    def descripcion(self):
        return VADS[self.nombre]

    def segmentos(self, senal):
        raise NotImplementedError

    def voz_neta(self, senal):
        """La señal con los silencios removidos."""
        segmentos = self.segmentos(senal)
        if not segmentos:
            return np.zeros(0, dtype=np.float32), segmentos
        return np.concatenate([senal[a:b] for a, b in segmentos]).astype(np.float32), segmentos


class DetectorSilero(_Detector):
    """Silero VAD (PyTorch, viene dentro del paquete silero-vad). Guarda estado: un uso a la vez."""

    nombre = "silero"
    modelo_descripcion = "Silero VAD (paquete silero-vad, PyTorch)"

    def __init__(self):
        from silero_vad import load_silero_vad

        self.modelo = load_silero_vad(onnx=False)

    def segmentos(self, senal):
        import torch
        from silero_vad import get_speech_timestamps

        marcas = get_speech_timestamps(
            torch.from_numpy(np.ascontiguousarray(senal, dtype=np.float32)), self.modelo, sampling_rate=SR,
            threshold=VAD_UMBRAL, min_speech_duration_ms=int(VAD_VOZ_MIN_S * 1000),
            min_silence_duration_ms=int(VAD_SILENCIO_MIN_S * 1000), speech_pad_ms=int(VAD_RELLENO_S * 1000),
        )
        return [(m["start"], m["end"]) for m in marcas]


class DetectorTen(_Detector):
    """
    TEN VAD con su modelo ONNX oficial, ejecutado con sherpa-onnx (funciona igual en
    x86_64 y arm64; el paquete ten-vad de PyPI solo trae la librería de x86_64).
    Se crea un detector por llamada: no comparte estado entre peticiones.
    """

    nombre = "ten"
    modelo_descripcion = "TEN VAD (modelo ONNX, ejecutado con sherpa-onnx)"
    VENTANA = 256           # 16 ms a 16 kHz, el tamaño de salto recomendado por TEN

    def __init__(self, ruta_modelo):
        import sherpa_onnx

        self._sherpa = sherpa_onnx
        self.ruta_modelo = str(ruta_modelo)
        self._config = self._crear_config()
        # Prueba de carga al arrancar: si el modelo no sirve, falla aquí y no en la primera validación.
        self._sherpa.VoiceActivityDetector(self._config, buffer_size_in_seconds=5)

    def _crear_config(self):
        config = self._sherpa.VadModelConfig()
        config.ten_vad.model = self.ruta_modelo
        config.ten_vad.threshold = VAD_UMBRAL
        config.ten_vad.min_silence_duration = VAD_SILENCIO_MIN_S
        config.ten_vad.min_speech_duration = VAD_VOZ_MIN_S
        config.ten_vad.max_speech_duration = 30.0
        config.ten_vad.window_size = self.VENTANA
        config.sample_rate = SR
        config.num_threads = 1
        config.provider = "cpu"
        return config

    def segmentos(self, senal):
        senal = np.ascontiguousarray(senal, dtype=np.float32)
        detector = self._sherpa.VoiceActivityDetector(self._config, buffer_size_in_seconds=60)
        crudos = []

        def recoger():
            while not detector.empty():
                crudos.append((int(detector.front.start), len(detector.front.samples)))
                detector.pop()

        for i in range(0, len(senal), self.VENTANA):
            bloque = senal[i:i + self.VENTANA]
            if len(bloque) < self.VENTANA:
                bloque = np.pad(bloque, (0, self.VENTANA - len(bloque)))
            detector.accept_waveform(bloque)
            recoger()
        detector.flush()
        recoger()
        return _rellenar_y_unir(crudos, len(senal))


def _rellenar_y_unir(crudos, largo, relleno_s=VAD_RELLENO_S):
    """Agrega el relleno a cada lado (como Silero) y une los segmentos que se tocan."""
    relleno = int(relleno_s * SR)
    segmentos = []
    for inicio, n in sorted(crudos):
        a, b = max(0, inicio - relleno), min(largo, inicio + n + relleno)
        if b <= a:
            continue
        if segmentos and a <= segmentos[-1][1]:
            segmentos[-1] = (segmentos[-1][0], max(segmentos[-1][1], b))
        else:
            segmentos.append((a, b))
    return segmentos


def crear_detector(nombre, rutas_modelos=None):
    """Detector del VAD pedido ("silero" o "ten")."""
    if nombre == "silero":
        return DetectorSilero()
    if nombre == "ten":
        if rutas_modelos is None:
            raise ValueError("TEN VAD necesita la ruta de su modelo ONNX.")
        return DetectorTen(rutas_modelos["ten_vad"])
    raise ValueError(f"VAD desconocido: {nombre}")


def partir_en_tramos(voz, segundos_tramo=SEGUNDOS_TRAMO, segundos_min=SEGUNDOS_MIN_TRAMO):
    """
    Parte la voz neta en tramos de `segundos_tramo`. Un sobrante de al menos
    `segundos_min` queda como tramo propio; uno menor se une al tramo anterior.
    Una voz corta (entre SEGUNDOS_MIN_REFERENCIA y `segundos_min`) es un único tramo.
    """
    largo = int(segundos_tramo * SR)
    minimo = int(segundos_min * SR)
    if len(voz) < minimo:
        return [voz] if len(voz) >= int(SEGUNDOS_MIN_REFERENCIA * SR) else []
    completos = len(voz) // largo
    tramos = [voz[i * largo:(i + 1) * largo] for i in range(completos)]
    sobrante = voz[completos * largo:]
    if len(sobrante) >= minimo or not tramos:
        tramos.append(sobrante)
    elif len(sobrante):
        tramos[-1] = np.concatenate([tramos[-1], sobrante])
    return tramos
