"""Experimento "Umbral": cuánta voz neta hace falta para identificar a alguien con confianza.

Flujo (peticiones HTTP normales, sin WebSocket):
  1. abrir(tasa)                 -> sesión nueva; se fijan las plantillas del pool en ese momento.
  2. agregar(id, pcm, procesar)  -> la página envía cada ~250 ms el audio nuevo (PCM 16 bits, mono,
                                    a la frecuencia del navegador). Con procesar=True se evalúa TODO
                                    lo recibido: VAD -> voz neta -> huella -> 1:N -> decisión, y se
                                    devuelve un punto de la curva.
  3. finalizar(id)               -> barrido preciso alrededor de los dos cruces, resultado y
                                    una línea en registros/umbral.jsonl (sin audio ni huellas).

Dos cifras:
  - Primer cruce: los primeros ms de voz neta en que la decisión es "identificado".
  - Cruce estable: desde qué ms la decisión es "identificado" con la misma persona hasta el
    final. Se confirma si después de ese punto hay al menos CONFIRMACION_MS de voz neta.

No se elige de antemano quién habla: la persona del resultado es la que el sistema
identificó al final de la sesión.
"""

import json
import statistics
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone
from math import gcd

import numpy as np

from huella_vocal.config import MARGEN_MINIMO, SR, UMBRAL_ALTO, UMBRAL_BAJO, VAD_VOZ_MIN_S

MAX_SEGUNDOS_AUDIO = 30.0         # tope de audio por sesión
INTERVALO_ENVIO_S = 0.25          # la página envía audio con esta frecuencia
# Voz neta mínima para calcular una huella: la misma duración mínima de un segmento de
# voz en el VAD (250 ms). Con menos, el VAD no entrega voz que analizar.
VOZ_MIN_MS = int(round(VAD_VOZ_MIN_S * 1000))
VOZ_MIN_MS_ANTERIOR = 500         # mínimo de la 0.8.0: las sesiones guardadas sin el dato lo usaron
PASO_GRUESO_MS = 250
PASO_FINO_MS = 50
CONFIRMACION_MS = 2000            # voz neta posterior al cruce estable para darlo por confirmado
VENCIMIENTO_S = 120               # una sesión sin actividad se descarta
MAX_SESIONES = 4
MAX_BYTES_ENVIO = 4 * 1024 * 1024


def _ahora_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _percentil(ordenados, p):
    """Percentil p (0 a 1) con interpolación lineal sobre una lista ya ordenada."""
    k = (len(ordenados) - 1) * p
    i = int(k)
    j = min(i + 1, len(ordenados) - 1)
    return ordenados[i] + (ordenados[j] - ordenados[i]) * (k - i)


class ErrorUmbral(ValueError):
    """Error de uso del experimento (sesión inexistente, pool vacío...)."""


class _Sesion:
    def __init__(self, tasa, ids, nombres, matriz):
        self.id = uuid.uuid4().hex
        self.tasa = tasa
        self.ids = ids
        self.nombres = nombres
        self.matriz = matriz                       # plantillas normalizadas, una por fila
        self.bloques = []
        self.muestras = 0
        self.completa = False
        self.puntos = []
        self.creada = time.monotonic()
        self.ultima = self.creada
        self.lock = threading.Lock()

    @property
    def max_muestras(self):
        return int(MAX_SEGUNDOS_AUDIO * self.tasa)

    def audio_16k(self):
        from scipy.signal import resample_poly

        if not self.bloques:
            return np.zeros(0, dtype=np.float32)
        senal = np.concatenate(self.bloques).astype(np.float32) / 32768.0
        if self.tasa != SR:
            divisor = gcd(self.tasa, SR)
            senal = resample_poly(senal, SR // divisor, self.tasa // divisor)
        return np.ascontiguousarray(senal, dtype=np.float32)


class SesionesUmbral:
    def __init__(self, motor, archivo_historial):
        self.motor = motor
        self.archivo = archivo_historial
        self._sesiones = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Sesiones
    # ------------------------------------------------------------------

    def _purgar(self):
        limite = time.monotonic() - VENCIMIENTO_S
        with self._lock:
            for clave in [k for k, s in self._sesiones.items() if s.ultima < limite]:
                self._sesiones.pop(clave, None)

    def _sesion(self, id_sesion):
        self._purgar()
        with self._lock:
            sesion = self._sesiones.get(id_sesion)
        if sesion is None:
            raise ErrorUmbral("La sesión no existe o venció por inactividad. Empiece de nuevo.")
        sesion.ultima = time.monotonic()
        return sesion

    def abrir(self, tasa):
        from huella_vocal.huella import normalizar

        try:
            tasa = int(tasa)
        except (TypeError, ValueError):
            raise ErrorUmbral("Frecuencia de muestreo inválida.") from None
        if not 8000 <= tasa <= 192000:
            raise ErrorUmbral("Frecuencia de muestreo fuera de rango.")
        if self.motor.estado_sync.get("en_curso"):
            raise ErrorUmbral("Hay una sincronización del pool en curso. Espere a que termine.")
        self._purgar()
        with self._lock:
            if len(self._sesiones) >= MAX_SESIONES:
                raise ErrorUmbral("Hay demasiadas sesiones de umbral abiertas. Intente en un momento.")
        plantillas = self.motor.almacen.plantillas()
        if not plantillas:
            raise ErrorUmbral("No hay personas registradas en el pool.")
        ids = [p.payload["persona_id"] for p in plantillas]
        nombres = {p.payload["persona_id"]: p.payload["nombre"] for p in plantillas}
        matriz = normalizar(np.array([p.vector for p in plantillas], dtype=np.float32))
        sesion = _Sesion(tasa, ids, nombres, matriz)
        with self._lock:
            self._sesiones[sesion.id] = sesion
        return {
            "id": sesion.id,
            "vad": self.motor.vad,
            "vad_nombre": self.motor.detector.descripcion,
            "personas": len(ids),
            "max_segundos": MAX_SEGUNDOS_AUDIO,
            "intervalo_s": INTERVALO_ENVIO_S,
            "voz_min_ms": VOZ_MIN_MS,
            "confirmacion_ms": CONFIRMACION_MS,
            "umbrales": self._umbrales(),
        }

    def cancelar(self, id_sesion):
        with self._lock:
            self._sesiones.pop(id_sesion, None)
        return {"detalle": "Sesión descartada."}

    @staticmethod
    def _umbrales():
        return {"alto": UMBRAL_ALTO, "bajo": UMBRAL_BAJO, "margen_minimo": MARGEN_MINIMO}

    # ------------------------------------------------------------------
    # Evaluación
    # ------------------------------------------------------------------

    def _evaluar_voz(self, sesion, voz):
        """Decisión sobre un trozo de voz neta. Debe llamarse con el candado de inferencia tomado."""
        from huella_vocal.decision import decidir

        voz_ms = int(round(len(voz) * 1000 / SR))
        if voz_ms < VOZ_MIN_MS:
            return {"voz_ms": voz_ms, "estado": "insuficiente", "persona_id": None, "nombre": None,
                    "score": None, "margen": None, "candidatos": []}
        huella = self.motor.extractor.extraer(voz)
        scores = sesion.matriz @ huella
        orden = np.argsort(-scores)[:3]
        candidatos = [(float(scores[i]), {"persona_id": sesion.ids[i], "nombre": sesion.nombres[sesion.ids[i]]})
                      for i in orden]
        decision = decidir(candidatos)
        persona = decision["persona"]
        return {
            "voz_ms": voz_ms,
            "estado": decision["resultado"],
            "persona_id": persona["persona_id"] if persona else None,
            "nombre": persona["nombre"] if persona else None,
            "score": decision.get("score"),
            "margen": decision.get("margen"),
            "candidatos": [{"persona_id": p["persona_id"], "nombre": p["nombre"], "score": round(s, 4)}
                           for s, p in candidatos],
        }

    def agregar(self, id_sesion, contenido, procesar=True):
        sesion = self._sesion(id_sesion)
        if len(contenido) > MAX_BYTES_ENVIO:
            raise ErrorUmbral("El envío es demasiado grande.")
        if len(contenido) % 2:
            raise ErrorUmbral("El audio debe ser PCM de 16 bits.")
        with sesion.lock:
            if contenido and not sesion.completa:
                muestras = np.frombuffer(contenido, dtype="<i2")
                restante = sesion.max_muestras - sesion.muestras
                if len(muestras) >= restante:
                    muestras = muestras[:restante]
                    sesion.completa = True
                sesion.bloques.append(muestras.copy())
                sesion.muestras += len(muestras)
            audio_ms = int(round(sesion.muestras * 1000 / sesion.tasa))
            if not procesar:
                return {"audio_ms": audio_ms, "completa": sesion.completa}
            inicio = time.perf_counter()
            senal = sesion.audio_16k()
            with self.motor._inferencia:
                voz, _ = self.motor.detector.voz_neta(senal)
                punto = self._evaluar_voz(sesion, voz)
            punto["audio_ms"] = audio_ms
            punto["proceso_ms"] = int(round((time.perf_counter() - inicio) * 1000))
            sesion.puntos.append(punto)
            return {**punto, "completa": sesion.completa}

    # ------------------------------------------------------------------
    # Barrido preciso y resultado
    # ------------------------------------------------------------------

    def finalizar(self, id_sesion):
        sesion = self._sesion(id_sesion)
        with sesion.lock:
            with self._lock:
                self._sesiones.pop(id_sesion, None)
            inicio = time.perf_counter()
            senal = sesion.audio_16k()
            audio_ms = int(round(sesion.muestras * 1000 / sesion.tasa))
            with self.motor._inferencia:
                voz, _ = self.motor.detector.voz_neta(senal)
                resultado = self._barrido(sesion, voz)
            resultado.update({
                "sesion_id": sesion.id,
                "fecha_utc": _ahora_iso(),
                "vad": self.motor.vad,
                "vad_nombre": self.motor.detector.descripcion,
                "umbrales": self._umbrales(),
                "audio_total_ms": audio_ms,
                "voz_min_ms": VOZ_MIN_MS,
                "personas_pool": len(sesion.ids),
                "duracion_barrido_s": round(time.perf_counter() - inicio, 2),
                "puntos": [{k: p.get(k) for k in ("voz_ms", "audio_ms", "estado", "persona_id", "nombre",
                                                    "score", "margen", "candidatos")} for p in sesion.puntos],
            })
        self._anotar(resultado)
        return resultado

    def _barrido(self, sesion, voz):
        total_ms = int(len(voz) * 1000 / SR)
        cache = {}

        def ev(ms):
            ms = int(max(0, min(ms, total_ms)))
            if ms not in cache:
                cache[ms] = self._evaluar_voz(sesion, voz[: int(ms * SR / 1000)])
            return cache[ms]

        base = {"voz_total_ms": total_ms, "primer_cruce_ms": None, "primer_cruce_persona_id": None,
                "primer_cruce_nombre": None, "cruce_estable_ms": None, "persona_id": None, "nombre": None,
                "score_final": None, "margen_final": None, "primer_cruce_en_minimo": False,
                "cruce_estable_en_minimo": False}
        if total_ms < VOZ_MIN_MS:
            return {**base, "estado": "sin_identificar", "evaluaciones": 0, "refinamiento": [],
                    "motivo": f"Hubo menos de {VOZ_MIN_MS} ms de voz neta."}

        final = ev(total_ms)
        persona_final = final["persona_id"] if final["estado"] == "identificado" else None
        vivos = [p for p in sesion.puntos if p["voz_ms"] >= VOZ_MIN_MS]

        # --- Primer cruce -------------------------------------------------
        def identificado(ms):
            return ev(ms)["estado"] == "identificado"

        i = next((k for k, p in enumerate(vivos) if p["estado"] == "identificado"), None)
        primer = None
        if i is not None:
            a = vivos[i - 1]["voz_ms"] if i > 0 else VOZ_MIN_MS
            primer = self._refinar_primero(identificado, a, vivos[i]["voz_ms"], total_ms)
        elif persona_final:
            a = vivos[-1]["voz_ms"] if vivos else VOZ_MIN_MS
            primer = self._refinar_primero(identificado, a, total_ms, total_ms)

        # --- Cruce estable --------------------------------------------------
        estable = None
        if persona_final:
            def con_final(ms):
                r = ev(ms)
                return r["estado"] == "identificado" and r["persona_id"] == persona_final

            fallos = [k for k, p in enumerate(vivos)
                      if not (p["estado"] == "identificado" and p["persona_id"] == persona_final)]
            if not fallos:                       # identificada desde el primer punto en vivo
                a, b = VOZ_MIN_MS, (vivos[0]["voz_ms"] if vivos else total_ms)
            else:
                j = fallos[-1]
                a = vivos[j]["voz_ms"]
                b = vivos[j + 1]["voz_ms"] if j + 1 < len(vivos) else total_ms
            estable = self._refinar_estable(con_final, a, b, total_ms)
            if estable is not None and (primer is None or estable < primer):
                primer = estable                 # si a esa voz ya está identificada, el primer cruce no es posterior

        if persona_final is None:
            estado = "sin_identificar"
        elif estable is not None and total_ms - estable >= CONFIRMACION_MS:
            estado = "confirmado"
        else:
            estado = "sin_confirmar"

        r_primer = ev(primer) if primer is not None else None
        return {
            **base,
            "estado": estado,
            "persona_id": persona_final,
            "nombre": final["nombre"] if persona_final else None,
            "score_final": final["score"],
            "margen_final": final["margen"],
            "primer_cruce_ms": primer,
            "primer_cruce_persona_id": r_primer["persona_id"] if r_primer else None,
            "primer_cruce_nombre": r_primer["nombre"] if r_primer else None,
            "cruce_estable_ms": estable,
            # Con menos de VOZ_MIN_MS no se puede calcular una huella: un cruce en ese punto
            # significa "con el mínimo medible ya alcanzaba" (el valor real puede ser menor).
            "primer_cruce_en_minimo": primer == VOZ_MIN_MS,
            "cruce_estable_en_minimo": estable == VOZ_MIN_MS,
            "evaluaciones": len(cache),
            "refinamiento": [{k: cache[ms][k] for k in ("voz_ms", "estado", "persona_id", "score", "margen")}
                             for ms in sorted(cache)],
        }

    @staticmethod
    def _refinar_primero(cumple, a, b, total_ms):
        """Primer ms (paso fino) en que se cumple la condición, buscando entre a (no cumple) y b (cumple)."""
        b = int(min(max(b, VOZ_MIN_MS), total_ms))
        a = int(max(VOZ_MIN_MS, min(a, b)))
        while not cumple(b):                     # en la voz final el cruce puede quedar un poco después
            if b >= total_ms:
                return None
            a, b = b, min(total_ms, b + PASO_GRUESO_MS)
        while a < b and cumple(a):               # ... o un poco antes
            if a <= VOZ_MIN_MS:
                return VOZ_MIN_MS
            b, a = a, max(VOZ_MIN_MS, a - PASO_GRUESO_MS)
        ms = (a // PASO_FINO_MS + 1) * PASO_FINO_MS        # rejilla común: múltiplos de PASO_FINO_MS
        while ms < b:
            if cumple(ms):
                return ms
            ms += PASO_FINO_MS
        return b

    @staticmethod
    def _refinar_estable(cumple, a, b, total_ms):
        """
        Menor ms desde el cual la condición se cumple sin interrupción hasta b (y, según la
        vista en vivo, hasta el final). a es el último punto en vivo que no la cumplía.
        """
        b = int(min(max(b, VOZ_MIN_MS), total_ms))
        a = int(max(VOZ_MIN_MS, min(a, b)))
        while not cumple(b):
            if b >= total_ms:
                return None
            a, b = b, min(total_ms, b + PASO_GRUESO_MS)
        estable = b
        piso = max(VOZ_MIN_MS, a - 2 * PASO_GRUESO_MS)
        ms = ((b - 1) // PASO_FINO_MS) * PASO_FINO_MS        # rejilla común: múltiplos de PASO_FINO_MS
        while ms >= piso:
            if not cumple(ms):
                break
            estable = ms
            ms -= PASO_FINO_MS
        return estable

    # ------------------------------------------------------------------
    # Historial
    # ------------------------------------------------------------------

    def _anotar(self, resultado):
        linea = {k: resultado.get(k) for k in (
            "fecha_utc", "sesion_id", "vad", "umbrales", "estado", "persona_id", "nombre", "score_final",
            "margen_final", "primer_cruce_ms", "primer_cruce_persona_id", "cruce_estable_ms",
            "primer_cruce_en_minimo", "cruce_estable_en_minimo", "voz_min_ms", "voz_total_ms",
            "audio_total_ms", "personas_pool", "evaluaciones", "duracion_barrido_s")}
        linea["curva"] = [[p["voz_ms"], p["estado"], p["persona_id"], p["score"], p["margen"]]
                          for p in resultado.get("puntos", [])]
        with open(self.archivo, "a", encoding="utf-8") as f:
            f.write(json.dumps(linea, ensure_ascii=False) + "\n")

    def _leer(self, ultimas=2000):
        if not self.archivo.exists():
            return []
        with open(self.archivo, encoding="utf-8") as f:
            lineas = deque(f, maxlen=ultimas)
        registros = []
        for linea in lineas:
            try:
                registros.append(json.loads(linea))
            except ValueError:
                continue
        return registros

    def historial(self):
        registros = self._leer()

        def estadisticas(valores):
            """n, media, mediana, p90, p95, mínimo y máximo (ms, redondeados)."""
            valores = sorted(v for v in valores if v is not None)
            if not valores:
                return {"n": 0, "media": None, "mediana": None, "p90": None, "p95": None, "min": None, "max": None}
            return {
                "n": len(valores),
                "media": round(statistics.fmean(valores)),
                "mediana": round(statistics.median(valores)),
                "p90": round(_percentil(valores, 0.90)),
                "p95": round(_percentil(valores, 0.95)),
                "min": valores[0],
                "max": valores[-1],
            }

        def resumen(grupo):
            confirmadas = [r for r in grupo if r.get("estado") == "confirmado"]
            return {
                "sesiones": len(grupo),
                "identificadas": sum(1 for r in grupo if r.get("estado") in ("confirmado", "sin_confirmar")),
                "confirmadas": len(confirmadas),
                # Primer cruce: todas las sesiones que lo tuvieron. Cruce estable: solo las confirmadas.
                "primer_cruce": estadisticas([r.get("primer_cruce_ms") for r in grupo]),
                "cruce_estable": estadisticas([r.get("cruce_estable_ms") for r in confirmadas]),
            }

        # Las sesiones se agrupan también por el mínimo de voz con que se hicieron:
        # cruces medidos con mínimos distintos (500, 100 o 250 ms) no son comparables.
        for r in registros:
            r.setdefault("voz_min_ms", VOZ_MIN_MS_ANTERIOR)
            if r.get("voz_min_ms") is None:
                r["voz_min_ms"] = VOZ_MIN_MS_ANTERIOR
        por_vad = {}
        for r in registros:
            por_vad.setdefault((r.get("vad") or "silero", r["voz_min_ms"]), []).append(r)
        por_persona = {}
        for r in registros:
            clave = (r.get("vad") or "silero", r["voz_min_ms"], r.get("persona_id"))
            por_persona.setdefault(clave, []).append(r)

        personas = []
        for (vad, voz_min, persona_id), grupo in por_persona.items():
            nombre = next((g.get("nombre") for g in reversed(grupo) if g.get("nombre")), None)
            personas.append({"vad": vad, "voz_min_ms": voz_min, "persona_id": persona_id, "nombre": nombre,
                             **resumen(grupo)})
        # Primero el mínimo actual; después los anteriores.
        personas.sort(key=lambda p: (p["vad"], p["voz_min_ms"] != VOZ_MIN_MS, p["voz_min_ms"], p["persona_id"] is None,
                                     (p["nombre"] or "").lower()))

        recientes = [{k: r.get(k) for k in ("fecha_utc", "vad", "estado", "nombre", "primer_cruce_ms",
                                             "cruce_estable_ms", "primer_cruce_en_minimo", "cruce_estable_en_minimo",
                                             "voz_min_ms", "voz_total_ms")} for r in registros[-15:]][::-1]
        return {
            "vad_actual": self.motor.vad,
            "sesiones": len(registros),
            "por_vad": [{"vad": v, "voz_min_ms": m, **resumen(g)}
                        for (v, m), g in sorted(por_vad.items(), key=lambda kv: (kv[0][0], kv[0][1] != VOZ_MIN_MS, kv[0][1]))],
            "por_persona": personas,
            "recientes": recientes,
            "confirmacion_ms": CONFIRMACION_MS,
            "voz_min_ms": VOZ_MIN_MS,
        }
