"""
Logica de negocio del RPC Ingest.

Resuelve el oneof del request (documento completo vs. chunks
pre-cortados), elige la estrategia de chunking segun el enum del
request, y decide el motor de embeddings + coleccion segun el perfil
declarado explicitamente por el cliente (igual criterio que Retrieve,
pero aqui el perfil viene en el propio IngestRequest en vez de
inferirse).

No conoce nada de gRPC: recibe y devuelve los mensajes generados por
protoc directamente.
"""

import hashlib
import logging
import uuid
from datetime import datetime, timezone

from fastembed.sparse.bm25 import Bm25
from qdrant_client import models

from rag_api.chunking.ast_codigo import ChunkingAstCodigo
from rag_api.chunking.base import ChunkGenerado, EstrategiaChunkingBase
from rag_api.chunking.clausula_legal import ChunkingClausulaLegal
from rag_api.chunking.fijo import ChunkingFijo
from rag_api.chunking.recursivo import ChunkingRecursivo
from rag_api.chunking.semantic import ChunkingSemantic
from rag_api.clients.ollama_client import OllamaClient
from rag_api.clients.qdrant_client import QdrantWrapper
from rag_api.clients.vllm_client import VllmClient
from rag_api.config import settings
from rag_api.generated import rag_pb2

logger = logging.getLogger(__name__)

# Mismo modelo BM25 que usa retrieve_service.py para consultas, pero
# aqui se usa para indexar documentos (metodo embed(), no
# query_embed()) -- ver docstring de _vectorizar_disperso_documento.
_MODELO_BM25 = Bm25(model_name="Qdrant/bm25", language="spanish")


class IngestService:
    def __init__(
        self,
        qdrant: QdrantWrapper,
        vllm_client: VllmClient,
        ollama_client: OllamaClient,
    ) -> None:
        self._qdrant = qdrant
        self._vllm_client = vllm_client
        self._ollama_client = ollama_client

    def ingest(self, request: rag_pb2.IngestRequest) -> rag_pb2.IngestResponse:
        self._validar_request(request)

        if request.HasField("documento"):
            chunks_generados = self._procesar_documento_completo(request)
        elif request.HasField("chunks"):
            chunks_generados = self._procesar_chunks_precortados(request)
        else:
            raise ValueError("IngestRequest debe traer 'documento' o 'chunks' (oneof 'contenido')")

        if not chunks_generados:
            raise ValueError(
                "La ingesta no produjo ningun chunk: revisa que el texto no este vacio "
                "y que la estrategia de chunking pueda dividirlo"
            )

        puntos = self._construir_puntos(chunks_generados, request)

        if request.perfil == rag_pb2.PERFIL_RAPIDO:
            self._qdrant.upsert_rapida(puntos)
        elif request.perfil == rag_pb2.PERFIL_PRECISO:
            self._qdrant.upsert_precisa(puntos)
        else:
            raise ValueError(f"Perfil de ingesta desconocido: {request.perfil}")

        return rag_pb2.IngestResponse(
            chunks_insertados=len(puntos),
            chunks_actualizados=0,  # el prototipo no distingue insert vs. update; Qdrant hace upsert por id
            ids_generados=[str(punto.id) for punto in puntos],
        )

    @staticmethod
    def _validar_request(request: rag_pb2.IngestRequest) -> None:
        """
        Validaciones comunes a ambos modos. El perfil es obligatorio: como
        PERFIL_RAPIDO vale 0 en el enum, sin HasField un cliente que olvide
        enviarlo ingestaria silenciosamente en la coleccion rapida.
        """
        if not request.HasField("perfil"):
            raise ValueError("IngestRequest.perfil es obligatorio (PERFIL_RAPIDO o PERFIL_PRECISO)")
        if request.perfil not in (rag_pb2.PERFIL_RAPIDO, rag_pb2.PERFIL_PRECISO):
            raise ValueError(f"Perfil de ingesta desconocido: {request.perfil}")
        if not request.categoria.strip():
            raise ValueError("IngestRequest.categoria es obligatoria")
        if not request.fuente.strip():
            raise ValueError("IngestRequest.fuente es obligatoria")

    # -----------------------------------------------------------------
    # Modo A: documento completo, la API chunkea
    # -----------------------------------------------------------------

    def _procesar_documento_completo(self, request: rag_pb2.IngestRequest) -> list[tuple[str, ChunkGenerado]]:
        documento = request.documento

        if not documento.HasField("estrategia"):
            raise ValueError(
                "DocumentoCompleto.estrategia es obligatorio: no hay default implicito oculto, "
                "el cliente debe declarar explicitamente la estrategia de chunking"
            )

        estrategia = self._instanciar_estrategia(documento.estrategia, request)

        tamano_tokens = settings.chunking.tamano_tokens_default
        overlap_tokens = settings.chunking.overlap_tokens_default
        if documento.HasField("parametros"):
            tamano_tokens = documento.parametros.tamano_tokens
            overlap_tokens = documento.parametros.overlap_tokens

        lenguaje_codigo = documento.lenguaje_codigo if documento.HasField("lenguaje_codigo") else None

        chunks = estrategia.chunkear(
            texto=documento.texto,
            tamano_tokens=tamano_tokens,
            overlap_tokens=overlap_tokens,
            lenguaje_codigo=lenguaje_codigo,
            fuente=request.fuente,
        )

        return [
            (self._generar_id(request.fuente, request.perfil, i, chunk.texto), chunk)
            for i, chunk in enumerate(chunks)
        ]

    def _instanciar_estrategia(
        self,
        estrategia_enum: int,
        request: rag_pb2.IngestRequest,
    ) -> EstrategiaChunkingBase:
        if estrategia_enum == rag_pb2.CHUNKING_RECURSIVO:
            return ChunkingRecursivo()
        if estrategia_enum == rag_pb2.CHUNKING_FIJO:
            return ChunkingFijo()
        if estrategia_enum == rag_pb2.CHUNKING_SEMANTIC:
            # El chunking semantico usa el mismo motor de embeddings
            # que corresponde al perfil de esta ingesta (rapido ->
            # vLLM, preciso -> Ollama), no un motor fijo -- asi la
            # medicion de similitud interna no le cuesta mas (ni
            # menos) que el resto de la ingesta de esa categoria.
            cliente = self._vllm_client if request.perfil == rag_pb2.PERFIL_RAPIDO else self._ollama_client
            return ChunkingSemantic(cliente_embeddings=cliente)
        if estrategia_enum == rag_pb2.CHUNKING_AST_CODIGO:
            return ChunkingAstCodigo()
        if estrategia_enum == rag_pb2.CHUNKING_CLAUSULA_LEGAL_JERARQUICA:
            return ChunkingClausulaLegal()

        raise ValueError(f"Estrategia de chunking desconocida: {estrategia_enum}")

    # -----------------------------------------------------------------
    # Modo B: chunks pre-cortados por el cliente
    # -----------------------------------------------------------------

    def _procesar_chunks_precortados(self, request: rag_pb2.IngestRequest) -> list[tuple[str, ChunkGenerado]]:
        if len(request.chunks.chunks) == 0:
            raise ValueError("ChunksPreCortados no puede venir vacio")

        resultado = []
        ids_vistos: set[str] = set()

        for i, chunk_entrante in enumerate(request.chunks.chunks):
            if not chunk_entrante.texto.strip():
                raise ValueError(f"Chunk {i + 1}: el campo 'texto' no puede estar vacio")

            if chunk_entrante.id.strip():
                chunk_id = self._validar_id(chunk_entrante.id.strip(), f"Chunk {i + 1}")
            else:
                chunk_id = self._generar_id(request.fuente, request.perfil, i, chunk_entrante.texto)

            if chunk_id in ids_vistos:
                raise ValueError(f"Chunk {i + 1}: id repetido dentro del mismo request ({chunk_id})")
            ids_vistos.add(chunk_id)

            fecha = None
            if chunk_entrante.fecha_ingesta.strip():
                fecha = self._normalizar_fecha(chunk_entrante.fecha_ingesta.strip(), f"Chunk {i + 1}")

            chunk_generado = ChunkGenerado(
                texto=chunk_entrante.texto,
                metadata_adicional=dict(chunk_entrante.metadata_adicional),
                fecha_ingesta=fecha,
            )
            resultado.append((chunk_id, chunk_generado))
        return resultado

    @staticmethod
    def _validar_id(valor: str, contexto: str) -> str:
        """
        Qdrant solo admite como id un entero sin signo o un UUID. Se valida
        aqui para devolver INVALID_ARGUMENT con un mensaje claro, en vez de
        un error interno de Qdrant. Se normaliza a UUID canonico.
        """
        try:
            return str(uuid.UUID(valor))
        except ValueError:
            raise ValueError(f"{contexto}: el id '{valor}' no es un UUID valido") from None

    @staticmethod
    def _normalizar_fecha(valor: str, contexto: str) -> str:
        """
        Valida una fecha ISO 8601 y la devuelve normalizada (con zona
        horaria; si viene sin zona se asume UTC), de modo que el filtro
        fecha_antes_de de Delete compare siempre contra el mismo formato.
        """
        try:
            fecha = datetime.fromisoformat(valor.replace("Z", "+00:00"))
        except ValueError:
            raise ValueError(
                f"{contexto}: fecha_ingesta '{valor}' no es ISO 8601 valida (ej. 2026-09-01T00:00:00Z)"
            ) from None
        if fecha.tzinfo is None:
            fecha = fecha.replace(tzinfo=timezone.utc)
        return fecha.isoformat()

    # -----------------------------------------------------------------
    # Construccion de puntos de Qdrant (comun a ambos modos)
    # -----------------------------------------------------------------

    def _construir_puntos(
        self,
        chunks_generados: list[tuple[str, ChunkGenerado]],
        request: rag_pb2.IngestRequest,
    ) -> list[models.PointStruct]:
        textos = [chunk.texto for _, chunk in chunks_generados]

        if request.perfil == rag_pb2.PERFIL_RAPIDO:
            vectores_densos = self._vllm_client.embed_lote(textos)
        else:
            vectores_densos = self._ollama_client.embed_lote(textos)

        puntos = []
        for i, (chunk_id, chunk) in enumerate(chunks_generados):
            payload = {
                "texto": chunk.texto,
                "fuente": request.fuente,
                "categoria": request.categoria,
                "fecha_ingesta": chunk.fecha_ingesta or datetime.now(timezone.utc).isoformat(),
            }
            if chunk.texto_padre:
                payload["texto_padre"] = chunk.texto_padre
            if chunk.metadata_adicional:
                payload["metadata_adicional"] = chunk.metadata_adicional

            if request.perfil == rag_pb2.PERFIL_RAPIDO:
                vector = vectores_densos[i]
            else:
                vector_disperso = self._vectorizar_disperso_documento(chunk.texto)
                vector = {"denso": vectores_densos[i], "disperso": vector_disperso}

            puntos.append(models.PointStruct(id=chunk_id, vector=vector, payload=payload))

        return puntos

    @staticmethod
    def _vectorizar_disperso_documento(texto: str) -> models.SparseVector:
        """
        Vectoriza un documento (chunk) a indexar con BM25 (embed, no
        query_embed): a diferencia de una consulta, un documento si
        usa pesos por termino (term frequency completa + stemming +
        stopwords), que es como BM25 esta disenado para funcionar.
        """
        (embedding_disperso,) = _MODELO_BM25.embed(texto)
        return models.SparseVector(
            indices=embedding_disperso.indices.tolist(),
            values=embedding_disperso.values.tolist(),
        )

    @staticmethod
    def _generar_id(fuente: str, perfil: int, indice: int, texto: str) -> str:
        """
        Id deterministico para chunks generados por chunking
        automatico (modo A): misma fuente + mismo perfil + mismo
        indice + mismo contenido de texto siempre produce el mismo id,
        de forma que reingerir el mismo documento (texto identico)
        actualiza (upsert) los chunks existentes en vez de duplicarlos.

        El hash del texto se incluye en la semilla para distinguir dos
        ingestas separadas que comparten fuente y perfil pero llevan
        contenido distinto (ej. dos llamadas a Ingest con la misma
        categoria/fuente pero textos diferentes): sin el hash, ambas
        caerian en el mismo indice (0) y colisionarian en el mismo id,
        sobre-escribiendo el chunk anterior en vez de agregar uno
        nuevo. Con el hash, cada contenido distinto obtiene su propio
        punto en Qdrant, y solo una reingesta textualmente identica
        actualiza en vez de duplicar.

        El perfil se incluye en la semilla para que un mismo documento
        ingerido por error en ambos perfiles nunca colisione en id
        entre las dos colecciones.
        """
        hash_texto = hashlib.sha256(texto.encode("utf-8")).hexdigest()[:16]
        semilla = f"{fuente}::{perfil}::{indice}::{hash_texto}"
        return str(uuid.uuid5(uuid.NAMESPACE_URL, semilla))
