#!/bin/bash

N=100  # número de peticiones concurrentes

echo "Lanzando $N peticiones simultáneas..."
start=$(date +%s.%N)

for i in $(seq 1 $N); do
  curl -s -o /dev/null -w "Request $i: %{time_total}s\n" \
    http://localhost:8001/v1/embeddings \
    -H "Content-Type: application/json" \
    -d '{"model": "/models/model", "input": "Buenos días, le habla el banco A"}' &
done

wait  # espera a que todas las peticiones en background terminen

end=$(date +%s.%N)
echo "---"
echo "Tiempo total del lote: $(echo "$end - $start" | bc)s"
