#!/bin/bash
set -e

PORT="${PORT:-50051}"
SGLANG_OMNI_PORT="${SGLANG_OMNI_PORT:-8000}"
SGLANG_OMNI_MODEL="${SGLANG_OMNI_MODEL:-/app/checkpoints/s2-pro}"
SGLANG_OMNI_CONFIG="${SGLANG_OMNI_CONFIG:-/app/configs/s2pro_tts.yaml}"

echo "[entrypoint] ════════════════════════════════════════════════"
echo "[entrypoint]  Fish Audio S2-Pro TTS gRPC Service (SGLang-Omni)"
echo "[entrypoint] ════════════════════════════════════════════════"

if [ -n "$CUDA_VISIBLE_DEVICES" ]; then
    echo "[entrypoint] GPU device(s) visibles: $CUDA_VISIBLE_DEVICES"
else
    echo "[entrypoint] CUDA_VISIBLE_DEVICES no definido — usando todas las GPU visibles"
fi
echo "[entrypoint]   Recordatorio: NUNCA combinar --gpus device=N con"
echo "[entrypoint]   CUDA_VISIBLE_DEVICES=N a la vez (causa error)"

# Diagnóstico de GPU antes de arrancar — usa el propio comando de sgl-omni
# para confirmar visibilidad de GPU con el mismo detalle que usa el motor.
echo "[entrypoint] Ejecutando diagnóstico de GPU (sgl-omni check-gpu)..."
/opt/venv-omni/bin/sgl-omni check-gpu || echo "[entrypoint] ⚠️ check-gpu falló — revisar antes de continuar"

# ── Arrancar sgl-omni serve en background, con su log visible en vivo ──────
# IMPORTANTE: se redirige a un archivo con > (no a un pipe), para que $!
# capture correctamente el PID real de "sgl-omni serve" — meterlo en un
# pipe (| tee | sed) rompería $! porque capturaría el PID del último
# proceso del pipeline, no el de sgl-omni serve, invalidando todo el
# manejo de señales/espera de abajo. En su lugar, un "tail -f" aparte,
# en su propio subproceso, transmite el contenido del archivo en vivo
# hacia la salida de este script, con un prefijo que lo distingue.
echo "[entrypoint] Iniciando sgl-omni serve en puerto interno ${SGLANG_OMNI_PORT}..."
echo "[entrypoint] Modelo: ${SGLANG_OMNI_MODEL} (checkpoint local, horneado en la imagen — sin acceso a internet requerido)"
echo "[entrypoint] Config: ${SGLANG_OMNI_CONFIG}"
echo "[entrypoint] HF_HUB_OFFLINE=${HF_HUB_OFFLINE:-no definido} — modo offline forzado"
echo "[entrypoint] NOTA: sin restricciones de mem_fraction_static — H200 no las necesita."
echo "[entrypoint] Su log se transmite en vivo aquí, con prefijo [sglang-omni]"

: > /tmp/sglang_omni.log  # truncar por si quedó algo de un arranque previo

/opt/venv-omni/bin/sgl-omni serve \
    --model-path "${SGLANG_OMNI_MODEL}" \
    --config "${SGLANG_OMNI_CONFIG}" \
    --port "${SGLANG_OMNI_PORT}" \
    > /tmp/sglang_omni.log 2>&1 &

SGLANG_OMNI_PID=$!
echo "[entrypoint] sgl-omni serve arrancado con PID ${SGLANG_OMNI_PID}"

# Subproceso separado que transmite el log en vivo con prefijo. Su propio
# PID se guarda para poder matarlo limpiamente al final (si no, quedaría
# huérfano intentando leer un archivo de un proceso ya terminado).
tail -n +1 -f /tmp/sglang_omni.log | sed 's/^/[sglang-omni] /' &
TAIL_PID=$!

# ── Manejo de señales: propagar SIGTERM/SIGINT a todos los procesos ────────
cleanup() {
    echo "[entrypoint] Señal de cierre recibida — deteniendo procesos..."
    kill -TERM "$SGLANG_OMNI_PID" "$TAIL_PID" 2>/dev/null || true
    wait "$SGLANG_OMNI_PID" 2>/dev/null || true
    echo "[entrypoint] sgl-omni serve detenido"
    exit 0
}
trap cleanup SIGTERM SIGINT

# ── Verificar que sgl-omni serve sigue vivo antes de lanzar el wrapper ────
# (el wrapper gRPC también espera activamente por /health en su propio
# main() — este chequeo aquí es solo para fallar rápido y con claridad si
# el proceso muere inmediatamente, en vez de esperar el timeout completo
# del wrapper para descubrirlo). Con el log ya visible en vivo arriba, ya
# no hace falta un "tail" adicional aquí solo para mostrar el error — ya
# se vio en pantalla mientras ocurría.
sleep 5
if ! kill -0 "$SGLANG_OMNI_PID" 2>/dev/null; then
    echo "[entrypoint] ❌ sgl-omni serve murió inmediatamente tras arrancar (ver arriba el log [sglang-omni] para el traceback completo)."
    kill -TERM "$TAIL_PID" 2>/dev/null || true
    exit 1
fi

# ── Arrancar el wrapper gRPC en foreground (PID 1 efectivo del contenedor) ──
echo "[entrypoint] Iniciando wrapper gRPC en puerto ${PORT}..."
export PYTHONPATH="/app"

/opt/venv-omni/bin/python /app/server.py \
    --port "${PORT}" \
    --config /app/config_tts.json &

SERVER_PID=$!

# Esperar a que cualquiera de los dos procesos principales termine (normal
# o por error) — el proceso de "tail" del log no cuenta para esta espera,
# solo es un espectador.
wait -n "$SGLANG_OMNI_PID" "$SERVER_PID"
EXIT_CODE=$?

echo "[entrypoint] Uno de los procesos terminó (exit code $EXIT_CODE) — deteniendo los demás..."
kill -TERM "$SGLANG_OMNI_PID" "$SERVER_PID" "$TAIL_PID" 2>/dev/null || true
wait 2>/dev/null || true

exit $EXIT_CODE
