"""Núcleo de huella vocal: audio, VAD, huella ECAPA, perfil acústico y referencias.

Lo usan los análisis de cada fase y, más adelante, el backend.
"""
