"""Descarga los modelos del servicio a una carpeta local, en versiones fijas y verificadas.

Se ejecuta UNA vez, con internet, al construir la imagen Docker:
    python descargar_modelos.py /opt/modelos

Sin Docker (desarrollo), se puede correr igual hacia la carpeta "modelos" del proyecto:
    python codigo/construccion/descargar_modelos.py modelos

Cada archivo se compara con el hash esperado: si Hugging Face o GitHub entregaran
otra cosa, la construcción falla aquí y no más tarde, ya sin internet.
Los hashes corresponden a los archivos que usó la versión 0.7.0 en la Spark de desarrollo.
"""

import hashlib
import json
import os
import shutil
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

# Revisiones exactas (commit de Hugging Face) y hash de cada archivo.
#   sha256: archivos grandes (LFS) -> sha256 del contenido
#   git:    archivos pequeños      -> sha1 de git ("blob <tamaño>\0" + contenido)
MODELOS_HF = {
    "ecapa": {
        "repo": "speechbrain/spkrec-ecapa-voxceleb",
        "revision": "0f99f2d0ebe89ac095bcc5903c4dd8f72b367286",
        "archivos": {
            "hyperparams.yaml": ("git", "70e4cd0beb74ca08a2df9de6bd79d938670a4d15"),
            "embedding_model.ckpt": ("sha256", "0575cb64845e6b9a10db9bcb74d5ac32b326b8dc90352671d345e2ee3d0126a2"),
            "mean_var_norm_emb.ckpt": ("git", "1978c5e7f20d5ffd14c8a932a7e85a09816f3da9"),
            "classifier.ckpt": ("sha256", "fd9e3634fe68bd0a427c95e354c0c677374f62b3f434e45b78599950d860d535"),
            "label_encoder.txt": ("git", "72c6fa7b170cbfd169df5e09326cd97febdf086a"),
        },
    },
    "whisper-base": {
        "repo": "Systran/faster-whisper-base",
        "revision": "ebe41f70d5b6dfa9166e2c581c45c9c0cfc57b66",
        "archivos": {
            "config.json": ("git", "867cf1a0fece1394e01d55e287ba2f09a577c046"),
            "model.bin": ("sha256", "d01c3014881c9c6f3133c182f3d2887eb6ca1c789a7538c5c007196857a0a6a9"),
            "tokenizer.json": ("git", "7818adb6de9fa3064d3ff81226fdd675be1f6344"),
            "vocabulary.txt": ("git", "c9074644d9d1205686f16d411564729461324b75"),
        },
    },
}

# Modelo ONNX de TEN VAD, el mismo que distribuye sherpa-onnx (Apache 2.0).
MODELO_TEN = {
    "url": "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/ten-vad.onnx",
    "destino": "ten-vad/ten-vad.onnx",
    "sha256": "718cb7eef47e3cf5ddbe7e967a7503f46b8b469c0706872f494dfa921b486206",
}


def _hash(ruta, tipo):
    datos = Path(ruta).read_bytes()
    if tipo == "sha256":
        return hashlib.sha256(datos).hexdigest()
    if tipo == "git":
        return hashlib.sha1(b"blob %d\0" % len(datos) + datos).hexdigest()
    raise ValueError(tipo)


def _verificar(ruta, tipo, esperado):
    obtenido = _hash(ruta, tipo)
    if obtenido != esperado:
        raise SystemExit(f"ERROR: {ruta} no coincide con la versión esperada ({tipo} {obtenido} != {esperado}).")


def descargar_hf(destino):
    os.environ["HF_HUB_OFFLINE"] = "0"          # aquí sí se permite internet
    from huggingface_hub import hf_hub_download

    for carpeta, modelo in MODELOS_HF.items():
        dir_modelo = destino / carpeta
        dir_modelo.mkdir(parents=True, exist_ok=True)
        for nombre, (tipo, esperado) in modelo["archivos"].items():
            print(f"  {modelo['repo']}@{modelo['revision'][:8]} / {nombre}", flush=True)
            ruta = Path(hf_hub_download(repo_id=modelo["repo"], filename=nombre, revision=modelo["revision"],
                                        local_dir=dir_modelo))
            final = dir_modelo / nombre
            if ruta.resolve() != final.resolve():           # por si la librería dejó un enlace
                shutil.copyfile(ruta.resolve(), final)
            _verificar(final, tipo, esperado)
        shutil.rmtree(dir_modelo / ".cache", ignore_errors=True)   # metadatos de descarga, no hacen falta


def descargar_ten(destino):
    final = destino / MODELO_TEN["destino"]
    final.parent.mkdir(parents=True, exist_ok=True)
    print(f"  {MODELO_TEN['url']}", flush=True)
    with urllib.request.urlopen(MODELO_TEN["url"], timeout=120) as respuesta, open(final, "wb") as f:
        shutil.copyfileobj(respuesta, f)
    _verificar(final, "sha256", MODELO_TEN["sha256"])


def verificar_carpeta(destino):
    """Comprueba que todos los archivos estén y coincidan con su hash (no usa la red)."""
    destino = Path(destino)
    for carpeta, modelo in MODELOS_HF.items():
        for nombre, (tipo, esperado) in modelo["archivos"].items():
            ruta = destino / carpeta / nombre
            if not ruta.is_file():
                raise SystemExit(f"ERROR: falta {ruta}")
            _verificar(ruta, tipo, esperado)
    ruta = destino / MODELO_TEN["destino"]
    if not ruta.is_file():
        raise SystemExit(f"ERROR: falta {ruta}")
    _verificar(ruta, "sha256", MODELO_TEN["sha256"])


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python descargar_modelos.py <carpeta_destino>")
    destino = Path(sys.argv[1]).resolve()
    destino.mkdir(parents=True, exist_ok=True)
    print(f"Descargando modelos a {destino}")
    descargar_hf(destino)
    descargar_ten(destino)
    verificar_carpeta(destino)
    manifiesto = {
        "fecha_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "hugging_face": {c: {"repo": m["repo"], "revision": m["revision"], "archivos": sorted(m["archivos"])}
                         for c, m in MODELOS_HF.items()},
        "ten_vad": MODELO_TEN,
    }
    (destino / "manifiesto.json").write_text(json.dumps(manifiesto, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Modelos descargados y verificados.")


if __name__ == "__main__":
    main()
