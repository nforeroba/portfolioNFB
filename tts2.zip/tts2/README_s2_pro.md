# Servicio TTS gRPC — Fish Audio S2-Pro
## Notas de despliegue — fase de pruebas (RTX 5070 Ti) y plan de producción (H200 NVL)

---

## 0. Diferencias clave respecto a `tts_s1_mini`

**Nota sobre versión de CUDA:** este proyecto usa `nvidia/cuda:12.8.0-cudnn-devel-ubuntu24.04` (no `12.8.1`) por instrucción confirmada de despliegue real en el entorno de trabajo — aunque el `Dockerfile` de S1-mini que se usó como base para este proyecto tenía `12.8.1`, en la práctica el build de producción de S1-mini se hizo con `12.8.0`. Si en algún momento se retoma el Dockerfile de S1-mini, vale la pena aplicar el mismo ajuste ahí.

| | S1-mini (ya en producción) | S2-Pro (este proyecto) |
|---|---|---|
| Parámetros | 0.5B | 5B (4B Slow AR + 400M Fast AR) |
| Checkpoint HF | `fishaudio/openaudio-s1-mini` | `fishaudio/s2-pro` |
| Tamaño descarga | ~3.5 GB | ~11 GB |
| Licencia | CC-BY-NC-SA-4.0 | Fish Audio Research License (no comercial) |
| VRAM (bf16) | ~5.1 GB medido | ≥24 GB recomendado oficialmente — **confirmado en pruebas: solo el LLaMA ya usa ~14.9GB en fp16 en una GPU de 16GB, no cabe** |
| Motor | `TTSInferenceEngine` clásico | `TTSInferenceEngine` clásico (mismo patrón — SGLang queda como plan B si el rendimiento no alcanza) |
| Precisión | bf16 fija | bf16/fp16 configurable vía `TTS_PRECISION` |
| Protocolo | gRPC (`.proto` propio) | gRPC — **mismo `.proto`, sin cambios** |

**Objetivo de esta fase**: en RTX 5070 Ti (16GB VRAM, 128GB RAM sistema) solo se busca confirmar que la imagen construye y el servicio arranca — no se espera buen rendimiento ni que quepa cómodamente en VRAM. La validación de rendimiento real ocurre en la H200 NVL.

---

## 1. Prerrequisito: licencia del modelo

A diferencia de S1-mini, `fishaudio/s2-pro` en HuggingFace tiene un gate con checkbox de aceptación explícita:

1. Ir a https://huggingface.co/fishaudio/s2-pro
2. Aceptar la **Fish Audio Research License Agreement** (marca el checkbox "I agree to use this model for non-commercial use ONLY")
3. Confirmar que tu token de lectura en `HF Token TTS Service.txt` corresponde a la cuenta que aceptó la licencia — si no, la descarga en el build fallará con 403.

---

## 2. Build en tu RTX 5070 Ti (solo validación de arranque)

```bash
cd tts_s2_pro

docker build \
    --build-arg HF_TOKEN=$(cat ~/Documentos/'HF Token TTS Service.txt') \
    -t fish-tts-s2pro:0.1.0-dev \
    .
```

**Advertencias esperadas para este build:**
- Descarga ~11 GB del checkpoint (vs ~3.5 GB de S1-mini) — tiempo estimado 30-60 min según tu conexión.
- `FISH_SPEECH_COMMIT` está fijado a `main` (no a un hash específico como en S1-mini) porque S2-Pro es soporte reciente en el repo. Una vez confirmes que un commit funciona bien, considera fijarlo con `--build-arg FISH_SPEECH_COMMIT=<hash>` para reproducibilidad, igual que se hizo con `781bf1c` en S1-mini.
- Si el build falla en el paso de `snapshot_download` con un error 403/401, es el gate de licencia del paso 1.

---

## 3. Arranque en RTX 5070 Ti — con `TTS_PRECISION=fp16`

Dado que la documentación oficial recomienda ≥24GB VRAM en bf16 y tu 5070 Ti tiene 16GB, arranca forzando fp16:

```bash
docker run -d \
    --gpus '"device=0"' \
    -e PORT=50051 \
    -e CUDA_VISIBLE_DEVICES=0 \
    -e TTS_PRECISION=fp16 \
    -v ~/Documentos/voices:/voices \
    -v ~/Documentos/tts_s2_pro/config_tts.json:/app/config_tts.json \
    -p 50051:50051 \
    --name fish-tts-s2pro-dev \
    fish-tts-s2pro:0.1.0-dev
```

Nota: se omitió `--restart unless-stopped` a propósito — es un contenedor de prueba, no de producción.

**Sobre `compile: true` y `warmup_runs: 3` (config actual):** se dejó la configuración "de producción" activa desde ya, ya que el objetivo es solo confirmar que arranca y no importa el tiempo. Tener en cuenta:
- El primer arranque va a tardar considerablemente más que los ~160s medidos en S1-mini — es un modelo ~10x más grande (5B vs 0.5B) y la combinación `compile=true` + `fp16` en Triton es una combinación menos probada que bf16. Si la compilación falla o se cuelga, es información útil en sí misma — indica que hay que investigar la compatibilidad Triton/fp16 puntualmente antes de llevarlo a la H200.
- Si se prefiere una primera corrida más rápida para descartar errores básicos de carga antes de invertir tiempo en compile, sobreescribir temporalmente el config montado con `"compile": false` y `"warmup_runs": 1`, confirmar que arranca, y luego volver a la config actual para la prueba real.

**Si hace OOM en VRAM:** con 128GB de RAM de sistema disponibles, una alternativa de último recurso es forzar `device="cpu"` en `server.py` (línea `device = "cuda" if torch.cuda.is_available() else "cpu"`) solo para confirmar que el pipeline de carga/inferencia no tiene errores de código — será lento (minutos por frase), y `compile=true` no aplica en CPU.

**Verificar arranque:**
```bash
docker logs -f fish-tts-s2pro-dev
```

Buscar en el log la línea `gRPC escuchando en 0.0.0.0:50051`. También revisar que el log confirme `Precisión : torch.float16 (TTS_PRECISION=fp16)`.

**⚠️ Punto de fallo más probable — `DECODER_CONFIG_NAME`:** a diferencia de S1-mini, no se encontró confirmación 100% explícita de que S2-Pro use el mismo nombre de config de codec (`modded_dac_vq`). Si el arranque falla en la etapa `CARGA | Codec DAC`, entrar al contenedor:

```bash
docker run --rm -it --entrypoint bash fish-tts-s2pro:0.1.0-dev
ls /app/fish_speech/configs/
```

y ajustar `DECODER_CONFIG_NAME` en el `docker run` con el nombre correcto que se encuentre ahí.

---

## 4. Probar síntesis

```bash
cd tts_s2_pro && \
python3 client_test.py \
    --text "Hola, esta es una prueba del modelo S2 Pro." \
    --voice vanessa \
    --output /tmp/test_s2pro.opus
```

Con `compile: true` y fp16 en una 5070 Ti, sobre un modelo 5B, espera latencias notablemente mayores que S1-mini incluso después del warmup — es normal y esperado para esta fase de solo-validación. El dato de RTF real que se obtenga aquí no es representativo de la H200 (otra GPU, otra precisión, sin el resto de tráfico de producción); solo sirve para confirmar que el pipeline completo funciona de punta a punta.

---

## 5. Resultados de la fase de pruebas en RTX 5070 Ti (completada)

**Build:** exitoso — imagen de 27GB (`fish-tts-s2pro:0.1.0-dev`, nombre usado solo en la fase de pruebas en la 5070 Ti), ~13.5 min de build total.

**Hallazgos confirmados durante las pruebas:**
- `DECODER_CONFIG_NAME=modded_dac_vq` es correcto para S2-Pro — no hubo que ajustarlo (la incertidumbre original quedó resuelta).
- **El LLaMA Dual-AR solo (sin el codec) ya consume ~14.9GB de VRAM en fp16** en la 5070 Ti (16GB) — no cabe ni con `TTS_PRECISION=fp16`. Confirma en la práctica el reporte de la comunidad de que S2-Pro necesita ≥24GB de VRAM real. `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True` no ayudó — no era un problema de fragmentación sino de capacidad insuficiente.
- Se agregó un flag `TTS_DEVICE=cpu` a `server.py` (no estaba en la versión original) para forzar CPU y validar el pipeline completo sin depender de VRAM. En CPU, el server automáticamente fuerza `float32` (fp16/bf16 no son estables en CPU-PyTorch) y deshabilita `compile` (Triton no aplica en CPU) — ambos ajustes son automáticos, no requieren tocar código.
- **Validación completa exitosa en CPU** (Ryzen 7 3700X, 128GB RAM): carga de LLaMA (39s) + codec (4.6s) + codificación de voz de referencia + generación de tokens semánticos + decodificación VQ→WAV + conversión WAV→Opus + respuesta gRPC completa al cliente. Se generó y recibió correctamente un audio de prueba (1.393s de audio, 10,829 bytes Opus) a través de `client_test.py`.
- Rendimiento en CPU-fp32 (solo como referencia de que "funciona", no de velocidad real): ~14.6-15s por token generado, RTF ~490-590. Esto es exclusivamente informativo — no representa en absoluto lo esperable en GPU.
- El servicio demostró ser robusto ante cancelación de RPC por timeout del cliente: la inferencia en curso no se corrompe ni crashea el servidor, simplemente continúa en el executor hasta terminar.

**Conclusión de esta fase:** el pipeline completo (build → carga de modelo → inferencia → gRPC) es funcionalmente correcto de punta a punta.

---

## 6. Despliegue en H200 NVL — receta para la ventana de internet

**Nota de nomenclatura:** la imagen de pruebas en la 5070 Ti se llamó `fish-tts-s2pro:0.1.0-dev`. Para producción, el nombre de imagen es `fish-tts-s2-pro-grpc:1.0.0`.


### 6.0 Antes de la ventana de internet — preparar todo lo que no la necesita

- Transferir la carpeta `tts_s2_pro/` (código del proyecto) y `voices/` a la máquina de la H200.
- Confirmar que Docker + NVIDIA Container Toolkit ya están instalados y funcionando en la máquina de la H200 (`docker run --rm --gpus all nvidia/cuda:12.8.1-base-ubuntu24.04 nvidia-smi`).
- Tener a mano el archivo `HF Token TTS Service.txt` con el token de lectura.

### 6.1 Durante la ventana de internet — build

Desde `tts_s2_pro/` en la máquina de la H200:

```bash
docker build \
    --build-arg HF_TOKEN=$(cat 'HF Token TTS Service.txt') \
    -t fish-tts-s2-pro-grpc:1.0.0 \
    .
```

**Notas sobre el build en H200:**
- `UV_EXTRA=cu128` (default del Dockerfile) **no necesita cambiarse** para Hopper/H200 — las wheels de PyTorch cu128 desde la versión ~2.7+ incluyen soporte multi-arquitectura para sm_90 (Hopper) y sm_120 (Blackwell) en el mismo paquete. Es el mismo build que ya probaste en la 5070 Ti.
- Aprovecha esta misma ventana para dejar el build cacheado — si necesitas rehacer el build después (ej. ajustar algo en `server.py`) sin internet, Docker reutilizará las capas ya construidas siempre que no cambie el Dockerfile ni los `ARG` de las etapas anteriores a la copia de `server.py`.
- Considera fijar `FISH_SPEECH_COMMIT` a un hash específico en este build (en vez de dejarlo en `main`) una vez confirmes que la versión actual del repo funciona bien — así el build queda reproducible sin necesitar internet en el futuro para volver a resolver qué commit usar. Puedes ver el commit exacto usado en el build de prueba con:
  ```bash
  docker run --rm --entrypoint bash fish-tts-s2pro:0.1.0-dev -c "cd /app && git rev-parse HEAD"
  ```

### 6.2 Arranque en producción (bf16, compile, warmup completo)

A diferencia de las pruebas en la 5070 Ti, aquí sí se usa la configuración completa:

```bash
docker run -d \
    --gpus '"device=0"' \
    -e PORT=50051 \
    -e CUDA_VISIBLE_DEVICES=0 \
    -v ~/voices:/voices \
    -v ~/tts_s2_pro/config_tts.json:/app/config_tts.json \
    -p 50051:50051 \
    --name fish-tts-s2-pro-grpc-0 \
    --restart unless-stopped \
    fish-tts-s2-pro-grpc:1.0.0
```

Notar que **no se pasa `TTS_PRECISION`** — el default es `bf16`, correcto para H200 (141GB VRAM, sin restricción como en la 5070 Ti). Tampoco se pasa `TTS_DEVICE` — el default es auto-detección de CUDA.

`config_tts.json` en este punto debería tener `"compile": true` y `"warmup_runs": 3` (la configuración que ya está en el proyecto) — con la H200 esto sí se ejecuta en GPU real y debería comportarse de forma comparable a como `compile:true` se comportaba en S1-mini, aunque el primer arranque será más lento por ser un modelo más grande.

### 6.3 Medir rendimiento real

```bash
python3 client_test.py \
    --text "Buenos días, le llamamos de parte de su entidad financiera." \
    --voice vanessa \
    --output /tmp/test_h200.opus
```

Con el timeout de `client_test.py` en 1800s (ajustado para las pruebas en CPU) — en H200 debería responder en segundos, pero no hace falta bajarlo, un timeout generoso no afecta el rendimiento real.

**Punto de comparación clave:** el benchmark oficial de Fish Audio es **RTF 0.195 en H200, pero con el motor SGLang** — no hay número de referencia publicado para `TTSInferenceEngine` clásico (el que estamos usando) en S2-Pro. El RTF que midas aquí es información nueva, no una validación contra un número esperado. Si el RTF resulta significativamente peor que 0.5 (el umbral que Fish Audio usa como límite operativo razonable), es la señal para evaluar seriamente el camino B (SGLang + wrapper gRPC).

### 6.4 Múltiples instancias / GPUs

Igual que en S1-mini (sección 6 del runbook original), aplican los mismos patrones de `docker run` con distintos `PORT`/`CUDA_VISIBLE_DEVICES` para escalar horizontalmente si el uso de VRAM por instancia lo permite. A diferencia de S1-mini (~5.1GB/instancia), S2-Pro en bf16 recomienda ≥24GB — en una H200 de 141GB esto da margen para varias instancias, pero conviene medir el consumo real antes de asumir cuántas caben.

---

## 7. Si el rendimiento con `TTSInferenceEngine` no alcanza — plan B (SGLang)

Sin cambios respecto a lo ya documentado: envolver el servidor HTTP OpenAI-compatible de SGLang-Omni con una capa gRPC propia que preserve el `.proto` actual — pendiente de diseño si se llega a este punto.

---

