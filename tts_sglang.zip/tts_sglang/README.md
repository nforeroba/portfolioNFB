# Servicio TTS gRPC — Fish Audio S2-Pro + motor SGLang-Omni
## Receta de despliegue en H200 NVL

---

## 0. Antes de nada — checklist de archivos

```
tts_sglang/
├── Dockerfile
├── entrypoint.sh
├── server.py
├── client_test.py
├── config_tts.json
├── tts_service.proto
├── samples/                 ← DENTRO de la imagen (COPY en el build)
│   ├── sample.wav   ✓ ya copiado
│   └── sample.txt   ✓ ya copiado
└── voices/                  ← FUERA de la imagen (volumen en runtime)
    ├── vanessa.wav   ✓ ya copiado
    └── vanessa.txt   ✓ ya copiado
```

**Diseño de las dos carpetas — dos roles distintos, no alternativas intercambiables:**

- **`samples/`** se copia dentro de la imagen en el build (`COPY samples/ /app/samples/` en el Dockerfile) y queda horneada ahí de forma permanente. Es el **fallback**: si el servidor arranca sin el volumen `/voices` montado, o si se pide un `reference_id` que no está en `/voices`, cae a lo que haya en `/app/samples`.
- **`voices/`** vive fuera de la imagen y se monta como volumen en runtime (`-v /ruta/a/voices:/voices`, ver sección 3) — **nunca** se copia dentro de la imagen ni se hornea en el build. Es donde vive `vanessa.wav`/`vanessa.txt`, la voz real de producción.
- `resolve_voice_paths()` en `server.py` busca primero en `/voices` (volumen) y solo si no encuentra ahí el archivo cae a `/app/samples`. Con el `docker run` de la sección 3 (que sí monta `/voices`) y `default_reference_id: "vanessa"` en `config_tts.json`, el servidor va a resolver `vanessa.wav`/`.txt` desde el volumen — `samples/sample.wav` queda como red de seguridad, no como lo que normalmente se usa.

**Nota sobre `configs/s2pro_tts.yaml`**: no existe como archivo en este repo — el Dockerfile lo genera directamente dentro de la imagen durante el build (stage `model`), con el default sin ajustes (`config_cls` + `model_path` apuntando al checkpoint local). Confirmado que en H200 no hace falta ningún ajuste de memoria sobre ese default — si en algún momento hiciera falta, el procedimiento (editar el YAML vía `sgl-omni config export`) queda documentado en la sesión de exploración de la 5070 Ti.

---

## 0.5 Antes del build — pull de la imagen base y espacio en disco

**La imagen base `lmsysorg/sglang:latest` también requiere internet para descargarse** (~47GB en disco, ~14GB comprimida) — vale la pena bajarla explícitamente primero, para verificar que la ventana de internet alcanza y confirmar el progreso antes de lanzar el build completo:

```bash
docker pull lmsysorg/sglang:latest
```

**Espacio en disco total a anticipar en el servidor de la H200** (suma de imagen base + instalación de `sglang-omni` + checkpoint horneado en la imagen):
- Imagen base: ~47GB
- + `sglang-omni` y dependencias instaladas: ~5-10GB adicionales
- + checkpoint de S2-Pro (~11GB, descargado en build-time — ver sección 2)
- **Total aproximado: 65-70GB** de espacio libre recomendado antes de iniciar el build, sin contar espacio de trabajo temporal que Docker usa durante el build (puede necesitar el doble momentáneamente).

Confirma espacio disponible:

```bash
df -h
```

---

## 1. Diferencias clave respecto a la validación en RTX 5070 Ti

| | Validación 5070 Ti | Este despliegue (H200) |
|---|---|---|
| `mem_fraction_static` / `total_gpu_memory_fraction` | Forzado a 0.52 (mínimo viable) | **Sin forzar — default de SGLang** |
| Resultado con 0.52 en 5070 Ti | Vocoder cargaba, pero KV cache insuficiente para síntesis real (solo 38 tokens de capacidad) | H200 tiene 141GB — no debería necesitar ningún ajuste |
| `TTS_PRECISION` / `TTS_DEVICE` (tts_s2_pro clásico) | N/A — este proyecto usa SGLang, no `TTSInferenceEngine` | N/A — SGLang no tiene flag de precisión por CLI para S2-Pro ni fallback a CPU (confirmado) |

**Si en H200 aparece algún problema de memoria** (poco probable con 141GB, pero no descartado del todo dado que `sglang-omni` es un proyecto joven): el mecanismo que sí funciona es editar `configs/s2pro_tts.yaml` agregando `total_gpu_memory_fraction` y `sglang_server_args.mem_fraction_static` dentro del stage `tts_engine` — ver la sesión de exploración en 5070 Ti para el procedimiento exacto (usar `sgl-omni config export` para obtener el YAML completo con todos los campos, editar el stage correcto, y apuntar `--config` al archivo editado).

---

## 2. Build — CRÍTICO: aquí se descarga el checkpoint completo

**El equipo tiene una sola ventana de internet, y el servidor queda offline después.** Por eso este Dockerfile descarga el checkpoint completo de `fishaudio/s2-pro` (~11GB) **durante el build**, no en runtime — a diferencia de lo que se observó en la sesión de exploración en la 5070 Ti (donde `sgl-omni serve` lo descargaba solo al arrancar). El resultado es una imagen más pesada (~15-20GB adicionales sobre la base), pero que arranca y opera sin ninguna dependencia de red después.

Desde `tts_sglang/`, **con la ventana de internet abierta**:

```bash
docker build -t fish-tts-s2-pro-sglang-grpc:1.0.0 .
```

**Qué esperar:**
- Sin necesidad de `HF_TOKEN` como build-arg — el repo `fishaudio/s2-pro` no tiene gate de licencia (confirmado en sesiones anteriores).
- Tiempo estimado: instalación de `sglang-omni` (~270 paquetes, algunos compilados desde fuente) + descarga del checkpoint (~11GB) — probablemente 20-45 minutos según la velocidad de la conexión de esa ventana.
- **Verifica que el build complete sin errores ANTES de que la ventana de internet se cierre** — si el stage `model` falla a mitad de la descarga por pérdida de conexión, Docker no cachea una descarga parcial exitosa; habría que reconstruir ese stage desde cero en la siguiente ventana disponible.

**Puntos de fricción conocidos, ya resueltos en este Dockerfile:**
- Las 2 dependencias transitivas no declaradas (`descript-audiotools`, `descript-audio-codec`) ya están incluidas.
- El downgrade de protobuf causado por `descript-audiotools` (a 3.19.6) se maneja instalando `grpcio-tools` DESPUÉS — si el build falla en el paso de generación de stubs con un error de protobuf, ese es el primer lugar a revisar.

**Verificación recomendada antes de cerrar la ventana de internet** — confirma que el checkpoint quedó completo dentro de la imagen:

```bash
docker run --rm fish-tts-s2-pro-sglang-grpc:1.0.0 \
    du -sh /app/checkpoints/s2-pro
```

Debería reportar algo cercano a 11GB. Si el número es mucho menor, la descarga quedó incompleta — hay que investigar antes de dar por bueno el build.

---

## 3. Arranque en H200

```bash
docker run -d \
    --gpus '"device=0"' \
    -e PORT=50051 \
    -v ~/voices:/voices \
    -v ~/tts_sglang/tts_sglang/config_tts.json:/app/config_tts.json \
    -p 50051:50051 \
    --shm-size 32g \
    --ipc host \
    --name fish-tts-s2-pro-sglang-0 \
    --restart unless-stopped \
    fish-tts-s2-pro-sglang-grpc:1.0.0
```

**Notas importantes:**

- **`--gpus '"device=0"'` SOLO, sin `CUDA_VISIBLE_DEVICES`** — regla ya aprendida por incidente real en producción con `tts_s2_pro` (ver ese README, sección 6.2). No repetir ese error aquí.
- **`--shm-size 32g --ipc host`** — igual que en las pruebas manuales exitosas. `sglang-omni` usa memoria compartida entre sus procesos internos (preprocessing/tts_engine/vocoder corren como procesos separados, comunicándose por IPC) — sin esto, el arranque puede fallar o degradarse.
- **Sin volumen de cache de HuggingFace** — a diferencia de una versión anterior de este README, el checkpoint ya vive DENTRO de la imagen (descargado en build-time, ver sección 2) — no hace falta persistir ningún cache externo, y el contenedor no necesita internet en ningún momento del arranque.
- El puerto interno de `sgl-omni serve` (8000 por defecto) **no se publica** — es interno al contenedor, solo el wrapper gRPC en 50051 se expone.

**Verificar arranque:**

```bash
docker logs -f fish-tts-s2-pro-sglang-0
```

El log del `entrypoint.sh` muestra primero el diagnóstico `sgl-omni check-gpu`, luego arranca `sgl-omni serve` en background, espera a que responda `/health`, y solo entonces arranca el wrapper gRPC. **El log completo de `sgl-omni serve` se transmite en vivo directamente en `docker logs`**, con el prefijo `[sglang-omni]` — no hace falta un `docker exec` aparte para verlo (también queda una copia en `/tmp/sglang_omni.log` dentro del contenedor, por si hace falta revisarlo después de que el contenedor ya se cerró, vía `docker cp` antes de que se elimine).

Buscar la línea `gRPC escuchando en 0.0.0.0:50051` como confirmación de arranque completo.

---

## 3.5 Generar los stubs para correr `client_test.py` desde el host

`client_test.py` corre en tu terminal, **fuera** del contenedor — necesita `tts_service_pb2.py` y `tts_service_pb2_grpc.py`, que se generan a partir de `tts_service.proto` dentro del build pero no salen automáticamente de la imagen. Hay que extraerlos una vez, después del build:

```bash
docker run --rm \
    -v /ruta/a/tts_sglang:/host \
    --entrypoint /opt/venv-omni/bin/python \
    fish-tts-s2-pro-sglang-grpc:1.0.0 \
    -c "
import sys, grpc_tools.protoc
grpc_tools.protoc.main([
    'grpc_tools.protoc', '-I', '/host',
    '--python_out=/host', '--grpc_python_out=/host',
    '/host/tts_service.proto'
])
print('OK')
"
```

Esto usa el mismo `protoc`/`grpcio-tools` que corre dentro de la imagen (garantiza compatibilidad de versión con el servidor real) y deja los dos archivos generados directamente en tu carpeta `tts_sglang/`, junto a `client_test.py`.

Como el contenedor corre como root, corrige el dueño de los archivos generados:

```bash
sudo chown $(whoami):$(whoami) /ruta/a/tts_sglang/tts_service_pb2*.py
```

`client_test.py` también necesita `grpcio` instalado en el Python de tu host (no el del contenedor):

```bash
pip3 install grpcio
```

Con eso, el cliente ya puede correr desde tu terminal normal, apuntando al puerto publicado (`-p 50051:50051` en el `docker run` de la sección 3):

```bash
cd tts_sglang
python3 client_test.py \
    --text "Hola, esta es una prueba." \
    --voice vanessa \
    --output /tmp/test.opus
```

**Nota**: en la validación en RTX 5070 Ti, el servidor nunca completó el arranque (falla en el vocoder por VRAM insuficiente, ver sección 1) — en esa GPU, `client_test.py` solo sirve para confirmar que la conexión gRPC se establece, no para obtener una síntesis real. La primera síntesis real solo se puede confirmar en H200.

---

## 4. Primera síntesis de prueba — y los puntos pendientes de validar

⚠️ **Importante**: durante la validación en RTX 5070 Ti nunca se completó una síntesis real de punta a punta (el vocoder llegó a cargar solo en el último intento, con `mem_fraction_static=0.52`, pero esa configuración dejaba el KV cache demasiado pequeño para procesar cualquier request real). Esto significa que **la traducción exacta de parámetros hacia la API HTTP de `sgl-omni serve` no está 100% confirmada empíricamente** — está basada en la documentación investigada, con las siguientes suposiciones marcadas explícitamente en `server.py`:

1. **Campo de audio de referencia**: se asume `"references": [{"audio_path": ..., "text": ...}]`. Si la primera síntesis falla con un error de validación de payload, este es el primer campo a revisar — el error debería verse directamente en `docker logs`, con el prefijo `[sglang-omni]`.
2. **Formato de evento SSE en streaming**: se asume `{"audio": "<base64>"}` o variantes (`chunk.audio`, `data`) dentro de cada línea `data: {...}` del stream. Si `TTSStream()` no produce audio o produce silencio, revisar el log en modo debug (`logger.warning` ya deja rastro de eventos no reconocidos).
3. **Sample rate del PCM en streaming**: se asume 44.1kHz mono 16-bit (mismo que S1-mini/S2-Pro clásico) en `pcm_chunk_to_opus()`. Si el audio en modo streaming suena a velocidad incorrecta, este es el valor a ajustar.

⚠️ **Riesgo adicional por operar 100% offline**: con `HF_HUB_OFFLINE=1` forzado (necesario porque el servidor no tiene internet, ver sección 2), si algún componente de `sgl-omni serve` intenta alcanzar HuggingFace por cualquier motivo durante la primera síntesis (no solo durante la carga del modelo), va a fallar explícitamente en vez de simplemente tardar más. Si el primer test falla con un error relacionado a red/conexión (no un error de validación de payload), ese es el síntoma — revisar `/tmp/sglang_omni.log` para identificar qué recurso intentó descargar, y evaluar si hace falta agregarlo al stage `model` del Dockerfile en un rebuild futuro (con internet disponible).

**Primer test recomendado — modo unary, texto corto:**

```bash
cd tts_sglang
python3 client_test.py \
    --text "Hola, esta es una prueba." \
    --voice vanessa \
    --output /tmp/test_h200_unary.opus
```

**Si funciona, segundo test — modo streaming:**

```bash
python3 client_test.py \
    --text "Hola, esta es una prueba de streaming." \
    --voice vanessa \
    --stream \
    --output /tmp/test_h200_stream.opus
```

El cliente en modo streaming imprime el *time-to-first-audio* de cada chunk — es el número que confirma si el `streaming_vocoder: true` que vimos en `Model capabilities` realmente se traduce en menor latencia percibida.

---

## 5. Medición de RTF real

Una vez confirmado que la síntesis funciona:

```bash
python3 client_test.py \
    --text "Buenos días, le llamamos de parte de su entidad financiera para confirmar los datos de su cuenta." \
    --voice vanessa \
    --output /tmp/test_rtf.opus
```

**Puntos de referencia:**
- **Piso actual de producción**: RTF ~0.43 (S2-Pro con `TTSInferenceEngine`, medido en H200 real).
- **Objetivo**: cualquier mejora sobre 0.43 ya es un avance, según lo confirmado con el equipo — no se espera necesariamente alcanzar el RTF~0.1 de S1-mini (arquitecturalmente distinto, modelo 10x más chico).
- **Benchmark de terceros para contexto** (no confiable como objetivo, ver conversación sobre Fase 2): RTF 0.34 (single-request, reportado por el propio equipo de SGLang) a RTF 0.195 (marketing, condiciones de alta concurrencia).

---

## 6. Si algo falla — orden de diagnóstico recomendado

1. `docker logs fish-tts-s2-pro-sglang-0` — ¿el wrapper gRPC llegó a arrancar? El log de `sgl-omni serve` (prefijo `[sglang-omni]`) también aparece aquí en vivo — no hace falta un comando aparte.
2. Si el contenedor ya se cerró y necesitas revisar el log completo de `sgl-omni serve` por separado: `docker cp fish-tts-s2-pro-sglang-0:/tmp/sglang_omni.log ./sglang_omni.log` antes de eliminar el contenedor.
3. `docker exec fish-tts-s2-pro-sglang-0 sgl-omni check-gpu` — ¿la GPU es visible y con la VRAM esperada?
4. Si el error es de payload HTTP hacia `sgl-omni serve` (ver punto 4 arriba) — ajustar `_build_payload()` en `server.py` según lo que el log de `sgl-omni serve` reporte como error de validación, y reconstruir solo la capa final del Dockerfile (`docker build` reutiliza cache hasta `COPY server.py`).

---

## 7. Pendiente — no incluido en este entregable

- Migración del cliente de producción a `TTSStream()` — este RPC ya existe y es funcional en el `.proto`, pero decidir si/cuándo migrar el tráfico real es una decisión de producto, no técnica.
- Ajuste fino de `initial_codec_chunk_frames` para optimizar time-to-first-audio en streaming — dejado en `null` (default de sgl-omni: 1 frame) hasta tener datos reales de latencia en H200.
