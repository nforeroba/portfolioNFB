# Servicio TTS gRPC — Fish Audio S1-mini
## Resumen técnico completo — 20 de junio de 2026

---

## 1. Estado actual: FUNCIONAL EN PRODUCCIÓN ✅

Servicio TTS gRPC con `fishaudio/openaudio-s1-mini` operativo. Genera voz inteligible en español colombiano con clonación de voz, sin HTTP interno, llamada directa al `TTSInferenceEngine`.

---

## 2. Requerimiento

### 2.1 Descripción
Servicio TTS 100% local, sin internet en runtime, protocolo gRPC, audio Opus, voces de referencia externas, marcadores emocionales. Docker autosuficiente.

### 2.2 Modelo
**`fishaudio/openaudio-s1-mini`** — 0.5B parámetros, arquitectura DualAR. Único modelo open-source de fish-speech con soporte de marcadores emocionales. Licencia CC-BY-NC-SA-4.0 (solo uso no comercial).

### 2.3 Hardware objetivo
| Entorno | GPU | VRAM total | VRAM usada por instancia | Instancias posibles |
|---------|-----|-----------|--------------------------|---------------------|
| Desarrollo | RTX 5070 Ti | 16.3 GB | ~5.1 GB | 3 |
| Producción mínima | RTX 5090 | 32 GB | ~5.1 GB | 6 |
| Producción máxima | H200 NVL | 141 GB | ~5.1 GB | 27 |

**Nota:** El uso real de VRAM medido en producción es **5,110 MB (~5.1 GB)** por instancia con `compile: true`. Las instancias posibles son aproximadas — se recomienda dejar margen para el sistema y otros procesos.

---

## 3. Arquitectura del servicio

```
Cliente externo
      ↓ gRPC :50051
server.py (grpc.aio — asyncio nativo)
      ↓ llamada directa en memoria
TTSInferenceEngine
  ├── FishTokenizer (tiktoken, FISH_TIKTOKEN_PATTERN)
  ├── LLaMA DualAR → tokens semánticos
  └── Codec DAC (modded_dac_vq) → WAV 44100 Hz mono
      ↓
WAV → Opus 48000 Hz (pydub + ffmpeg)
      ↓ gRPC
Cliente externo
```

Sin HTTP interno. Un solo proceso Python por instancia.

### 3.1 Archivos del proyecto
```
tts_s1_mini/
├── Dockerfile
├── tts_service.proto
├── tts_service_pb2.py        ← generado (no versionar)
├── tts_service_pb2_grpc.py   ← generado (no versionar)
├── server.py
├── config_tts.json           ← montado como volumen externo
├── entrypoint.sh
├── client_test.py
└── samples/
    ├── sample.wav            (voz femenina español colombiano)
    └── sample.txt

voices/                       ← volumen externo montado en /voices
├── vanessa.wav   (33s, mono, 48000 Hz)
└── vanessa.txt   (transcripción exacta)
```

---

## 4. gRPC — Conceptos clave

### 4.1 Qué es gRPC
gRPC es un protocolo de comunicación remota desarrollado por Google. Usa HTTP/2 como transporte y Protocol Buffers (protobuf) como formato de serialización. Es binario, eficiente y fuertemente tipado.

A diferencia de REST (que usa HTTP/1.1 + JSON en texto plano), gRPC:
- Es binario — más compacto y rápido
- Es fuertemente tipado — el contrato define exactamente qué se puede enviar y recibir
- No se puede usar con `curl` — requiere clientes gRPC

### 4.2 El contrato: `tts_service.proto`
El archivo `.proto` es el contrato del servicio — define los mensajes y métodos disponibles. Es el único archivo que el cliente necesita para integrarse, independientemente del lenguaje.

```protobuf
message ServeTTSRequest {
    string text               = 1;  // Texto a sintetizar (obligatorio)
    string reference_id       = 2;  // ID de voz (vacío = default del servidor)
    float  temperature        = 3;  // 0 = usar default del config
    float  top_p              = 4;  // 0 = usar default del config
    float  repetition_penalty = 5;  // 0 = usar default del config
}

message ServeAudioResponse {
    bytes audio_bytes    = 1;  // Bytes de audio en formato Opus
    float audio_duration = 2;  // Duración en segundos
}

service TTSService {
    rpc TTS(ServeTTSRequest) returns (ServeAudioResponse);
}
```

### 4.3 Stubs — qué son y por qué se llaman así
Un **stub** es una clase generada automáticamente a partir del `.proto` que permite al cliente llamar métodos del servicio remoto como si fueran funciones locales. El stub se encarga de toda la comunicación de red — serializar el request, enviarlo por HTTP/2, recibir la respuesta y deserializarla.

El nombre "stub" viene de la ingeniería de software clásica (años 80, RPC) — en inglés significa "trozo" o "sustituto". Es un trozo de código que representa algo real que vive en otro lugar.

Los stubs se generan a partir del `.proto` en el lenguaje del cliente:
- **Python** → `grpc_tools.protoc` genera `_pb2.py` y `_pb2_grpc.py`
- **Java** → plugin Java genera clases `.java`
- **Go** → `protoc-gen-go` genera archivos `.go`
- **Node.js** → `grpc-tools` genera archivos `.js`
- **C#** → `Grpc.Tools` genera clases `.cs`

El servidor no sabe ni le importa en qué lenguaje está escrito el cliente.

### 4.4 Solicitud mínima desde cualquier cliente

La solicitud mínima solo requiere el campo `text`. Todo lo demás tiene defaults en el servidor (`config_tts.json`):

**Python:**
```python
import grpc
import tts_service_pb2
import tts_service_pb2_grpc

channel = grpc.insecure_channel("192.168.x.x:50051")
stub = tts_service_pb2_grpc.TTSServiceStub(channel)

response = stub.TTS(
    tts_service_pb2.ServeTTSRequest(
        text="Buenos días, le llamamos de parte de su entidad financiera."
    )
)

# response.audio_bytes → bytes Opus listos para usar
# response.audio_duration → duración en segundos (float)
```

El cliente recibe bytes Opus y hace con ellos lo que necesite: guardar como `.opus`, decodificar a WAV, convertir a base64, reproducir directamente, etc.

---

## 5. Receta de despliegue desde cero (Ubuntu Server sin UI)

Esta receta es para un PC de producción con Ubuntu Server, sin interfaz gráfica, accedido remotamente por SSH (Putty u otro cliente).

### Paso 0 — Prerrequisitos del sistema (requiere internet)

```bash
# Instalar Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker

# Instalar NVIDIA Container Toolkit
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
    sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
sudo apt-get update && sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

# Verificar
docker run --rm --gpus all nvidia/cuda:12.8.1-base-ubuntu24.04 nvidia-smi

# Instalar ffplay para pruebas de audio (opcional en servidor)
sudo apt-get install -y ffmpeg

# Instalar Python y grpcio para el cliente de prueba
sudo apt-get install -y python3 python3-pip
pip3 install grpcio grpcio-tools
```

### Paso 1 — Obtener token de HuggingFace

1. Ir a https://huggingface.co/fishaudio/openaudio-s1-mini y aceptar la licencia CC-BY-NC-SA-4.0
2. Ir a https://huggingface.co/settings/tokens → crear token con permisos `read`
3. Guardar el token:

```bash
mkdir -p ~/Documentos
echo "hf_xxxxxxxxxxxxxxxxxxxx" > ~/Documentos/'HF Token TTS Service.txt'
chmod 600 ~/Documentos/'HF Token TTS Service.txt'
```

### Paso 2 — Transferir archivos al servidor

Desde el PC de desarrollo, transferir por SCP:

```bash
# Desde el PC local
scp -r /ruta/local/tts_s1_mini usuario@ip_servidor:~/Documentos/
scp -r /ruta/local/voices usuario@ip_servidor:~/Documentos/
```

O usar el `.tar.gz` de la imagen si ya fue construida en otro PC:

```bash
# En el PC con la imagen construida
docker save fish-tts-service:1.0.0 | gzip > fish-tts-service-1.0.0.tar.gz

# Transferir al servidor
scp fish-tts-service-1.0.0.tar.gz usuario@ip_servidor:~/

# En el servidor — cargar la imagen
docker load < fish-tts-service-1.0.0.tar.gz
```

### Paso 3 — Construir la imagen (si no se transfirió)

```bash
cd ~/Documentos/tts_s1_mini && \
docker build \
    --build-arg HF_TOKEN=$(cat ~/Documentos/'HF Token TTS Service.txt') \
    -t fish-tts-service:1.0.0 \
    .
```

Descarga ~15 GB. Tiempo estimado: 20-40 minutos.

### Paso 4 — Habilitar puerto en el firewall

```bash
sudo ufw allow 50051/tcp
sudo ufw reload
sudo ufw status
```

### Paso 5 — Generar stubs en el servidor

```bash
docker run --rm \
    -v ~/Documentos/tts_s1_mini:/host \
    --entrypoint /app/.venv/bin/python \
    fish-tts-service:1.0.0 \
    -c "
import sys, grpc_tools.protoc
sys.path.insert(0, '/app')
grpc_tools.protoc.main([
    'grpc_tools.protoc', '-I', '/host',
    '--python_out=/host', '--grpc_python_out=/host',
    '/host/tts_service.proto'
])
print('OK')
" && chown $USER:$USER ~/Documentos/tts_s1_mini/tts_service_pb2*.py
```

### Paso 6 — Arrancar el servicio

```bash
docker run -d \
    --gpus '"device=0"' \
    -e PORT=50051 \
    -e CUDA_VISIBLE_DEVICES=0 \
    -v ~/Documentos/voices:/voices \
    -v ~/Documentos/tts_s1_mini/config_tts.json:/app/config_tts.json \
    -p 50051:50051 \
    --name fish-tts-0 \
    --restart unless-stopped \
    fish-tts-service:1.0.0
```

Con `compile: true` en el config, el primer arranque tarda ~3 minutos compilando kernels Triton.

Verificar que está listo:
```bash
docker logs fish-tts-0 | grep "gRPC escuchando"
```

### Paso 7 — Probar síntesis de voz

```bash
cd ~/Documentos/tts_s1_mini && \
python3 client_test.py \
    --text "Buenos días, le llamamos de parte de su entidad financiera." \
    --voice vanessa \
    --output /tmp/test.opus

# Verificar que el archivo tiene contenido
ls -lh /tmp/test.opus

# En servidor sin UI, verificar con ffprobe
ffprobe /tmp/test.opus 2>&1 | grep -E "Duration|Stream"
```

Si el archivo tiene duración (~5s para ese texto) y el log del servidor muestra `RESPONSE | RTF=0.23`, el servicio está funcionando.

### Paso 8 — Desconectar internet (offline definitivo)

La imagen contiene todo lo necesario. Las variables `HF_HUB_OFFLINE=1` y `TRANSFORMERS_OFFLINE=1` están seteadas — el servicio no intenta conectarse a internet en runtime.

Para verificar que funciona offline:
```bash
# Deshabilitar red (opcional, para prueba)
sudo ip link set eth0 down

# Reiniciar el contenedor
docker restart fish-tts-0

# Esperar que arranque (~3 min con compile) y probar
docker logs -f fish-tts-0
```

---

## 6. Operación del servicio

### Comandos de gestión
```bash
# Ver logs en tiempo real
docker logs -f fish-tts-0

# Ver logs del servicio
docker logs fish-tts-0 2>&1 | grep -E "INFO|ERROR"

# Detener
docker stop fish-tts-0

# Iniciar
docker start fish-tts-0

# Reiniciar
docker restart fish-tts-0

# Ver uso de VRAM
nvidia-smi
```

### Múltiples instancias en la misma GPU
```bash
# Instancia 0 — puerto 50051
docker run -d --gpus '"device=0"' -e PORT=50051 -e CUDA_VISIBLE_DEVICES=0 \
    -v ~/Documentos/voices:/voices \
    -v ~/Documentos/tts_s1_mini/config_tts.json:/app/config_tts.json \
    -p 50051:50051 --name fish-tts-0 --restart unless-stopped \
    fish-tts-service:1.0.0

# Instancia 1 — mismo puerto de GPU, puerto de host diferente
docker run -d --gpus '"device=0"' -e PORT=50052 -e CUDA_VISIBLE_DEVICES=0 \
    -v ~/Documentos/voices:/voices \
    -v ~/Documentos/tts_s1_mini/config_tts.json:/app/config_tts.json \
    -p 50052:50052 --name fish-tts-1 --restart unless-stopped \
    fish-tts-service:1.0.0
```

### Múltiples GPUs
```bash
for i in 0 1 2 3; do
    docker run -d \
        --gpus "\"device=${i}\"" \
        -e PORT=$((50051 + i)) \
        -e CUDA_VISIBLE_DEVICES=${i} \
        -v ~/Documentos/voices:/voices \
        -v ~/Documentos/tts_s1_mini/config_tts.json:/app/config_tts.json \
        -p $((50051 + i)):$((50051 + i)) \
        --name fish-tts-${i} \
        --restart unless-stopped \
        fish-tts-service:1.0.0
done
```

### Agregar nueva voz
```bash
# Copiar wav y transcripción al directorio de voces
cp nueva_voz.wav ~/Documentos/voices/nueva_voz.wav
cp nueva_voz.txt ~/Documentos/voices/nueva_voz.txt
# No requiere reiniciar el servicio
```

---

## 7. Métricas de rendimiento (RTX 5070 Ti)

| Métrica | Sin compile | Con compile |
|---------|-------------|-------------|
| VRAM usada | ~5.1 GB | ~5.1 GB |
| Tiempo arranque | ~47s | ~160s (compilación Triton) |
| Velocidad LLaMA | ~17 tok/s | ~165 tok/s |
| Bandwidth GPU | ~14 GB/s | ~141 GB/s |
| RTF | ~1.32-1.41 | ~0.23-0.25 |
| Inferencia ~100 chars | ~7s | ~1.7s |
| Inferencia ~200 chars | ~11s | ~2.4s |
| Audio generado ~100 chars | ~5s | ~5s |
| Audio generado ~200 chars | ~10.5s | ~10.5s |
| Conversión WAV→Opus | ~0.1s | ~0.1s |

Con `compile: true` el servicio genera **~4x más rápido que tiempo real**. El costo es un primer arranque más lento (~160s vs ~47s) por la compilación de kernels Triton. A partir del segundo warmup el rendimiento es pleno y estable.

---

## 8. `config_tts.json` — parámetros

```json
{
    "listen": "0.0.0.0:50051",
    "temperature": 0.66,
    "top_p": 0.65,
    "repetition_penalty": 1.4,
    "default_reference_id": "vanessa",
    "warmup_text": "Hola, esta es una prueba de síntesis de voz...",
    "warmup_reference_id": "vanessa",
    "warmup_runs": 3,
    "compile": true
}
```

| Campo | Descripción |
|-------|-------------|
| `temperature` | Aleatoriedad del sampling. Más bajo = más determinista. |
| `top_p` | Nucleus sampling. Más bajo = vocabulario más restringido. |
| `repetition_penalty` | Penaliza repetir tokens. Más alto = menos repetición. |
| `default_reference_id` | Voz usada cuando el cliente no especifica ninguna. |
| `warmup_runs` | Corridas de calentamiento al arrancar. |
| `compile` | Activa torch.compile (Triton). Recomendado `true` en producción. |

El config se monta como volumen — se puede modificar sin rebuild. Requiere reiniciar el contenedor para aplicar cambios.

---

## 9. Audio de referencia — requisitos

| Característica | Requerimiento |
|---------------|---------------|
| Canales | Mono |
| Duración | Mínimo 10-30 segundos |
| Formato | WAV PCM s16le |
| Sample rate | 44100 Hz o 48000 Hz |
| Calidad | Sin ruido de fondo, voz clara |

```bash
# Concatenar múltiples clips
for f in clip1.wav clip2.wav clip3.wav; do
    echo "file '$(pwd)/$f'"
done > /tmp/lista.txt
ffmpeg -f concat -safe 0 -i /tmp/lista.txt -acodec copy vanessa.wav -y
```

---

## 10. Marcadores emocionales

Sintaxis: `(marcador) texto a sintetizar`

**Emociones:** `(angry)` `(sad)` `(excited)` `(surprised)` `(satisfied)` `(worried)` `(nervous)` `(frustrated)` `(empathetic)` `(confident)` `(curious)` `(confused)` `(joyful)` `(sarcastic)` `(whispering)` y ~40 más.

**Sonidos no verbales:** `(laughing)` `(chuckling)` `(sobbing)` `(crying loudly)` `(sighing)` `(panting)` `(groaning)`

**Estado con S1-mini:** `(laughing)` produce efecto audible claro. Emociones sutiles tienen efecto débil en el modelo de 0.5B. La expressividad depende también del audio de referencia — una referencia neutra suprime las emociones.

---

## 11. Variables de entorno del contenedor

| Variable | Default | Descripción |
|----------|---------|-------------|
| `PORT` | `50051` | Puerto gRPC |
| `CUDA_VISIBLE_DEVICES` | — | GPU a usar (ej: `0`, `1`) |
| `LLAMA_CHECKPOINT_PATH` | `checkpoints/openaudio-s1-mini` | Ruta al LLaMA |
| `DECODER_CHECKPOINT_PATH` | `checkpoints/openaudio-s1-mini/codec.pth` | Ruta al codec |
| `DECODER_CONFIG_NAME` | `modded_dac_vq` | Arquitectura del codec |
| `HF_HUB_OFFLINE` | `1` | Sin acceso a HuggingFace |
| `TRANSFORMERS_OFFLINE` | `1` | Sin acceso a transformers hub |

---

## 12. Troubleshooting

| Síntoma | Causa | Solución |
|---------|-------|----------|
| Silencio en el audio | Audio referencia <10s o estéreo | Usar mono ≥10s |
| Audio distorsionado | Tokenizador incorrecto | Usar commit `781bf1c` sin `fish_tokenizer_patch.py` |
| `ModuleNotFoundError: tts_service_pb2` | Stubs no generados en el host | Ejecutar comando de generación de stubs |
| `ffplay` no reproduce opus | `aplay` no soporta Opus | Usar `ffplay` |
| RTF >1.5 | `compile: false` | Cambiar a `compile: true` y reiniciar |
| Arranque lento (~160s) | Compilación Triton normal con `compile: true` | Esperar — solo ocurre en el primer arranque |
| SyntaxWarning al iniciar | Warnings de pydub/audiotools (Python 3.12) | Inocuos, ignorar |

---

## 13. Notas técnicas importantes

- **Commit `781bf1c`** del repo fish-speech — era OpenAudio S1, tokenizador correcto
- **No usar `uv run`** para el api_server — revierte protobuf a 3.19.6 e incompatible con los stubs
- **No usar `--compile` con kernels Blackwell no validados** — actualmente funciona correctamente en RTX 5070 Ti
- El codec DAC de S1-mini pesa 1.87 GB y tiene 391M parámetros (vs ~74MB del DAC estándar)
- El modelo permanece en VRAM mientras el contenedor esté activo
- `--restart unless-stopped` hace que el contenedor arranque automáticamente al reiniciar el PC
- `config_tts.json` montado como volumen: cambios no requieren rebuild, solo `docker restart`

---

## 14. Descripción de archivos del proyecto

### `Dockerfile`
Define la imagen Docker en 4 stages:
- **base** — imagen CUDA 12.8.1 + Ubuntu 24.04. Instala dependencias del sistema (ffmpeg, git, libsndfile, opus, portaudio) e instala el gestor de paquetes `uv`.
- **builder** — clona `fishaudio/fish-speech` en commit `781bf1c` e instala todas las dependencias Python del proyecto con `uv sync --extra cu128` (PyTorch cu128 para GPUs Blackwell/Hopper).
- **model** — descarga el checkpoint `fishaudio/openaudio-s1-mini` desde HuggingFace usando el token provisto como build arg. Incluye `model.pth` (LLaMA DualAR, ~1.7 GB) y `codec.pth` (DAC modded_dac_vq, ~1.9 GB).
- **final** — instala dependencias del proxy gRPC (`grpcio-tools`, `grpcio[aio]`, `soundfile`, `pydub`, `numpy`), copia el proto, genera los stubs pb2, copia los archivos del servicio y define el entrypoint.

---

### `tts_service.proto`
Contrato gRPC del servicio. Define los mensajes y el método disponible:
- **`ServeTTSRequest`** — mensaje de solicitud: `text`, `reference_id`, `temperature`, `top_p`, `repetition_penalty`.
- **`ServeAudioResponse`** — mensaje de respuesta: `audio_bytes` (bytes Opus), `audio_duration` (float, segundos).
- **`TTSService`** — servicio con un único método `TTS` (unary).

Es el único archivo que el cliente necesita para integrarse, independientemente del lenguaje.

---

### `tts_service_pb2.py` + `tts_service_pb2_grpc.py`
Stubs generados automáticamente a partir de `tts_service.proto` durante el build del Dockerfile:
```bash
/app/.venv/bin/python -m grpc_tools.protoc \
    -I /app --python_out=/app --grpc_python_out=/app /app/tts_service.proto
```
- **`tts_service_pb2.py`** — clases Python para los mensajes protobuf (`ServeTTSRequest`, `ServeAudioResponse`).
- **`tts_service_pb2_grpc.py`** — clases Python para el stub del cliente (`TTSServiceStub`) y el servicer del servidor (`TTSServiceServicer`).

Los que están en el host (`tts_s1_mini/`) son una copia para que `client_test.py` pueda importarlos. No se versionan — se regeneran con el comando de la sección 5 (Paso 5).

---

### `server.py`
Núcleo del servicio. Carga el `TTSInferenceEngine` directamente al arrancar y sirve requests gRPC de forma asíncrona con `grpc.aio`. Responsabilidades:

- Lee `config_tts.json` al arrancar
- Carga el LLaMA DualAR y el codec DAC directamente en GPU
- Ejecuta warmup de síntesis al iniciar
- Implementa `TTS` (unary): recibe `ServeTTSRequest`, resuelve la voz de referencia desde `/voices/`, llama al `TTSInferenceEngine`, convierte WAV→Opus con pydub+ffmpeg, devuelve `ServeAudioResponse` con bytes Opus
- Logging detallado con tiempos en cada etapa del arranque y de cada request

La inferencia corre en un thread pool (`run_in_executor`) para no bloquear el event loop de asyncio.

---

### `entrypoint.sh`
Script bash ejecutado al iniciar el contenedor. Hace una sola cosa: arrancar `server.py` con `exec` (reemplaza el proceso bash). Sin procesos secundarios, sin health checks HTTP.

```bash
exec /app/.venv/bin/python /app/server.py \
    --port "${PORT}" \
    --config /app/config_tts.json
```

---

### `config_tts.json`
Configuración del servicio, montado como volumen externo. Parámetros:

| Campo | Valor actual | Descripción |
|-------|-------------|-------------|
| `temperature` | `0.66` | Aleatoriedad del sampling |
| `top_p` | `0.65` | Nucleus sampling |
| `repetition_penalty` | `1.4` | Penalización de repetición |
| `default_reference_id` | `vanessa` | Voz default |
| `warmup_text` | (texto largo) | Texto de calentamiento |
| `warmup_reference_id` | `vanessa` | Voz de calentamiento |
| `warmup_runs` | `3` | Corridas de warmup al arrancar |
| `compile` | `true` | Activa torch.compile (Triton) |

Cambios en este archivo no requieren rebuild — solo `docker restart fish-tts-0`.

---

### `client_test.py`
Cliente de prueba en Python para verificar el servicio desde el host. No forma parte del servicio — es una herramienta de desarrollo y verificación.

```
Argumentos:
  --host HOST               Host del servicio (default: localhost)
  --port PORT               Puerto (default: 50051)
  --text TEXT               Texto a sintetizar (obligatorio)
  --voice VOICE             ID de voz (default: voz default del servidor)
  --temperature FLOAT       Temperatura (0 = usa config del servidor)
  --top-p FLOAT             Top-p (0 = usa config del servidor)
  --repetition-penalty FLOAT Penalización (0 = usa config del servidor)
  --output FILE             Archivo de salida Opus (default: output.opus)
```

Imprime métricas por request: duración del audio, tiempo total, RTF y tamaño Opus.

---

### `samples/sample.wav` + `samples/sample.txt`
Audio de referencia de prueba incluido dentro de la imagen. Voz femenina en español colombiano. Se usa con `--voice sample` para pruebas sin necesitar el volumen externo `/voices`.
