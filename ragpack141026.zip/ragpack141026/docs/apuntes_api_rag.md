# Documentación

# 12-14 Agosto 2026

# Evidencia descarga modelo Qwen Reranker 8b

root@Bog2-cpul040547:/home/user_ia# ollama list
NAME                              ID              SIZE      MODIFIED     
dengcao/Qwen3-Reranker-8B:q8_0    20b136c51d90    8.7 GB    25 hours ago    
north-mini-code-1.0:q4_K_M        d8b269ad5c7c    18 GB     7 weeks ago     
north-mini-code-1.0:q8_0          b6c144236e03    32 GB     7 weeks ago     
translategemma:12b                c2f9a9ca1ec7    8.1 GB    7 weeks ago     
translategemma:4b                 c49d986b0764    3.3 GB    7 weeks ago     
qwen3-embedding:8b                64b933495768    4.7 GB    7 weeks ago     
qwen3-embedding:4b                df5bd2e3c74c    2.5 GB    7 weeks ago     
qwen3-embedding:0.6b              ac6da0dfba84    639 MB    7 weeks ago     
embeddinggemma:300m               85462619ee72    621 MB    7 weeks ago     
deepseek-ocr:3b                   0e7b018b8a22    6.7 GB    7 weeks ago     
nemotron3:33b                     f6d8b7ff496c    27 GB     7 weeks ago     
qwen3.5:9b                        6488c96fa5fa    6.6 GB    7 weeks ago     
phi4:14b                          ac896e5b8b34    9.1 GB    7 weeks ago     
granite4.1:8b                     444af1c4b2fe    5.3 GB    7 weeks ago     
granite4.1:3b                     6fd349357287    2.1 GB    7 weeks ago     
qwen3:14b                         bdbd181c33f2    9.3 GB    7 weeks ago     
mathstral:7b                      4ee7052be55a    4.1 GB    7 weeks ago     
gpt-oss:120b                      a951a23b46a1    65 GB     7 weeks ago     
gpt-oss:20b                       17052f91a42e    13 GB     7 weeks ago     
glm-ocr:bf16                      6effedd0dc8a    2.2 GB    7 weeks ago     
glm-ocr:q8_0                      2a5a0f1a9301    1.6 GB    7 weeks ago     
qwen3:30b-a3b                     ad815644918f    18 GB     7 weeks ago     
qwen3-coder:30b                   06c1097efce0    18 GB     7 weeks ago     
glm-4.7-flash:q4_K_M              4475827791a2    19 GB     7 weeks ago     
gemma4:e2b                        7fbdbf8f5e45    7.2 GB    7 weeks ago     
gemma4:e4b                        c6eb396dbd59    9.6 GB    7 weeks ago     
gemma4:12b                        4eb23ef187e2    7.6 GB    7 weeks ago     
gemma4:26b                        5571076f3d70    17 GB     7 weeks ago     
llama3.2:1b                       baf6a787fdff    1.3 GB    7 weeks ago     
llama3.2:3b                       a80c4f17acd5    2.0 GB    7 weeks ago     

# Evidencia descarga contenedor vLLM parcheado para Qwen3-0.6b en ASUS Spark

root@Bog2-cpul040547:/home/user_ia# ip addr | grep "inet "
    inet 127.0.0.1/8 scope host lo
    inet 192.168.10.211/24 brd 192.168.10.255 scope global dynamic noprefixroute enP7s7
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
root@Bog2-cpul040547:/home/user_ia# 

root@Bog2-cpul040547:/home/user_ia# docker pull hellohal2064/vllm-dgx-spark-gb10
Using default tag: latest
latest: Pulling from hellohal2064/vllm-dgx-spark-gb10
523b48785243: Pull complete 
7316858f521f: Pull complete 
b84df8e9e1a9: Pull complete 
43065e3a596b: Pull complete 
e21358941534: Pull complete 
59acae7a4756: Pull complete 
ad9ee086717e: Pull complete 
a69c8b8a5a6f: Pull complete 
4dbb572cf91d: Pull complete 
3c30bec40d0e: Pull complete 
8300bfbba18d: Pull complete 
4d2d54aa3b8f: Pull complete 
9c2a0c9e8551: Pull complete 
66d8df3947b8: Pull complete 
5e91a6d77ef2: Pull complete 
5989edcbf011: Pull complete 
4f4fb700ef54: Pull complete 
c72f1c7b8211: Pull complete 
8bbc001f607f: Pull complete 
7e4251239c35: Pull complete 
Digest: sha256:d6642f8b43b702d57104c75fc6a7d419d980021c352fafceca5509ba9d51171b
Status: Downloaded newer image for hellohal2064/vllm-dgx-spark-gb10:latest
docker.io/hellohal2064/vllm-dgx-spark-gb10:latest
root@Bog2-cpul040547:/home/user_ia# 

# Evidencia del contenedor descargado en docker images

root@Bog2-cpul040547:/home/user_ia# docker images
                                                                                     i Info →   U  In Use
IMAGE                                     ID             DISK USAGE   CONTENT SIZE   EXTRA
192.168.10.210:5000/dummy-test:v1         7a8a0961fe14       8.66MB             0B        
192.168.10.210:5000/dummy-test:v2         f28c258bd2ce       8.66MB             0B        
192.168.10.210:5000/hello-world:latest    eb84fdc6f2a3        5.2kB             0B    U   
192.168.10.210:5000/mineru-vlm:1.0.0      8be4e8ce280e       25.2GB             0B    U   
fish-tts-service:1.0.0                    65ab0d28e530       22.4GB             0B    U   
hello-world:latest                        eb84fdc6f2a3        5.2kB             0B    U   
hellohal2064/vllm-dgx-spark-gb10:latest   6fb7417017af       22.2GB             0B        
llama-gb10:latest                         886107df1d7c       7.28GB             0B        
llm-tipificador:1.0.0                     837ba49de1ab       61.5GB             0B    U   
mineru-api-wrapper:1.0.0                  00bc5bbbba20       9.54GB             0B    U   
nemotron-omni-vllm:v1                     6ff2a38aa965       23.9GB             0B        
qdrant/qdrant:latest                      4cf05bbc19d3        202MB             0B    U   
stt-dev-c:latest                          1725e598599f       21.6GB             0B    U   
stt-dev-d:latest                          85beccfa8e53       29.8GB             0B    U   
stt-dev-f:latest                          7d1a34c2904d       26.6GB             0B    U   
stt-grpc:latest                           c32f3850039f       20.8GB             0B    U   
vllm/vllm-openai:cu130-nightly            ffa30d66ff5c       23.3GB             0B        
vllm/vllm-openai:v0.20.0                  bf05c8a0d56f       23.6GB             0B        
whisper-dev:latest                        2dff848e630b       9.01GB             0B    U   
root@Bog2-cpul040547:/home/user_ia# 

# Evidencia descarga del modelo qwen3-0.6b

(nemotron-venv) root@Bog2-cpul040547:/home/user_ia# ls
Desktop  PruebasEscucha  api_rag_prototipo  mineru_api_wrapper  models            qwen3_30b_a3b_it_2507
LLMCPP   WhisperCPP      gemma4_26b_moe     mineru_mini_front   nemotron_30b_moe  voices
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia# cd api_rag_prototipo/
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo# ls
qdrant_storage  qwen3_0_6_b
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo# cd qwen3_0_6_b/
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# ls
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# huggingface-cli download Qwen/Qwen3-Embedding-0.6B \
  --local-dir /home/user_ia/api_rag_prototipo/qwen3_0_6_b \
  --token $(cat /home/user_ia/.hft)
Warning: `huggingface-cli` is deprecated and no longer works. Use `hf` instead.

Hint: `hf` is already installed! Use it directly.

Hint: Examples:
  hf auth login
  hf download unsloth/gemma-4-31B-it-GGUF
  hf upload my-cool-model . .
  hf models ls --search "gemma"
  hf repos ls --format json
  hf jobs run python:3.12 python -c 'print("Hello!")'
  hf --help

(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# hf download Qwen/Qwen3-Embedding-0.6B \
  --local-dir /home/user_ia/api_rag_prototipo/qwen3_0_6_b \
  --token $(cat /home/user_ia/.hft)
Fetching 12 files: 100%|███████████████████████████████████████████████| 12/12 [28:10<00:00, 140.88s/it]
Download complete: 100%|███████████████████████████████████████████| 1.21G/1.21G [28:10<00:00, 2.18MB/s]✓ Downloaded
  path: /home/user_ia/api_rag_prototipo/qwen3_0_6_b
Download complete: 100%|████████████████████████████████████████████| 1.21G/1.21G [28:10<00:00, 714kB/s]
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# 

(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# ls
1_Pooling    config_sentence_transformers.json  model.safetensors  tokenizer_config.json
README.md    generation_config.json             modules.json       vocab.json
config.json  merges.txt                         tokenizer.json
(nemotron-venv) root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# 

# Evidencia de ejecución del contenedor de QDRANT

- Maneja dos puertos, uno HTTP y otro gRPC:

root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo# mkdir -p /home/user_ia/api_rag_prototipo/qdrant_storage
root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo# ls
qdrant_storage
root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo# docker run -d \
  --name qdrant \
  -p 6333:6333 \
  -p 6334:6334 \
  -v /home/user_ia/api_rag_prototipo/qdrant_storage:/qdrant/storage \
  qdrant/qdrant && docker logs -f qdrant
24ec970120a0c6997fd5d67c7c4588b3ed50631b51a2f2e61577c2dc462703e7
           _                 _    
  __ _  __| |_ __ __ _ _ __ | |_  
 / _` |/ _` | '__/ _` | '_ \| __| 
| (_| | (_| | | | (_| | | | | |_  
 \__, |\__,_|_|  \__,_|_| |_|\__| 
    |_|                           

Version: 1.19.0, build: 74f3e85b
Access web UI at http://localhost:6333/dashboard
Agentic Skills: https://skills.qdrant.tech/

2026-08-13T20:45:11.882255Z  INFO storage::content_manager::consensus::persistent: Initializing new raft state at ./storage/raft_state.json
2026-08-13T20:45:11.898000Z  INFO qdrant: Distributed mode disabled
2026-08-13T20:45:11.898101Z  INFO qdrant: Telemetry reporting enabled, id: e6e3be9c-7014-4f56-8810-26ff3286a6cb
2026-08-13T20:45:11.914136Z  INFO qdrant::actix: REST transport settings: keep_alive=5s, client_request_timeout=5s, client_disconnect_timeout=5s
2026-08-13T20:45:11.914156Z  INFO qdrant::actix: TLS disabled for REST API
2026-08-13T20:45:11.914264Z  INFO qdrant::actix: Qdrant HTTP listening on 6333
2026-08-13T20:45:11.914328Z  INFO actix_server::builder: starting 19 workers
2026-08-13T20:45:11.914409Z  INFO actix_server::server: Actix runtime found; starting in Actix runtime
2026-08-13T20:45:11.914411Z  INFO actix_server::server: starting service: "actix-web-service-0.0.0.0:6333", workers: 19, listening on: 0.0.0.0:6333
2026-08-13T20:45:11.915990Z  INFO qdrant::tonic: Qdrant gRPC listening on 6334
2026-08-13T20:45:11.916007Z  INFO qdrant::tonic: TLS disabled for gRPC API


- El puerto para HTTP, el 6333, sirve para diagnóstico mediante página web:

# http://localhost:6333/dashboard#/welcome

Versión de Qdrant: 1.19.0

El link lleva a un dashboard con varios vínculos en el panel lateral izquierdo:

## Welcome

- Get started with vector search in Qdrant (view quickstart)
- Getting Started Resources: Agent Skills, API Reference, Sample Data
- Interactive Tutorials: filtering (beginner, advenced, full text), multivector search, sparse vector search, hybrid search, multitenancy

## Console

La página web local tiene una consola embebida para ejecutar comandos de búsqueda, e.g.:

- Comando:
// List all collections
GET collections

- Resultado:
{
  "result": {
    "collections": [
      {
        "name": "qdrant_web_docs"
      }
    ]
  },
  "status": "ok",
  "time": 0.000004528
}

- Comando:
// Get collection info
GET collections/qdrant_web_docs

- Resultado:
{
  "result": {
    "status": "green",
    "optimizer_status": "ok",
    "indexed_vectors_count": 18828,
    "points_count": 18828,
    "segments_count": 2,
    "config": {
      "params": {
        "vectors": {
          "size": 384,
          "distance": "Cosine"
        },
        "shard_number": 1,
        "replication_factor": 1,
        "write_consistency_factor": 1,
        "on_disk_payload": true
      },
      "hnsw_config": {
        "m": 16,
        "ef_construct": 100,
        "full_scan_threshold": 10000,
        "max_indexing_threads": 0,
        "on_disk": false
      },
      "optimizer_config": {
        "deleted_threshold": 0.2,
        "vacuum_min_vector_number": 1000,
        "default_segment_number": 0,
        "max_segment_size": null,
        "memmap_threshold": null,
        "indexing_threshold": 10000,
        "flush_interval_sec": 5,
        "max_optimization_threads": 1,
        "prevent_unoptimized": null
      },
      "wal_config": {
        "wal_capacity_mb": 32,
        "wal_segments_ahead": 0,
        "wal_retain_closed": 1
      },
      "quantization_config": null
    },
    "payload_schema": {
      "sections": {
        "data_type": "keyword",
        "points": 18828
      },
      "text": {
        "data_type": "text",
        "params": {
          "type": "text",
          "tokenizer": "prefix",
          "min_token_len": 1,
          "max_token_len": 20,
          "lowercase": true
        },
        "points": 18732
      },
      "tag": {
        "data_type": "keyword",
        "points": 18828
      }
    },
    "update_queue": {
      "length": 0
    }
  },
  "status": "ok",
  "time": 0.000400289
}

- Comando:
// List points in a collection
POST collections/qdrant_web_docs/points/scroll
{
  "limit": 3,
  "with_payload": true
}

- Resultado:
{
  "result": {
    "points": [
      {
        "id": 0,
        "payload": {
          "location": "html > body > div:nth-of-type(1) > div:nth-of-type(1) > div > section > article > ul > li:nth-of-type(1)",
          "sections": [
            "articles",
            "articles/rag-is-dead"
          ],
          "tag": "li",
          "text": "Home",
          "titles": [
            "RAG is Dead. Long Live RAG! - Qdrant"
          ],
          "url": "/articles/rag-is-dead/"
        }
      },
      {
        "id": 1,
        "payload": {
          "location": "html > body > div:nth-of-type(1) > div:nth-of-type(1) > div > section > article > ul > li:nth-of-type(2)",
          "sections": [
            "articles",
            "articles/rag-is-dead"
          ],
          "tag": "li",
          "text": "/",
          "titles": [
            "RAG is Dead. Long Live RAG! - Qdrant"
          ],
          "url": "/articles/rag-is-dead/"
        }
      },
      {
        "id": 2,
        "payload": {
          "location": "html > body > div:nth-of-type(1) > div:nth-of-type(1) > div > section > article > ul > li:nth-of-type(3)",
          "sections": [
            "articles",
            "articles/rag-is-dead"
          ],
          "tag": "li",
          "text": "Articles",
          "titles": [
            "RAG is Dead. Long Live RAG! - Qdrant"
          ],
          "url": "/articles/rag-is-dead/"
        }
      }
    ],
    "next_page_offset": 3
  },
  "status": "ok",
  "time": 0.000620209
}

- Comando:
POST collections/qdrant_web_docs/points/scroll
{
  "limit": 2,
  "filter": {
    "must": [
      {
        "key": "sections",
        "match": {
          "any": ["articles"]
        }
      }
    ]
  }
}

- Resultado:
{
  "result": {
    "points": [
      {
        "id": 0,
        "payload": {
          "location": "html > body > div:nth-of-type(1) > div:nth-of-type(1) > div > section > article > ul > li:nth-of-type(1)",
          "sections": [
            "articles",
            "articles/rag-is-dead"
          ],
          "tag": "li",
          "text": "Home",
          "titles": [
            "RAG is Dead. Long Live RAG! - Qdrant"
          ],
          "url": "/articles/rag-is-dead/"
        }
      },
      {
        "id": 1,
        "payload": {
          "location": "html > body > div:nth-of-type(1) > div:nth-of-type(1) > div > section > article > ul > li:nth-of-type(2)",
          "sections": [
            "articles",
            "articles/rag-is-dead"
          ],
          "tag": "li",
          "text": "/",
          "titles": [
            "RAG is Dead. Long Live RAG! - Qdrant"
          ],
          "url": "/articles/rag-is-dead/"
        }
      }
    ],
    "next_page_offset": 2
  },
  "status": "ok",
  "time": 0.000510369
}

## Collections

### Al principio no hay nada, pero descargué desde el mismo dashboard un dataset llamado 'Qdrant Web Documentation', lo nombré **qdrant_web_docs**:

- Tiene 18828 points, 2 segments, 1 shard, vectores de 384 dimensiones y método de similitud por coseno

- En menú actions, están las opciones: snapshots, visualize, graph, refresh y delete

### Visualize: permite ver los puntos respecto a sí mismos en una visual interactiva:

- En la pestaña Code:

'''
// Try me!

{
  "limit": 2000
}

// Specify request parameters to select data for visualization.
//
// Distances between points are computed by Qdrant server-side
// (Distance Matrix API), so raw vectors are not transferred to the browser.
//
// Available parameters:
//
// - 'limit': number of points to sample for visualization.
//            UMAP (default) handles tens of thousands of points;
//            TSNE and PCA get slow above a few thousand.
//
// - 'n_neighbors': number of nearest neighbors per point to request
//                  from the server. Default: 15.
//
// - 'filter': filter expression to select vectors for visualization.
//             See https://qdrant.tech/documentation/concepts/filtering/
//
// - 'color_by': specify score or payload field to use for coloring points.
//               How to use:
//
//                "color_by": {
//                  "payload": "field_name"
//                }
//
// - 'using': specify which vector to use for visualization
//                  if there are multiple.
//
// - 'algorithm': specify algorithm to use for visualization.
//                Available options: 'UMAP' (default), 'TSNE',
//                'PCA' (loads raw vectors into the browser).
//
// - 'perplexity': TSNE only, effective number of neighbors per point.
//                 The request automatically fetches 3x this many
//                 neighbors from the server. Default: derived
//                 from 'n_neighbors'.
//
// - 'highlight': emphasize points matching a filter, dim the rest:
//
//                "highlight": {
//                  "filter": { ... }
//                }
//
// Chart interactions:
//
// - click a point to see its payload and its nearest neighbors
// - shift+drag to select points: the selection is emphasized and
//   the Selection tab opens, where selected points can be inspected
//   and copied (ids, JSON or a ready-to-use filter);
//   close the selection tag to reset it
// - drag to pan, mouse wheel to zoom
'''

Al ejecutar el comando anterior, los n puntos especificados en el 'limit' aparecen en pantalla y se empiezan a agrupar mediante un algoritmo no lineal de reducción de dimensionalidad llamado UMAP.

- En la pestaña Data Panel (Select a point to see its data preview), aparece información (payload) en función del punto o los puntos que seleccione y puntos similares con score.

e.g. Point 12103

{"location":"html > body > div:nth-of-type(1) > div > section > div > div > div > div > div:nth-of-type(2) > div > div > div > div:nth-of-type(2) > article > p:nth-of-type(1)","sections":["tags","tags/retriever-ranker-architecture"],"tag":"p","text":"How did Nicolas Mauti and the team at Malt identify the need to transition to a retriever-ranker architecture for their freelancer matching app?","titles":["Retriever-Ranker Architecture - Qdrant"],"url":"/tags/retriever-ranker-architecture/"}

### También están las opciones 'Create Collection' y 'Upload Snapshot'

### Cuando doy click en el nombre de la colección, aparecen varias pestañas:

- **Points:** aparece el JSON del payload de cada punto, con opciones de copiar, borrar, filtrar, editar, abrir grafo y encontrar similar PARA CADA PUNTO. Cuando se abre el grafo, se puede ver el punto rodeado de 5 puntos en una visual interactiva, y su payload, así como el código. Si se cambia el limit, parece una miscena o diente de león.

{
  "limit": 5
}

// Parameters for expansion request:
//
// Available parameters:
//
// - 'limit': number of records to use on each step.
// - 'sample': bootstrap graph with sample data from collection.
//
// - 'filter': filter expression to select vectors for visualization.
//             See https://qdrant.tech/documentation/concepts/filtering/
//
// - 'using': specify which vector to use for visualization
//                  if there are multiple.
//
// - 'tree': if true, will use show spanning tree instead of full graph.

- **Info:** Aparece un JSON con toda la información de la colección, y las secciones Payload Indexes y Collection Cluster Info.

{"status":"green","optimizer_status":"ok","indexed_vectors_count":18828,"points_count":18828,"segments_count":2,"config":{"params":{"vectors":{"size":384,"distance":"Cosine"},"shard_number":1,"replication_factor":1,"write_consistency_factor":1,"on_disk_payload":true},"hnsw_config":{"m":16,"ef_construct":100,"full_scan_threshold":10000,"max_indexing_threads":0,"on_disk":false},"optimizer_config":{"deleted_threshold":0.2,"vacuum_min_vector_number":1000,"default_segment_number":0,"max_segment_size":null,"memmap_threshold":null,"indexing_threshold":10000,"flush_interval_sec":5,"max_optimization_threads":1,"prevent_unoptimized":null},"wal_config":{"wal_capacity_mb":32,"wal_segments_ahead":0,"wal_retain_closed":1},"quantization_config":null},"payload_schema":{"text":{"data_type":"text","params":{"type":"text","tokenizer":"prefix","min_token_len":1,"max_token_len":20,"lowercase":true},"points":18732},"tag":{"data_type":"keyword","points":18828},"sections":{"data_type":"keyword","points":18828}},"update_queue":{"length":0}}

{
"status":"green"// Current state of the collection.
"optimizer_status":"ok"// Current state of the collection
"indexed_vectors_count":18828// Approximate number of indexed vectors in the collection.
"points_count":18828// Approximate number of points (vectors + payloads) in collect…
"segments_count":2// Number of segments in collection.
"config":{
"params":{
"vectors":{
"size":384// Size of a vectors used
"distance":"Cosine"// Type of internal tags, build from payload Distance function …
}
"shard_number":1// Number of shards the collection has
"replication_factor":1// Number of replicas for each shard
"write_consistency_factor":1// Defines how many replicas should apply the operation for us …
"on_disk_payload":true// Deprecated: use payload.memory instead.
}
"hnsw_config":{
"m":16// Number of edges per node in the index graph.
"ef_construct":100// Number of neighbours to consider during the index building.
"full_scan_threshold":10000// Minimal size threshold (in KiloBytes) below which full-scan …
"max_indexing_threads":0// Number of parallel threads used for background index buildin…
"on_disk":false// Deprecated: use memory instead.
}
"optimizer_config":{
"deleted_threshold":0.2// The minimal fraction of deleted vectors in a segment, requir…
"vacuum_min_vector_number":1000// The minimal number of vectors in a segment, required to perf…
"default_segment_number":0// Target amount of segments optimizer will try to keep.
"max_segment_size":null// Do not create segments larger this size (in kilobytes).
"memmap_threshold":null// Maximum size (in kilobytes) of vectors to store in-memory pe…
"indexing_threshold":10000// Maximum size (in kilobytes) of vectors allowed for plain ind…
"flush_interval_sec":5// Minimum interval between forced flushes.
"max_optimization_threads":1// Max number of threads (jobs) for running optimizations per s…
"prevent_unoptimized":null// If enabled, the service will try to prevent the creation of …
}
"wal_config":{
"wal_capacity_mb":32// Size of a single WAL segment in MB
"wal_segments_ahead":0// Number of WAL segments to create ahead of actually used ones
"wal_retain_closed":1// Number of closed WAL segments to keep
}
"quantization_config":null
}
"payload_schema":{
"text":{
"data_type":"text"// All possible names of payload types
"params":{
"type":"text"
"tokenizer":"prefix"
"min_token_len":1// Minimum characters to be tokenized.
"max_token_len":20// Maximum characters to be tokenized.
"lowercase":true// If true, lowercase all tokens.
}
"points":18732// Number of points indexed with this index
}
"tag":{
"data_type":"keyword"// All possible names of payload types
"points":18828// Number of points indexed with this index
}
"sections":{
"data_type":"keyword"// All possible names of payload types
"points":18828// Number of points indexed with this index
}
}
"update_queue":{
"length":0// Number of elements in the queue
}
}

- **Optimizations:** Muestra los paneles Optimization Progress, Timeline y Optimization Tree.

- **Memory:** Permite ver métricas de uso de RAM (en este caso URAM) y SSD. Disclaimer: RAM measurements are approximate. Actual memory usage can be up to 20% higher than reported due to allocator overhead and runtime factors. Aparecen gráficos de barras pero cuando se copia, se obtiene el JSON subyacente:

{"result":{"total":{"disk_bytes":170143519,"ram_bytes":10192693,"cached_bytes":88074868,"expected_cache_bytes":37600100},"vectors":[{"name":"","storage":{"disk_bytes":35651284,"ram_bytes":0,"cached_bytes":33553968,"expected_cache_bytes":35651284},"index":{"disk_bytes":1948816,"ram_bytes":0,"cached_bytes":1948516,"expected_cache_bytes":1948816}}],"sparse_vectors":[],"payload":{"disk_bytes":69272130,"ram_bytes":0,"cached_bytes":7332224,"expected_cache_bytes":0},"payload_index":[{"name":"sections","usage":{"disk_bytes":10834099,"ram_bytes":1310599,"cached_bytes":5243136,"expected_cache_bytes":0}},{"name":"tag","usage":{"disk_bytes":9954960,"ram_bytes":536032,"cached_bytes":5243136,"expected_cache_bytes":0}},{"name":"text","usage":{"disk_bytes":42086842,"ram_bytes":6881870,"cached_bytes":34603264,"expected_cache_bytes":0}}],"other":{"id_tracker":{"disk_bytes":395388,"ram_bytes":1464192,"cached_bytes":150624,"expected_cache_bytes":0}}},"status":"ok","time":0.001769108}

- **Cluster:** No sé que hace, solo dice 'Distributed mode is not enabled for this cluster.' Posiblemente es porque solo es un nodo y no está habilitado un modo multi-nodo, i.e. cluster. En teoría al arrancar el contenedor con QDRANT__CLUSTER__ENABLED=true se habilitan esas opciones. **Se puede dejar como perspectiva, porque una configuración multinodo permitiría tener espejos como respaldo ante la caída de algún servidor**.

- **ANN Recall:** En Qdrant, ANN recall es una medida de qué tan bien la búsqueda aproximada de vecinos (Approximate Nearest Neighbors) encuentra los mismos resultados que encontrarías con una búsqueda exacta.

*Supón que buscas los 10 vectores más similares a tu query:

  > Búsqueda exacta → encuentra los 10 vecinos reales.
  > ANN con HNSW → intenta encontrarlos más rápido, pero puede equivocarse y devolver algunos diferentes.

*Si ANN encuentra 9 de esos 10, tienes:

  > Recall@10 = 9 / 10 = 90%

*Fórmula:

  > Recall@k = resultados correctos encontrados por ANN / top-k resultados de la búsqueda exacta

*El panel de ANN Recall tiene modo sencillo y modo avanzado. Indica:

> Vector Name: Default Vector
> Size: 384
> Distance: Cosine
> Recall: 84.50 %

*En modo avanzado indica:


// Run this code to estimate ANN recall versus exact search
{
  "limit": 10,

  "params": {
    "hnsw_ef": 128
  }
}

// You can specify filters and different vector fields
// {
//   "limit": 100,
//   "using": "vector_name",
//   "filter": {
//     "must": {
//       "key": "field_name",
//       "match": {
//         "value": "field_value"
//       }
//     }
//   },
//  "timeout": 20
// }

*Y se puede obtener un reporte del proceso:

"[8/14/2026, 3:34:32 PM] Mean recall@10 for collection: 0.845 ± 0.2583\n[8/14/2026, 3:34:32 PM] Point 99 (100/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 98 (99/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 97 (98/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 96 (97/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 95 (96/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 94 (95/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 93 (94/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 92 (93/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 91 (92/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 90 (91/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 89 (90/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 88 (89/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 87 (88/100) recall@10: 0.3 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 86 (87/100) recall@10: 0.1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 85 (86/100) recall@10: 0.3 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 84 (85/100) recall@10: 0.2 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 83 (84/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 82 (83/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 81 (82/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 80 (81/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 79 (80/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 78 (79/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 77 (78/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 76 (77/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 75 (76/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 74 (75/100) recall@10: 1 (search time: \"exact\" 3ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 73 (74/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 72 (73/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 71 (72/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 70 (71/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 2ms)\n[8/14/2026, 3:34:32 PM] Point 69 (70/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 68 (69/100) recall@10: 0 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 67 (68/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 66 (67/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 65 (66/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 64 (65/100) recall@10: 0.6 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 63 (64/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 62 (63/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 61 (62/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 60 (61/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 59 (60/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 58 (59/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 57 (58/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 56 (57/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 55 (56/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:32 PM] Point 54 (55/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 53 (54/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 52 (53/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 51 (52/100) recall@10: 0 (search time: \"exact\" 2ms; \"regular\" 0ms)\n[8/14/2026, 3:34:31 PM] Point 50 (51/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 49 (50/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 48 (49/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 47 (48/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 46 (47/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 45 (46/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 44 (45/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 43 (44/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 42 (43/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 41 (42/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 40 (41/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 39 (40/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 38 (39/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 37 (38/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 36 (37/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 35 (36/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 34 (35/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 33 (34/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 32 (33/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 31 (32/100) recall@10: 0.5 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 30 (31/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 29 (30/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 28 (29/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 27 (28/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 26 (27/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 25 (26/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 24 (25/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 23 (24/100) recall@10: 0.4 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 22 (23/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 21 (22/100) recall@10: 0.4 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 20 (21/100) recall@10: 0.7 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 19 (20/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 18 (19/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 17 (18/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 16 (17/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 15 (16/100) recall@10: 0.5 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 14 (15/100) recall@10: 0.7 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 13 (14/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 12 (13/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 11 (12/100) recall@10: 0.8 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 10 (11/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 9 (10/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 8 (9/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 7 (8/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 6 (7/100) recall@10: 0.9 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 5 (6/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 4 (5/100) recall@10: 1 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 3 (4/100) recall@10: 0.3 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 2 (3/100) recall@10: 0.1 (search time: \"exact\" 2ms; \"regular\" 0ms)\n[8/14/2026, 3:34:31 PM] Point 1 (2/100) recall@10: 0.3 (search time: \"exact\" 2ms; \"regular\" 1ms)\n[8/14/2026, 3:34:31 PM] Point 0 (1/100) recall@10: 0.2 (search time: \"exact\" 1ms; \"regular\" 0ms)\n[8/14/2026, 3:34:31 PM] Starting measuring recall@10 on 100 requests for: Default vector\n"

*Qué es hnsw_ef?

  > HNSW (Hierarchical Navigable Small World) es el algoritmo que usa Qdrant para hacer búsquedas vectoriales eficientes, intercambiando algo de exactitud por velocidad.
  
  > El parámetro que más directamente afecta el compromiso de velocidad del recall vs. exactitud del recall es el hnsw_ef:

  >> **hnsw_ef más alto:** busca más candidatos, mejor recall, más latencia.
  >> **hnsw_ef más bajo:** busca menos candidatos, menor latencia, potencialmente peor recall.

*Importante: recall no es "qué tan buenos son los embeddings". Recall de ANN mide la calidad de la búsqueda aproximada comparándola con la búsqueda exacta. No mide directamente si tu modelo de embeddings representa bien la semántica. Por ejemplo, si tu embedding es malo pero Qdrant encuentra perfectamente los vecinos según ese embedding, puedes tener 99.9% de ANN recall y aun así obtener resultados semánticamente malos.

- **Snapshot:** Es una copia de seguridad o imagen exacta de una colección o de todo el almacenamiento en un momento puntual. Guarda los vectores, los datos asociados y la estructura del índice listos para restaurar el sistema con rapidez. Sirve para:

  >> Copias de seguridad: permite guardar el estado de los datos para prevenir pérdidas por fallos.
  >> Migración de datos: facilita mover información de un servidor o clúster a otro.
  >> Recuperación rápida: restaura una colección a un estado anterior de forma sencilla mediante su API.

*Características principales:

  >> Formato: archivo comprimido con extensión .snapshot.
  >> Alcance: se puede hacer de una sola colección específica o de todo el nodo/clúster.
  >> Gestión por API: Qdrant ofrece rutas HTTP/REST para crear, listar, descargar y recuperar estos archivos de manera programática.

## Tutorial

Trae varios tutoriales, e.g. filtering, multivector search, sparse vector search, hybrid search, etc. **Me interesa el de Multitenancy, pero sería parte de otra incidencia.**

**Multitenancy allows you to host multiple tenants or clients within a single instance of Qdrant, ensuring data isolation and access control between tenants. This feature is essential for use cases where you need to serve different clients while maintaining separation of their data.**

## Datasets

Trae 3 datasets de prueba para importar como colecciones:

- Qdrant Web Documentation: 18828 vectors, 384 dims, cosine similarity, all-MiniLM-L6-v2 embedding model
- Prefix Cache: 163075 vectors, 384 dims, cosine similarity, all-MiniLM-L6-v2 embedding model 
- Midjourney Styles: 5417 vectors, 512 dims, cosine similarity, clip-ViT-B-16 embedding model

## Access Tokens

No aparece habilitado

## Settings

Permite establecer límites de memoria RAM y de almacenamiento en disco. Deshabilitado por default.

## Conclusión

Instalé y probé Qdrant en el Asus Spark 192.168.10.211. Su interfaz gráfica puede ser útil para la gestión de colecciones y benchmarks de recuperación mediante HNSW. También permite monitoreo de RAM y SSD.

################
## 18/08/2026 ##
################

Previamente ya habíamos descargado tanto el contenedor hellohal2064/vllm-dgx-spark-gb10:latest como el modelo qwen3-embedding-0.6b:

## Contenedor
hellohal2064/vllm-dgx-spark-gb10:latest   6fb7417017af       22.2GB

## Modelo
root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# ls -la
total 1179236
drwxr-xr-x 4 root root       4096 Aug 18 14:27 .
drwxr-xr-x 4 root root       4096 Aug 13 16:20 ..
drwxr-xr-x 3 root root       4096 Aug 13 16:25 .cache
-rw-r--r-- 1 root root       1570 Aug 13 16:25 .gitattributes
drwxr-xr-x 2 root root       4096 Aug 13 16:25 1_Pooling
-rw-r--r-- 1 root root      17237 Aug 13 16:25 README.md
-rw-r--r-- 1 root root        727 Aug 13 16:25 config.json
-rw-r--r-- 1 root root        215 Aug 13 16:25 config_sentence_transformers.json
-rw-r--r-- 1 root root        117 Aug 13 16:25 generation_config.json
-rw-r--r-- 1 root root    1671853 Aug 13 16:25 merges.txt
-rw-r--r-- 1 root root 1191586416 Aug 13 16:53 model.safetensors
-rw-r--r-- 1 root root        349 Aug 13 16:25 modules.json
-rw-r--r-- 1 root root   11423705 Aug 13 16:25 tokenizer.json
-rw-r--r-- 1 root root       9706 Aug 13 16:25 tokenizer_config.json
-rw-r--r-- 1 root root    2776833 Aug 13 16:25 vocab.json
root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# 

## config.json del modelo

{
  "architectures": [
    "Qwen3ForCausalLM"  // clase de modelo en Transformers que define la arquitectura; vLLM la reutiliza como backbone y le pone la cabeza de pooling encima para embeddings
  ],
  "attention_bias": false,  // las proyecciones de atención no usan término de sesgo (bias), solo pesos
  "attention_dropout": 0.0,  // sin dropout en atención; no aplica en inferencia, solo sería relevante en entrenamiento
  "bos_token_id": 151643,  // id del token que marca inicio de secuencia
  "eos_token_id": 151643,  // id del token que marca fin de secuencia (aquí coincide con el de inicio)
  "head_dim": 128,  // dimensión de cada cabeza individual de atención
  "hidden_act": "silu",  // función de activación usada en las capas feed-forward internas
  "hidden_size": 1024,  // dimensión del vector interno del modelo en cada capa (y la base de la dimensión del embedding final)
  "initializer_range": 0.02,  // desviación estándar usada para inicializar pesos al entrenar; sin efecto en inferencia
  "intermediate_size": 3072,  // dimensión interna de la capa feed-forward (más ancha que hidden_size, es normal)
  "max_position_embeddings": 32768,  // longitud máxima de contexto que el modelo puede procesar, en tokens
  "max_window_layers": 28,  // hasta qué capa aplicaría una ventana de atención deslizante, si estuviera activa
  "model_type": "qwen3",  // identifica la familia de arquitectura para que Transformers/vLLM sepan cómo cargarlo
  "num_attention_heads": 16,  // número de cabezas de atención en paralelo por capa
  "num_hidden_layers": 28,  // número total de capas (bloques transformer) apiladas
  "num_key_value_heads": 8,  // cabezas de key/value compartidas entre grupos de cabezas de atención (GQA, ahorra memoria de KV cache)
  "rms_norm_eps": 1e-06,  // valor pequeño para evitar división por cero en la normalización RMSNorm
  "rope_scaling": null,  // sin escalado adicional aplicado al esquema de posiciones RoPE
  "rope_theta": 1000000,  // parámetro base de RoPE que determina cómo codifica las posiciones para contextos largos
  "sliding_window": null,  // sin ventana de atención deslizante activa; usa atención completa
  "tie_word_embeddings": true,  // la matriz de embeddings de entrada y la de salida comparten los mismos pesos, ahorrando parámetros
  "torch_dtype": "bfloat16",  // precisión numérica en la que están guardados los pesos
  "transformers_version": "4.51.3",  // versión de la librería Transformers con la que se generó/valida esta config
  "use_cache": true,  // permite reutilizar el KV cache entre pasos (relevante para generación, no tanto para un solo embedding)
  "use_sliding_window": false,  // confirma explícitamente que la ventana deslizante está desactivada
  "vocab_size": 151669  // número total de tokens distintos que el tokenizer/modelo reconoce
}

- vLLM está tomando el backbone del modelo de lenguaje y descartando/adaptando la cabeza de generación para convertirlo en un modelo de pooling, usando la configuración que sí es específica de embeddings (1_Pooling, config_sentence_transformers.json en la carpeta del modelo). Es la forma estándar en que Qwen3-Embedding fue construido: parte del mismo backbone que los Qwen3 conversacionales, con una cabeza de pooling entrenada encima.

- Pooling: 

Cuando un modelo tipo transformer procesa una oración, no produce un solo vector, produce un vector por cada token. Si la frase "Buenos días, le habla fulanito" tiene, digamos, 9 tokens, el modelo internamente genera 9 vectores de 1024 dimensiones cada uno (recordar el hidden_size: 1024 que aparece en el config), uno por cada palabra/fragmento.

El problema: para hacer búsqueda de similitud en Qdrant, se necesita un solo vector por chunk, no nueve. **Pooling es la operación que toma esos N vectores (uno por token) y los combina en un único vector final que representa el significado de todo el texto**.

**Mean pooling:** promediar los 9 vectores, dando el mismo peso a cada token.
**Last token pooling:** quedarse solo con el vector del último token, asumiendo que ya "acumuló" el contexto de todos los anteriores (así es como suelen funcionar los modelos causales/generativos, que leen de izquierda a derecha).
**CLS pooling:** usar un token especial dedicado a resumir la oración (común en arquitecturas tipo BERT, no en esta familia).

## Evidencia ejecución modelo Qwen3-embedding-0.6B en ASUS Spark con contenedor parcheado

docker run -d \
  --name vllm-embedding-06b \
  --gpus all \
  -p 8001:8000 \
  -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model \
  -e MODEL_PATH=/models/model \
  -e MAX_MODEL_LEN=32768 \
  -e GPU_MEMORY_UTIL=0.3 \
  hellohal2064/vllm-dgx-spark-gb10:latest

### Resultado

root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# docker run -d   --name vllm-embedding-06b   --gpus all   -p 8001:8000   -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model   -e MODEL_PATH=/models/model   -e MAX_MODEL_LEN=32768   -e GPU_MEMORY_UTIL=0.3   hellohal2064/vllm-dgx-spark-gb10:latest && docker logs -f vllm-embedding-06b
34ec78df7e66f2710ffd5cef1367adb8a60423382f6c657e996c050f35210fe7
[PATCH] Applied Qwen3 reasoning parser fix
=============================================
vLLM Server for NVIDIA GB10 (SM121 Blackwell)
=============================================

Configuration:
  Model: /models/model
  Host: 0.0.0.0:8000
  Max Model Length: 32768
  GPU Memory Utilization: 0.3
  Attention Backend: FLASHINFER
  Tool Call Parser: qwen3_coder
  Reasoning Parser: qwen3
  Thinking Mode: true

Starting vLLM server...

INFO 08-18 19:14:37 [importing.py:85] Detected GPU with compute capability 12.1 (arch=121). Configuring TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas to ensure Triton kernel compilation compatibility.
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:314] 
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:314]        █     █     █▄   ▄█
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:314]  ▄▄ ▄█ █     █     █ ▀▄▀ █  version 0.16.0rc1.dev122+g6595a2380
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:314]   █▄█▀ █     █     █     █  model   /models/model
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:314]    ▀▀  ▀▀▀▀▀ ▀▀▀▀▀ ▀     ▀
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:314] 
(APIServer pid=1) INFO 08-18 19:14:38 [utils.py:250] non-default args: {'model_tag': '/models/model', 'api_server_count': 1, 'host': '0.0.0.0', 'default_chat_template_kwargs': {'enable_thinking': True}, 'enable_auto_tool_choice': True, 'tool_call_parser': 'qwen3_coder', 'enable_prompt_tokens_details': True, 'model': '/models/model', 'max_model_len': 32768, 'generation_config': 'vllm', 'load_format': 'fastsafetensors', 'reasoning_parser': 'qwen3', 'gpu_memory_utilization': 0.3, 'swap_space': 1.0, 'attention_config': AttentionConfig(backend=<AttentionBackendEnum.FLASHINFER: 'vllm.v1.attention.backends.flashinfer.FlashInferBackend'>, flash_attn_version=None, use_prefill_decode_attention=False, flash_attn_max_num_splits_for_cuda_graph=32, use_cudnn_prefill=False, use_trtllm_ragged_deepseek_prefill=True, use_trtllm_attention=None, disable_flashinfer_prefill=False, disable_flashinfer_q_quantization=False)}
(APIServer pid=1) INFO 08-18 19:14:42 [config.py:764] Found sentence-transformers modules configuration.
(APIServer pid=1) INFO 08-18 19:14:42 [config.py:791] Found pooling configuration.
(APIServer pid=1) INFO 08-18 19:14:42 [model.py:804] Resolved `--runner auto` to `--runner pooling`. Pass the value explicitly to silence this message.
(APIServer pid=1) INFO 08-18 19:14:42 [model.py:856] Resolved `--convert auto` to `--convert embed`. Pass the value explicitly to silence this message.
(APIServer pid=1) INFO 08-18 19:14:42 [model.py:532] Resolved architecture: Qwen3ForCausalLM
(APIServer pid=1) INFO 08-18 19:14:42 [model.py:1543] Using max model len 32768
(APIServer pid=1) INFO 08-18 19:14:42 [scheduler.py:226] Chunked prefill is enabled with max_num_batched_tokens=2048.
(APIServer pid=1) INFO 08-18 19:14:42 [vllm.py:669] Asynchronous scheduling is enabled.
(APIServer pid=1) WARNING 08-18 19:14:42 [vllm.py:786] Pooling models do not support full cudagraphs. Overriding cudagraph_mode to PIECEWISE.
(EngineCore_DP0 pid=106) INFO 08-18 19:14:45 [core.py:96] Initializing a V1 LLM engine (v0.16.0rc1.dev122+g6595a2380) with config: model='/models/model', speculative_config=None, tokenizer='/models/model', skip_tokenizer_init=False, tokenizer_mode=auto, revision=None, tokenizer_revision=None, trust_remote_code=False, dtype=torch.bfloat16, max_seq_len=32768, download_dir=None, load_format=fastsafetensors, tensor_parallel_size=1, pipeline_parallel_size=1, data_parallel_size=1, disable_custom_all_reduce=False, quantization=None, enforce_eager=False, enable_return_routed_experts=False, kv_cache_dtype=auto, device_config=cuda, structured_outputs_config=StructuredOutputsConfig(backend='auto', disable_fallback=False, disable_any_whitespace=False, disable_additional_properties=False, reasoning_parser='qwen3', reasoning_parser_plugin='', enable_in_reasoning=False), observability_config=ObservabilityConfig(show_hidden_metrics_for_version=None, otlp_traces_endpoint=None, collect_detailed_traces=None, kv_cache_metrics=False, kv_cache_metrics_sample=0.01, cudagraph_metrics=False, enable_layerwise_nvtx_tracing=False, enable_mfu_metrics=False, enable_mm_processor_stats=False, enable_logging_iteration_details=False), seed=0, served_model_name=/models/model, enable_prefix_caching=True, enable_chunked_prefill=True, pooler_config=PoolerConfig(pooling_type=None, seq_pooling_type='LAST', tok_pooling_type='ALL', use_activation=True, dimensions=None, enable_chunked_processing=None, max_embed_len=None, logit_bias=None, step_tag_id=None, returned_token_ids=None), compilation_config={'level': None, 'mode': <CompilationMode.VLLM_COMPILE: 3>, 'debug_dump_path': None, 'cache_dir': '', 'compile_cache_save_format': 'binary', 'backend': 'inductor', 'custom_ops': ['none'], 'splitting_ops': ['vllm::unified_attention', 'vllm::unified_attention_with_output', 'vllm::unified_mla_attention', 'vllm::unified_mla_attention_with_output', 'vllm::mamba_mixer2', 'vllm::mamba_mixer', 'vllm::short_conv', 'vllm::linear_attention', 'vllm::plamo2_mamba_mixer', 'vllm::gdn_attention_core', 'vllm::kda_attention', 'vllm::sparse_attn_indexer', 'vllm::rocm_aiter_sparse_attn_indexer', 'vllm::unified_kv_cache_update'], 'compile_mm_encoder': False, 'compile_sizes': [], 'compile_ranges_split_points': [2048], 'inductor_compile_config': {'enable_auto_functionalized_v2': False, 'combo_kernels': True, 'benchmark_combo_kernel': True}, 'inductor_passes': {}, 'cudagraph_mode': <CUDAGraphMode.PIECEWISE: 1>, 'cudagraph_num_of_warmups': 1, 'cudagraph_capture_sizes': [1, 2, 4, 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136, 144, 152, 160, 168, 176, 184, 192, 200, 208, 216, 224, 232, 240, 248, 256, 272, 288, 304, 320, 336, 352, 368, 384, 400, 416, 432, 448, 464, 480, 496, 512], 'cudagraph_copy_inputs': False, 'cudagraph_specialize_lora': True, 'use_inductor_graph_partition': False, 'pass_config': {'fuse_norm_quant': False, 'fuse_act_quant': False, 'fuse_attn_quant': False, 'eliminate_noops': True, 'enable_sp': False, 'fuse_gemm_comms': False, 'fuse_allreduce_rms': False, 'fuse_act_padding': False}, 'max_cudagraph_capture_size': 512, 'dynamic_shapes_config': {'type': <DynamicShapesType.BACKED: 'backed'>, 'evaluate_guards': False, 'assume_32_bit_indexing': False}, 'local_cache_dir': None, 'static_all_moe_layers': []}
(EngineCore_DP0 pid=106) INFO 08-18 19:14:45 [parallel_state.py:1234] world_size=1 rank=0 local_rank=0 distributed_init_method=tcp://172.17.0.4:44863 backend=nccl
(EngineCore_DP0 pid=106) INFO 08-18 19:14:45 [parallel_state.py:1445] rank 0 in world size 1 is assigned as DP rank 0, PP rank 0, PCP rank 0, TP rank 0, EP rank N/A
(EngineCore_DP0 pid=106) INFO 08-18 19:14:46 [gpu_model_runner.py:4116] Starting to load model /models/model...
(EngineCore_DP0 pid=106) INFO 08-18 19:14:46 [cuda.py:360] Using AttentionBackendEnum.FLASHINFER backend.
(EngineCore_DP0 pid=106) INFO 08-18 19:14:46 [selector.py:112] Using HND KV cache layout for FLASHINFER backend.
Loading safetensors using Fastsafetensor loader:   0% Completed | 0/1 [00:00<?, ?it/s]
get_mempolicy: Operation not permitted
(EngineCore_DP0 pid=106) /opt/vllm-env/lib/python3.12/site-packages/fastsafetensors/copier/gds.py:185: UserWarning: GDS is not supported in this platform but nogds is False. use nogds=True
(EngineCore_DP0 pid=106)   warnings.warn(
(EngineCore_DP0 pid=106) INFO 08-18 19:14:47 [adapters.py:204] Mapping weights to Qwen3Model as they are relative to this model instead of Qwen3ForEmbedding.
Loading safetensors using Fastsafetensor loader: 100% Completed | 1/1 [00:00<00:00,  1.84it/s]
Loading safetensors using Fastsafetensor loader: 100% Completed | 1/1 [00:00<00:00,  1.84it/s]
(EngineCore_DP0 pid=106) 
(EngineCore_DP0 pid=106) INFO 08-18 19:14:47 [default_loader.py:291] Loading weights took 0.55 seconds
(EngineCore_DP0 pid=106) INFO 08-18 19:14:47 [gpu_model_runner.py:4213] Model loading took 1.12 GiB memory and 1.215677 seconds
(EngineCore_DP0 pid=106) INFO 08-18 19:14:50 [backends.py:860] Using cache directory: /root/.cache/vllm/torch_compile_cache/498b6246d7/rank_0_0/backbone for vLLM's torch.compile
(EngineCore_DP0 pid=106) INFO 08-18 19:14:50 [backends.py:920] Dynamo bytecode transform time: 2.71 s
(EngineCore_DP0 pid=106) [rank0]:W0818 19:14:51.702000 106 torch/_inductor/utils.py:1697] Not enough SMs to use max_autotune_gemm mode
(EngineCore_DP0 pid=106) INFO 08-18 19:14:55 [backends.py:300] Cache the graph of compile range (1, 2048) for later use
(EngineCore_DP0 pid=106) INFO 08-18 19:14:59 [backends.py:317] Compiling a graph for compile range (1, 2048) takes 8.06 s
(EngineCore_DP0 pid=106) INFO 08-18 19:14:59 [monitor.py:34] torch.compile takes 10.77 s in total
(EngineCore_DP0 pid=106) INFO 08-18 19:14:59 [decorators.py:574] saving AOT compiled function to /root/.cache/vllm/torch_aot_compile/2dc783d39d2a13c6e4dd3d69daf05c27a3924311560ad69cfe446d5253370ae5/rank_0_0/model
(EngineCore_DP0 pid=106) INFO 08-18 19:15:00 [decorators.py:578] saved AOT compiled function to /root/.cache/vllm/torch_aot_compile/2dc783d39d2a13c6e4dd3d69daf05c27a3924311560ad69cfe446d5253370ae5/rank_0_0/model
(EngineCore_DP0 pid=106) INFO 08-18 19:15:00 [gpu_worker.py:359] Available KV cache memory: 34.03 GiB
(EngineCore_DP0 pid=106) INFO 08-18 19:15:00 [kv_cache_utils.py:1307] GPU KV cache size: 318,592 tokens
(EngineCore_DP0 pid=106) INFO 08-18 19:15:00 [kv_cache_utils.py:1312] Maximum concurrency for 32,768 tokens per request: 9.72x
(EngineCore_DP0 pid=106) INFO 08-18 19:15:02 [utils.py:59] `_KV_CACHE_LAYOUT_OVERRIDE` variable detected. Setting KV cache layout to HND.
(EngineCore_DP0 pid=106) 2026-08-18 19:15:02,271 - INFO - autotuner.py:256 - flashinfer.jit: [Autotuner]: Autotuning process starts ...
(EngineCore_DP0 pid=106) 2026-08-18 19:15:02,294 - INFO - autotuner.py:262 - flashinfer.jit: [Autotuner]: Autotuning process ends
Capturing CUDA graphs (mixed prefill-decode, PIECEWISE): 100%|██████████| 51/51 [00:00<00:00, 58.41it/s]
(EngineCore_DP0 pid=106) INFO 08-18 19:15:03 [gpu_model_runner.py:5227] Graph capturing finished in 1 secs, took 0.34 GiB
(EngineCore_DP0 pid=106) INFO 08-18 19:15:03 [core.py:272] init engine (profile, create kv cache, warmup model) took 16.05 seconds
(EngineCore_DP0 pid=106) INFO 08-18 19:15:04 [vllm.py:669] Asynchronous scheduling is enabled.
(APIServer pid=1) INFO 08-18 19:15:04 [api_server.py:455] Supported tasks: ['embed', 'token_embed']
(APIServer pid=1) INFO 08-18 19:15:04 [api_server.py:460] Starting vLLM API server 0 on http://0.0.0.0:8000 
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:38] Available routes are:
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /openapi.json, Methods: GET, HEAD
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /docs, Methods: GET, HEAD
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /docs/oauth2-redirect, Methods: GET, HEAD
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /redoc, Methods: GET, HEAD
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /load, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /version, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /scale_elastic_ep, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /is_scaling_elastic_ep, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /tokenize, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /detokenize, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /inference/v1/generate, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /pause, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /resume, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /is_paused, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /metrics, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /health, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /v1/models, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /ping, Methods: GET
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /ping, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /invocations, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /pooling, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /v1/embeddings, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /score, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /v1/score, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /rerank, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /v1/rerank, Methods: POST
(APIServer pid=1) INFO 08-18 19:15:04 [launcher.py:47] Route: /v2/rerank, Methods: POST
(APIServer pid=1) INFO:     Started server process [1]
(APIServer pid=1) INFO:     Waiting for application startup.
(APIServer pid=1) INFO:     Application startup complete.


- En el log de la ejecución del contenedor, aparece esta línea dentro de la configuración del engine:

**pooler_config=PoolerConfig(pooling_type=None, seq_pooling_type='LAST', tok_pooling_type='ALL', ...)**

seq_pooling_type='LAST' confirma que **este modelo usa last token pooling** — coherente con que su arquitectura base (Qwen3ForCausalLM) es generativa/causal, donde el último token ya "vio" toda la oración anterior gracias al mecanismo de atención, así que su vector es una representación razonable del significado completo.

## Pruebas del endpoint

### Salud

admin@Bog2-cpul040547:~$ curl -i http://localhost:8001/health
HTTP/1.1 200 OK
date: Tue, 18 Aug 2026 19:24:07 GMT
server: uvicorn
content-length: 0

### Vectorización

Como el tamaño de vector es de 1024, indicamos ver solamente las primeras 30 posiciones:

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{
    "model": "/models/model",
    "input": "Buenos días, le habla fulanito"
  }' | python3 -m json.tool | head -30
{
    "id": "embd-9d336af9c383f3b9",
    "object": "list",
    "created": 1787082826,
    "model": "/models/model",
    "data": [
        {
            "index": 0,
            "object": "embedding",
            "embedding": [
                0.02682586945593357,
                -0.02244342491030693,
                -0.0030876309610903263,
                -0.0355907566845417,
                0.06374464184045792,
                -0.07755597680807114,
                -0.025232253596186638,
                0.05657336860895157,
                -0.1067722737789154,
                0.05710457265377045,
                -0.019256193190813065,
                -0.05869818851351738,
                0.08446164429187775,
                -0.003851238638162613,
                -0.04116841405630112,
                0.03612196072936058,
                -0.0030378305818885565,
                0.07489994913339615,
                0.09296093136072159,
                -0.050464507192373276,

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{
    "model": "/models/model",
    "input": "Buenos días, le habla el Banco X"
  }' | python3 -m json.tool | head -30
{
    "id": "embd-969bae1f6a809cd5",
    "object": "list",
    "created": 1787082840,
    "model": "/models/model",
    "data": [
        {
            "index": 0,
            "object": "embedding",
            "embedding": [
                -0.06748960167169571,
                -0.02876139059662819,
                -0.005410558544099331,
                -0.036734845489263535,
                0.04072157293558121,
                -0.06748960167169571,
                -0.017726698890328407,
                0.019648870453238487,
                -0.034171950072050095,
                0.04556259885430336,
                -0.03787391260266304,
                -0.01594690978527069,
                0.07688688486814499,
                -0.005980091169476509,
                -0.04470830038189888,
                0.06435716897249222,
                -0.06150950863957405,
                0.02705279365181923,
                0.04442353546619415,
                -0.004431674722582102,

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{
    "model": "/models/model",
    "input": "Contemplari et allis tradere contemplata"
  }' | python3 -m json.tool | head -30
{
    "id": "embd-a57af563c4e50ab1",
    "object": "list",
    "created": 1787082870,
    "model": "/models/model",
    "data": [
        {
            "index": 0,
            "object": "embedding",
            "embedding": [
                0.002638124395161867,
                -0.020162807777523994,
                -0.014792339876294136,
                0.0034860929008573294,
                0.03278811648488045,
                -0.06708373129367828,
                0.05690810829401016,
                -0.022706711664795876,
                -0.007537498138844967,
                0.03674530237913132,
                -0.01818421296775341,
                -0.06105373427271843,
                0.02204718068242073,
                -0.014132808893918991,
                -0.056531235575675964,
                0.11230871826410294,
                -0.013096402399241924,
                0.052762486040592194,
                0.08818872272968292,
                -0.016111401841044426,

#### Para vericar la dimensión de los vectores:

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model": "/models/model", "input": "Buenos días, le habla el banco A"}' \
  | python3 -c "
import json, sys
data = json.load(sys.stdin)
emb = data['data'][0]['embedding']
print('Dimensiones del vector:', len(emb))
print('Usage:', data.get('usage'))
"

Dimensiones del vector: 1024
Usage: {'prompt_tokens': 12, 'total_tokens': 12, 'completion_tokens': 0, 'prompt_tokens_details': None}
admin@Bog2-cpul040547:~$ 

- Se confirma dimensión de vector de 1024. Por otra parte, 12 tokens de prompt, y 0 completion tokens porque este es un modelo de embedding, no de generación de texto.

## OTROS ENDPOINTS UTILES

### /v1/models

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/v1/models | python3 -m json.tool
{
    "object": "list",
    "data": [
        {
            "id": "/models/model",
            "object": "model",
            "created": 1787083915,
            "owned_by": "vllm",
            "root": "/models/model",
            "parent": null,
            "max_model_len": 32768,
            "permission": [
                {
                    "id": "modelperm-bb471e7abf9971b6",
                    "object": "model_permission",
                    "created": 1787083915,
                    "allow_create_engine": false,
                    "allow_sampling": true,
                    "allow_logprobs": true,
                    "allow_search_indices": false,
                    "allow_view": true,
                    "allow_fine_tuning": false,
                    "organization": "*",
                    "group": null,
                    "is_blocking": false
                }
            ]
        }
    ]
}

### /tokenize

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/tokenize   -H "Content-Type: application/json"   -d '{"model": "/models/model", "prompt": "Buenos días, le habla el banco A"}'   | python3 -m json.tool
{
    "count": 12,
    "max_model_len": 32768,
    "tokens": [
        33,
        10316,
        436,
        45080,
        11,
        512,
        6055,
        4260,
        655,
        52465,
        362,
        151643
    ],
    "token_strs": null
}

- y con "add_special_tokens": false

admin@Bog2-cpul040547:~/Documents$ curl -s http://localhost:8001/tokenize \
  -H "Content-Type: application/json" \
  -d '{
    "model": "/models/model",
    "prompt": "Buenos días, le habla el banco A",
    "add_special_tokens": false
  }' | python3 -m json.tool
{
    "count": 11,
    "max_model_len": 32768,
    "tokens": [
        33,
        10316,
        436,
        45080,
        11,
        512,
        6055,
        4260,
        655,
        52465,
        362
    ],
    "token_strs": null
}
admin@Bog2-cpul040547:~/Documents$ 

OBTENEMOS LA MISMA LISTA DE TOKENS, A EXCEPCIÓN DEL ÚLTIMO, QUE ES EL TOKEN DE FINALIZACIÓN QUE APARECE EN EL CONFIG:

**151643, el id del token que marca fin de secuencia**

### /metrics

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/metrics
# HELP python_gc_objects_collected_total Objects collected during gc
# TYPE python_gc_objects_collected_total counter
python_gc_objects_collected_total{generation="0"} 12511.0
python_gc_objects_collected_total{generation="1"} 1835.0
python_gc_objects_collected_total{generation="2"} 463.0
# HELP python_gc_objects_uncollectable_total Uncollectable objects found during GC
# TYPE python_gc_objects_uncollectable_total counter
python_gc_objects_uncollectable_total{generation="0"} 0.0
python_gc_objects_uncollectable_total{generation="1"} 0.0
python_gc_objects_uncollectable_total{generation="2"} 0.0
# HELP python_gc_collections_total Number of times this generation was collected
# TYPE python_gc_collections_total counter
python_gc_collections_total{generation="0"} 1350.0
python_gc_collections_total{generation="1"} 123.0
python_gc_collections_total{generation="2"} 9.0
# HELP python_info Python platform information
# TYPE python_info gauge
python_info{implementation="CPython",major="3",minor="12",patchlevel="3",version="3.12.3"} 1.0
# HELP process_virtual_memory_bytes Virtual memory size in bytes.
# TYPE process_virtual_memory_bytes gauge
process_virtual_memory_bytes 2.214273024e+010
# HELP process_resident_memory_bytes Resident memory size in bytes.
# TYPE process_resident_memory_bytes gauge
process_resident_memory_bytes 1.063575552e+09
# HELP process_start_time_seconds Start time of the process since unix epoch in seconds.
# TYPE process_start_time_seconds gauge
process_start_time_seconds 1.78708047507e+09
# HELP process_cpu_seconds_total Total user and system CPU time spent in seconds.
# TYPE process_cpu_seconds_total counter
process_cpu_seconds_total 9.76
# HELP process_open_fds Number of open file descriptors.
# TYPE process_open_fds gauge
process_open_fds 51.0
# HELP process_max_fds Maximum number of open file descriptors.
# TYPE process_max_fds gauge
process_max_fds 65535.0
# HELP vllm:num_requests_running Number of requests in model execution batches.
# TYPE vllm:num_requests_running gauge
vllm:num_requests_running{engine="0",model_name="/models/model"} 0.0
# HELP vllm:num_requests_waiting Number of requests waiting to be processed.
# TYPE vllm:num_requests_waiting gauge
vllm:num_requests_waiting{engine="0",model_name="/models/model"} 0.0
# HELP vllm:engine_sleep_state Engine sleep state; awake = 0 means engine is sleeping; awake = 1 means engine is awake; weights_offloaded = 1 means sleep level 1; discard_all = 1 means sleep level 2.
# TYPE vllm:engine_sleep_state gauge
vllm:engine_sleep_state{engine="0",model_name="/models/model",sleep_state="awake"} 1.0
vllm:engine_sleep_state{engine="0",model_name="/models/model",sleep_state="weights_offloaded"} 0.0
vllm:engine_sleep_state{engine="0",model_name="/models/model",sleep_state="discard_all"} 0.0
# HELP vllm:kv_cache_usage_perc KV-cache usage. 1 means 100 percent usage.
# TYPE vllm:kv_cache_usage_perc gauge
vllm:kv_cache_usage_perc{engine="0",model_name="/models/model"} 0.0
# HELP vllm:prefix_cache_queries_total Prefix cache queries, in terms of number of queried tokens.
# TYPE vllm:prefix_cache_queries_total counter
vllm:prefix_cache_queries_total{engine="0",model_name="/models/model"} 59.0
# HELP vllm:prefix_cache_queries_created Prefix cache queries, in terms of number of queried tokens.
# TYPE vllm:prefix_cache_queries_created gauge
vllm:prefix_cache_queries_created{engine="0",model_name="/models/model"} 1.7870805044138453e+09
# HELP vllm:prefix_cache_hits_total Prefix cache hits, in terms of number of cached tokens.
# TYPE vllm:prefix_cache_hits_total counter
vllm:prefix_cache_hits_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:prefix_cache_hits_created Prefix cache hits, in terms of number of cached tokens.
# TYPE vllm:prefix_cache_hits_created gauge
vllm:prefix_cache_hits_created{engine="0",model_name="/models/model"} 1.7870805044138532e+09
# HELP vllm:external_prefix_cache_queries_total External prefix cache queries from KV connector cross-instance cache sharing, in terms of number of queried tokens.
# TYPE vllm:external_prefix_cache_queries_total counter
vllm:external_prefix_cache_queries_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:external_prefix_cache_queries_created External prefix cache queries from KV connector cross-instance cache sharing, in terms of number of queried tokens.
# TYPE vllm:external_prefix_cache_queries_created gauge
vllm:external_prefix_cache_queries_created{engine="0",model_name="/models/model"} 1.7870805044138606e+09
# HELP vllm:external_prefix_cache_hits_total External prefix cache hits from KV connector cross-instance cache sharing, in terms of number of cached tokens.
# TYPE vllm:external_prefix_cache_hits_total counter
vllm:external_prefix_cache_hits_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:external_prefix_cache_hits_created External prefix cache hits from KV connector cross-instance cache sharing, in terms of number of cached tokens.
# TYPE vllm:external_prefix_cache_hits_created gauge
vllm:external_prefix_cache_hits_created{engine="0",model_name="/models/model"} 1.7870805044138694e+09
# HELP vllm:mm_cache_queries_total Multi-modal cache queries, in terms of number of queried items.
# TYPE vllm:mm_cache_queries_total counter
vllm:mm_cache_queries_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:mm_cache_queries_created Multi-modal cache queries, in terms of number of queried items.
# TYPE vllm:mm_cache_queries_created gauge
vllm:mm_cache_queries_created{engine="0",model_name="/models/model"} 1.7870805044138768e+09
# HELP vllm:mm_cache_hits_total Multi-modal cache hits, in terms of number of cached items.
# TYPE vllm:mm_cache_hits_total counter
vllm:mm_cache_hits_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:mm_cache_hits_created Multi-modal cache hits, in terms of number of cached items.
# TYPE vllm:mm_cache_hits_created gauge
vllm:mm_cache_hits_created{engine="0",model_name="/models/model"} 1.787080504413884e+09
# HELP vllm:num_preemptions_total Cumulative number of preemption from the engine.
# TYPE vllm:num_preemptions_total counter
vllm:num_preemptions_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:num_preemptions_created Cumulative number of preemption from the engine.
# TYPE vllm:num_preemptions_created gauge
vllm:num_preemptions_created{engine="0",model_name="/models/model"} 1.7870805044138913e+09
# HELP vllm:prompt_tokens_total Number of prefill tokens processed.
# TYPE vllm:prompt_tokens_total counter
vllm:prompt_tokens_total{engine="0",model_name="/models/model"} 59.0
# HELP vllm:prompt_tokens_created Number of prefill tokens processed.
# TYPE vllm:prompt_tokens_created gauge
vllm:prompt_tokens_created{engine="0",model_name="/models/model"} 1.7870805044138982e+09
# HELP vllm:generation_tokens_total Number of generation tokens processed.
# TYPE vllm:generation_tokens_total counter
vllm:generation_tokens_total{engine="0",model_name="/models/model"} 0.0
# HELP vllm:generation_tokens_created Number of generation tokens processed.
# TYPE vllm:generation_tokens_created gauge
vllm:generation_tokens_created{engine="0",model_name="/models/model"} 1.7870805044139059e+09
# HELP vllm:request_success_total Count of successfully processed requests.
# TYPE vllm:request_success_total counter
vllm:request_success_total{engine="0",finished_reason="stop",model_name="/models/model"} 5.0
vllm:request_success_total{engine="0",finished_reason="length",model_name="/models/model"} 0.0
vllm:request_success_total{engine="0",finished_reason="abort",model_name="/models/model"} 0.0
vllm:request_success_total{engine="0",finished_reason="error",model_name="/models/model"} 0.0
# HELP vllm:request_success_created Count of successfully processed requests.
# TYPE vllm:request_success_created gauge
vllm:request_success_created{engine="0",finished_reason="stop",model_name="/models/model"} 1.7870805044139218e+09
vllm:request_success_created{engine="0",finished_reason="length",model_name="/models/model"} 1.7870805044139261e+09
vllm:request_success_created{engine="0",finished_reason="abort",model_name="/models/model"} 1.7870805044139297e+09
vllm:request_success_created{engine="0",finished_reason="error",model_name="/models/model"} 1.7870805044139333e+09
# HELP vllm:request_prompt_tokens Number of prefill tokens processed.
# TYPE vllm:request_prompt_tokens histogram
vllm:request_prompt_tokens_bucket{engine="0",le="1.0",model_name="/models/model"} 0.0
vllm:request_prompt_tokens_bucket{engine="0",le="2.0",model_name="/models/model"} 0.0
vllm:request_prompt_tokens_bucket{engine="0",le="5.0",model_name="/models/model"} 0.0
vllm:request_prompt_tokens_bucket{engine="0",le="10.0",model_name="/models/model"} 0.0
vllm:request_prompt_tokens_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="100.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="200.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="500.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="1000.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="2000.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="5000.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="10000.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="20000.0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_count{engine="0",model_name="/models/model"} 5.0
vllm:request_prompt_tokens_sum{engine="0",model_name="/models/model"} 59.0
# HELP vllm:request_prompt_tokens_created Number of prefill tokens processed.
# TYPE vllm:request_prompt_tokens_created gauge
vllm:request_prompt_tokens_created{engine="0",model_name="/models/model"} 1.787080504413956e+09
# HELP vllm:request_generation_tokens Number of generation tokens processed.
# TYPE vllm:request_generation_tokens histogram
vllm:request_generation_tokens_bucket{engine="0",le="1.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="2.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="5.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="10.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="100.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="200.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="500.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="1000.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="2000.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="5000.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="10000.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="20000.0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_generation_tokens_count{engine="0",model_name="/models/model"} 5.0
vllm:request_generation_tokens_sum{engine="0",model_name="/models/model"} 0.0
# HELP vllm:request_generation_tokens_created Number of generation tokens processed.
# TYPE vllm:request_generation_tokens_created gauge
vllm:request_generation_tokens_created{engine="0",model_name="/models/model"} 1.7870805044139879e+09
# HELP vllm:iteration_tokens_total Histogram of number of tokens per engine_step.
# TYPE vllm:iteration_tokens_total histogram
vllm:iteration_tokens_total_bucket{engine="0",le="1.0",model_name="/models/model"} 0.0
vllm:iteration_tokens_total_bucket{engine="0",le="8.0",model_name="/models/model"} 0.0
vllm:iteration_tokens_total_bucket{engine="0",le="16.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="32.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="64.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="128.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="256.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="512.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="1024.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="2048.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="4096.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="8192.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="16384.0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_count{engine="0",model_name="/models/model"} 5.0
vllm:iteration_tokens_total_sum{engine="0",model_name="/models/model"} 59.0
# HELP vllm:iteration_tokens_total_created Histogram of number of tokens per engine_step.
# TYPE vllm:iteration_tokens_total_created gauge
vllm:iteration_tokens_total_created{engine="0",model_name="/models/model"} 1.787080504414007e+09
# HELP vllm:request_max_num_generation_tokens Histogram of maximum number of requested generation tokens.
# TYPE vllm:request_max_num_generation_tokens histogram
vllm:request_max_num_generation_tokens_bucket{engine="0",le="1.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="2.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="5.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="10.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="100.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="200.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="500.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="1000.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="2000.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="5000.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="10000.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="20000.0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_count{engine="0",model_name="/models/model"} 5.0
vllm:request_max_num_generation_tokens_sum{engine="0",model_name="/models/model"} 0.0
# HELP vllm:request_max_num_generation_tokens_created Histogram of maximum number of requested generation tokens.
# TYPE vllm:request_max_num_generation_tokens_created gauge
vllm:request_max_num_generation_tokens_created{engine="0",model_name="/models/model"} 1.787080504414027e+09
# HELP vllm:request_params_n Histogram of the n request parameter.
# TYPE vllm:request_params_n histogram
vllm:request_params_n_bucket{engine="0",le="1.0",model_name="/models/model"} 5.0
vllm:request_params_n_bucket{engine="0",le="2.0",model_name="/models/model"} 5.0
vllm:request_params_n_bucket{engine="0",le="5.0",model_name="/models/model"} 5.0
vllm:request_params_n_bucket{engine="0",le="10.0",model_name="/models/model"} 5.0
vllm:request_params_n_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_params_n_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_params_n_count{engine="0",model_name="/models/model"} 5.0
vllm:request_params_n_sum{engine="0",model_name="/models/model"} 5.0
# HELP vllm:request_params_n_created Histogram of the n request parameter.
# TYPE vllm:request_params_n_created gauge
vllm:request_params_n_created{engine="0",model_name="/models/model"} 1.7870805044140449e+09
# HELP vllm:request_params_max_tokens Histogram of the max_tokens request parameter.
# TYPE vllm:request_params_max_tokens histogram
vllm:request_params_max_tokens_bucket{engine="0",le="1.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="2.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="5.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="10.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="20.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="50.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="100.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="200.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="500.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="1000.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="2000.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="5000.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="10000.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="20000.0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_bucket{engine="0",le="+Inf",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_count{engine="0",model_name="/models/model"} 0.0
vllm:request_params_max_tokens_sum{engine="0",model_name="/models/model"} 0.0
# HELP vllm:request_params_max_tokens_created Histogram of the max_tokens request parameter.
# TYPE vllm:request_params_max_tokens_created gauge
vllm:request_params_max_tokens_created{engine="0",model_name="/models/model"} 1.7870805044140599e+09
# HELP vllm:time_to_first_token_seconds Histogram of time to first token in seconds.
# TYPE vllm:time_to_first_token_seconds histogram
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.001",model_name="/models/model"} 0.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.005",model_name="/models/model"} 0.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.01",model_name="/models/model"} 1.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.02",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.04",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.06",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.08",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.1",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.25",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="0.75",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="7.5",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 4.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="80.0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="160.0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="640.0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="2560.0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:time_to_first_token_seconds_sum{engine="0",model_name="/models/model"} 14.72799015045166
# HELP vllm:time_to_first_token_seconds_created Histogram of time to first token in seconds.
# TYPE vllm:time_to_first_token_seconds_created gauge
vllm:time_to_first_token_seconds_created{engine="0",model_name="/models/model"} 1.7870805044140801e+09
# HELP vllm:inter_token_latency_seconds Histogram of inter-token latency in seconds.
# TYPE vllm:inter_token_latency_seconds histogram
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.01",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.025",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.05",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.075",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.1",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.15",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.2",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.4",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="0.75",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="7.5",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="80.0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_count{engine="0",model_name="/models/model"} 0.0
vllm:inter_token_latency_seconds_sum{engine="0",model_name="/models/model"} 0.0
# HELP vllm:inter_token_latency_seconds_created Histogram of inter-token latency in seconds.
# TYPE vllm:inter_token_latency_seconds_created gauge
vllm:inter_token_latency_seconds_created{engine="0",model_name="/models/model"} 1.787080504414105e+09
# HELP vllm:request_time_per_output_token_seconds Histogram of time_per_output_token_seconds per request.
# TYPE vllm:request_time_per_output_token_seconds histogram
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.01",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.025",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.05",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.075",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.1",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.15",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.2",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.4",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.75",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="7.5",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="80.0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:request_time_per_output_token_seconds_sum{engine="0",model_name="/models/model"} 0.0
# HELP vllm:request_time_per_output_token_seconds_created Histogram of time_per_output_token_seconds per request.
# TYPE vllm:request_time_per_output_token_seconds_created gauge
vllm:request_time_per_output_token_seconds_created{engine="0",model_name="/models/model"} 1.7870805044141262e+09
# HELP vllm:e2e_request_latency_seconds Histogram of e2e request latency in seconds.
# TYPE vllm:e2e_request_latency_seconds histogram
vllm:e2e_request_latency_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="0.8",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="1.5",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="2.0",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 4.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="15.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="30.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="60.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="120.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="240.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="480.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="960.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="1920.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="7680.0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:e2e_request_latency_seconds_sum{engine="0",model_name="/models/model"} 14.72799015045166
# HELP vllm:e2e_request_latency_seconds_created Histogram of e2e request latency in seconds.
# TYPE vllm:e2e_request_latency_seconds_created gauge
vllm:e2e_request_latency_seconds_created{engine="0",model_name="/models/model"} 1.7870805044141476e+09
# HELP vllm:request_queue_time_seconds Histogram of time spent in WAITING phase for request.
# TYPE vllm:request_queue_time_seconds histogram
vllm:request_queue_time_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="0.8",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="1.5",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="2.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="15.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="30.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="60.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="120.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="240.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="480.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="960.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="1920.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="7680.0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:request_queue_time_seconds_sum{engine="0",model_name="/models/model"} 6.745639257133007e-05
# HELP vllm:request_queue_time_seconds_created Histogram of time spent in WAITING phase for request.
# TYPE vllm:request_queue_time_seconds_created gauge
vllm:request_queue_time_seconds_created{engine="0",model_name="/models/model"} 1.7870805044141695e+09
# HELP vllm:request_inference_time_seconds Histogram of time spent in RUNNING phase for request.
# TYPE vllm:request_inference_time_seconds histogram
vllm:request_inference_time_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="0.8",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="1.5",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="2.0",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 4.0
vllm:request_inference_time_seconds_bucket{engine="0",le="15.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="30.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="60.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="120.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="240.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="480.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="960.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="1920.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="7680.0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:request_inference_time_seconds_sum{engine="0",model_name="/models/model"} 14.71841752785258
# HELP vllm:request_inference_time_seconds_created Histogram of time spent in RUNNING phase for request.
# TYPE vllm:request_inference_time_seconds_created gauge
vllm:request_inference_time_seconds_created{engine="0",model_name="/models/model"} 1.7870805044141922e+09
# HELP vllm:request_prefill_time_seconds Histogram of time spent in PREFILL phase for request.
# TYPE vllm:request_prefill_time_seconds histogram
vllm:request_prefill_time_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="0.8",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="1.5",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="2.0",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 4.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="15.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="30.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="60.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="120.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="240.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="480.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="960.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="1920.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="7680.0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:request_prefill_time_seconds_sum{engine="0",model_name="/models/model"} 14.71841752785258
# HELP vllm:request_prefill_time_seconds_created Histogram of time spent in PREFILL phase for request.
# TYPE vllm:request_prefill_time_seconds_created gauge
vllm:request_prefill_time_seconds_created{engine="0",model_name="/models/model"} 1.787080504414243e+09
# HELP vllm:request_decode_time_seconds Histogram of time spent in DECODE phase for request.
# TYPE vllm:request_decode_time_seconds histogram
vllm:request_decode_time_seconds_bucket{engine="0",le="0.3",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="0.5",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="0.8",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="1.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="1.5",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="2.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="2.5",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="5.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="10.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="15.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="30.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="40.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="60.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="120.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="240.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="480.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="960.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="1920.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="7680.0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_count{engine="0",model_name="/models/model"} 5.0
vllm:request_decode_time_seconds_sum{engine="0",model_name="/models/model"} 0.0
# HELP vllm:request_decode_time_seconds_created Histogram of time spent in DECODE phase for request.
# TYPE vllm:request_decode_time_seconds_created gauge
vllm:request_decode_time_seconds_created{engine="0",model_name="/models/model"} 1.7870805044142642e+09
# HELP vllm:request_prefill_kv_computed_tokens Histogram of new KV tokens computed during prefill (excluding cached tokens).
# TYPE vllm:request_prefill_kv_computed_tokens histogram
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="1.0",model_name="/models/model"} 0.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="2.0",model_name="/models/model"} 0.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="5.0",model_name="/models/model"} 0.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="10.0",model_name="/models/model"} 0.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="20.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="50.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="100.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="200.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="500.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="1000.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="2000.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="5000.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="10000.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="20000.0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_bucket{engine="0",le="+Inf",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_count{engine="0",model_name="/models/model"} 5.0
vllm:request_prefill_kv_computed_tokens_sum{engine="0",model_name="/models/model"} 59.0
# HELP vllm:request_prefill_kv_computed_tokens_created Histogram of new KV tokens computed during prefill (excluding cached tokens).
# TYPE vllm:request_prefill_kv_computed_tokens_created gauge
vllm:request_prefill_kv_computed_tokens_created{engine="0",model_name="/models/model"} 1.7870805044142897e+09
# HELP vllm:cache_config_info Information of the LLMEngine CacheConfig
# TYPE vllm:cache_config_info gauge
vllm:cache_config_info{block_size="16",cache_dtype="auto",calculate_kv_scales="False",cpu_kvcache_space_bytes="None",cpu_offload_gb="0.0",enable_prefix_caching="True",engine="0",gpu_memory_utilization="0.3",is_attention_free="False",kv_cache_memory_bytes="None",kv_offloading_backend="native",kv_offloading_size="None",kv_sharing_fast_prefill="False",mamba_block_size="None",mamba_cache_dtype="auto",mamba_cache_mode="none",mamba_page_size_padded="None",mamba_ssm_cache_dtype="auto",num_cpu_blocks="None",num_gpu_blocks="19912",num_gpu_blocks_override="None",prefix_caching_hash_algo="sha256",sliding_window="None",swap_space="1.0"} 1.0
# HELP http_requests_total Total number of requests by method, status and handler.
# TYPE http_requests_total counter
http_requests_total{handler="/v1/embeddings",method="POST",status="2xx"} 5.0
http_requests_total{handler="/v1/models",method="GET",status="2xx"} 2.0
http_requests_total{handler="/tokenize",method="POST",status="2xx"} 2.0
# HELP http_requests_created Total number of requests by method, status and handler.
# TYPE http_requests_created gauge
http_requests_created{handler="/v1/embeddings",method="POST",status="2xx"} 1.7870827960476089e+09
http_requests_created{handler="/v1/models",method="GET",status="2xx"} 1.7870837804883225e+09
http_requests_created{handler="/tokenize",method="POST",status="2xx"} 1.7870838398336523e+09
# HELP http_request_size_bytes Content length of incoming requests by handler. Only value of header is respected. Otherwise ignored. No percentile calculated. 
# TYPE http_request_size_bytes summary
http_request_size_bytes_count{handler="/v1/embeddings"} 5.0
http_request_size_bytes_sum{handler="/v1/embeddings"} 411.0
http_request_size_bytes_count{handler="/v1/models"} 2.0
http_request_size_bytes_sum{handler="/v1/models"} 0.0
http_request_size_bytes_count{handler="/tokenize"} 2.0
http_request_size_bytes_sum{handler="/tokenize"} 146.0
# HELP http_request_size_bytes_created Content length of incoming requests by handler. Only value of header is respected. Otherwise ignored. No percentile calculated. 
# TYPE http_request_size_bytes_created gauge
http_request_size_bytes_created{handler="/v1/embeddings"} 1.7870827960476198e+09
http_request_size_bytes_created{handler="/v1/models"} 1.7870837804883327e+09
http_request_size_bytes_created{handler="/tokenize"} 1.7870838398336675e+09
# HELP http_response_size_bytes Content length of outgoing responses by handler. Only value of header is respected. Otherwise ignored. No percentile calculated. 
# TYPE http_response_size_bytes summary
http_response_size_bytes_count{handler="/v1/embeddings"} 5.0
http_response_size_bytes_sum{handler="/v1/embeddings"} 109731.0
http_response_size_bytes_count{handler="/v1/models"} 2.0
http_response_size_bytes_sum{handler="/v1/models"} 922.0
http_response_size_bytes_count{handler="/tokenize"} 2.0
http_response_size_bytes_sum{handler="/tokenize"} 240.0
# HELP http_response_size_bytes_created Content length of outgoing responses by handler. Only value of header is respected. Otherwise ignored. No percentile calculated. 
# TYPE http_response_size_bytes_created gauge
http_response_size_bytes_created{handler="/v1/embeddings"} 1.7870827960476313e+09
http_response_size_bytes_created{handler="/v1/models"} 1.7870837804883416e+09
http_response_size_bytes_created{handler="/tokenize"} 1.787083839833682e+09
# HELP http_request_duration_highr_seconds Latency with many buckets but no API specific labels. Made for more accurate percentile calculations. 
# TYPE http_request_duration_highr_seconds histogram
http_request_duration_highr_seconds_bucket{le="0.01"} 4.0
http_request_duration_highr_seconds_bucket{le="0.025"} 8.0
http_request_duration_highr_seconds_bucket{le="0.05"} 8.0
http_request_duration_highr_seconds_bucket{le="0.075"} 8.0
http_request_duration_highr_seconds_bucket{le="0.1"} 8.0
http_request_duration_highr_seconds_bucket{le="0.25"} 8.0
http_request_duration_highr_seconds_bucket{le="0.5"} 8.0
http_request_duration_highr_seconds_bucket{le="0.75"} 8.0
http_request_duration_highr_seconds_bucket{le="1.0"} 8.0
http_request_duration_highr_seconds_bucket{le="1.5"} 8.0
http_request_duration_highr_seconds_bucket{le="2.0"} 8.0
http_request_duration_highr_seconds_bucket{le="2.5"} 8.0
http_request_duration_highr_seconds_bucket{le="3.0"} 8.0
http_request_duration_highr_seconds_bucket{le="3.5"} 8.0
http_request_duration_highr_seconds_bucket{le="4.0"} 8.0
http_request_duration_highr_seconds_bucket{le="4.5"} 8.0
http_request_duration_highr_seconds_bucket{le="5.0"} 8.0
http_request_duration_highr_seconds_bucket{le="7.5"} 8.0
http_request_duration_highr_seconds_bucket{le="10.0"} 8.0
http_request_duration_highr_seconds_bucket{le="30.0"} 9.0
http_request_duration_highr_seconds_bucket{le="60.0"} 9.0
http_request_duration_highr_seconds_bucket{le="+Inf"} 9.0
http_request_duration_highr_seconds_count 9.0
http_request_duration_highr_seconds_sum 14.756744188023731
# HELP http_request_duration_highr_seconds_created Latency with many buckets but no API specific labels. Made for more accurate percentile calculations. 
# TYPE http_request_duration_highr_seconds_created gauge
http_request_duration_highr_seconds_created 1.7870805045408237e+09
# HELP http_request_duration_seconds Latency with only few buckets by handler. Made to be only used if aggregation by handler is important. 
# TYPE http_request_duration_seconds histogram
http_request_duration_seconds_bucket{handler="/v1/embeddings",le="0.1",method="POST"} 4.0
http_request_duration_seconds_bucket{handler="/v1/embeddings",le="0.5",method="POST"} 4.0
http_request_duration_seconds_bucket{handler="/v1/embeddings",le="1.0",method="POST"} 4.0
http_request_duration_seconds_bucket{handler="/v1/embeddings",le="+Inf",method="POST"} 5.0
http_request_duration_seconds_count{handler="/v1/embeddings",method="POST"} 5.0
http_request_duration_seconds_sum{handler="/v1/embeddings",method="POST"} 14.748908526962623
http_request_duration_seconds_bucket{handler="/v1/models",le="0.1",method="GET"} 2.0
http_request_duration_seconds_bucket{handler="/v1/models",le="0.5",method="GET"} 2.0
http_request_duration_seconds_bucket{handler="/v1/models",le="1.0",method="GET"} 2.0
http_request_duration_seconds_bucket{handler="/v1/models",le="+Inf",method="GET"} 2.0
http_request_duration_seconds_count{handler="/v1/models",method="GET"} 2.0
http_request_duration_seconds_sum{handler="/v1/models",method="GET"} 0.0008339220657944679
http_request_duration_seconds_bucket{handler="/tokenize",le="0.1",method="POST"} 2.0
http_request_duration_seconds_bucket{handler="/tokenize",le="0.5",method="POST"} 2.0
http_request_duration_seconds_bucket{handler="/tokenize",le="1.0",method="POST"} 2.0
http_request_duration_seconds_bucket{handler="/tokenize",le="+Inf",method="POST"} 2.0
http_request_duration_seconds_count{handler="/tokenize",method="POST"} 2.0
http_request_duration_seconds_sum{handler="/tokenize",method="POST"} 0.007001738995313644
# HELP http_request_duration_seconds_created Latency with only few buckets by handler. Made to be only used if aggregation by handler is important. 
# TYPE http_request_duration_seconds_created gauge
http_request_duration_seconds_created{handler="/v1/embeddings",method="POST"} 1.7870827960476475e+09
http_request_duration_seconds_created{handler="/v1/models",method="GET"} 1.787083780488357e+09
http_request_duration_seconds_created{handler="/tokenize",method="POST"} 1.7870838398337033e+09
admin@Bog2-cpul040547:~$ 


### Para evaluar tiempos de respuesta por petición de embedding:

admin@Bog2-cpul040547:~$ time curl -s http://localhost:8001/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model": "/models/model", "input": "Buenos días, le habla el banco A"}' \
  -o /dev/null

real	0m0.019s
user	0m0.002s
sys	0m0.003s
admin@Bog2-cpul040547:~$ time curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{"model": "/models/model", "input": "Mi vieja mula ya no es lo que era"}'   -o /dev/null

real	0m0.019s
user	0m0.003s
sys	0m0.001s
admin@Bog2-cpul040547:~$ time curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{"model": "/models/model", "input": "Tengo dos gatos adoptados"}'   -o /dev/null

real	0m0.019s
user	0m0.001s
sys	0m0.003s
admin@Bog2-cpul040547:~$ time curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{"model": "/models/model", "input": "Tengo que perder 6 kilos"}'   -o /dev/null

real	0m0.019s
user	0m0.003s
sys	0m0.003s
admin@Bog2-cpul040547:~$ 


- 19 milisegundos! Súper rápido, es prometedor.

# Pruebas de concurrencia

## Script en Bash para N solicitudes simultáneas

-----------------------
#!/bin/bash

N=10  # número de peticiones concurrentes

echo "Lanzando $N peticiones simultáneas..."
start=$(date +%s.%N)

for i in $(seq 1 $N); do
  curl -s -o /dev/null -w "Request $i: %{time_total}s\n" \
    http://localhost:8001/v1/embeddings \
    -H "Content-Type: application/json" \
    -d '{"model": "/models/model", "input": "Buenos días, le habla el banco A"}' &
done

wait  # espera a que todas las peticiones en background terminen

end=$(date +%s.%N)
echo "---"
echo "Tiempo total del lote: $(echo "$end - $start" | bc)s"
-----------------------

admin@Bog2-cpul040547:~/Documents$ nano prueba_concurrencia.sh

admin@Bog2-cpul040547:~/Documents$ ls
apuntes_api_rag.md  docs_varios_para_mineru  nvidia-toolkit  prueba_concurrencia.sh

admin@Bog2-cpul040547:~/Documents$ chmod +x prueba_concurrencia.sh

admin@Bog2-cpul040547:~/Documents$ ls
apuntes_api_rag.md  docs_varios_para_mineru  nvidia-toolkit  prueba_concurrencia.sh

admin@Bog2-cpul040547:~/Documents$ ./prueba_concurrencia.sh 
Lanzando 10 peticiones simultáneas...
Request 3: 0.020271s
Request 6: 0.023386s
Request 7: 0.024825s
Request 4: 0.024852s
Request 10: 0.024623s
Request 5: 0.025259s
Request 1: 0.025320s
Request 2: 0.023776s
Request 9: 0.022976s
Request 8: 0.023278s
---
Tiempo total del lote: .033327871s


# AHORA CON N=100

admin@Bog2-cpul040547:~/Documents$ ./prueba_concurrencia.sh 
Lanzando 100 peticiones simultáneas...
Request 5: 0.033607s
Request 3: 0.033720s
Request 1: 0.033776s
Request 7: 0.033523s
Request 9: 0.033475s
Request 11: 0.052869s
Request 22: 0.050732s
Request 13: 0.050773s
Request 33: 0.049370s
Request 19: 0.051664s
Request 12: 0.051105s
Request 2: 0.052495s
Request 26: 0.047598s
Request 25: 0.050561s
Request 4: 0.051852s
Request 10: 0.050047s
Request 18: 0.050529s
Request 6: 0.053770s
Request 16: 0.048772s
Request 24: 0.050056s
Request 17: 0.052017s
Request 20: 0.050314s
Request 8: 0.052957s
Request 32: 0.103144s
Request 86: 0.095641s
Request 73: 0.097192s
Request 48: 0.091546s
Request 49: 0.099227s
Request 37: 0.092883s
Request 82: 0.097390s
Request 36: 0.101227s
Request 40: 0.100488s
Request 34: 0.099560s
Request 39: 0.099705s
Request 88: 0.093975s
Request 14: 0.103159s
Request 28: 0.099857s
Request 61: 0.100357s
Request 43: 0.101713s
Request 23: 0.104206s
Request 31: 0.097598s
Request 47: 0.101408s
Request 70: 0.094103s
Request 42: 0.098059s
Request 27: 0.101941s
Request 52: 0.103121s
Request 74: 0.096783s
Request 21: 0.102534s
Request 30: 0.100222s
Request 66: 0.093819s
Request 15: 0.105468s
Request 87: 0.098975s
Request 38: 0.103225s
Request 45: 0.094490s
Request 55: 0.100517s
Request 85: 0.098943s
Request 29: 0.094681s
Request 81: 0.090862s
Request 78: 0.094489s
Request 84: 0.090176s
Request 44: 0.093633s
Request 90: 0.087459s
Request 54: 0.089822s
Request 57: 0.092194s
Request 56: 0.090589s
Request 80: 0.096169s
Request 62: 0.092498s
Request 63: 0.089462s
Request 79: 0.090523s
Request 67: 0.089327s
Request 46: 0.092055s
Request 60: 0.099636s
Request 97: 0.091555s
Request 64: 0.094913s
Request 96: 0.092829s
Request 95: 0.094478s
Request 75: 0.096787s
Request 58: 0.094772s
Request 89: 0.094454s
Request 83: 0.097757s
Request 51: 0.091538s
Request 68: 0.091539s
Request 92: 0.091544s
Request 72: 0.096221s
Request 94: 0.096218s
Request 71: 0.092056s
Request 91: 0.093772s
Request 35: 0.091120s
Request 76: 0.092653s
Request 69: 0.093811s
Request 99: 0.096479s
Request 59: 0.096926s
Request 100: 0.094952s
Request 98: 0.094012s
Request 93: 0.096155s
Request 65: 0.093135s
Request 53: 0.091846s
Request 41: 0.098878s
Request 77: 0.097347s
Request 50: 0.092555s
---
Tiempo total del lote: .122481493s
admin@Bog2-cpul040547:~/Documents$ 


| Banda | Peticiones | Latencia individual |
|---|---|---|
| Primer grupo (~9) | Las que arrancaron primero | ~33ms |
| Segundo grupo (~13) | Llegaron un poco después | ~48-53ms |
| Grupo grande (~78) | El resto | ~87-105ms |


# Resumen

El Qwen3-embedding-0.6B con vLLM en la ASUS Ascent GX10 DGX Spark, con la imagen comunitaria parcheada:

- 1 petición aislada: ~19ms
- 10 concurrentes: ~20-25ms cada una, sin degradación perceptible
- 100 concurrentes: ~90-105ms en el peor caso, con throughput real de paralelismo (122ms para el lote completo)

# Prueba adicional de truncamiento

- Previamente yo había leído que qwen3-embedding-0.6b permitía dimensiones de embedding desde 32 hasta 1024, que el 4b desde 32 hasta 2560, y que el 8b desde 32 hasta 4096.

- En el config aparece "hidden_size": 1024 como la dimensión del vector interno del modelo en cada capa (y la base de la dimensión del embedding final). **Sé que esa es la dimensión máxima para este modelo.**

## Pregunta: ¿¿¿la dimensión vectorial es realmente flexible, entre 32 y 1024 como límites, tal y como tengo el servicio actualmente???

## Respuesta: No :-(

### Fijando dimensions a 256:

admin@Bog2-cpul040547:~/Documents$ curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{
    "model": "/models/model",
    "input": "Buenos días, le habla el banco A",
    "dimensions": 256
  }' | python3 -m json.tool
{
    "error": {
        "message": "Model \"/models/model\" does not support matryoshka representation, changing output dimensions will lead to poor results.",
        "type": "BadRequestError",
        "param": null,
        "code": 400
    }
}

### Fijando dimensions a 1024, igual sale el error, como si el problema en sí fuera el parámetro dimensions:

admin@Bog2-cpul040547:~/Documents$ curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{
    "model": "/models/model",
    "input": "Buenos días, le habla el banco A",
    "dimensions": 1024
  }' | python3 -m json.tool
{
    "error": {
        "message": "Model \"/models/model\" does not support matryoshka representation, changing output dimensions will lead to poor results.",
        "type": "BadRequestError",
        "param": null,
        "code": 400
    }
}

### Sin el parámetro dimensions y solo viendo las primeras 30 dimensiones para que no sea tan largo:

admin@Bog2-cpul040547:~/Documents$ curl -s http://localhost:8001/v1/embeddings   -H "Content-Type: application/json"   -d '{                                                                                          "model": "/models/model",
    "input": "Buenos días, le habla el Banco A"
  }' | python3 -m json.tool | head -30
{
    "id": "embd-83a4c083a9030bec",
    "object": "list",
    "created": 1787087665,
    "model": "/models/model",
    "data": [
        {
            "index": 0,
            "object": "embedding",
            "embedding": [
                -0.05679900944232941,
                -0.021165668964385986,
                -0.0025954735465347767,
                -0.04099173843860626,
                0.02652406506240368,
                -0.056531090289354324,
                -0.028533464297652245,
                0.041259657591581345,
                -0.04018797725439072,
                0.04367093741893768,
                -0.03724085912108421,
                -0.006932426244020462,
                0.08359099179506302,
                -0.0038848379626870155,
                -0.04608221352100372,
                0.07608924061059952,
                -0.08037595450878143,
                0.020763788372278214,
                0.04929725453257561,
                -0.024380706250667572,
admin@Bog2-cpul040547:~/Documents$ 

- En este caso mejor que sobre y no que falte. Vectores del máximo 1024 no están mal y garantizarían representación semántica grande para el voicebot. Pero en principio, este modelo Qwen de embedding soporta **Matryoshka Representation Learning**.


**Matryoshka Representation Learning (MRL)** es una técnica de entrenamiento que hace que un embedding sea "recortable": las primeras N dimensiones del vector, tomadas solas, ya son una representación útil del significado completo, sin necesitar las dimensiones restantes.

Esto significa que se puede usar el vector completo (ej. 1024 dimensiones) para máxima precisión, o truncarlo a un tamaño menor (ej. 256) para ahorrar memoria y velocidad de búsqueda, sacrificando algo de calidad de forma controlada y predecible.

El nombre viene de las muñecas rusas Matryoshka: cada muñeca más chica vive completa dentro de la más grande, igual que cada "sub-vector" más corto vive como un prefijo válido dentro del vector completo.


# BUSCANDO EN INTERNET, AL PARECER TOCA PROPORCIONAR PARÁMETROS ADICIONALES A vLLM PARA QUE ENTIENDA QUE EL MODELO SI PERMITE LA REPRESENTACIÓN MATRYOSHKA, PORQUE EL CONFIG.JSON DEL MODELO NO DICE EN NINGUNA PARTE QUE EL MODELO SOPORTE MATRYOSHKA:

- Detenemos y borramos la instancia del contenedor previamente ejecutado:

root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# docker stop vllm-embedding-06b
vllm-embedding-06b
root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# docker rm vllm-embedding-06b
vllm-embedding-06b

- Ejecutamos otro docker run, CON ALGO LLAMADO hf_overrides:

*Para modelos que sí soportan Matryoshka Embeddings pero vLLM no los reconoce automáticamente, se puede sobreescribir manualmente la configuración usando hf_overrides={"is_matryoshka": True} o hf_overrides={"matryoshka_dimensions": [<dimensiones permitidas>]} — ya sea en modo offline (código Python) o al servir online, con la flag --hf_overrides.*


docker run -d \
  --name vllm-embedding-06b \
  --gpus all \
  -p 8001:8000 \
  -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model \
  -e MODEL_PATH=/models/model \
  -e MAX_MODEL_LEN=32768 \
  -e GPU_MEMORY_UTIL=0.3 \
  hellohal2064/vllm-dgx-spark-gb10:latest \
  --hf_overrides '{"matryoshka_dimensions": [32, 64, 128, 256, 512, 1024]}' && docker logs -f vllm-embedding-06b

# Resultado ejecución contenedor punto servidor

root@Bog2-cpul040547:/home/user_ia/api_rag_prototipo/qwen3_0_6_b# docker run -d   --name vllm-embedding-06b   --gpus all   -p 8001:8000   -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model   -e MODEL_PATH=/models/model   -e MAX_MODEL_LEN=32768   -e GPU_MEMORY_UTIL=0.3   hellohal2064/vllm-dgx-spark-gb10:latest   --hf_overrides '{"matryoshka_dimensions": [32, 64, 128, 256, 512, 1024]}' && docker logs -f vllm-embedding-06b
bc92d357813ca60609d02939260a8c0ee1414a3a39c62a8709eb05e742b37e68
[PATCH] Applied Qwen3 reasoning parser fix
=============================================
vLLM Server for NVIDIA GB10 (SM121 Blackwell)
=============================================

Configuration:
  Model: /models/model
  Host: 0.0.0.0:8000
  Max Model Length: 32768
  GPU Memory Utilization: 0.3
  Attention Backend: FLASHINFER
  Tool Call Parser: qwen3_coder
  Reasoning Parser: qwen3
  Thinking Mode: true

Starting vLLM server...

INFO 08-20 12:53:08 [importing.py:85] Detected GPU with compute capability 12.1 (arch=121). Configuring TRITON_PTXAS_PATH=/usr/local/cuda/bin/ptxas to ensure Triton kernel compilation compatibility.
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:314] 
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:314]        █     █     █▄   ▄█
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:314]  ▄▄ ▄█ █     █     █ ▀▄▀ █  version 0.16.0rc1.dev122+g6595a2380
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:314]   █▄█▀ █     █     █     █  model   /models/model
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:314]    ▀▀  ▀▀▀▀▀ ▀▀▀▀▀ ▀     ▀
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:314] 
(APIServer pid=1) INFO 08-20 12:53:10 [utils.py:250] non-default args: {'model_tag': '/models/model', 'api_server_count': 1, 'host': '0.0.0.0', 'default_chat_template_kwargs': {'enable_thinking': True}, 'enable_auto_tool_choice': True, 'tool_call_parser': 'qwen3_coder', 'enable_prompt_tokens_details': True, 'model': '/models/model', 'max_model_len': 32768, 'hf_overrides': {'matryoshka_dimensions': [32, 64, 128, 256, 512, 1024]}, 'generation_config': 'vllm', 'reasoning_parser': 'qwen3', 'gpu_memory_utilization': 0.3, 'attention_config': AttentionConfig(backend=<AttentionBackendEnum.FLASHINFER: 'vllm.v1.attention.backends.flashinfer.FlashInferBackend'>, flash_attn_version=None, use_prefill_decode_attention=False, flash_attn_max_num_splits_for_cuda_graph=32, use_cudnn_prefill=False, use_trtllm_ragged_deepseek_prefill=True, use_trtllm_attention=None, disable_flashinfer_prefill=False, disable_flashinfer_q_quantization=False)}
(APIServer pid=1) INFO 08-20 12:53:13 [config.py:764] Found sentence-transformers modules configuration.
(APIServer pid=1) INFO 08-20 12:53:13 [config.py:791] Found pooling configuration.
(APIServer pid=1) INFO 08-20 12:53:13 [model.py:804] Resolved `--runner auto` to `--runner pooling`. Pass the value explicitly to silence this message.
(APIServer pid=1) INFO 08-20 12:53:13 [model.py:856] Resolved `--convert auto` to `--convert embed`. Pass the value explicitly to silence this message.
(APIServer pid=1) INFO 08-20 12:53:13 [model.py:532] Resolved architecture: Qwen3ForCausalLM
(APIServer pid=1) INFO 08-20 12:53:13 [model.py:1543] Using max model len 32768
(APIServer pid=1) INFO 08-20 12:53:13 [scheduler.py:226] Chunked prefill is enabled with max_num_batched_tokens=2048.
(APIServer pid=1) INFO 08-20 12:53:13 [vllm.py:669] Asynchronous scheduling is enabled.
(APIServer pid=1) WARNING 08-20 12:53:13 [vllm.py:786] Pooling models do not support full cudagraphs. Overriding cudagraph_mode to PIECEWISE.
(EngineCore_DP0 pid=106) INFO 08-20 12:53:16 [core.py:96] Initializing a V1 LLM engine (v0.16.0rc1.dev122+g6595a2380) with config: model='/models/model', speculative_config=None, tokenizer='/models/model', skip_tokenizer_init=False, tokenizer_mode=auto, revision=None, tokenizer_revision=None, trust_remote_code=False, dtype=torch.bfloat16, max_seq_len=32768, download_dir=None, load_format=auto, tensor_parallel_size=1, pipeline_parallel_size=1, data_parallel_size=1, disable_custom_all_reduce=False, quantization=None, enforce_eager=False, enable_return_routed_experts=False, kv_cache_dtype=auto, device_config=cuda, structured_outputs_config=StructuredOutputsConfig(backend='auto', disable_fallback=False, disable_any_whitespace=False, disable_additional_properties=False, reasoning_parser='qwen3', reasoning_parser_plugin='', enable_in_reasoning=False), observability_config=ObservabilityConfig(show_hidden_metrics_for_version=None, otlp_traces_endpoint=None, collect_detailed_traces=None, kv_cache_metrics=False, kv_cache_metrics_sample=0.01, cudagraph_metrics=False, enable_layerwise_nvtx_tracing=False, enable_mfu_metrics=False, enable_mm_processor_stats=False, enable_logging_iteration_details=False), seed=0, served_model_name=/models/model, enable_prefix_caching=True, enable_chunked_prefill=True, pooler_config=PoolerConfig(pooling_type=None, seq_pooling_type='LAST', tok_pooling_type='ALL', use_activation=True, dimensions=None, enable_chunked_processing=None, max_embed_len=None, logit_bias=None, step_tag_id=None, returned_token_ids=None), compilation_config={'level': None, 'mode': <CompilationMode.VLLM_COMPILE: 3>, 'debug_dump_path': None, 'cache_dir': '', 'compile_cache_save_format': 'binary', 'backend': 'inductor', 'custom_ops': ['none'], 'splitting_ops': ['vllm::unified_attention', 'vllm::unified_attention_with_output', 'vllm::unified_mla_attention', 'vllm::unified_mla_attention_with_output', 'vllm::mamba_mixer2', 'vllm::mamba_mixer', 'vllm::short_conv', 'vllm::linear_attention', 'vllm::plamo2_mamba_mixer', 'vllm::gdn_attention_core', 'vllm::kda_attention', 'vllm::sparse_attn_indexer', 'vllm::rocm_aiter_sparse_attn_indexer', 'vllm::unified_kv_cache_update'], 'compile_mm_encoder': False, 'compile_sizes': [], 'compile_ranges_split_points': [2048], 'inductor_compile_config': {'enable_auto_functionalized_v2': False, 'combo_kernels': True, 'benchmark_combo_kernel': True}, 'inductor_passes': {}, 'cudagraph_mode': <CUDAGraphMode.PIECEWISE: 1>, 'cudagraph_num_of_warmups': 1, 'cudagraph_capture_sizes': [1, 2, 4, 8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136, 144, 152, 160, 168, 176, 184, 192, 200, 208, 216, 224, 232, 240, 248, 256, 272, 288, 304, 320, 336, 352, 368, 384, 400, 416, 432, 448, 464, 480, 496, 512], 'cudagraph_copy_inputs': False, 'cudagraph_specialize_lora': True, 'use_inductor_graph_partition': False, 'pass_config': {'fuse_norm_quant': False, 'fuse_act_quant': False, 'fuse_attn_quant': False, 'eliminate_noops': True, 'enable_sp': False, 'fuse_gemm_comms': False, 'fuse_allreduce_rms': False, 'fuse_act_padding': False}, 'max_cudagraph_capture_size': 512, 'dynamic_shapes_config': {'type': <DynamicShapesType.BACKED: 'backed'>, 'evaluate_guards': False, 'assume_32_bit_indexing': False}, 'local_cache_dir': None, 'static_all_moe_layers': []}
(EngineCore_DP0 pid=106) INFO 08-20 12:53:16 [parallel_state.py:1234] world_size=1 rank=0 local_rank=0 distributed_init_method=tcp://172.17.0.4:48801 backend=nccl
(EngineCore_DP0 pid=106) INFO 08-20 12:53:16 [parallel_state.py:1445] rank 0 in world size 1 is assigned as DP rank 0, PP rank 0, PCP rank 0, TP rank 0, EP rank N/A
(EngineCore_DP0 pid=106) INFO 08-20 12:53:17 [gpu_model_runner.py:4116] Starting to load model /models/model...
(EngineCore_DP0 pid=106) INFO 08-20 12:53:17 [cuda.py:360] Using AttentionBackendEnum.FLASHINFER backend.
(EngineCore_DP0 pid=106) INFO 08-20 12:53:17 [selector.py:112] Using HND KV cache layout for FLASHINFER backend.
Loading safetensors checkpoint shards:   0% Completed | 0/1 [00:00<?, ?it/s]
(EngineCore_DP0 pid=106) INFO 08-20 12:53:17 [adapters.py:204] Mapping weights to Qwen3Model as they are relative to this model instead of Qwen3ForEmbedding.
Loading safetensors checkpoint shards: 100% Completed | 1/1 [00:00<00:00, 376.47it/s]
(EngineCore_DP0 pid=106) 
(EngineCore_DP0 pid=106) INFO 08-20 12:53:24 [default_loader.py:291] Loading weights took 6.58 seconds
(EngineCore_DP0 pid=106) INFO 08-20 12:53:24 [gpu_model_runner.py:4213] Model loading took 1.12 GiB memory and 7.292358 seconds
(EngineCore_DP0 pid=106) INFO 08-20 12:53:28 [backends.py:860] Using cache directory: /root/.cache/vllm/torch_compile_cache/d9954e5120/rank_0_0/backbone for vLLM's torch.compile
(EngineCore_DP0 pid=106) INFO 08-20 12:53:28 [backends.py:920] Dynamo bytecode transform time: 3.23 s
(EngineCore_DP0 pid=106) [rank0]:W0820 12:53:29.455000 106 torch/_inductor/utils.py:1697] Not enough SMs to use max_autotune_gemm mode
(EngineCore_DP0 pid=106) INFO 08-20 12:53:33 [backends.py:300] Cache the graph of compile range (1, 2048) for later use
(EngineCore_DP0 pid=106) INFO 08-20 12:53:37 [backends.py:317] Compiling a graph for compile range (1, 2048) takes 8.34 s
(EngineCore_DP0 pid=106) INFO 08-20 12:53:37 [monitor.py:34] torch.compile takes 11.56 s in total
(EngineCore_DP0 pid=106) INFO 08-20 12:53:37 [decorators.py:574] saving AOT compiled function to /root/.cache/vllm/torch_aot_compile/bdefa702f9129be0c22143c46cdb344f988ba918cc0bb1cc0fe05eba3be07bef/rank_0_0/model
(EngineCore_DP0 pid=106) INFO 08-20 12:53:38 [decorators.py:578] saved AOT compiled function to /root/.cache/vllm/torch_aot_compile/bdefa702f9129be0c22143c46cdb344f988ba918cc0bb1cc0fe05eba3be07bef/rank_0_0/model
(EngineCore_DP0 pid=106) INFO 08-20 12:53:39 [gpu_worker.py:359] Available KV cache memory: 34.07 GiB
(EngineCore_DP0 pid=106) INFO 08-20 12:53:39 [kv_cache_utils.py:1307] GPU KV cache size: 319,008 tokens
(EngineCore_DP0 pid=106) INFO 08-20 12:53:39 [kv_cache_utils.py:1312] Maximum concurrency for 32,768 tokens per request: 9.74x
(EngineCore_DP0 pid=106) INFO 08-20 12:53:40 [utils.py:59] `_KV_CACHE_LAYOUT_OVERRIDE` variable detected. Setting KV cache layout to HND.
(EngineCore_DP0 pid=106) 2026-08-20 12:53:40,315 - INFO - autotuner.py:256 - flashinfer.jit: [Autotuner]: Autotuning process starts ...
(EngineCore_DP0 pid=106) 2026-08-20 12:53:40,335 - INFO - autotuner.py:262 - flashinfer.jit: [Autotuner]: Autotuning process ends
Capturing CUDA graphs (mixed prefill-decode, PIECEWISE): 100%|██████████| 51/51 [00:00<00:00, 62.69it/s]
(EngineCore_DP0 pid=106) INFO 08-20 12:53:41 [gpu_model_runner.py:5227] Graph capturing finished in 1 secs, took 0.34 GiB
(EngineCore_DP0 pid=106) INFO 08-20 12:53:41 [core.py:272] init engine (profile, create kv cache, warmup model) took 16.81 seconds
(EngineCore_DP0 pid=106) INFO 08-20 12:53:42 [vllm.py:669] Asynchronous scheduling is enabled.
(APIServer pid=1) INFO 08-20 12:53:42 [api_server.py:455] Supported tasks: ['embed', 'token_embed']
(APIServer pid=1) INFO 08-20 12:53:42 [api_server.py:460] Starting vLLM API server 0 on http://0.0.0.0:8000
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:38] Available routes are:
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /openapi.json, Methods: HEAD, GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /docs, Methods: HEAD, GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /docs/oauth2-redirect, Methods: HEAD, GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /redoc, Methods: HEAD, GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /load, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /version, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /scale_elastic_ep, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /is_scaling_elastic_ep, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /tokenize, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /detokenize, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /inference/v1/generate, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /pause, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /resume, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /is_paused, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /metrics, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /health, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /v1/models, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /ping, Methods: GET
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /ping, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /invocations, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /pooling, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /v1/embeddings, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /score, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /v1/score, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /rerank, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /v1/rerank, Methods: POST
(APIServer pid=1) INFO 08-20 12:53:42 [launcher.py:47] Route: /v2/rerank, Methods: POST
(APIServer pid=1) INFO:     Started server process [1]
(APIServer pid=1) INFO:     Waiting for application startup.
(APIServer pid=1) INFO:     Application startup complete.


# Resultado ejecución comando embedding punto cliente consola

admin@Bog2-cpul040547:~$ curl -s http://localhost:8001/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{
    "model": "/models/model",
    "input": "Buenos días, le habla el banco A",
    "dimensions": 32 
  }' | python3 -m json.tool
{
    "id": "embd-be1fdc1903b614db",
    "object": "list",
    "created": 1787230556,
    "model": "/models/model",
    "data": [
        {
            "index": 0,
            "object": "embedding",
            "embedding": [
                -0.23306338489055634,
                -0.08950985223054886,
                -0.017099758610129356,
                -0.21279700100421906,
                0.12722784280776978,
                -0.24544839560985565,
                -0.08275438845157623,
                0.16776059567928314,
                -0.18239742517471313,
                0.1722642332315445,
                -0.1610051393508911,
                -0.0344809964299202,
                0.3805575966835022,
                -0.022377463057637215,
                -0.20716744661331177,
                0.2949884235858917,
                -0.25670748949050903,
                0.06586574018001556,
                0.20716744661331177,
                -0.10245781391859055,
                -0.0923246219754219,
                0.12835374474525452,
                0.1086503192782402,
                0.285981148481369,
                0.015270154923200607,
                -0.10470963269472122,
                -0.19816017150878906,
                0.2792257070541382,
                0.11090213805437088,
                0.004486048128455877,
                0.17789378762245178,
                0.026740364730358124
            ]
        }
    ],
    "usage": {
        "prompt_tokens": 12,
        "total_tokens": 12,
        "completion_tokens": 0,
        "prompt_tokens_details": null
    }
}


# 21 Septiembre 2026: Continuación API RAG

Tuve que interrumpir porque me pidieron un contenedor con SGLang para ejecutar el modelo Fish S2 Pro, con despliegue en H200 y pruebas de RTF.

Hasta el momento tenemos lo siguiente en cuanto a la API de RAG:

## - Endpoint de Qdrant:

### Ejecución:

docker run -d \
  --name qdrant \
  -p 6333:6333 \
  -p 6334:6334 \
  -v /home/user_ia/api_rag_prototipo/qdrant_storage:/qdrant/storage \
  qdrant/qdrant && docker logs -f qdrant
  
### Ingreso a la URL:

http://localhost:6333/dashboard#/welcome

## - Endpoint vLLM con Qwen3-embedding-0.6b:

### Ejecución:

docker run -d \
  --name vllm-embedding-06b \
  --gpus all \
  -p 8001:8000 \
  -v /home/user_ia/api_rag_prototipo/qwen3_0_6_b:/models/model \
  -e MODEL_PATH=/models/model \
  -e MAX_MODEL_LEN=32768 \
  -e GPU_MEMORY_UTIL=0.3 \
  hellohal2064/vllm-dgx-spark-gb10:latest \
  --hf_overrides '{"matryoshka_dimensions": [32, 64, 128, 256, 512, 1024]}' && docker logs -f vllm-embedding-06b

## - Endpoint convencional de ollama con modelos dengcao/Qwen3-Reranker-8B:q8_0 y qwen3-embedding:8b:

root@Bog2-cpul040547:/home/user_ia# ollama list

NAME                              ID              SIZE      MODIFIED
dengcao/Qwen3-Reranker-8B:q8_0    20b136c51d90    8.7 GB    5 weeks ago
qwen3-embedding:8b                64b933495768    4.7 GB    2 months ago
qwen3-embedding:4b                df5bd2e3c74c    2.5 GB    2 months ago
qwen3-embedding:0.6b              ac6da0dfba84    639 MB    2 months ago


# Estructura prototipo 1

api_rag_code/
├── proto/
│   └── rag.proto                      # Contrato gRPC (Retrieve/Ingest/Delete), incluye ef_search opcional
├── rag_api/
│   ├── __init__.py                    # Marca rag_api/ como paquete Python importable
│   ├── server.py                      # Punto de entrada: arranca gRPC, registra el servicio, dispara bootstrap
│   ├── config.py                      # Lee todas las variables de entorno y las expone tipadas al resto del código
│   ├── generated/                     # Stubs generados por protoc a partir de rag.proto (no se editan a mano)
│   ├── clients/
│   │   ├── qdrant_client.py           # Crear/verificar colecciones, upsert, search (denso/hybrid), delete
│   │   ├── vllm_client.py             # Llama al endpoint de embeddings 0.6b (camino rápido)
│   │   └── ollama_client.py           # Llama a embeddings 8b y al reranker (camino preciso)
│   ├── chunking/
│   │   ├── base.py                    # Interfaz común que cumplen las 5 estrategias de chunking
│   │   ├── recursivo.py               # Corte por separadores naturales, con corte ciego como último recurso
│   │   ├── fijo.py                    # Corte ciego cada N tokens (punto de comparación/control)
│   │   ├── semantic.py                # Corte por cambio de tema usando el propio modelo de embeddings
│   │   ├── ast_codigo.py              # Chunking consciente de código vía Tree-sitter (patrón cAST)
│   │   └── clausula_legal.py          # Chunking jerárquico padre-hijo para artículos/cláusulas legales
│   └── services/
│       ├── retrieve_service.py        # Lógica de negocio del RPC Retrieve (bifurca perfil rápido/preciso)
│       ├── ingest_service.py          # Lógica de negocio del RPC Ingest (chunking + embedding + upsert)
│       └── delete_service.py          # Lógica de negocio del RPC Delete (por id o filtro, con dry_run)
├── scripts/
│   └── bootstrap_collections.py       # Invocación manual/independiente de la creación de colecciones
├── tests/
│   └── ...                            # Pruebas del proyecto
├── requirements.txt                   # Dependencias Python del proyecto
└── README.md                          # Documentación del proyecto
