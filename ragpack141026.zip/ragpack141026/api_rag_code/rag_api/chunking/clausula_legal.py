"""
Estrategia de chunking jerarquico para contenido legal.

Pensada para leyes, decretos, resoluciones, acuerdos y contratos, en
Markdown o en texto plano. La estructura que reconoce es:

  - Encabezado: todo lo que precede a CONSIDERANDO / DECRETA / el
    primer articulo (titulo, epigrafe, facultades).
  - Considerandos: parrafos "Que ..." de la parte motiva. Se agrupan
    parrafos completos hasta el tamano maximo; no llevan texto_padre.
  - Articulos (o clausulas): la unidad legal. Cada articulo es el
    "padre". Si el articulo tiene parragrafos, cada parte (el cuerpo y
    cada parragrafo) es un chunk "hijo" y texto_padre guarda el
    articulo completo. Si no tiene parragrafos y cabe en el tamano
    maximo, es un solo chunk sin texto_padre. Si no cabe, se divide
    por parrafos (incisos) y luego por oraciones, nunca a mitad de
    palabra, y texto_padre guarda el articulo completo.
  - Cierre: PUBLIQUESE / firmas, desde la regla horizontal o el
    marcador de publicacion hasta el final del documento.

Cada chunk lleva como primera linea un contexto breve (norma, seccion
si la hay y, cuando el chunk no empieza con el encabezado del
articulo, la etiqueta del articulo). Esa linea forma parte del texto
que se vectoriza.

Las citas en bloque (lineas que empiezan con '>') se consideran parte
del articulo que las contiene: un articulo citado dentro de otro, con
sus parragrafos, no se interpreta como estructura propia.

El texto de los chunks se entrega sin marcas de formato Markdown
(negritas, cursivas, '>' y '#').

overlap_tokens se ignora deliberadamente: las unidades legales son
unidades de sentido completas.
"""

import logging
import re
from dataclasses import dataclass, field

import tiktoken

from rag_api.chunking.base import ChunkGenerado, EstrategiaChunkingBase

logger = logging.getLogger(__name__)

_ENCODING = tiktoken.get_encoding("cl100k_base")

# El texto_padre se omite si el articulo completo supera este multiplo
# del tamano de chunk (evita payloads enormes en articulos gigantes).
_MULTIPLO_MAX_PADRE = 4

_RE_IDENTIFICADOR = re.compile(
    r"^(ley|decreto|resoluci[oó]n|acuerdo|circular|ordenanza|sentencia|contrato|acto legislativo)\b.*\d",
    re.IGNORECASE,
)
_RE_ARTICULO = re.compile(
    r"^(art[ií]culo|cl[aá]usula)\s+[\w\-]+\s*[°º]?\s*[\.\-:]",
    re.IGNORECASE,
)
_RE_PARAGRAFO = re.compile(
    r"^par[aá]grafo(?:\s+[\w\-]+)?\s*[°º]?\s*[\.\-:]",
    re.IGNORECASE,
)
_RE_SECCION = re.compile(
    r"^(cap[ií]tulo|t[ií]tulo|secci[oó]n|libro|parte)\s+[\w\-]+",
    re.IGNORECASE,
)
_RE_CIERRE = re.compile(
    r"^(publ[ií]quese|comun[ií]quese|not[ií]fiquese|c[uú]mplase)\b",
    re.IGNORECASE,
)
_RE_REGLA = re.compile(r"^\s*([-*_])(?:\s*\1){2,}\s*$")

_CLAVES_CONSIDERANDO = {"considerando", "considerandos"}
_CLAVES_RESOLUTIVA = {"decreta", "resuelve", "acuerda", "ordena", "expide", "dispone"}


@dataclass
class _Bloque:
    tipo: str  # encabezado | considerando | articulo | texto | cierre
    lineas: list[str] = field(default_factory=list)
    etiqueta: str = ""
    seccion: str = ""


def _contar_tokens(texto: str) -> int:
    return len(_ENCODING.encode(texto))


def _limpiar_linea(raw: str) -> str:
    s = raw.strip()
    s = re.sub(r"^(?:>\s?)+", "", s)
    s = re.sub(r"^#{1,6}\s+", "", s)
    s = s.replace("**", "").replace("__", "")
    s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"\1", s)
    s = s.strip()
    if s.lower() == "[firma]":
        return ""
    return s


def _unir(lineas: list[str]) -> str:
    texto = "\n".join(lineas)
    texto = re.sub(r"\n{3,}", "\n\n", texto)
    return texto.strip()


def _clave(limpia: str) -> str:
    return limpia.strip().rstrip(":.").strip().lower()


def _es_cita(raw: str) -> bool:
    return raw.lstrip().startswith(">")


def _es_encabezado_seccion(raw: str, limpia: str) -> bool:
    if len(limpia) > 120 or not _RE_SECCION.match(limpia):
        return False
    s = raw.strip()
    return s.startswith("#") or (s.startswith("**") and s.endswith("**")) or limpia.isupper()


def _extraer_etiqueta(raw: str, limpia: str) -> str:
    s = re.sub(r"^(?:>\s?)+", "", raw.strip())
    m = re.match(r"^\*\*(.+?)\*\*(?:\s*\*([^*]+?)\*)?", s)
    if m:
        etiqueta = _limpiar_linea(m.group(1))
        if m.group(2):
            etiqueta += " " + m.group(2).strip()
    else:
        m2 = re.match(r"^(\S+\s+\S+?[\.\-:])", limpia)
        etiqueta = m2.group(1) if m2 else limpia[:60]
    return etiqueta.strip().rstrip(".:-").strip()


def _con_prefijo(prefijo: str, cuerpo: str) -> str:
    return f"{prefijo}\n{cuerpo}" if prefijo else cuerpo


class ChunkingClausulaLegal(EstrategiaChunkingBase):
    def chunkear(
        self,
        texto: str,
        tamano_tokens: int,
        overlap_tokens: int,
        lenguaje_codigo: str | None = None,
        fuente: str | None = None,
    ) -> list[ChunkGenerado]:
        if not texto.strip():
            return []

        lineas = texto.splitlines()
        doc_id = self._detectar_identificador(lineas) or (fuente or "")
        bloques = self._segmentar(lineas)

        if not any(b.tipo == "articulo" for b in bloques):
            logger.warning(
                "CHUNKING_CLAUSULA_LEGAL_JERARQUICA: no se detecto ningun articulo ni clausula "
                "(fuente=%s); el documento se divide por parrafos y oraciones", fuente
            )

        chunks: list[ChunkGenerado] = []
        for bloque in bloques:
            cuerpo = _unir([_limpiar_linea(raw) for raw in bloque.lineas])
            if not cuerpo:
                continue

            if bloque.tipo == "encabezado":
                chunks.extend(self._chunks_planos(cuerpo, "", tamano_tokens))
            elif bloque.tipo == "considerando":
                prefijo = self._unir_prefijo(doc_id, "CONSIDERANDO")
                chunks.extend(self._chunks_planos(cuerpo, prefijo, tamano_tokens))
            elif bloque.tipo == "cierre":
                prefijo = self._unir_prefijo(doc_id, "Cierre")
                chunks.extend(self._chunks_planos(cuerpo, prefijo, tamano_tokens))
            elif bloque.tipo == "texto":
                prefijo = self._unir_prefijo(doc_id, bloque.seccion)
                chunks.extend(self._chunks_planos(cuerpo, prefijo, tamano_tokens))
            else:
                chunks.extend(self._chunks_articulo(bloque, doc_id, tamano_tokens))

        return chunks

    # -----------------------------------------------------------------
    # Segmentacion del documento en bloques
    # -----------------------------------------------------------------

    @staticmethod
    def _detectar_identificador(lineas: list[str]) -> str:
        for raw in lineas[:40]:
            limpia = _limpiar_linea(raw)
            if limpia and len(limpia) <= 160 and _RE_IDENTIFICADOR.match(limpia):
                return limpia
        return ""

    @staticmethod
    def _unir_prefijo(*partes: str) -> str:
        return " | ".join(p for p in partes if p)

    def _segmentar(self, lineas: list[str]) -> list[_Bloque]:
        actual = _Bloque("encabezado")
        bloques = [actual]
        seccion = ""
        hay_articulo = False

        i = 0
        while i < len(lineas):
            raw = lineas[i]
            i += 1
            limpia = _limpiar_linea(raw)

            if _es_cita(raw):
                actual.lineas.append(raw)
                continue

            if _RE_REGLA.match(raw):
                if hay_articulo and actual.tipo != "cierre":
                    actual = _Bloque("cierre")
                    bloques.append(actual)
                continue

            clave = _clave(limpia)

            if clave in _CLAVES_CONSIDERANDO and not hay_articulo:
                actual = _Bloque("considerando")
                bloques.append(actual)
                continue

            if clave in _CLAVES_RESOLUTIVA and actual.tipo != "cierre":
                actual = _Bloque("texto", seccion=seccion)
                bloques.append(actual)
                continue

            if hay_articulo and actual.tipo != "cierre" and _RE_CIERRE.match(limpia):
                actual = _Bloque("cierre")
                bloques.append(actual)
                actual.lineas.append(raw)
                continue

            if actual.tipo != "cierre" and _RE_ARTICULO.match(limpia):
                hay_articulo = True
                actual = _Bloque("articulo", etiqueta=_extraer_etiqueta(raw, limpia), seccion=seccion)
                actual.lineas.append(raw)
                bloques.append(actual)
                continue

            if actual.tipo != "cierre" and _es_encabezado_seccion(raw, limpia):
                nombre = limpia
                j = i
                while j < len(lineas) and not lineas[j].strip():
                    j += 1
                if j < len(lineas) and not _es_cita(lineas[j]):
                    siguiente = _limpiar_linea(lineas[j])
                    if (
                        siguiente
                        and siguiente.isupper()
                        and len(siguiente) <= 120
                        and not _RE_ARTICULO.match(siguiente)
                    ):
                        nombre = f"{limpia} - {siguiente}"
                        i = j + 1
                seccion = nombre
                if actual.tipo == "articulo":
                    actual = _Bloque("texto", seccion=seccion)
                    bloques.append(actual)
                continue

            actual.lineas.append(raw)

        return bloques

    # -----------------------------------------------------------------
    # Generacion de chunks
    # -----------------------------------------------------------------

    def _chunks_planos(self, cuerpo: str, prefijo: str, tamano_tokens: int) -> list[ChunkGenerado]:
        limite = self._limite(prefijo, tamano_tokens)
        parrafos = [p for p in re.split(r"\n\s*\n", cuerpo) if p.strip()]
        grupos = self._empaquetar(parrafos, limite, "\n\n", 0)
        return [ChunkGenerado(texto=_con_prefijo(prefijo, grupo)) for grupo in grupos]

    def _chunks_articulo(self, bloque: _Bloque, doc_id: str, tamano_tokens: int) -> list[ChunkGenerado]:
        limpias = [_limpiar_linea(raw) for raw in bloque.lineas]

        partes: list[list[str]] = [[]]
        for indice, (raw, limpia) in enumerate(zip(bloque.lineas, limpias)):
            if indice > 0 and not _es_cita(raw) and _RE_PARAGRAFO.match(limpia):
                partes.append([])
            partes[-1].append(limpia)
        textos_partes = [t for t in (_unir(p) for p in partes) if t]

        completo = _unir(limpias)
        prefijo_base = self._unir_prefijo(doc_id, bloque.seccion)
        prefijo_con_articulo = self._unir_prefijo(prefijo_base, bloque.etiqueta)
        limite = self._limite(prefijo_con_articulo, tamano_tokens)

        usar_padre = _contar_tokens(completo) <= _MULTIPLO_MAX_PADRE * tamano_tokens
        padre = _con_prefijo(prefijo_base, completo) if usar_padre else None

        tiene_hijos = len(textos_partes) > 1

        if not tiene_hijos:
            if _contar_tokens(_con_prefijo(prefijo_base, completo)) <= tamano_tokens:
                return [ChunkGenerado(texto=_con_prefijo(prefijo_base, completo))]

        chunks: list[ChunkGenerado] = []
        for indice_parte, parte in enumerate(textos_partes):
            fragmentos = self._fragmentar(parte, limite)
            for indice_fragmento, fragmento in enumerate(fragmentos):
                empieza_con_encabezado = indice_parte == 0 and indice_fragmento == 0
                prefijo = prefijo_base if empieza_con_encabezado else prefijo_con_articulo
                chunks.append(ChunkGenerado(texto=_con_prefijo(prefijo, fragmento), texto_padre=padre))
        return chunks

    # -----------------------------------------------------------------
    # Utilidades de tamano
    # -----------------------------------------------------------------

    @staticmethod
    def _limite(prefijo: str, tamano_tokens: int) -> int:
        reservado = _contar_tokens(prefijo) if prefijo else 0
        return max(tamano_tokens - reservado, tamano_tokens // 2, 1)

    def _fragmentar(self, texto: str, limite: int) -> list[str]:
        if _contar_tokens(texto) <= limite:
            return [texto]
        parrafos = [p for p in re.split(r"\n\s*\n", texto) if p.strip()]
        return self._empaquetar(parrafos, limite, "\n\n", 0)

    def _empaquetar(self, unidades: list[str], limite: int, separador: str, nivel: int) -> list[str]:
        """
        Agrupa unidades completas hasta el limite de tokens. nivel 0:
        parrafos; nivel 1: oraciones; nivel 2: palabras. Una unidad
        que por si sola excede el limite se baja al nivel siguiente,
        asi el corte cae siempre en un limite de parrafo, oracion o
        palabra, nunca en mitad de una palabra.
        """
        grupos: list[str] = []
        actual: list[str] = []
        usados = 0

        for unidad in unidades:
            unidad = unidad.strip()
            if not unidad:
                continue
            tokens = _contar_tokens(unidad)

            if tokens > limite and nivel < 2:
                if actual:
                    grupos.append(separador.join(actual))
                    actual = []
                    usados = 0
                if nivel == 0:
                    sub = re.split(r"(?<=[\.;:])\s+", unidad)
                    grupos.extend(self._empaquetar(sub, limite, " ", 1))
                else:
                    grupos.extend(self._empaquetar(unidad.split(), limite, " ", 2))
                continue

            if actual and usados + tokens > limite:
                grupos.append(separador.join(actual))
                actual = []
                usados = 0

            actual.append(unidad)
            usados += tokens

        if actual:
            grupos.append(separador.join(actual))

        return grupos
