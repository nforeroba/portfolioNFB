"""
Carga el modelo y tokenizador al inicio del contenedor
según las variables de entorno MODEL_NAME y QUANTIZATION.
"""

import os
import sys
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

# ── Variables de entorno ──────────────────────────────────────────────────────

MODEL_NAME    = os.environ.get("MODEL_NAME", "").strip()
QUANTIZATION  = os.environ.get("QUANTIZATION", "none").strip().lower()

# ── Mapa de nombres cortos a rutas locales ────────────────────────────────────

MODEL_MAP = {
    "qwen2.5-0.5b-instruct":  "Qwen--Qwen2.5-0.5B-Instruct",
    "qwen2.5-1.5b-instruct":  "Qwen--Qwen2.5-1.5B-Instruct",
    "qwen2.5-3b-instruct":    "Qwen--Qwen2.5-3B-Instruct",
    "gemma-3-1b-it":          "google--gemma-3-1b-it",
    "smollm2-1.7b-instruct":  "HuggingFaceTB--SmolLM2-1.7B-Instruct",
    "phi-3.5-mini-instruct":  "microsoft--Phi-3.5-mini-instruct",
}

MODELS_DIR = "/app/models"

# ── Validaciones ──────────────────────────────────────────────────────────────

def _validate():
    if not MODEL_NAME:
        print("ERROR: La variable de entorno MODEL_NAME no está definida.", file=sys.stderr)
        print(f"       Modelos disponibles: {', '.join(MODEL_MAP.keys())}", file=sys.stderr)
        sys.exit(1)

    key = MODEL_NAME.lower()
    if key not in MODEL_MAP:
        print(f"ERROR: MODEL_NAME='{MODEL_NAME}' no reconocido.", file=sys.stderr)
        print(f"       Modelos disponibles: {', '.join(MODEL_MAP.keys())}", file=sys.stderr)
        sys.exit(1)

    if QUANTIZATION not in ("none", "fp16", "int8", "int4", "fp8"):
        print(f"ERROR: QUANTIZATION='{QUANTIZATION}' no válido.", file=sys.stderr)
        print("       Valores válidos: none, fp16, int8, int4, fp8", file=sys.stderr)
        sys.exit(1)

    model_path = os.path.join(MODELS_DIR, MODEL_MAP[key])
    if not os.path.isdir(model_path):
        print(f"ERROR: No se encontró el modelo en {model_path}", file=sys.stderr)
        sys.exit(1)

    return model_path


# ── Construcción de kwargs de cuantización ────────────────────────────────────

def _quant_kwargs():
    if QUANTIZATION in ("none", "fp16"):
        return {"torch_dtype": torch.float16}

    if QUANTIZATION == "fp8":
        # FP8 requiere GPU con compute capability >= 8.9 (Ada Lovelace, Hopper, Blackwell)
        return {"torch_dtype": torch.float8_e4m3fn}

    if QUANTIZATION == "int8":
        bnb_config = BitsAndBytesConfig(load_in_8bit=True)
        return {"quantization_config": bnb_config}

    if QUANTIZATION == "int4":
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
        )
        return {"quantization_config": bnb_config}


# ── Carga principal ───────────────────────────────────────────────────────────

def load_model():
    model_path = _validate()
    quant_kwargs = _quant_kwargs()

    print(f"Cargando modelo : {MODEL_NAME}")
    print(f"Ruta local      : {model_path}")
    print(f"Cuantización    : {QUANTIZATION}")
    print(f"Dispositivo     : {'CUDA' if torch.cuda.is_available() else 'CPU'}")

    tokenizer = AutoTokenizer.from_pretrained(
        model_path,
        local_files_only=True,
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        local_files_only=True,
        device_map="auto",
        **quant_kwargs,
    )

    model.eval()

    print(f"Modelo cargado correctamente: {MODEL_NAME}")
    return model, tokenizer


# ── Info pública ──────────────────────────────────────────────────────────────

def get_model_info():
    return {
        "model_name":    MODEL_NAME,
        "quantization":  QUANTIZATION,
        "cuda_available": torch.cuda.is_available(),
        "device":        str(next(iter(torch.cuda.device_count() and
                          [torch.cuda.get_device_name(0)] or ["cpu"]))),
    }
