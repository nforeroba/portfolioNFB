# TABLAS DE CONVERSION DE UNIDADES

|LONGITUD|Col2|Col3|Col4|Col5|Col6|
|---|---|---|---|---|---|
|metro m|milímetro mm|pulgada in (¨)|pie ft|yarda yd|milla (statute) mi|
|1|1000|39,3700787|3,2808399|1,0936133|0,00062137|
|0,001|1|0,0393701|0,0032808|0,0010936|0,00000062137|
|0,0254|25,4|1|0,08333|0,02777|0,000015782|
|0,3048|304,8|12|1|0,333|0,00018939|
|0,9144|914,4|36|3|1|0,00056818|

|SUPERFICIE|Col2|Col3|Col4|Col5|Col6|
|---|---|---|---|---|---|
|metro cuadrado m2|hectárea ha|pulgada cuadrada in2|pie cuadrado ft2|yarda cuadrada yd2|acre|
|1|0,0001|1550,0031|10,76391|1,19599|0,00024711|
|10000|1|15500031|107639,1|0,0001196|2,4710538|
|0,0006,4516|0,00000006451|1|0,006944|0,0007716|0,00000015942|
|0,09290304|0,000009290351|144|1|0,111|0,000022957|
|0,8361274|0,000083613|1296|9|1|0,00020661|
|4046,856|0,4046856|6272640|43560|4840|1|


1 ft[3]=0,0283 m[3]

|VOLUMEN|Col2|Col3|Col4|Col5|Col6|
|---|---|---|---|---|---|
|metro cúbico m3|litro dm3|pie cúbico ft3|galón (USA) gal|galón imperial (GB) gal|barril de petróleo bbl (oil)|
|1|1000|35,3146667|264,17205|219,96923|6,2898108|
|0,001|1|0,0353147|0,2641721|0,2199692|0,0062898|
|0,0283168|28,3168466|1|7,4805195|6,2288349|0,1781076|
|0,0037854|3,7854118|0,1336806|1|0,8326741|0,0238095|
|0,0045461|4,5460904|0,1635437|1,20095|1|0,028594|
|1589873|158987295|56145833|42'|34,9723128|1|
|1 gal (USA) =3,78541dm3 1 ft3=0,0283 m3||||||

|UNIDADES DE PRESI|ON|Col3|Col4|Col5|Col6|
|---|---|---|---|---|---|
|kilopascal kN /m2|atmósfera técnica Kgf/cm2|milímetro de c. Hg (0ºC)|metros de c. agua (4ºC)|libras por pulgada2 lib/in2|bar 100000 Pa|
|kPa|atm|mm Hg|m H O 2|psi|bar (hpz)|
|1|0,0101972|7,5006278|0,1019745|0,1450377|0,01|
|98,0665|1|735,560217|1000028|14,2233433|0,980665|
|0,1333222|0,0013595|1|0,0135955|193367|0,0013332|
|9,8063754|0,0999972|73,5539622|1|1,4222945|0,0980638|
|6,8947573|0,070307|51,7150013|0,7030893|1|0,0689476|
|100|1,0197162|750,062679|10,1974477|14,5037738|1|
|1 in H O (60ºF = 15,55ºC) = 0,248843 kP 2 in H2O (60ºF=20ºC)=0,248641 kPa 1 atmósfera física (Atm)= 101,325 kPa=760 mm Hg in Hg (60ºF=20ºC)=3,37685 kPa 1 Torr= (101,325/760) kPa||||||


-----

|Kilojulio kJ|kW/hora kW h|Hourse power/hora USA 550 ft.lbf/seg hp. h|Caballo/hora 75 m.Kgf/seg CV.h|Kilocaloría (IT) Kcal(IT) Kcal (IT)|British Thermal Unit Btu (IT)|
|---|---|---|---|---|---|
|1|0,0002777|0,000372506|0,000377673|0,2388459|0,9478171|
|3600|1|1,3410221|1,3596216|859,84523|3412,1416|
|2684,5195|0,7456999|1|1,0138697|641,18648|2544,4336|
|2647,7955|0,7354988|0,9863201|1|632,41509|2509,6259|
|4,1868|0,001163|0,00155961|0,00158124|1|3,9683207|
|1,0550559|0,000293071|0,00039301|0,000398466|0,2519958|1|
|1 termia = 1000 Kca 1 therm = 100.000 Btu 1 But (IT) = 1055,0558 J 1 kilogramo fuerza.metro (m.Kgf) = 0,00980665 kJ IT se refiere a las unidades definidas en International Steam Ta||||||

|MACROUNIDADES E|NERGETICAS|Col3|Col4|Col5|Col6|
|---|---|---|---|---|---|
|Terajulio TJ|Gigavatio hora GW h|Teracaloría (IT) Tcal (IT)|Ton. equivalente de carbón Tec|Ton. equivalente de petróleo Tep|Barril de petróleo día-año bd|
|1|0,2727|0,2388459|34,1208424|23,8845897|0,4955309|
|3,6|1|0,8598452|122,8350326|85,9845228|1,7839113|
|4,1868|1,163|1|142,8571429|100|2,0746888|
|0,0293076|0,008141|0,007|1|0,7|0,0145228|
|0,041868|0,01163|0,01|1,4285714|1|0,0207469|
|2,0180376|0,560568|0,482|68,8571429|48,2|1|

|POTENCIA|Col2|Col3|Col4|Col5|Col6|
|---|---|---|---|---|---|
|Kilowatio kW|Kilocaloría/hora Kcal (IT)/h|Btu (IT)/hora Btu (IT)/h|Horse power (USA) hp|Caballo vapor métrico CV|Tonelada de refrigeración|
|1|859,84523|3412,1416|1,3410221|1,3596216|0,2843494|
|0,001163|1|3,9683207|0,0015596|0,0015812|0,0003307|
|0,00029307|0,2519958|1|0,00039301|0,00039847|0,000083335|
|0,7456999|641,18648|2544,4336|1|1,0138697|0,2120393|
|0,7354988|632,41509|2509,6259|0,9863201|1|0,2091386|
|3,5168|3023,9037|11999,82|4,7161065|4,7815173|1|
|1 caballo vapor (mét 1 Horse power (USA|rico> = 75 m kgf/seg ) mecánico = 550 ft I|= 735,499 W bf/seg||||


TEMPERATURA
Temperatura en ºC = (ºF -32)/1,8

Temperatura en ºF = 1,8 ºC + 32
Temperatura en ºK = ºC + 273,14

|PREFIJO|S DEL S|ISTEMA|INTER|NACION|AL DE|UNIDA|DES|Col9|Col10|Col11|Col12|Col13|Col14|Col15|Col16|Col17|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Prefijo|exa|peta|tera|giga|mega|kilo|hecto|deca|deci|centi|mili|micro|nano|pico|femto|atto|
|Símbolo|E|P|T|G|M|k|h|da|d|c|m|m|n|p|f|a|
|Factor|1e +18|1e +15|1e +12|1e +9|1e +6|1000|100|10|0,1|0,01|0,001|1e-6|1e-9|1e -12|1e -15|1e -18|


-----

