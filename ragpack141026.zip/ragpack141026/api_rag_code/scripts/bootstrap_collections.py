#!/usr/bin/env python3
"""
Script independiente para verificar/crear las colecciones de Qdrant
sin arrancar el servidor gRPC completo.

Reutiliza exactamente la misma logica que rag_api/server.py ejecuta
automaticamente al arrancar (QdrantWrapper.asegurar_colecciones), asi
que este script nunca puede quedar desincronizado de lo que hace el
servidor -- no duplica la logica de creacion de colecciones.

Uso:
    python -m scripts.bootstrap_collections
"""

import logging
import sys

from rag_api.clients.qdrant_client import DimensionInconsistenteError, QdrantWrapper
from rag_api.config import settings


def main() -> None:
    logging.basicConfig(
        level=settings.servidor.nivel_log,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    logger = logging.getLogger(__name__)

    logger.info("Conectando a Qdrant en %s:%d...", settings.qdrant.grpc_host, settings.qdrant.grpc_port)
    qdrant = QdrantWrapper()

    logger.info("Verificando/creando colecciones...")
    try:
        qdrant.asegurar_colecciones()
    except DimensionInconsistenteError as error:
        logger.error("Desajuste de dimension: %s", error)
        sys.exit(1)

    logger.info("Coleccion rapida: %s", qdrant.coleccion_rapida)
    logger.info("Coleccion precisa: %s", qdrant.coleccion_precisa)
    logger.info("Listo.")


if __name__ == "__main__":
    main()
