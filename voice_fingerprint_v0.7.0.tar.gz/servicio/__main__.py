"""Arranque del servicio: python -m servicio (desde la carpeta codigo/).

Si VF_SSL_CERT y VF_SSL_KEY apuntan a un certificado y su llave, sirve por
HTTPS (necesario para usar el micrófono desde otros equipos de la red).
"""

import os
from pathlib import Path

import uvicorn

if __name__ == "__main__":
    certificado = os.environ.get("VF_SSL_CERT")
    llave = os.environ.get("VF_SSL_KEY")
    tls = {}
    if certificado and llave:
        if not (Path(certificado).is_file() and Path(llave).is_file()):
            raise SystemExit(f"No se encontró el certificado ({certificado}) o la llave ({llave}).")
        tls = {"ssl_certfile": certificado, "ssl_keyfile": llave}
    uvicorn.run(
        "servicio.app:app",
        host=os.environ.get("VF_HOST", "0.0.0.0"),
        port=int(os.environ.get("VF_PUERTO", "8000")),
        workers=1,          # los modelos se cargan una vez y el VAD guarda estado
        **tls,
    )
