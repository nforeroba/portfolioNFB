"""
Interfaz comun para las estrategias de chunking.

Cada estrategia concreta (recursivo, fijo, semantico, AST de codigo,
clausula legal jerarquica) implementa esta interfaz. El servicio de
ingesta elige la estrategia por el enum EstrategiaChunking del
request y la invoca de forma identica, sin necesitar saber los
detalles internos de cada una.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class ChunkGenerado:
    """
    Resultado de aplicar una estrategia de chunking a un texto.

    `texto_padre` se llena en estrategias que producen contexto
    adicional para el chunk: CHUNKING_CLAUSULA_LEGAL_JERARQUICA lo usa
    para el texto completo del articulo/clausula al que pertenece un
    chunk hijo (cuerpo o paragrafo); CHUNKING_AST_CODIGO lo usa para un
    preambulo compacto (archivo, alcance/scope, firma) que ubica al
    fragmento de codigo dentro de su archivo de origen. Para las demas
    estrategias queda en None.

    `metadata_adicional` y `fecha_ingesta` solo los llena el modo B de
    Ingest (chunks pre-cortados por el cliente). Las estrategias de
    chunking automatico los dejan vacios.
    """

    texto: str
    texto_padre: str | None = None
    metadata_adicional: dict[str, str] = field(default_factory=dict)
    fecha_ingesta: str | None = None


class EstrategiaChunkingBase(ABC):
    """
    Contrato que toda estrategia de chunking debe cumplir.
    """

    @abstractmethod
    def chunkear(
        self,
        texto: str,
        tamano_tokens: int,
        overlap_tokens: int,
        lenguaje_codigo: str | None = None,
        fuente: str | None = None,
    ) -> list[ChunkGenerado]:
        """
        Divide `texto` en una lista de ChunkGenerado.

        `tamano_tokens` y `overlap_tokens` solo son relevantes para
        las estrategias que cortan por tamano fijo (CHUNKING_FIJO,
        CHUNKING_RECURSIVO) o que agrupan hasta ese tamano
        (CHUNKING_SEMANTIC, CHUNKING_AST_CODIGO); las demas estrategias
        pueden ignorarlos.

        `lenguaje_codigo` solo lo usa CHUNKING_AST_CODIGO (ej. "python",
        "javascript", "html", "sql", "cpp"). Obligatorio unicamente
        cuando la estrategia activa es CHUNKING_AST_CODIGO.

        `fuente` es el valor de IngestRequest.fuente (ej. la ruta del
        archivo cuando se trata de codigo). Solo lo usa
        CHUNKING_AST_CODIGO, para construir el preambulo de contexto
        de cada chunk. Las demas estrategias lo ignoran.
        """
        raise NotImplementedError
