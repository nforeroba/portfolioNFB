"""
Cliente de vLLM para rag-api.

Habla con el endpoint /v1/embeddings (compatible con la API de OpenAI)
que expone el servicio de embeddings para el modelo qwen3-embedding:0.6b.
Es el motor de embeddings del camino rapido (voicebot).
"""

import logging
import random
import time

import httpx

from rag_api.config import settings

logger = logging.getLogger(__name__)


class VllmClientError(Exception):
    """Error de comunicacion o respuesta invalida del servicio vLLM."""


class VllmClient:
    def __init__(self) -> None:
        cfg = settings.vllm
        self._base_url = f"http://{cfg.host}:{cfg.port}"
        self._nombre_modelo = cfg.nombre_modelo
        self._timeout = cfg.timeout_segundos
        self._reintentos = cfg.reintentos
        self._dimensiones = settings.qdrant.dim_coleccion_rapida

        self._client = httpx.Client(base_url=self._base_url, timeout=self._timeout)

    def embed(self, texto: str) -> list[float]:
        """
        Genera el embedding de un solo texto. Pide explicitamente la
        dimension configurada (QDRANT_DIM_COLECCION_RAPIDA), para
        mantener siempre sincronizado el tamano del vector con lo que
        espera la coleccion de Qdrant, incluso si se trunca por debajo
        de la dimension nativa del modelo.
        """
        return self.embed_lote([texto])[0]

    def embed_lote(self, textos: list[str]) -> list[list[float]]:
        """
        Genera embeddings para varios textos en un solo request
        (aprovecha el continuous batching de vLLM).

        Reintenta con backoff exponencial + jitter: si un intento
        falla, espera antes del siguiente intento, duplicando la
        espera cada vez (0.5s, 1s, 2s, ...), con una variacion
        aleatoria pequena para que, bajo alta concurrencia, distintas
        llamadas que fallan al mismo tiempo no vuelvan a reintentar
        todas en el mismo instante exacto.
        """
        payload = {
            "model": self._nombre_modelo,
            "input": textos,
            "dimensions": self._dimensiones,
        }

        espera_base_segundos = 0.5
        ultimo_error: Exception | None = None

        for intento in range(1, self._reintentos + 2):  # +1 intento inicial + reintentos
            try:
                respuesta = self._client.post("/v1/embeddings", json=payload)
                respuesta.raise_for_status()
                datos = respuesta.json()
                return [item["embedding"] for item in datos["data"]]
            except (httpx.HTTPError, KeyError, ValueError) as error:
                ultimo_error = error
                es_ultimo_intento = intento == self._reintentos + 1
                logger.warning(
                    "Fallo al pedir embeddings a vLLM (intento %d/%d): %s",
                    intento, self._reintentos + 1, error,
                )
                if not es_ultimo_intento:
                    espera = espera_base_segundos * (2 ** (intento - 1))
                    espera_con_jitter = espera + random.uniform(0, espera * 0.1)
                    time.sleep(espera_con_jitter)

        raise VllmClientError(
            f"No se pudo obtener embeddings de vLLM tras {self._reintentos + 1} intentos"
        ) from ultimo_error

    def cerrar(self) -> None:
        self._client.close()
