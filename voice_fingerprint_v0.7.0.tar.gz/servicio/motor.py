"""Motor del servicio: modelos cargados una vez, pool en Qdrant y los flujos de la página.

  - Sincronización en segundo plano (al arrancar y con el botón "resincronizar").
  - Desafíos de un solo uso con vencimiento.
  - Validación: VAD -> (STT de dígitos || huella) -> búsqueda 1:N -> decisión.
  - Registro: grabaciones web -> WAV + JSON en referencias_wav -> sincronización.
  - Material visual: espectrogramas, huellas y mapa 2D.
"""

import hmac
import json
import os
import re
import tempfile
import threading
import time
import uuid
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import soundfile as sf

from huella_vocal.config import (
    ERRORES_DIGITOS_PERMITIDOS, SEGUNDOS_MIN_VALIDACION, SR, configurar_cache_modelos,
)

SEGUNDOS_VIGENCIA_DESAFIO = 120
SEGUNDOS_MIN_GRABACION_REGISTRO = 3.0
TEXTO_CONSENTIMIENTO = (
    "Autorizo el registro de mi voz y de su huella vocal para esta demostración de validación de "
    "identidad. Sé que es un dato biométrico y que puedo pedir que se elimine en cualquier momento."
)


def _ahora():
    return datetime.now(timezone.utc)


INTENTOS_CLAVE_ANTES_DE_BLOQUEO = 5
MINUTOS_BLOQUEO_CLAVE = 5


class ErrorDeUso(ValueError):
    """Error causado por la petición (datos faltantes, desafío vencido...), no por el servidor."""


class PermisoDenegado(PermissionError):
    """Clave de eliminación incorrecta, deshabilitada o bloqueada por intentos fallidos."""


class Motor:
    def __init__(self, dir_referencias, dir_modelos, dir_registros):
        self.dir_referencias = Path(dir_referencias).resolve()
        self.dir_registros = Path(dir_registros).resolve()
        self.dir_referencias.mkdir(parents=True, exist_ok=True)
        self.dir_registros.mkdir(parents=True, exist_ok=True)
        dir_modelos = configurar_cache_modelos(dir_modelos)

        from huella_vocal.almacen import Almacen
        from huella_vocal.huella import ExtractorHuella
        from huella_vocal.prueba_vida import Transcriptor
        from huella_vocal.vad import DetectorVoz

        from .recursos import Monitor

        inicio = time.perf_counter()
        cargas = {}

        def cargar(clave, fabrica):
            t = time.perf_counter()
            objeto = fabrica()
            cargas[clave] = round(time.perf_counter() - t, 2)
            return objeto

        self.detector = cargar("vad", DetectorVoz)
        self.extractor = cargar("huella", lambda: ExtractorHuella(dir_modelos))
        self.transcriptor = cargar("stt", lambda: Transcriptor(dir_modelos))
        self.almacen = cargar("qdrant", Almacen)
        self.almacen.asegurar_colecciones()
        self.segundos_carga = round(time.perf_counter() - inicio, 2)
        self.cargas_modelos = cargas
        self.monitor = Monitor()
        self.ultima_validacion = None

        self._inferencia = threading.Lock()       # el VAD guarda estado: una inferencia a la vez
        self._sincronizando = threading.Lock()
        self._desafios_lock = threading.Lock()
        self._desafios = {}
        self._hilos = ThreadPoolExecutor(max_workers=2)
        self._mapa = None
        clave = (os.environ.get("VF_CLAVE_BORRADO") or "").strip()
        self._clave_borrado = clave if re.fullmatch(r"\d{4}", clave) else None
        self._intentos_fallidos = 0
        self._bloqueo_hasta = None
        self.estado_sync = {"en_curso": False, "hechos": 0, "total": 0, "archivo": None,
                            "inicio_utc": None, "ultimo_resumen": None, "error": None}

    # ------------------------------------------------------------------
    # Sincronización
    # ------------------------------------------------------------------

    def iniciar_sincronizacion(self):
        """Lanza la sincronización en segundo plano. False si ya hay una en curso."""
        if self._sincronizando.locked():
            return False
        threading.Thread(target=self.sincronizar_ahora, daemon=True).start()
        return True

    def sincronizar_ahora(self):
        from huella_vocal.sincronizacion import sincronizar

        with self._sincronizando:
            self.estado_sync.update(en_curso=True, hechos=0, total=0, archivo=None,
                                    inicio_utc=_ahora().isoformat(timespec="seconds"), error=None)

            def progreso(hechos, total, archivo):
                self.estado_sync.update(hechos=hechos, total=total, archivo=archivo)

            try:
                with self._inferencia:
                    resumen = sincronizar(self.dir_referencias, self.almacen, self.detector, self.extractor, progreso)
                self.estado_sync["ultimo_resumen"] = {**resumen, "fin_utc": _ahora().isoformat(timespec="seconds")}
                return resumen
            except Exception as exc:  # noqa: BLE001
                self.estado_sync["error"] = f"{type(exc).__name__}: {exc}"
                raise
            finally:
                self.estado_sync.update(en_curso=False, archivo=None)
                self._mapa = None

    # ------------------------------------------------------------------
    # Desafíos
    # ------------------------------------------------------------------

    def nuevo_desafio(self):
        from huella_vocal.desafio import generar_desafio

        desafio = generar_desafio()
        identificador = uuid.uuid4().hex
        expira = _ahora() + timedelta(seconds=SEGUNDOS_VIGENCIA_DESAFIO)
        with self._desafios_lock:
            self._desafios = {k: v for k, v in self._desafios.items() if v["expira"] > _ahora()}
            self._desafios[identificador] = {"digitos": desafio["digitos"], "expira": expira}
        return {
            "id": identificador,
            "digitos": desafio["digitos"],
            "texto_pantalla": desafio["texto_pantalla"],
            "instruccion": desafio["instruccion"],
            "vigencia_s": SEGUNDOS_VIGENCIA_DESAFIO,
        }

    def _consumir_desafio(self, identificador):
        """Un desafío sirve una sola vez y solo mientras está vigente."""
        with self._desafios_lock:
            desafio = self._desafios.pop(identificador, None)
        if desafio is None:
            raise ErrorDeUso("El desafío no existe o ya se usó. Pida uno nuevo.")
        if desafio["expira"] < _ahora():
            raise ErrorDeUso("El desafío venció. Pida uno nuevo.")
        return desafio["digitos"]

    # ------------------------------------------------------------------
    # Validación
    # ------------------------------------------------------------------

    def validar_subida(self, contenido, nombre_original, id_desafio, inicio=None):
        """Recibe el audio subido, valida y deja medidos los tiempos por paso y el consumo."""
        from .recursos import Cronometro

        crono = Cronometro(inicio)
        consumo = {}
        ruta = None
        try:
            with self.monitor.consumo(consumo):
                with crono.paso("recepcion"):
                    ruta = self.guardar_subida(contenido, nombre_original)
                resultado = self.validar(ruta, id_desafio, crono, anotar=False)
        finally:
            if ruta is not None:
                ruta.unlink(missing_ok=True)
        resultado["tiempos"]["consumo"] = consumo
        self._cerrar(resultado, resultado.pop("_pedidos"), crono, anotar=True)
        tiempos = resultado["tiempos"]
        self.ultima_validacion = {
            "fecha_utc": _ahora().isoformat(timespec="seconds"),
            "veredicto": resultado["veredicto"],
            "voz_neta_s": resultado.get("voz_neta_s"),
            **tiempos,
        }
        return resultado

    def validar(self, ruta_audio, id_desafio, crono=None, anotar=True):
        from huella_vocal.audio import cargar_audio
        from huella_vocal.decision import decidir
        from huella_vocal.perfil import perfil_acustico, trayectoria_tono
        from huella_vocal.prueba_vida import marcas_digitos, verificar_digitos
        from huella_vocal.visual import espectrograma_datos, proyectar

        from .recursos import Cronometro

        crono = crono or Cronometro()
        paso = crono.paso
        with paso("desafio"):
            digitos = self._consumir_desafio(id_desafio)
        with paso("lectura_audio"):
            senal, _ = cargar_audio(ruta_audio)

        t = time.perf_counter()
        with self._inferencia:
            crono.anotar("espera_turno", t, time.perf_counter())
            with paso("vad"):
                voz, _ = self.detector.voz_neta(senal)
            neta = len(voz) / SR
            if neta < SEGUNDOS_MIN_VALIDACION:
                resultado = {
                    "veredicto": "muestra_insuficiente",
                    "mensaje": f"Se captaron {neta:.1f} s de voz; se necesitan al menos "
                               f"{SEGUNDOS_MIN_VALIDACION:.0f} s. Hable un poco más y repita.",
                    "voz_neta_s": round(neta, 2),
                }
                return self._cerrar(resultado, digitos, crono, anotar)

            # STT (prueba de vida) y huella en paralelo: ambos sueltan el GIL.
            def transcribir():
                inicio_stt = time.perf_counter()
                try:
                    return self.transcriptor.transcribir_detallado(voz)
                finally:
                    crono.anotar("stt", inicio_stt, time.perf_counter(), carril="paralelo")

            futuro_texto = self._hilos.submit(transcribir)
            with paso("huella"):
                huella = self.extractor.extraer(voz)
            texto, palabras = futuro_texto.result()

        with paso("busqueda"):
            candidatos = self.almacen.buscar_personas(huella, k=3)
        with paso("decision"):
            decision = decidir(candidatos)
            vida = verificar_digitos(texto, digitos)

            if not vida["aprobada"]:
                veredicto = "rechazado_prueba_de_vida"
                mensaje = ("Los números dichos no coinciden con los pedidos. Puede ser una grabación "
                           "reproducida, o que no se entendió bien: intente de nuevo.")
            elif decision["resultado"] == "identificado":
                veredicto = "validado"
                mensaje = (f"Dijo los números pedidos y su voz coincide claramente con la huella de "
                           f"{decision['persona']['nombre']}.")
            elif decision["resultado"] == "no_concluyente":
                veredicto = "no_concluyente"
                mensaje = f"No es posible confirmar la identidad. {decision['motivo']} Repita la prueba."
            else:
                veredicto = "no_identificado"
                mensaje = "La voz no corresponde a ninguna persona registrada."

        # Material para la pantalla de resultado
        with paso("perfil"):
            try:
                perfil = perfil_acustico(voz)
            except Exception:  # noqa: BLE001
                perfil = None
        with paso("espectrograma"):
            espectro = espectrograma_datos(voz)
        if espectro is not None:
            with paso("tono"):
                try:
                    espectro["f0"] = trayectoria_tono(voz)
                except Exception:  # noqa: BLE001
                    espectro["f0"] = None
            espectro["digitos"] = marcas_digitos(palabras)
        with paso("candidato"):
            mejor = None
            encontrada = self.almacen.plantilla_de(candidatos[0][1]["persona_id"]) if candidatos else None
            if encontrada:
                vector, payload = encontrada
                mejor = {"persona_id": payload["persona_id"], "nombre": payload["nombre"], "origen": payload.get("origen"),
                         "perfil": payload.get("perfil"), "plantilla": [round(float(v), 4) for v in vector]}
        with paso("mapa"):
            mapa = self.mapa()
            posicion, similitudes = None, {}
            if mapa.get("pca") is not None:
                x, y = proyectar(mapa["pca"], huella)[0]
                posicion = {"x": round(float(x), 4), "y": round(float(y), 4)}
                puntajes = mapa["vectores_personas"] @ (huella / max(float(np.linalg.norm(huella)), 1e-12))
                similitudes = {pid: round(float(v), 4) for pid, v in zip(mapa["ids_personas"], puntajes)}

        resultado = {
            "veredicto": veredicto,
            "mensaje": mensaje,
            "voz_neta_s": round(neta, 2),
            "prueba_de_vida": {**vida, "pedidos": digitos, "transcripcion": texto,
                               "errores_permitidos": ERRORES_DIGITOS_PERMITIDOS},
            "identificacion": {
                "resultado": decision["resultado"],
                "motivo": decision["motivo"],
                "score": decision.get("score"),
                "margen": decision.get("margen"),
                "umbrales": decision.get("umbrales"),
                "candidatos": [{"persona_id": p["persona_id"], "nombre": p["nombre"], "origen": p.get("origen"),
                                "score": round(s, 4)} for s, p in candidatos],
            },
            "muestra": {
                "huella": [round(float(v), 4) for v in huella],
                "perfil": perfil,
                "espectrograma": espectro,
                "posicion_mapa": posicion,
                "similitudes": similitudes,
            },
            "mejor_candidato": mejor,
        }
        return self._cerrar(resultado, digitos, crono, anotar)

    def _cerrar(self, resultado, digitos, crono, anotar):
        """
        Deja en el resultado los pasos medidos y el total. Con anotar=False la
        bitácora queda para después (validar_subida la escribe ya con el consumo).
        """
        consumo = (resultado.get("tiempos") or {}).get("consumo")
        resultado["tiempos"] = {"pasos": list(crono.pasos), "total_s": crono.total(), "consumo": consumo}
        if not anotar:
            resultado["_pedidos"] = digitos
            return resultado
        with crono.paso("bitacora"):
            self._anotar(resultado, digitos)
        resultado["tiempos"]["pasos"] = list(crono.pasos)
        return resultado

    def _anotar(self, resultado, digitos):
        """Bitácora sin audio ni huellas, para recalibrar umbrales con el uso real."""
        ident = resultado.get("identificacion", {})
        vida = resultado.get("prueba_de_vida", {})
        linea = {
            "fecha_utc": _ahora().isoformat(timespec="seconds"),
            "veredicto": resultado["veredicto"],
            "voz_neta_s": resultado.get("voz_neta_s"),
            "pedidos": digitos,
            "oidos": vida.get("digitos_oidos"),
            "errores_digitos": vida.get("errores"),
            "candidatos": [(c["persona_id"], c["score"]) for c in ident.get("candidatos", [])],
            "tiempo_total_s": resultado.get("tiempos", {}).get("total_s"),
            "pasos": resultado.get("tiempos", {}).get("pasos"),
            "consumo": resultado.get("tiempos", {}).get("consumo"),
        }
        with open(self.dir_registros / "validaciones.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(linea, ensure_ascii=False) + "\n")

    # ------------------------------------------------------------------
    # Tiempos y recursos
    # ------------------------------------------------------------------

    def _bitacora(self, ultimas=200):
        ruta = self.dir_registros / "validaciones.jsonl"
        if not ruta.exists():
            return []
        with open(ruta, encoding="utf-8") as f:
            lineas = deque(f, maxlen=ultimas * 3)      # sobra margen para líneas viejas sin pasos
        registros = []
        for linea in lineas:
            try:
                r = json.loads(linea)
            except ValueError:
                continue
            if r.get("pasos"):
                registros.append(r)
        return registros[-ultimas:]

    def tiempos(self, ultimas=200):
        from .recursos import PASOS, estadisticas

        registros = self._bitacora(ultimas)
        ultima = self.ultima_validacion
        if ultima is None and registros:                # tras reiniciar el servicio: la última de la bitácora
            r = registros[-1]
            ultima = {"fecha_utc": r["fecha_utc"], "veredicto": r["veredicto"], "voz_neta_s": r.get("voz_neta_s"),
                      "pasos": r["pasos"], "total_s": r.get("tiempo_total_s"), "consumo": r.get("consumo")}
        return {"nombres": PASOS, "ultima": ultima, "historial": estadisticas(registros)}

    def sistema(self):
        from huella_vocal.config import MODELO_HUELLA, MODELO_STT, config_qdrant

        from .recursos import ficha_sistema

        modelos = [
            {"rol": "Detección de voz", "modelo": "Silero VAD", "carga_s": self.cargas_modelos.get("vad")},
            {"rol": "Huella vocal", "modelo": f"{MODELO_HUELLA} (192 valores)", "carga_s": self.cargas_modelos.get("huella")},
            {"rol": "Transcripción", "modelo": f"faster-whisper {MODELO_STT}, int8 en CPU", "carga_s": self.cargas_modelos.get("stt")},
            {"rol": "Base vectorial", "modelo": f"Qdrant en {config_qdrant()['url']}", "carga_s": self.cargas_modelos.get("qdrant")},
        ]
        return ficha_sistema(modelos, self.segundos_carga, self.estado_sync)

    # ------------------------------------------------------------------
    # Registro
    # ------------------------------------------------------------------

    def registrar(self, nombre, origen, consentimiento, rutas_audio):
        from huella_vocal.audio import cargar_audio
        from huella_vocal.referencias import SEPARADOR_WEB, slug

        nombre = " ".join((nombre or "").split())
        if not consentimiento:
            raise ErrorDeUso("Se necesita el consentimiento para registrar la voz.")
        if not nombre or not slug(nombre):
            raise ErrorDeUso("Escriba el nombre de la persona.")
        if not rutas_audio:
            raise ErrorDeUso("No llegó ninguna grabación.")
        persona_id = slug(nombre)

        # 1. Revisar todas las grabaciones antes de guardar nada
        senales = []
        with self._inferencia:
            for n, ruta in enumerate(rutas_audio, start=1):
                senal, info = cargar_audio(ruta)
                voz, _ = self.detector.voz_neta(senal)
                neta = len(voz) / SR
                if neta < SEGUNDOS_MIN_GRABACION_REGISTRO:
                    raise ErrorDeUso(f"La grabación {n} tiene solo {neta:.1f} s de voz "
                                     f"(mínimo {SEGUNDOS_MIN_GRABACION_REGISTRO:.0f} s). Repítala.")
                if info["fraccion_saturada"] > 0.01:
                    raise ErrorDeUso(f"La grabación {n} está saturada (habló muy cerca o muy fuerte). Repítala.")
                senales.append(senal)

        # 2. Guardar WAV (16 kHz, mono) y el JSON con nombre, origen y consentimiento
        sesion = _ahora().strftime("%Y%m%d-%H%M%S")
        base = SEPARADOR_WEB.join([persona_id, "web", sesion])
        archivos = []
        for n, senal in enumerate(senales, start=1):
            ruta = self.dir_referencias / f"{base}{SEPARADOR_WEB}{n}.wav"
            sf.write(ruta, senal, SR, subtype="PCM_16")
            archivos.append(ruta.name)
        (self.dir_referencias / f"{base}.json").write_text(json.dumps({
            "nombre_mostrar": nombre,
            "origen": (origen or "").strip() or None,
            "consentimiento": {"aceptado": True, "fecha_utc": _ahora().isoformat(timespec="seconds"),
                               "texto": TEXTO_CONSENTIMIENTO},
        }, ensure_ascii=False, indent=2), encoding="utf-8")

        # 3. Sincronizar (espera si ya hay una sincronización en curso)
        resumen = self.sincronizar_ahora()
        problemas = [f"{e['archivo']}: {e['error']}" for e in resumen["errores"] if e["archivo"] in archivos]
        persona = next((p for p in self.almacen.personas() if p["persona_id"] == persona_id), None)
        if persona is None:
            raise ErrorDeUso("Las grabaciones no se pudieron procesar. " + "; ".join(problemas))
        return {"persona": persona, "archivos": archivos, "advertencias": problemas, "sincronizacion": resumen}

    # ------------------------------------------------------------------
    # Pool y material visual
    # ------------------------------------------------------------------

    def personas(self):
        return sorted(self.almacen.personas(), key=lambda p: p["nombre"].lower())

    def mapa(self):
        """Proyección 2D de todos los tramos y plantillas. Se recalcula tras cada sincronización."""
        if self._mapa is not None:
            return self._mapa
        from huella_vocal.visual import ajustar_pca, proyectar

        tramos = self.almacen.todos_los_tramos()
        if len(tramos) < 3:
            self._mapa = {"pca": None, "varianza_pct": None, "tramos": [], "personas": [],
                          "vectores_personas": np.zeros((0, 1)), "ids_personas": []}
            return self._mapa
        pca = ajustar_pca([t.vector for t in tramos])
        xy = proyectar(pca, [t.vector for t in tramos])
        plantillas = self.almacen.plantillas()
        xy_p = proyectar(pca, [p.vector for p in plantillas]) if plantillas else []
        self._mapa = {
            "pca": pca,
            "varianza_pct": [round(float(v) * 100, 1) for v in pca["varianza"]],
            "tramos": [{"persona_id": t.payload["persona_id"], "x": round(float(a), 4), "y": round(float(b), 4)}
                       for t, (a, b) in zip(tramos, xy)],
            "personas": [{"persona_id": p.payload["persona_id"], "nombre": p.payload["nombre"],
                          "origen": p.payload.get("origen"), "tramos": p.payload.get("tramos"),
                          "f0_mediana_hz": (p.payload.get("perfil") or {}).get("f0_mediana_hz"),
                          "x": round(float(a), 4), "y": round(float(b), 4)}
                         for p, (a, b) in zip(plantillas, xy_p)],
            "vectores_personas": np.array([p.vector for p in plantillas], dtype=np.float32),
            "ids_personas": [p.payload["persona_id"] for p in plantillas],
        }
        return self._mapa

    # ------------------------------------------------------------------
    # Eliminación
    # ------------------------------------------------------------------

    @property
    def eliminacion_habilitada(self):
        return self._clave_borrado is not None

    def _verificar_clave(self, clave):
        if not self.eliminacion_habilitada:
            raise PermisoDenegado("La eliminación está deshabilitada: falta configurar VF_CLAVE_BORRADO (4 dígitos).")
        if self._bloqueo_hasta and _ahora() < self._bloqueo_hasta:
            minutos = max(1, round((self._bloqueo_hasta - _ahora()).total_seconds() / 60))
            raise PermisoDenegado(f"Demasiados intentos con clave incorrecta. Espere {minutos} min e intente de nuevo.")
        if not hmac.compare_digest(str(clave or "").strip().encode(), self._clave_borrado.encode()):
            self._intentos_fallidos += 1
            if self._intentos_fallidos >= INTENTOS_CLAVE_ANTES_DE_BLOQUEO:
                self._intentos_fallidos = 0
                self._bloqueo_hasta = _ahora() + timedelta(minutes=MINUTOS_BLOQUEO_CLAVE)
                raise PermisoDenegado(f"Clave incorrecta. La eliminación queda bloqueada {MINUTOS_BLOQUEO_CLAVE} min.")
            raise PermisoDenegado("Clave incorrecta.")
        self._intentos_fallidos = 0
        self._bloqueo_hasta = None

    def eliminar_persona(self, persona_id, clave):
        """Borra definitivamente los audios (y el consentimiento) de una persona y la quita del pool."""
        from huella_vocal.referencias import SEPARADOR_WEB, listar_referencias

        self._verificar_clave(clave)
        nombre = next((p["nombre"] for p in self.almacen.personas() if p["persona_id"] == persona_id), persona_id)
        borrados = []
        for ref in listar_referencias(self.dir_referencias):
            if ref.persona_id != persona_id:
                continue
            ref.archivo.unlink(missing_ok=True)
            borrados.append(ref.archivo.name)
            if ref.fuente == "web":
                partes = ref.archivo.stem.split(SEPARADOR_WEB)
                consentimiento = ref.archivo.with_name(SEPARADOR_WEB.join(partes[:3]) + ".json")
                if consentimiento.exists():
                    consentimiento.unlink()
                    borrados.append(consentimiento.name)
        if not borrados and not any(p["persona_id"] == persona_id for p in self.almacen.personas()):
            raise ErrorDeUso("Esa persona no está registrada.")
        resumen = self.sincronizar_ahora()
        return {"persona_id": persona_id, "nombre": nombre, "archivos_eliminados": sorted(set(borrados)),
                "sincronizacion": resumen}

    @staticmethod
    def guardar_subida(contenido, nombre_original):
        """Guarda un archivo subido en un temporal y devuelve su ruta."""
        sufijo = Path(nombre_original or "audio.webm").suffix or ".webm"
        temporal = tempfile.NamedTemporaryFile(delete=False, suffix=sufijo)
        temporal.write(contenido)
        temporal.close()
        return Path(temporal.name)
