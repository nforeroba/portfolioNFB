"""
Logica de negocio del RPC Delete.

Resuelve el oneof del request (id puntual vs. filtro compuesto),
valida que un filtro nunca este completamente vacio (para evitar
borrar una coleccion entera por accidente), y maneja el modo dry_run
(contar sin borrar).

Los ids no tienen garantia absoluta de unicidad global entre las dos
colecciones (el modo B de Ingest permite que el cliente elija el id
libremente), asi que tanto el borrado por id como por filtro se
aplican en ambas colecciones: Qdrant no falla si el criterio no
coincide con nada en una de ellas, simplemente no borra nada ahi.

No conoce nada de gRPC: recibe y devuelve los mensajes generados por
protoc directamente.
"""

import logging
import uuid

from qdrant_client import models

from rag_api.clients.qdrant_client import QdrantWrapper
from rag_api.generated import rag_pb2

logger = logging.getLogger(__name__)


class FiltroVacioError(Exception):
    """
    Se lanza cuando un FiltroDelete llega sin ningun campo
    especificado. Proteccion explicita contra borrar una coleccion
    entera por accidente.
    """


class DeleteService:
    def __init__(self, qdrant: QdrantWrapper) -> None:
        self._qdrant = qdrant

    def delete(self, request: rag_pb2.DeleteRequest) -> rag_pb2.DeleteResponse:
        if request.HasField("id"):
            filtro_qdrant = self._filtro_por_id(request.id)
        elif request.HasField("filtro"):
            self._validar_filtro_no_vacio(request.filtro)
            filtro_qdrant = self._filtro_desde_proto(request.filtro)
        else:
            raise ValueError("DeleteRequest debe traer 'id' o 'filtro' (oneof 'criterio')")

        colecciones = [self._qdrant.coleccion_rapida, self._qdrant.coleccion_precisa]

        total_afectados = sum(
            self._qdrant.contar_por_filtro(coleccion, filtro_qdrant) for coleccion in colecciones
        )

        if not request.dry_run:
            for coleccion in colecciones:
                self._qdrant.borrar_por_filtro(coleccion, filtro_qdrant)

        return rag_pb2.DeleteResponse(
            chunks_afectados=total_afectados,
            fue_dry_run=request.dry_run,
        )

    @staticmethod
    def _filtro_por_id(punto_id: str) -> models.Filter:
        try:
            punto_id_normalizado = str(uuid.UUID(punto_id.strip()))
        except ValueError:
            raise ValueError(f"El id '{punto_id}' no es un UUID valido") from None

        return models.Filter(
            must=[models.HasIdCondition(has_id=[punto_id_normalizado])]
        )

    @staticmethod
    def _validar_filtro_no_vacio(filtro: rag_pb2.FiltroDelete) -> None:
        tiene_categoria = filtro.HasField("categoria")
        tiene_fuente = filtro.HasField("fuente")
        tiene_fecha = filtro.HasField("fecha_antes_de")

        if not (tiene_categoria or tiene_fuente or tiene_fecha):
            raise FiltroVacioError(
                "FiltroDelete no puede estar completamente vacio: se requiere al menos "
                "uno de 'categoria', 'fuente' o 'fecha_antes_de', para evitar borrar "
                "la coleccion entera por accidente"
            )

    @staticmethod
    def _filtro_desde_proto(filtro: rag_pb2.FiltroDelete) -> models.Filter:
        condiciones = []

        if filtro.HasField("categoria"):
            condiciones.append(models.FieldCondition(key="categoria", match=models.MatchValue(value=filtro.categoria)))
        if filtro.HasField("fuente"):
            condiciones.append(models.FieldCondition(key="fuente", match=models.MatchValue(value=filtro.fuente)))
        if filtro.HasField("fecha_antes_de"):
            condiciones.append(
                models.FieldCondition(
                    key="fecha_ingesta",
                    range=models.DatetimeRange(lt=filtro.fecha_antes_de),
                )
            )

        return models.Filter(must=condiciones)
