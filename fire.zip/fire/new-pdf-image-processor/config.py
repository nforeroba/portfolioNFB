# config.py
# Archivo de configuración para el procesador de PDF e imágenes

import os
from pathlib import Path
from dotenv import load_dotenv

# Cargar variables de entorno desde archivo .env (si existe)
load_dotenv()

# Configuración de directorios
# Para desarrollo (Windows):
DEV_INPUT_DIR = r"C:\Users\midna\Documents\incs\fire\IN"  # Ajusta la ruta según tu entorno Windows
DEV_OUTPUT_DIR = r"C:\Users\midna\Documents\incs\fire\OUT"  # Ajusta la ruta según tu entorno Windows
DEV_LOG_DIR = r"C:\Users\midna\Documents\incs\fire\new-pdf-image-processor\logs"  # Ajusta la ruta según tu entorno Windows

# Para producción (Ubuntu):
PROD_INPUT_DIR = "/ruta/a/carpeta/compartida/IN"  # Ajusta para tu entorno Linux
PROD_OUTPUT_DIR = "/ruta/a/carpeta/compartida/OUT"  # Ajusta para tu entorno Linux
PROD_LOG_DIR = "/var/log/pdf_processor"  # Ajusta para tu entorno Linux

# Determinar entorno
IS_WINDOWS = os.name == 'nt'

# Usar configuración según el entorno, pero priorizar variables de entorno si existen
if IS_WINDOWS:
    INPUT_DIR = os.getenv("INPUT_DIR", DEV_INPUT_DIR)
    OUTPUT_DIR = os.getenv("OUTPUT_DIR", DEV_OUTPUT_DIR)
    LOG_DIR = os.getenv("LOG_DIR", DEV_LOG_DIR)
else:
    INPUT_DIR = os.getenv("INPUT_DIR", PROD_INPUT_DIR)
    OUTPUT_DIR = os.getenv("OUTPUT_DIR", PROD_OUTPUT_DIR)
    LOG_DIR = os.getenv("LOG_DIR", PROD_LOG_DIR)

# Configuración del programa
SCAN_INTERVAL = int(os.getenv("SCAN_INTERVAL", "60"))  # Intervalo en segundos para buscar nuevos archivos
PDF_PROCESSING_TIMEOUT = int(os.getenv("PDF_PROCESSING_TIMEOUT", "300"))  # Límite de tiempo total (5 minutos)
PDF_EXTRACTION_TIMEOUT = int(os.getenv("PDF_EXTRACTION_TIMEOUT", "10"))  # Límite para extracción directa (10 segundos)

# Palabras clave para filtrar archivos (se pueden personalizar según sea necesario)
KEYWORDS = [
    'solicitud', 'solisitud', 'solicitud credito', 'solicitud de credito',
    'solicitud financiera', 'solicitud servicios financieros',
    'solicitud de servicios financieros', 'solicitud prestamo',
    'solicitud de prestamo', 'solic', 'sol credito', 'sol de credito',
    'SOLICITUD', 'SOL', 'nos interesa conocerlo', 'SOLCREDITO', 'SF'
]

# Formatos de imagen soportados
SUPPORTED_IMAGE_FORMATS = ['tiff', 'tif', 'jpg', 'jpeg', 'png', 'bmp', 'gif']

# Configuración para Ollama (Procesamiento de imágenes y fallback para PDFs)
OLLAMA_ENABLED = os.getenv("OLLAMA_ENABLED", "true").lower() == "true"
OLLAMA_ENDPOINT = os.getenv("OLLAMA_ENDPOINT", "http://localhost:11434/api/chat")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llava:latest")

# Configuración futura para PostgreSQL
DB_ENABLED = os.getenv("DB_ENABLED", "false").lower() == "true"
DB_CONFIG = {
    'host': os.getenv("DB_HOST", "localhost"),
    'database': os.getenv("DB_NAME", "pdf_processor"),
    'user': os.getenv("DB_USER", "usuario"),
    'password': os.getenv("DB_PASSWORD", ""),
    'port': int(os.getenv("DB_PORT", "5432"))
}
