#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para encriptar contraseñas para uso en archivo .env
"""

import argparse
import logging
from security_module import SecurityManager

def main():
    # Configurar el parser de argumentos
    parser = argparse.ArgumentParser(description='Encripta una contraseña para uso en archivo .env')
    parser.add_argument('--password', '-p', help='Contraseña a encriptar')
    
    args = parser.parse_args()
    
    # Si no se proporciona la contraseña, pedirla interactivamente
    password = args.password
    if not password:
        import getpass
        password = getpass.getpass('Introduce la contraseña a encriptar: ')
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    
    # Crear gestor de seguridad y encriptar
    security = SecurityManager()
    encrypted = security.encrypt(password)
    
    print(f"\nContraseña encriptada: enc:{encrypted}")
    print("\nPara usar esta contraseña en tu archivo .env:")
    print(f"DB_PASSWORD=enc:{encrypted}")
    print("\nNota: Asegúrate de mantener seguro el archivo de clave de encriptación (.security_key)")

if __name__ == "__main__":
    main()
