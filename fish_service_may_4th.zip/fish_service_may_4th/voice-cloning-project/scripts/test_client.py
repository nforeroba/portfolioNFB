#!/usr/bin/env python3
import websockets
import json
import base64
import wave
import io
import asyncio
import argparse

async def test_voice_synthesis(text, voice):
    # Configurar para mensajes grandes
    uri = "ws://localhost:8000/synthesize"
    
    # Aumentar el límite de tamaño de mensaje
    async with websockets.connect(uri, max_size=16777216) as websocket:
        # Test message
        message = {
            "text": text,
            "voz": voice  # Cambiado a "voz"
        }
        
        print("=== Enviando solicitud ===")
        print(json.dumps(message, indent=2))
        print()
        
        # Send request
        await websocket.send(json.dumps(message))
        
        # Receive response
        response = await websocket.recv()
        result = json.loads(response)
        
        if "error" in result:
            print(f"Error: {result['error']}")
            return
        
        # Mostrar el JSON completo de respuesta (con base64 truncado)
        print("=== Respuesta JSON del servidor ===")
        print(f"Llaves presentes: {list(result.keys())}")
        print()
        
        # Crear una copia para mostrar con base64 truncado
        display_result = result.copy()
        if "base64" in display_result:
            base64_length = len(display_result["base64"])
            display_result["base64"] = f"{display_result['base64'][:100]}... [total: {base64_length} caracteres]"
        
        print("JSON truncado:")
        print(json.dumps(display_result, indent=2))
        print()
        
        # Mostrar métricas
        print("=== Métricas ===")
        if "metricas" in result:
            print(json.dumps(result["metricas"], indent=2))
        print()
        
        # Decode base64 audio
        audio_data = result["base64"].split(",")[1]
        audio_bytes = base64.b64decode(audio_data)
        
        # Save audio file
        output_path = "../outputs/test_output.wav"
        with open(output_path, "wb") as f:
            f.write(audio_bytes)
        
        print(f"=== Audio guardado ===")
        print(f"Ruta: {output_path}")
        print(f"Tamaño: {len(audio_bytes)} bytes")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test WebSocket voice synthesis")
    parser.add_argument("--text", required=True, help="Text to synthesize")
    parser.add_argument("--voice", required=True, help="Voice to use")
    parser.add_argument("--show-full-base64", action="store_true", help="Show full base64 string (warning: very long)")
    
    args = parser.parse_args()
    asyncio.run(test_voice_synthesis(args.text, args.voice))
