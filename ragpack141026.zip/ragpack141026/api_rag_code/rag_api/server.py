"""
Punto de entrada del proceso rag-api.

Arranca el servidor gRPC, registra el servicio RagService (conectando
los tres servicios de negocio: retrieve, ingest, delete), ejecuta el
bootstrap de colecciones de Qdrant al inicio, y maneja el apagado
ordenado del proceso (SIGTERM).
"""

import logging
import signal
import sys
from concurrent import futures

import grpc

from rag_api.clients.ollama_client import OllamaClient
from rag_api.clients.qdrant_client import DimensionInconsistenteError, QdrantWrapper
from rag_api.clients.vllm_client import VllmClient
from rag_api.config import settings
from rag_api.generated import rag_pb2, rag_pb2_grpc
from rag_api.services.delete_service import DeleteService, FiltroVacioError
from rag_api.services.ingest_service import IngestService
from rag_api.services.retrieve_service import RetrieveService

logger = logging.getLogger(__name__)


class RagServiceServicer(rag_pb2_grpc.RagServiceServicer):
    """
    Implementacion del servicio gRPC. Traduce entre los mensajes
    protobuf y las llamadas a los servicios de negocio, y convierte
    las excepciones de negocio en errores gRPC con el codigo de
    estado apropiado.
    """

    def __init__(
        self,
        retrieve_service: RetrieveService,
        ingest_service: IngestService,
        delete_service: DeleteService,
    ) -> None:
        self._retrieve_service = retrieve_service
        self._ingest_service = ingest_service
        self._delete_service = delete_service

    def Retrieve(self, request: rag_pb2.RetrieveRequest, context: grpc.ServicerContext) -> rag_pb2.RetrieveResponse:
        try:
            return self._retrieve_service.retrieve(request)
        except ValueError as error:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, str(error))
        except Exception:
            logger.exception("Error inesperado en Retrieve")
            context.abort(grpc.StatusCode.INTERNAL, "Error interno procesando Retrieve")

    def Ingest(self, request: rag_pb2.IngestRequest, context: grpc.ServicerContext) -> rag_pb2.IngestResponse:
        try:
            return self._ingest_service.ingest(request)
        except ValueError as error:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, str(error))
        except Exception:
            logger.exception("Error inesperado en Ingest")
            context.abort(grpc.StatusCode.INTERNAL, "Error interno procesando Ingest")

    def Delete(self, request: rag_pb2.DeleteRequest, context: grpc.ServicerContext) -> rag_pb2.DeleteResponse:
        try:
            return self._delete_service.delete(request)
        except FiltroVacioError as error:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, str(error))
        except ValueError as error:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, str(error))
        except Exception:
            logger.exception("Error inesperado en Delete")
            context.abort(grpc.StatusCode.INTERNAL, "Error interno procesando Delete")


def _configurar_logging() -> None:
    logging.basicConfig(
        level=settings.servidor.nivel_log,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


def _construir_servidor() -> tuple[grpc.Server, QdrantWrapper, VllmClient, OllamaClient]:
    qdrant = QdrantWrapper()
    vllm_client = VllmClient()
    ollama_client = OllamaClient()

    logger.info("Verificando/creando colecciones de Qdrant...")
    try:
        qdrant.asegurar_colecciones()
    except DimensionInconsistenteError:
        logger.exception(
            "Desajuste de dimension entre configuracion y coleccion existente. "
            "El proceso no puede arrancar de forma segura -- revisa las variables "
            "QDRANT_DIM_COLECCION_RAPIDA / QDRANT_DIM_COLECCION_PRECISA."
        )
        sys.exit(1)
    logger.info("Colecciones listas.")

    retrieve_service = RetrieveService(qdrant, vllm_client, ollama_client)
    ingest_service = IngestService(qdrant, vllm_client, ollama_client)
    delete_service = DeleteService(qdrant)

    servicer = RagServiceServicer(retrieve_service, ingest_service, delete_service)

    servidor = grpc.server(futures.ThreadPoolExecutor(max_workers=settings.servidor.max_workers))
    rag_pb2_grpc.add_RagServiceServicer_to_server(servicer, servidor)
    servidor.add_insecure_port(f"[::]:{settings.servidor.puerto}")

    return servidor, qdrant, vllm_client, ollama_client


def main() -> None:
    _configurar_logging()

    servidor, qdrant, vllm_client, ollama_client = _construir_servidor()

    def _apagar(signum, frame) -> None:
        logger.info("Senal de apagado recibida (%s), cerrando ordenadamente...", signum)
        servidor.stop(grace=10)
        vllm_client.cerrar()
        ollama_client.cerrar()
        logger.info("Apagado completo.")

    signal.signal(signal.SIGTERM, _apagar)
    signal.signal(signal.SIGINT, _apagar)

    servidor.start()
    logger.info("rag-api escuchando en el puerto %d", settings.servidor.puerto)
    servidor.wait_for_termination()


if __name__ == "__main__":
    main()
