#!/usr/bin/env python3
import torch
import torchaudio
import argparse
import time
import os
import json
from pathlib import Path
import sys
import subprocess

# Configurar paths
project_root = Path(__file__).parent.parent

def load_embedding_metadata(voice_name, config_path):
    """Load metadata for voice embedding if exists"""
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        metadata_path = os.path.join(config["embeddings_dir"], f"{voice_name}_metadata.json")
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                full_text = metadata.get("prompt_text", None)
                # Ya NO cortamos el texto - devolvemos tal cual
                if full_text:
                    print(f"Texto de referencia completo cargado")
                    return full_text
    except Exception as e:
        print(f"No se pudo cargar metadata: {e}")
    return None

def synthesize_speech(text, voice_embedding_path, output_path, config_path, prompt_text=None, zero_shot=False):
    """Synthesize speech using voice embedding with Fish Speech"""
    start_time = time.time()
    
    # Cargar configuración
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    print(f"Sintetizando texto: {text}")
    
    try:
        # Cambiar al directorio de Fish Speech
        fish_speech_dir = str(project_root / "fish-speech")
        os.chdir(fish_speech_dir)
        
        # Asegurarse de que el directorio temp existe
        os.makedirs("temp", exist_ok=True)
        
        # Paso 1: Texto a tokens semánticos
        text_processing_start = time.time()
        
        cmd = [
            sys.executable,
            "-m", "fish_speech.models.text2semantic.inference",
            "--text", text,
            "--checkpoint-path", config["model_path"],
            "--num-samples", "1"
        ]
        
        # Si no es zero-shot, usar el embedding como referencia
        if not zero_shot and os.path.exists(voice_embedding_path):
            if not prompt_text:
                # Si no hay prompt text pero se quiere usar el embedding,
                # Fish Speech necesita el texto del audio de referencia
                print("Error: Se necesita --prompt-text cuando se usa un embedding de voz")
                print("Opción 1: Usa --zero-shot para síntesis sin referencia")
                print("Opción 2: Proporciona --prompt-text con el texto del audio de referencia")
                return False, {}
            
            print(f"Modo Few-shot: usando embedding de voz -> {voice_embedding_path}")
            print(f"                texto de referencia -> '{prompt_text}'")
            cmd.extend(["--prompt-tokens", voice_embedding_path])
            cmd.extend(["--prompt-text", prompt_text])
        else:
            print("Modo Zero-shot: síntesis sin referencia de voz")
        
        subprocess.run(cmd, check=True)
        text_processing_time = time.time() - text_processing_start
        
        # Paso 2: Tokens a audio
        audio_generation_start = time.time()
        
        # El archivo se guarda en temp/codes_0.npy
        codes_path = "temp/codes_0.npy"
        if not os.path.exists(codes_path):
            print(f"Error: Archivo de tokens no encontrado en {codes_path}")
            return False, {}
        
        cmd = [
            sys.executable,
            "-m", "fish_speech.models.vqgan.inference",
            "-i", codes_path,
            "--checkpoint-path", os.path.join(config["model_path"], "firefly-gan-vq-fsq-8x1024-21hz-generator.pth")
        ]
        
        subprocess.run(cmd, check=True)
        audio_generation_time = time.time() - audio_generation_start
        
        # Mover archivo de salida
        output_audio = "fake.wav"
        if os.path.exists(output_audio):
            os.rename(output_audio, str(project_root / "scripts" / output_path))
            
            # Cambiar de vuelta al directorio scripts
            os.chdir(str(project_root / "scripts"))
            
            # Obtener duración del audio
            waveform, _ = torchaudio.load(output_path)
            audio_duration = waveform.shape[1] / config["sample_rate"]
            
            synthesis_time = time.time() - start_time
            
            metrics = {
                "synthesis_time": synthesis_time,
                "text_length": len(text),
                "audio_duration": audio_duration,
                "real_time_factor": audio_duration / synthesis_time if synthesis_time > 0 else 0,
                "text_processing_time": text_processing_time,
                "audio_generation_time": audio_generation_time,
                "mode": "zero-shot" if zero_shot else "few-shot"
            }
            
            return True, metrics
        else:
            # El archivo podría estar en diferentes ubicaciones, vamos a buscar
            possible_paths = ["fake.wav", "temp/fake.wav", "outputs/fake.wav"]
            for path in possible_paths:
                if os.path.exists(path):
                    os.rename(path, str(project_root / "scripts" / output_path))
                    # Continuar con las métricas...
                    break
            else:
                print(f"Error: No se encontró el archivo de audio generado")
                return False, {}
            
    except Exception as e:
        print(f"Error en síntesis: {e}")
        # Volver al directorio scripts en caso de error
        os.chdir(str(project_root / "scripts"))
        return False, {}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Synthesize speech with Fish Speech")
    parser.add_argument("--text", required=True, help="Text to synthesize")
    parser.add_argument("--voice", help="Voice embedding name (for few-shot)")
    parser.add_argument("--output", required=True, help="Output audio file path")
    parser.add_argument("--config", default="../config/config.json", help="Config file path")
    parser.add_argument("--prompt-text", help="Text prompt corresponding to the voice embedding")
    parser.add_argument("--zero-shot", action="store_true", help="Use zero-shot synthesis without voice reference")
    parser.add_argument("--auto-metadata", action="store_true", help="Try to load metadata automatically")
    
    args = parser.parse_args()
    
    # Determinar el modo de operación
    if args.zero_shot:
        embedding_path = None
        prompt_text = None
    else:
        if not args.voice:
            print("Error: --voice es requerido para mode few-shot")
            print("Usa --zero-shot para síntesis sin referencia de voz")
            exit(1)
        
        embedding_path = f"../embeddings/{args.voice}.npy"
        
        # Decidir qué texto de referencia usar
        prompt_text = args.prompt_text
        
        # Si está habilitado auto-metadata, intentar cargar desde archivo
        if args.auto_metadata and not prompt_text:
            prompt_text = load_embedding_metadata(args.voice, args.config)
            if prompt_text:
                print(f"Texto de referencia cargado desde metadata")
    
    success, metrics = synthesize_speech(args.text, embedding_path, args.output, args.config, prompt_text, args.zero_shot)
    
    if success:
        print(f"Speech synthesized successfully: {args.output}")
        print(f"Metrics: {json.dumps(metrics, indent=2)}")
    else:
        print("Failed to synthesize speech")
